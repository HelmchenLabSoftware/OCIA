function this = OCIA_dataConfig_wf(this)
% OCIA_dataConfig_widefield - [no description]
%
%       OCIA_dataConfig_widefield(this)
%
% Adds the widefield data structures to the OCIA.
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

%% imaging data type

% defines the data storage options
this.main.dataConfig = [this.main.dataConfig; cell2table({ ...
...     rowType             id      shortLabel      label               saveFormat  defaultOn
        'Widefield data',   'wf',   'Widefield',    'Widefield images', 'HDF5',     false;
}, 'VariableNames', this.main.dataConfig.Properties.VariableNames)];

% define the analysis parameters for this data type
this.an.wf = struct();


end
