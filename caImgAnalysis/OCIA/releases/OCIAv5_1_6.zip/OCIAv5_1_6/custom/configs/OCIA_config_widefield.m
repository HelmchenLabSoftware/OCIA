function this = OCIA_config_widefield(this)
% OCIA_config_widefield - "widefield" OCIA configuration file
%
%       this = OCIA('widefield')
%
% Configuration file for OCIA using the "widefield" configuration. This function should not be called directly
%   but rather using the "this = OCIA('widefield');" syntax to launch the software with this configuration.
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

% get the default configuration
configHandle = str2func('OCIA_config_default');
this = configHandle(this);

%% - input parameters
this.GUI.noGUI = false;
this.GUI.dw.DWFilt = { 'mou_bl_150217_05', '2015_06_09' };
this.GUI.dw.DWWatchTypes = 'all';
this.GUI.dw.DWSkiptMeta = false;
this.GUI.dw.DWKeepTable = false;
this.GUI.dw.DWRawOrLocal = 'local';
%% - properties: general
this.verb = 2;
% path of the raw data (usually stored on the server)
this.path.rawData = 'W:/Scratch-02 no Backup/RawDataBalazs/2015/1502_chronic/';
% path of the local data
this.path.localData = 'F:/RawData/1502_chronic/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'F:/RawData/1502_chronic/';

% name of the function that do post-processing after the notebook file parsing
this.dw.annotateTableFunctionName = 'none';
% name of the function that parses the notebook file
this.dw.notebookParsingFunctionName = 'none';


%% - properties: GUI
% this.GUI.pos = [694, 343, 1220, 805];
this.GUI.pos = [10, 425, 1880, 740];
% this.GUI.pos = [1, 1, 1920, 1058];

end