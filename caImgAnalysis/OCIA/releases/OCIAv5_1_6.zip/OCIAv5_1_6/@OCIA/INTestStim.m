%% #INTestStim
function INTestStim(this, ~, ~)

% disable button
set(this.GUI.handles.in.testStimBut, 'Value', 1, 'Enable', 'off', 'BackgroundColor', 'yellow');

try
    % extract the parameters structure
    params = this.in.standard;
    comParams = this.in.common;

    % get the correct sampling frequency
    sampFreq = iff(comParams.useTDT, this.in.TDTSampFreq, this.in.standardSampFreq);

    % build the cloud of tones
    uniqueFreqs = params.stdBaseFreq * (2 .^ ((0 : params.stdNFreqs - 1) * (2 ^ params.stdPowOf2)));
    warning('off', 'MakeCloudOfTonesSound:NumberOfTonesMismatch');
    COT = MakeCloudOfTonesSound(uniqueFreqs, params.stdCloudCenter, params.stdCloudDispersion, 1, params.stdToneDur, ...
        params.stdToneISI, params.stdStimDur, 0, sampFreq, 0, 0);
    soundToPlay = COT{1};

    % play by triggering the TDT
    if comParams.useTDT;
    
        amplifFactor = 20;
        soundToPlay = soundToPlay * amplifFactor;
        
        % load stimulus
        this.in.RP = playTDTSound(soundToPlay, 0, this.GUI.figH);

        % launch stimulus
        this.in.RP.SoftTrg(1);

        pause(numel(soundToPlay) / sampFreq);
        
    % play through sound card
    else
        
        sound(soundToPlay, sampFreq);
        
    end;
    
catch err;
    showWarning(this, 'OCIA:INTestStim:TestFailed', sprintf('Error during testing of stimulation ("%s"): %s.', ...
        err.identifier, err.message));
end;

% stop and clean up
if comParams.useTDT && ~isempty(this.in.RP);
    try
        this.in.RP.Halt();
        delete(this.in.RP);
        this.in.RP = [];
    catch err;
        showWarning(this, 'OCIA:INTestStim:CleanupFailed', sprintf('Error during cleaning up of TDT ("%s"): %s.', ...
            err.identifier, err.message));
    end;
end;

% show message
set(this.GUI.handles.in.testStimBut, 'Value', 0, 'Enable', 'on', 'BackgroundColor', ones(3, 1) * 0.941);

end
