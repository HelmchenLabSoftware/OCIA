function INPreview(this, ~, ~)
% INPreview - [no description]
%
%       INPreview(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

% check for hardware connection state
if ~this.in.connected;
    showWarning(this, 'OCIA:INPreview:HardwareNotConnected', 'Intrinsic: hardware is not connected');
    set(this.GUI.handles.in.prevBut, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;

% already in preview mode => stop it
if this.in.previewRunning;
    
    showMessage(this, 'Intrinsic: stopping preview ...', 'yellow');
    set(this.GUI.handles.in.prevBut, 'BackgroundColor', 'yellow', 'Value', 1);
    pause(0.01);
    
    stop(this.in.camH);
    flushdata(this.in.camH);
    this.in.previewRunning = false;
    
    showMessage(this, 'Intrinsic: preview stopped.');
    set(this.GUI.handles.in.prevBut, 'BackgroundColor', 'red', 'Value', 0);

% not in preview mode yet => start it
else
    
    showMessage(this, 'Intrinsic: starting preview ...', 'yellow');
    set(this.GUI.handles.in.prevBut, 'BackgroundColor', 'yellow', 'Value', 1);
    pause(0.01);
    
    stop(this.in.camH);
    flushdata(this.in.camH);
    triggerconfig(this.in.camH, 'immediate');
    set(this.in.camH, 'TimerPeriod', 1 / this.GUI.in.prevFrameRate, 'TimerFcn', ...
        @(h, e)INDisplayImage(this, this.GUI.handles.in.prevImg, this.GUI.in.prevShowSaturation, this.GUI.in.prevUseGrayscale), ...
        'FramesPerTrigger', Inf);
    start(this.in.camH);
    
    stop(this.in.camH);
    start(this.in.camH);
    this.in.previewRunning = true;
    
    set(this.GUI.handles.in.prevBut, 'BackgroundColor', 'green', 'Value', 0);
    showMessage(this, 'Intrinsic: preview started.');

end;

end
