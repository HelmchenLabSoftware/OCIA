function INUpdateParams(this, ~, ~)
% INUpdateParams - [no description]
%
%       INUpdateParams(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

OCIAUpdateVariablesFromParamPanel(this, 'in');

showMessage(this, 'Intrinsic: parameters updated.');

INUpdateGUI(this);

end
