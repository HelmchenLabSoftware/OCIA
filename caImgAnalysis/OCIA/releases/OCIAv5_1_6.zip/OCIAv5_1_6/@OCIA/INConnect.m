function INConnect(this, ~, ~)
% INConnect - [no description]
%
%       INConnect(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

% check the connection state
if ~this.in.connected;
    
    %% connect camera
    % show message
    showMessage(this, 'Intrinsic: connecting camera ...', 'yellow');
    set(this.GUI.handles.in.connect, 'BackgroundColor', 'yellow', 'Value', 1);
    pause(0.01);

    % connect camera in a try-catch to avoid errors in case things go wrong
    try        
        imaqreset();
        this.in.camH = videoinput(this.in.adaptorName, this.in.deviceID);  
        
    % abort on error
    catch err;        
        showWarning(this, 'OCIA:INConnect:CameraConnectionFailed', sprintf('Problem while connecting the camera (%s): %s.', ...
            err.identifier, err.message));
        set(this.GUI.handles.in.connect, 'BackgroundColor', 'red', 'Value', 0);
        return;
        
    end;
    
    % proper connection: show message
    showMessage(this, 'Intrinsic: camera connected.');
    
    % if everything succeeded, change connection status
    set(this.GUI.handles.in.connect, 'BackgroundColor', 'green', 'Value', 0);
    this.in.connected = true;

% if we are already connected
else

    showMessage(this, 'Intrinsic: disconnecting camera ...', 'yellow');
    set(this.GUI.handles.in.connect, 'BackgroundColor', 'yellow', 'Value', 1);
    pause(0.01);
    
    % kill everything
    delete(this.in.camH);
    this.in.camH = [];
    imaqreset();
    
    delete(this.in.RP);
    this.in.RP = [];
    
    % show message and change connection status    
    this.in.connected = false;
    set(this.GUI.handles.in.connect, 'BackgroundColor', 'red', 'Value', 0);
    showMessage(this, 'Intrinsic: camera disconnected.');

end;

end
