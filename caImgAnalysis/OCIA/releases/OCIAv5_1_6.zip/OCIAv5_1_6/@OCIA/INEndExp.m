function INEndExp(this, ~, ~)
% INEndExp - [no description]
%
%       INEndExp(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

this.in.expRunning = false;
showMessage(this, 'Intrinsic: aborted experiment.', 'yellow');
set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'red', 'Value', 0);

% stop TDT
if this.in.common.useTDT && ~isempty(this.in.RP);
    this.in.RP.Halt();
    delete(this.in.RP);
    this.in.RP = [];
end;

end
