function INRunExp_fourier(this)
% INRunExp_fourier - [no description]
%
%       INRunExp_fourier(this)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

o('#%s ...', mfilename, 0, this.verb);

%% init
% extract the parameters structure
params = this.in.fourier;
comParams = this.in.common;

% stores the frames for the whole stimulation procedure
this.in.data.stimulusFrames = [];

uniqueFreqs = params.fouBaseFreq * (2 .^ ((0 : params.fouNFreqs - 1) * (2 ^ params.fouPowOf2)));
% uniqueFreqs = fliplr(uniqueFreqs);
nStimsPerSweep = numel(uniqueFreqs);
nSweeps = params.nSweeps;
params.stimDurDiffTolerance = 0.001;
stimISIDur = (params.sweepDur / nStimsPerSweep) - params.fouStimDur;
this.in.fourier.stimFreqSingle = 1 / (stimISIDur + params.fouStimDur);
this.in.fourier.stimFreqAll = 1 / ((stimISIDur + params.fouStimDur) * nStimsPerSweep);
if stimISIDur <= params.fouStimDur;
    showWarning(this, 'OCIA:INRunExp_fourier:stimISITooShort', sprintf(['Intrinsic: with %d stimFreqs, a stimSweepDur ', ...
        'of %.3f sec and a stimToneDur of %.3f sec, stimISI is %.3f sec !'], nStimsPerSweep, params.sweepDur, params.fouStimDur, stimISIDur));
    INEndExp(this);
    return;
end;

showMessage(this, sprintf('Intrinsic: stimulation for a single frequency: %.3f.', this.in.fourier.stimFreqSingle), 'yellow');
showMessage(this, sprintf('Intrinsic: stimulation for any frequency: %.3f.', this.in.fourier.stimFreqAll), 'yellow');

% get the correct sampling frequency
sampFreq = iff(comParams.useTDT, this.in.TDTSampFreq, this.in.standardSampFreq);

%% build sound stimulation
stimsCell = makePureTone(uniqueFreqs, params.fouStimDur, sampFreq); % get the pure tones as cell array
stimISI = zeros(1, round(stimISIDur * sampFreq)); % get the inter-stimulus interval
stimsMat = cell2mat(stimsCell); % get the tones cell as matrix
stimsMatWithStimISI = [stimsMat repmat(stimISI, nStimsPerSweep, 1)]; % append the inter-stimulus intervals to each tone
stim = reshape(stimsMatWithStimISI', 1, numel(stimsMatWithStimISI)); % linearize everything as one sound (a stimISI is still at the end)
amplifFactor = 20;
stim = stim * amplifFactor;

% check for sound duration consistency
stimDurCalc = numel(stim) / sampFreq;
if abs(params.sweepDur - stimDurCalc) > params.stimDurDiffTolerance;
    showWarning(this, 'OCIA:INRunExp_fourier:soundDurMismatch', sprintf(['Sound duration should be: stimRangeDur = %.6f sec but is %.6f sec ', ...
        '(%d samples at %.3f Hz, tolerance: %.6f sec) !'], params.sweepDur, stimDurCalc, numel(stim), sampFreq, params.stimDurDiffTolerance));
    INEndExp(this);
    return;
end;

% generate the stimulus vector with the repetitions
totStimDur = (numel(stim) * nSweeps) / sampFreq; % get the total duration
showMessage(this, sprintf('Intrinsic: stimulus initialized: %.2f sec total duration (%.2f sec * %02d sweeps).', ...
    totStimDur, stimDurCalc, nSweeps), 'yellow');

%% TDT setup    
% if TDT usage is requested, connect it
if comParams.useTDT;
    showMessage(this, 'Intrinsic: loading sound to TDT ...', 'yellow');
    this.in.RP = playTDTSound(stim, 0, this.GUI.figH);
    if ~this.in.expRunning; INEndExp(this); return; end;
end;
if ~this.in.expRunning; INEndExp(this); return; end;

%% camera setup
% flush the previous data
stop(this.in.camH);
flushdata(this.in.camH);
% switch to non-stop collection mode
set(this.in.camH, 'FramesPerTrigger', Inf, 'TimerFcn', []);
% increase memory
imaqmem(10E10);
% calculate number of frames
nPowOf10Round = 2;
nFrames = roundn(totStimDur * params.camFPS + (10 ^ nPowOf10Round) * 0.5, nPowOf10Round);
set(this.in.camH, 'FramesPerTrigger', nFrames);
triggerconfig(this.in.camH, 'manual');
start(this.in.camH);
showMessage(this, sprintf('Intrinsic: camera initialized: %.3f sec recording, %d frames.', totStimDur, nFrames), 'yellow');

%% starting delay
showMessage(this, sprintf('Intrinsic: starting delay (%.1f sec) ...', comParams.startDelay), 'yellow');
pause(comParams.startDelay);
if ~this.in.expRunning; INEndExp(this); return; end;

%% record
recordTic = tic; % for performance timing purposes
startTime = nowUNIXSec();
trigger(this.in.camH); % launch imaging
showMessage(this, sprintf('Intrinsic: started imaging (T = %.3f sec).', toc(recordTic)), 'yellow');

if comParams.useTDT;
    this.in.RP.SoftTrg(1); % launch stimulus
end;
stimStartTime = nowUNIXSec();
showMessage(this, sprintf('Intrinsic: started stimulus (T = %.3f sec).', toc(recordTic)), 'yellow');

% wait until stimulation finished
lastPercent = -1;
iSweep = 1;
while (nowUNIXSec() - startTime) < totStimDur;
    pause(0.001); % avoid full-speed looping
    
    if comParams.useTDT && (nowUNIXSec() - stimStartTime) >= stimDurCalc;
%         loadTic = tic;
        this.in.RP.SoftTrg(2); % reset stimulus
        this.in.RP.SoftTrg(1); % launch stimulus
        stimStartTime = nowUNIXSec();
        iSweep = iSweep + 1;
%         showMessage(this, sprintf('Intrinsic: launched sweep %02d/%02d (%.3f sec) ...', iSweep, nSweeps, toc(loadTic)), 'yellow');
        if ~this.in.expRunning; INEndExp(this); return; end;
    end;
    
    percentDone = floor(10 * (nowUNIXSec - startTime) / totStimDur) * 10;
    if percentDone ~= lastPercent;
        lastPercent = percentDone;
        nFramesRec = get(this.in.camH, 'FramesAvailable');
        showMessage(this, sprintf('Intrinsic: stimulation progress: %02d%% (%03d frames recorded).', percentDone, nFramesRec), 'yellow');
    end;
end;
nFramesRec = get(this.in.camH, 'FramesAvailable');
recTime = toc(recordTic);
this.in.fourier.realCamFPS = nFramesRec / recTime;
showMessage(this, sprintf('Intrinsic: recording done (%d frames, %.3f sec, %.3f fps).', nFramesRec, recTime, this.in.fourier.realCamFPS));
if ~this.in.expRunning; INEndExp(this); return; end;

% wait for camera to finish
showMessage(this, 'Intrinsic: waiting for camera ...', 'yellow'); pause(0.05);
wait(this.in.camH);
stop(this.in.camH);
if ~this.in.expRunning; INEndExp(this); return; end;

%% stop and extract data
% stop TDT
if comParams.useTDT;
    this.in.RP.Halt();
    delete(this.in.RP);
    this.in.RP = [];
end;

% get and process the frames
extrTic = tic;
showMessage(this, 'Intrinsic: extracting data ...', 'yellow'); pause(0.05);
this.in.data.stimulusFrames = getdata(this.in.camH);
this.in.data.stimulusFrames = this.in.data.stimulusFrames(:, :, :, 1 : nFramesRec); % remove late frames
this.in.data.stimulusFrames = squeeze(INProcessFrames(this, this.in.data.stimulusFrames));
showMessage(this, sprintf('Intrinsic: extracting data done (%.1f sec).', toc(extrTic)), 'yellow'); pause(0.05);

% finalize
this.in.expRunning = false;
this.in.common.expNumber = this.in.common.expNumber + 1;

% update in GUI
set(this.GUI.handles.in.paramPanElems.expNumber, 'String', sprintf('%d', this.in.common.expNumber));

set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'red', 'Value', 0);
showMessage(this, sprintf('Intrinsic: experiment number %02d done !', this.in.common.expNumber));

% INAnalyseFourierFrames(this);

end
