function INRunExp_standard(this)
% INRunExp_standard - [no description]
%
%       INRunExp_standard(this)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

o('#%s ...', mfilename, 0, this.verb);

%% init
% extract the parameters structure
params = this.in.standard;
comParams = this.in.common;

% flush the previous data
stop(this.in.camH);
flushdata(this.in.camH);
% switch to non-stop collection mode
triggerconfig(this.in.camH, 'immediate');
set(this.in.camH, 'FramesPerTrigger', Inf, 'TimerFcn', []);

% stores the baseline 1 frames for each run
this.in.data.baseline1Frames = cell(params.nRuns, 1);
% stores the baseline 2 frames for each run
this.in.data.baseline2Frames = cell(params.nRuns, 1);
% stores the stimulus frames for each run
this.in.data.stimulusFrames = cell(params.nRuns, 1);

% stores the DRR average frame for each run
this.in.data.baselineDRRAvg = cell(params.nRuns, 1);
this.in.data.stimulusDRRAvg = cell(params.nRuns, 1);

% set the include states
this.in.data.includeInAverage = ones(params.nRuns, 1);

% get the correct sampling frequency
sampFreq = iff(comParams.useTDT, this.in.TDTSampFreq, this.in.standardSampFreq);

% build the cloud of tones
uniqueFreqs = params.stdBaseFreq * (2 .^ ((0 : params.stdNFreqs - 1) * (2 ^ params.stdPowOf2)));
warning('off', 'MakeCloudOfTonesSound:NumberOfTonesMismatch');
COT = MakeCloudOfTonesSound(uniqueFreqs, params.stdCloudCenter, params.stdCloudDispersion, 1, params.stdToneDur, ...
    params.stdToneISI, params.stdStimDur, 0, sampFreq, 0, 0);
soundToPlay = COT{1};
amplifFactor = 20;
soundToPlay = soundToPlay * amplifFactor;

%% starting delay
showMessage(this, sprintf('Intrinsic: starting delay (%.1f sec) ...', comParams.startDelay), 'yellow');
pause(comParams.startDelay);
if ~this.in.expRunning; INEndExp(this); return; end;

%% run loop
% loop over all runs
for iRun = 1 : params.nRuns;
    
    % if TDT usage is requested, connect it
    if comParams.useTDT;
        this.in.RP = playTDTSound(soundToPlay, 0, this.GUI.figH);
    end;

    % create the title string
    titleString = sprintf('Intrinsic: Run %02d/%02d:', iRun, params.nRuns);

    % collect the baseline frames
    showMessage(this, sprintf('%s baseline 1 frames collection ...', titleString), 'yellow');
    this.in.data.baseline1Frames{iRun} = collectData(this, params.baselineAvgDur);
    if ~this.in.expRunning; INEndExp(this); return; end;

    % wait until stimulus time
    showMessage(this, sprintf('%s waiting for second baseline ...', titleString), 'yellow');
    pause(params.baselineToStimDelay);
    if ~this.in.expRunning; INEndExp(this); return; end;

    % collect the baseline frames
    showMessage(this, sprintf('%s baseline 2 frames collection ...', titleString), 'yellow');
    this.in.data.baseline2Frames{iRun} = collectData(this, params.baselineAvgDur);
    % calculate DRR of baseline data
    this.in.data.baselineDRRAvg{iRun} = getDRRAvg(this.in.data.baseline1Frames{iRun}, this.in.data.baseline2Frames{iRun});
    % display data
    INUpdateGUI(this);
    if ~this.in.expRunning; INEndExp(this); return; end;

    % wait until stimulus time
    showMessage(this, sprintf('%s waiting for stimulus time ...', titleString), 'yellow');
    pause(params.baselineToStimDelay);
    if ~this.in.expRunning; INEndExp(this); return; end;

    % stimulus
    showMessage(this, sprintf('%s stimulus ...', titleString), 'yellow');
    % play sound using TDT
    if comParams.useTDT;
        this.in.RP.SoftTrg(1);
        pause(params.stdStimDur);
        
    % play sound without TDT
    else
        player = audioplayer(soundToPlay, sampFreq); %#ok<TNMLP>
        player.playblocking();
        
    end;
    if ~this.in.expRunning; INEndExp(this); return; end;

    % wait until stimulus data collection time
    showMessage(this, sprintf('%s waiting for stimulus collection time ...', titleString), 'yellow');
    pause(params.stimToStimAvgDelay);
    if ~this.in.expRunning; INEndExp(this); return; end;

    % collect the stimulus frames
    showMessage(this, sprintf('%s stimulus frames collection ...', titleString), 'yellow');
    this.in.data.stimulusFrames{iRun} = collectData(this, params.stimAvgDur);
    % calculate DRR of stimulus data
    this.in.data.stimulusDRRAvg{iRun} = getDRRAvg(this.in.data.baseline1Frames{iRun}, this.in.data.stimulusFrames{iRun});
    % display data
    INUpdateGUI(this);
    if ~this.in.expRunning; INEndExp(this); return; end;
    
    % wait the end period (recovery), unless it is the last run
    if iRun ~= params.nRuns;
        showMessage(this, sprintf('%s waiting for recovery period ...', titleString), 'yellow');
        pause(params.waitPeriod);
    end;
    if ~this.in.expRunning; INEndExp(this); return; end;

end;

if comParams.useTDT;
    this.in.RP.Halt();
    delete(this.in.RP);
    this.in.RP = [];
end;

this.in.expRunning = false;
this.in.common.expNumber = this.in.common.expNumber + 1;
set(this.GUI.handles.in.paramPanElems.expNumber, 'String', sprintf('%d', this.in.common.expNumber)); % update in GUI
set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'red', 'Value', 0);
showMessage(this, sprintf('Intrinsic: experiment number %02d done !', this.in.common.expNumber));

end

function frames = collectData(this, collectTime)

% get the starting time
startTime = nowUNIXSec;

% start collecting
start(this.in.camH);

% start waiting loop
while (nowUNIXSec - startTime) < collectTime;
    pause(0.01); % avoid full-speed looping
end;

% stop and collect frames
stop(this.in.camH);
frames = getdata(this.in.camH);

% process the frames
frames = INProcessFrames(this, frames);

% flush data
flushdata(this.in.camH);

end

function DRRAvg = getDRRAvg(frames1, frames2)

    frames1 = nanmean(squeeze(frames1), 3);
    frames2 = nanmean(squeeze(frames2), 3);
    DRRAvg = (frames2 - frames1) ./ frames1;

end
