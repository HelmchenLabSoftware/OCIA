% ROIDepthCorrectionScript

tic;

RCaMPProjectRoot = 'W:\Neurophysiology\Projects\RUNNING\RCaMP\';
% RCaMPProjectRoot = 'W:\Projects\RUNNING\RCaMP\';
ROIDepthFilePath = [RCaMPProjectRoot 'ROI depth correction\ROI depth correction.xlsx'];
ROITableFilePath = [RCaMPProjectRoot 'Analysis\2015_09_03__Balazs\ROITable.mat'];

load(ROITableFilePath);

nTotNotFoundROIs = 0;
nTotMultiMatchROIs = 0;
nTotFoundROIs = 0;

for iAnim = 0 : 7;

    nNotFoundROIs = 0;
    nMultiMatchROIs = 0;
    nFoundROIs = 0;

    animID = sprintf('Mouse %d', iAnim);
    o('Processing "%s" ...', animID, 0, 0);
    try
        [~, ~, raw] = xlsread(ROIDepthFilePath, animID, '', 'basic');
    catch err;
        if strcmp(err.identifier, 'MATLAB:xlsread:WorksheetNotFound');
            o('"%s" not found in excel file, skipping...', animID, 0, 0);
            continue;
        else
            rethrow(err);
        end;
    end;
    
    animalMask = strcmp(ROITable.animal, animID);
    for iRow = 2 : size(raw, 1);
        [dayID, spotNum, spotDepth, ROIID, ROIDepth] = raw{iRow, [1 2 4 3 9]};
        if any(isnan(dayID)) || any(isnan(spotNum)) || any(isnan(spotDepth)) || any(isnan(ROIID)) || any(isnan(ROIDepth));
            continue;
        end;
        spotName = sprintf('Spot%d_%d', spotNum, spotDepth);
        ROITableIndex = find(animalMask & strcmp(ROITable.day, dayID) ...
            & strcmp(ROITable.spot, spotName) & strcmp(ROITable.ROIID, ROIID));
        if isempty(ROITableIndex);
%             o(' - Warning: ROI not found in ROITable: ROI %s - %s - %s - %s', ROIID, dayID, spotName, animID, 0, 0);
            nNotFoundROIs = nNotFoundROIs + 1;
        elseif numel(ROITableIndex) > 1;
%             o(' - Warning: ROI with multiple matches: ROI %s - %s - %s - %s', ROIID, dayID, spotName, animID, 0, 0);
            nMultiMatchROIs = nMultiMatchROIs + 1;
        else
            ROITable{ROITableIndex, 'depth'} = ROIDepth; %#ok<SAGROW>
            nFoundROIs = nFoundROIs + 1;
        end;
    end;
    
    o('Processing "%s" done: %02d ROI(s) not found, %02d ROI(s) with multiple match, %02d ROI(s) found.', ...
        animID, nNotFoundROIs, nMultiMatchROIs, nFoundROIs, 0, 0);
    
    nTotNotFoundROIs = nTotNotFoundROIs + nNotFoundROIs;
    nTotMultiMatchROIs = nTotMultiMatchROIs + nMultiMatchROIs;
    nTotFoundROIs = nTotFoundROIs + nFoundROIs;
    
end;

o('Processing all mice done: %02d ROI(s) not found, %02d ROI(s) with multiple match, %02d ROI(s) found.', ...
    nTotNotFoundROIs, nTotMultiMatchROIs, nTotFoundROIs, 0, 0);
    
o('Checking ROITable ...', 0, 0);
nNotFoundROIs = 0;
nFoundROIs = 0;
nFoundROIsNPil = 0;
for iRow = 1 : size(ROITable, 1);
    ROIDepth = ROITable{iRow, 'depth'};
    ROIID = ROITable{iRow, 'ROIID'};
    if ROIDepth == 0 && strcmp(ROIID, 'NPil');
        ROITable{iRow, 'depth'} = str2double(regexprep(ROITable{iRow, 'spot'}, 'Spot\d_', '')); %#ok<SAGROW>
        nFoundROIs = nFoundROIs + 1;
        nFoundROIsNPil = nFoundROIsNPil + 1;
    elseif ROIDepth == 0;
        o(' - Warning: ROI not found in excel file: ROI %s - %s - %s - %s', ROIID, ROITable{iRow, 'day'}, ...
            ROITable{iRow, 'spot'}, ROITable{iRow, 'animal'}, 0, 0);
        nNotFoundROIs = nNotFoundROIs + 1;
    else
        ROITable{ROITableIndex, 'depth'} = ROIDepth; %#ok<SAGROW>
        nFoundROIs = nFoundROIs + 1;
    end;
end;
o('Checking table done: %02d ROI(s) not found, %02d ROI(s) found (%02d are NPil).', ...
    nNotFoundROIs, nFoundROIs, nFoundROIsNPil, 0, 0);

o('Saving new ROITable ...', 0, 0);
save(regexprep(ROITableFilePath, '.mat', '_depthCorrected.mat'), 'ROITable');

o('Done ! (%.3f sec)', toc, 0, 0);