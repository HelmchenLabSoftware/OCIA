function RP = playTDTSound(y, attenuation, fig)
% Runs a Tucker Davis circuit to play a sound.

if isempty(attenuation);
    attenuation = 0;
end;

% specify the path of the data-playing circuit
circuitPath = 'C:\TDT\Balazs_RPvdsEx_Circuits\PlayData.rcx';

% create the ActiveX control
if ~exist('fig', 'var') || isempty(fig);
    fig = gcf;
end;
RP = actxcontrol('RPco.x', [0 0 0 0], fig);
if RP.ConnectRZ6('GB', 1) == 0; error('TDT:Connect', 'Could not connect!'); end;

RP.Halt(); % stop any processing chains running
RP.ClearCOF(); % clear all the buffers and circuits

RP.LoadCOFsf(circuitPath, 4); % 4 corresponds to 100 kHz (97656.25 Hz)
% RP.LoadCOFsf(circuitPath, 5); % 5 corresponds to 200 kHz (195312.5 Hz)

% set tags
RP.SetTagVal('bufferSize', numel(y));
RP.SetTagVal('attenuation', attenuation);

RP.Run(); % start circuit

% set tags and load data
RP.SetTagVal('bufferSize', numel(y));
RP.WriteTagV('data', 0, y);

end