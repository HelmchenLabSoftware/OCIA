function whiskTraces = OCIA_analysis_getRawWhiskTracesMatrix(this, iDWRows, doDownSampling)

% get the imaging frame rate and number of frames
imgFrameRate = this.an.img.defaultFrameRate;    
% get the number of skipped frames from the imaging
skipFrameParams = this.an.skipFrame;

% get the whisker data
whiskDataStructCellArray = getData(this, iDWRows, 'whisk', 'data');
% make sure this is a cell-array
if ~isempty(whiskDataStructCellArray) && ~iscell(whiskDataStructCellArray);
    whiskDataStructCellArray = { whiskDataStructCellArray };
end;

% if no whisker data was found, abort;
% whikser data must be a non empty structure
if isempty(whiskDataStructCellArray) || ~isstruct(whiskDataStructCellArray{1}) ... 
...     % check that angle field is present and not empty
        || ~isfield(whiskDataStructCellArray{1}, 'angle') || isempty(whiskDataStructCellArray{1}.angle) ...
...     % check that frameRate field is present and not empty
        || ~isfield(whiskDataStructCellArray{1}, 'frameRate') || isempty(whiskDataStructCellArray{1}.frameRate);
    
    % return empty array and show a warning message
    whiskTraces = [];
    showWarning(this, 'OCIA:OCIA_analysis_getRawWhiskTracesMatrix:NoWhiskData', ...
        sprintf('Cannot find whisker data for row %s %03d. Aborting.', rowID, iDWRow));
    return; % abort processing of this row
    
end;

% get the size of the data set
nRows = size(whiskDataStructCellArray, 1);
% extract the angle vector and the frame rate
whiskDataCellArray = arrayfun(@(i)whiskDataStructCellArray{i}.angle, 1 : nRows, 'UniformOutput', false)'; 
whiskFrameRateCellArray = arrayfun(@(i)whiskDataStructCellArray{i}.frameRate, 1 : nRows, 'UniformOutput', false)';    
    
[WAEnvs, WAAmp, WASetP, WAExpWhisk, WAFovWhisk, WhiskVector] = OCIA_analysis_getWhiskVectors(whiskDataCellArray, whiskDataStructCellArray{1}.frameRate);
whiskDataCellArray = WAExpWhisk;

% do the down sampling depending on the specifying variable
if doDownSampling;
    % down sample the whisking data to the imaging frame rate
    ANShowHideMessage(this, 1, 'Down-sampling the whisker traces ...');
    % down sample the whisker traces one by one
    parfor iRow = 1 : nRows;        
        whiskDataCellArray{iRow} = interp1DS(whiskFrameRateCellArray{iRow}, imgFrameRate, whiskDataCellArray{iRow});
        % adjust for the imaging's frame skipping
        whiskDataCellArray{iRow} = whiskDataCellArray{iRow}(1 + skipFrameParams.nFramesBegin ...
            : end - skipFrameParams.nFramesEnd); %#ok<PFBNS>
    end;
end;

% adjust the number of frames by putting NaN paddings at the *begining* of the traces
maxNFramesWhiskTraces = max(arrayfun(@(i)size(whiskDataCellArray{i}, 2), 1 : nRows));    
whiskDataCellArray = arrayfun(@(i) ...
    [nan(1, maxNFramesWhiskTraces - size(whiskDataCellArray{i}, 2)), whiskDataCellArray{i}], ...
    1 : nRows, 'UniformOutput', false)';

% transform the whisker traces into a nRows x nFrames matrix
whiskTraces = cell2mat(whiskDataCellArray);

end