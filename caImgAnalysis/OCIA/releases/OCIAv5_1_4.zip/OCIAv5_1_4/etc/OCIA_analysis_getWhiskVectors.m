%% #OCIA:AN:OCIA_analysis_caTraces_whiskvectors
function [WAEnvs, WAAmp, WASetP, WAExpWhisk, WAFovWhisk, WhiskVector] = OCIA_analysis_getWhiskVectors(rawWhiskTraces, whiskFrameRate)

nRuns = numel(rawWhiskTraces);
nWhiskFrames = size(rawWhiskTraces{1}, 2);

% define frequency bands
Expwhisk_low_frequ = 7;   % Hz  frequ. band for exploratory whisking 
Expwhisk_up_frequ = 12;   % Hz
Fovwhisk_low_frequ = 15;   % Hz  frequ. band for foveal whisking
Fovwhisk_up_frequ = 25;   % Hz
ExpWhiskThresh = 0.01;       % threshold for construction of whiskvector
EnvWinSize = 0.3;            % window size in seconds for envelope and sliding mean/amp calculation

% loop through each run and calculate various whisking angle (WA) variables
WAEnvs = cell(rawWhiskTraces);
WAAmp = cell(rawWhiskTraces);
WASetP = cell(rawWhiskTraces);
WAExpWhisk = cell(rawWhiskTraces);    % exploratory whisking
WAFovWhisk = cell(rawWhiskTraces);    % foveal whisking
WhiskVector = cell(rawWhiskTraces);

for iRun = 1 : nRuns;    
    % calculate the envelope
    whiskAngle = rawWhiskTraces{iRun};
    winSize = round(EnvWinSize*whiskFrameRate);
    for iFrame = 1 : nWhiskFrames;    
        r = iFrame - winSize : iFrame + winSize;
        r(r < 1 | r > nWhiskFrames) = [];
        WAEnvs{iRun}(iFrame) = max(whiskAngle(r))-min(whiskAngle(r));    % Whisking envelope
        WAAmp{iRun}(iFrame)  = max(whiskAngle(r))-min(whiskAngle(r));    % Whisking amplitude
        WASetP{iRun}(iFrame) = mean(whiskAngle(r));                           % Whisker set point
     end;
    [out, bandpow1, bandpow2] = spectralDensityAnalysis(whiskAngle,128,127,128,whiskFrameRate, Expwhisk_low_frequ, Expwhisk_up_frequ, Fovwhisk_low_frequ, Fovwhisk_up_frequ);
    % ...(whiskAngle, windowsiz, overlap, nfft, ...)
    WAExpWhisk{iRun}=bandpow1;
    WAFovWhisk{iRun}=bandpow2;   
    % now calculate binary whisking vector from ExpWhisk %
    WhiskVector{iRun} = find(WAExpWhisk{iRun} > ExpWhiskThresh);
end;


