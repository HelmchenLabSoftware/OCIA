function OCIA_analysis_setIfExists(this, fieldName, stringOrValue, GUIVal, varargin)
    anh = this.GUI.handles.an;
    if isfield(anh.paramPanElems, fieldName);
        set(anh.paramPanElems.(fieldName), stringOrValue, GUIVal);
    elseif ~isempty(varargin) && ~isempty(varargin{1});
        this.an.img.(fieldName) = varargin{1};
    elseif isempty(varargin);
        this.an.img.(fieldName) = GUIVal;
    end;
end