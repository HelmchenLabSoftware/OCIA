function anh = OCIA_analysis_updatePlotAndSave(this, savePath, iMask, varargin)
    ANUpdatePlot(this, 'force');
    anh = this.GUI.handles.an;
    % only save if no further input argument or if input is positive
    if isempty(varargin) || varargin{1} > 0;
        if ~isempty(iMask);
%             savePath = [savePath iff(iMask == 1, '_noMask', '_withMask')];
            savePath = [savePath iff(iMask == 1, '', '_withMotionMask')];
        end;
        ANSavePlot(this, savePath);
        ANSavePlot(this, [savePath, '.png']);
    end;
end