%% #INGrabReferenceImage
function INGrabReferenceImage(this, ~, ~)

% check for hardware connection state
if ~this.in.connected;
    showWarning(this, 'OCIA:INGrabReferenceImage:HardwareNotConnected', 'Intrinsic: hardware is not connected');
    return;
end;

% if preview is running, stop it
isPreview = this.in.previewRunning;
if isPreview;
    INPreview(this);
end;

% show message
showMessage(this, 'Intrinsic: grabbing reference image ...', 'yellow');
set(this.GUI.handles.in.refBut, 'Value', 1);
pause(0.01);

% reset camera
stop(this.in.camH);
flushdata(this.in.camH);

% change camera settings
triggerconfig(this.in.camH, 'immediate');
set(this.in.camH, 'FramesPerTrigger', this.GUI.in.nFramesRef, 'TimerFcn', []);

% aquire frames
start(this.in.camH);
frames = INDisplayImage(this, this.GUI.handles.in.refImg, 0, 0);

% store frames
this.in.data.refImg = squeeze(nanmean(frames, 4));

% show message
set(this.GUI.handles.in.refBut, 'Value', 0);
showMessage(this, 'Intrinsic: reference image acquired.');

% if preview was running, res-start it
if isPreview;
    INPreview(this);
end;

end
