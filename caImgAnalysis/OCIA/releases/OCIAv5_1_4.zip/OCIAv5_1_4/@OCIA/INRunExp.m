%% #INRunExp
function INRunExp(this, ~, ~)

runExpTic = tic;
o('#%s ...', mfilename, 4, this.verb);

%% init
% check for hardware connection state
if ~this.in.connected;
    showWarning(this, 'OCIA:INRunExp:HardwareNotConnected', 'Intrinsic: hardware is not connected');
    set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;

% if preview is running, stop it
isPreview = this.in.previewRunning;
if isPreview;
    INPreview(this);
end;

% if already running an experiment abort it
if this.in.expRunning;
    this.in.expRunning = false;
    showMessage(this, 'Intrinsic: aborting experiment ...', 'yellow');
    return;
end;

% otherwise start running an experiment
this.in.expRunning = true;

showMessage(this, sprintf('Intrinsic: running experiment, mode: "%s" ...', this.in.expMode), 'yellow');
set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'yellow', 'Value', 1);
pause(0.01);

%% run requested experiment
try
    runExpFuncHandle = str2func(sprintf('INRunExp_%s', this.in.expMode));
    runExpFuncHandle(this);
catch err;
    showWarning(this, 'OCIA:INRunExp:RunError', sprintf('"Intrinsic: error while running experiment: %s (%s)\n%s.', ...
        err.message, err.identifier, getStackText(err)));
    INEndExp(this);
end;
o('#%s: running experiment done: %.1f sec', mfilename, toc(runExpTic), 3, this.verb);

end
