%% #INDisplayImage
function frames = INDisplayImage(this, targetImgHandle, showSaturation, useGrayScale, varargin)

updateGUITic = tic;
o('#%s: targetImgHandle: %d', mfilename, targetImgHandle, 3, this.verb);

% if no input frames, get them from the camera
if numel(varargin) == 0;    
    
    % check for hardware connection state
    if ~this.in.connected;
        frames = [];
        showWarning(this, 'OCIA:INUpdateGUI:HardwareNotConnected', 'Hardware is not connected');
        return;
    end;

    % get the frames
    frames = getdata(this.in.camH);

% use the frames provided as input
else    
    
    frames = varargin{1};
    
end;

% return if no frames available
if isempty(frames); return; end;

% process the frames
frames = INProcessFrames(this, frames);
[H, W, ~, ~] = size(frames);

% if no image handle, abort
if isempty(targetImgHandle); return; end;

% create the average image
avgImg = reshape(nanmean(frames, 4), [H, W]);

% convert to grayscale by setting all RGB channels to the same values
if useGrayScale;        
    avgImgRGB = repmat(avgImg, [1 1 3]);

    % mark saturated pixels
    if showSaturation;

        satDisplayTic = tic;
        o('#%s: maxValue: %.1f, minValue: %.1f, saturation bounds: %d, %d', mfilename, ...
            max(avgImg(:)), min(avgImg(:)), this.GUI.in.prevSaturationBounds, 4, this.verb);

        maxValue = max(avgImg(:));

        % over saturated pixels
        overSatPixelMask = avgImg >= this.GUI.in.prevSaturationBounds(2);
        overSatPixelMaskRGB = repmat(overSatPixelMask, [1 1 3]);
        overSatPixelMaskRedChan = overSatPixelMaskRGB;
        overSatPixelMaskRedChan(:, :, [2 3]) = 0;
        overSatPixelMaskGreenBlueChan = overSatPixelMaskRGB;
        overSatPixelMaskGreenBlueChan(:, :, 1) = 0;
        avgImgRGB(overSatPixelMaskRedChan) = maxValue;
        avgImgRGB(overSatPixelMaskGreenBlueChan) = 0;

        % under saturated pixels
        underSatPixelMask = avgImg <= this.GUI.in.prevSaturationBounds(1);
        underSatPixelMaskRGB = repmat(underSatPixelMask, [1 1 3]);
        underSatPixelMaskGreenChan = underSatPixelMaskRGB;
        underSatPixelMaskGreenChan(:, :, [1 3]) = 0;
        underSatPixelMaskRedBlueChan = underSatPixelMaskRGB;
        underSatPixelMaskRedBlueChan(:, :, 2) = 0;
        avgImgRGB(underSatPixelMaskGreenChan) = maxValue;
        avgImgRGB(underSatPixelMaskRedBlueChan) = 0;

        o('#%s: saturation display done: %.1f sec', mfilename, toc(satDisplayTic), 4, this.verb);

    end;
    
%     minVal = 100; maxVal = 795;
%     avgImgRGB(avgImgRGB < minVal) = minVal;
%     avgImgRGB(avgImgRGB > maxVal) = maxVal;
%     avgImgLinScaled = linScale([avgImgRGB(:)', minVal, maxVal]);
%     avgImgLinScaled = reshape(avgImgLinScaled(1 : end - 2), [H W 3]);
    
    avgImgLinScaled = linScale(avgImgRGB);

    if targetImgHandle == this.GUI.handles.in.prevImg;
        minVal = get(this.GUI.handles.in.imAdjMinPrev, 'Value');
        maxVal = get(this.GUI.handles.in.imAdjMaxPrev, 'Value');
        if minVal >= maxVal;
            minVal = maxVal - 0.01;
            if minVal < 0;
                minVal = 0.01;
                maxVal = 0.02;
            end;
            set(this.GUI.handles.in.imAdjMinPrev, 'Value', minVal);
            set(this.GUI.handles.in.imAdjMaxPrev, 'Value', maxVal);
        end;
        v = ones(1, size(avgImgLinScaled, 3));
        avgImgLinScaled = imadjust(avgImgLinScaled, [minVal * v; maxVal * v]);
    end;

% keep RGB
else        
    avgImgRGB = avgImg;
    avgImgLinScaled = avgImgRGB;    
end;

% set the image
set(targetImgHandle, 'CData', avgImgLinScaled);
set(get(targetImgHandle, 'Parent'), 'XLim', [0 W], 'YLim', [0 H]);

o('#%s: updating GUI done: %.1f sec', mfilename, toc(updateGUITic), 3, this.verb);

end
