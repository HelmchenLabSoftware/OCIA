%% #INEndExp
function INEndExp(this, ~, ~)

this.in.expRunning = false;
showMessage(this, 'Intrinsic: aborted experiment.', 'yellow');
set(this.GUI.handles.in.runExpBut, 'BackgroundColor', 'red', 'Value', 0);

% stop TDT
if this.in.common.useTDT && ~isempty(this.in.RP);
    this.in.RP.Halt();
    delete(this.in.RP);
    this.in.RP = [];
end;

end
