%% #INSetInclRun
function INSetInclRun(this, ~, ~)

% get the current run
iRun = round(get(this.GUI.handles.in.runChooser, 'Value'));
% set its include value
this.in.data.includeInAverage(iRun) = get(this.GUI.handles.in.inclRun, 'Value');

end
