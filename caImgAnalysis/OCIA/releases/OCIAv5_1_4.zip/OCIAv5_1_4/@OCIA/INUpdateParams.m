%% #INUpdateParams
function INUpdateParams(this, ~, ~)

OCIAUpdateVariablesFromParamPanel(this, 'in');

showMessage(this, 'Intrinsic: parameters updated.');

INUpdateGUI(this);

end
