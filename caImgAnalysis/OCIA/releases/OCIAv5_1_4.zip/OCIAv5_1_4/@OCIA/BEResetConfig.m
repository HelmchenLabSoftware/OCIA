%% #BEResetConfig
function BEResetConfig(this, ~, ~)

this.be.room = '';
BEActivate(this);

end
