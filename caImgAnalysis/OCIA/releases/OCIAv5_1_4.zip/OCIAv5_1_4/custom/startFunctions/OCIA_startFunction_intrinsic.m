%% #OCIA:OCIA_startFunction_intrinsic
function OCIA_startFunction_intrinsic(this)

    OCIAChangeMode(this, 'Intrinsic');
    
end
