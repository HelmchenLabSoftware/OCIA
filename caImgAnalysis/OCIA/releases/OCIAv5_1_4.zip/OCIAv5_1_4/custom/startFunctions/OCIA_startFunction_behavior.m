%% #OCIA:OCIA_startFunction_behavior
function OCIA_startFunction_behavior(this)

    OCIAChangeMode(this, 'Behavior');
    
end
