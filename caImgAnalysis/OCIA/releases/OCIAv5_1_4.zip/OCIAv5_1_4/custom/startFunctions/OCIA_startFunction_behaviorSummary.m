%% #OCIA:OCIA_startFunction_behaviorSummary
function OCIA_startFunction_behaviorSummary(this)

    %% get all behavior data
    OCIAChangeMode(this, 'DataWatcher');
    
    % get the DataWatcher's and the Analyser's GUI handles
    dwh = this.GUI.handles.dw;
    
    % set the watch types
    set(dwh.watchTypes.animal,      'Value', 1);
    set(dwh.watchTypes.day,         'Value', 1);
    set(dwh.watchTypes.spot,        'Value', 0);
    set(dwh.watchTypes.img,         'Value', 0);
    set(dwh.watchTypes.notebook,    'Value', 0);
    set(dwh.watchTypes.behav,       'Value', 1);
    set(dwh.watchTypes.roiset,      'Value', 0);
    set(dwh.watchTypes.intrinsic,   'Value', 0);
    
    % set the filters
    set(dwh.filt.animalID,          'Value', 1, 'String', { '-' });
    set(dwh.filt.dayID,             'Value', 1, 'String', { '-' });
    set(dwh.filt.spotID,            'Value', 1, 'String', { '-' });
    set(dwh.filt.rowTypeID,         'Value', 1, 'String', { '-' });
    set(dwh.filt.dataLoadStatus,    'Value', 0, 'String', '');
    set(dwh.filt.rowNum,            'Value', 0, 'String', '');
    set(dwh.filt.runNum,            'Value', 0, 'String', '');
    set(dwh.filt.all,               'Value', 0, 'String', '');
    
    % update the table
    DWProcessWatchFolder(this);
            
    %% go through each animal
    for iAnimal = 2 : numel(this.dw.animalIDs);
        
        %% switch to Analyser
        % select the animal and the behavior data and filter the table
        set(dwh.filt.animalID, 'Value', iAnimal);
        set(dwh.filt.rowTypeID, 'Value', find(strcmp(get(dwh.filt.rowTypeID, 'String'), 'Behavior data')));
        DWFilterSelectTable(this, 'new');
        
        % abort if no rows selected
        if numel(this.dw.selectedTableRows) == 0; continue; end;
        
        % go to analyser mode
        OCIA_dataWatcherProcess_analyseRows(this);
        
        % create save path
        baseSavePath = sprintf('%s%s/ref/behav/%s__behavior__', this.path.OCIASave, this.dw.animalIDs{iAnimal}, ...
            regexprep(this.dw.animalIDs{iAnimal}, 'mou_bl_', ''));        
        % get the list of variables
        varList = get(this.GUI.handles.an.paramPanElems.behavVarToPlot, 'String');        
        % select all runs
        set(this.GUI.handles.an.rowList, 'Value', 1 : numel(get(this.GUI.handles.an.rowList, 'String')));
        
        warning('off', 'MATLAB:LargeImage');
        
        %% summary plot with runs
        savePath = sprintf('%ssummary.png', baseSavePath);
        toSelVars = { 'days', 'n. of trials - date', 'training phase', 'animal ID', ...
            'imaged trials', 'hit rate - run', 'false alarm rate - run', ...
            'performance (d'') - run' };
        set(this.GUI.handles.an.paramPanElems.behavVarToPlot, 'Value', find(ismember(varList, toSelVars)));
        set(this.GUI.handles.an.paramPanElems.plotLims, 'String', '[0, 500; 0, 100; 0, 100; -1, 4]');
        ANUpdatePlot(this, 'force'); ANSavePlot(this, savePath, [], 300);
        
        %% summary plot with days
        savePath = sprintf('%ssummary_date.png', baseSavePath);
        toSelVars = { 'days', 'n. of trials - date', 'training phase', 'animal ID', ...
            'imaged trials', 'hit rate - date', 'false alarm rate - date', ...
            'performance (d'') - date' };
        set(this.GUI.handles.an.paramPanElems.behavVarToPlot, 'Value', find(ismember(varList, toSelVars)));
        set(this.GUI.handles.an.paramPanElems.plotLims, 'String', '[0, 500; 0, 100; 0, 100; -1, 4]');
        ANUpdatePlot(this, 'force'); ANSavePlot(this, savePath, [], 300);
        
        %% output to make the pooled summary accross mice
        savePath = sprintf('%soutput', baseSavePath);
        ANSaveOutput(this, savePath);
        
        %{
        
        %% trial timing plot
        savePath = sprintf('%strialTiming.png', baseSavePath);
        toSelVars = { 'behav. file num.', 'date', 'training phase name', 'training phase', 'animal ID', ...
            'imaged trials', 'starting delay', 'light delay' };
        set(this.GUI.handles.an.paramPanElems.behavVarToPlot, 'Value', find(ismember(varList, toSelVars)));
        set(this.GUI.handles.an.paramPanElems.plotLims, 'String', '[0, 7.5; 0, 7.5]');
        ANUpdatePlot(this, 'force'); ANSavePlot(this, savePath, [], 300);
        
        %% response delay plot
        savePath = sprintf('%sresponseDelay.png', baseSavePath);
        toSelVars = { 'behav. file num.', 'date', 'training phase name', 'training phase', 'animal ID', ...
            'response delay', 'imaged trials'};
        set(this.GUI.handles.an.paramPanElems.behavVarToPlot, 'Value', find(ismember(varList, toSelVars)));
        set(this.GUI.handles.an.paramPanElems.plotLims, 'String', '[0, 2.5]');
        ANUpdatePlot(this, 'force'); ANSavePlot(this, savePath, [], 300);
        
        %% lick plots
        ANClearData(this);
        set(this.GUI.handles.an.plotList, 'Value', 13);
        set(this.GUI.handles.an.rowList, 'Value', 1 : 2);
        ANUpdatePlot(this, 'force');
        set(this.GUI.handles.an.paramPanElems.selTimes, 'Value', [2 3 4]);
        set(this.GUI.handles.an.paramPanElems.sgFiltFrameSize, 'String', '301');
        uniqueDays = unique(get(this, this.an.selectedTableRows, 'day'));
        for iDay = 1 : numel(uniqueDays);
            savePath = sprintf('%slickHeatMap__%s.png', baseSavePath, uniqueDays{iDay});
            if exist(savePath, 'file'); continue; end; % skip plots that are already present
            set(this.GUI.handles.an.rowFilt, 'String', regexprep(uniqueDays{iDay}, '_', ''));
            ANFiltRows(this);
            ANUpdatePlot(this, 'force');
            ANSavePlot(this, savePath, [], 300);
            ANClearData(this);
        end;
        
        %}
        
        %% flush
        warning('on', 'MATLAB:LargeImage');
        ANClearData(this);
        % get back to data watcher and flush the data
        OCIAChangeMode(this, 'DataWatcher');
        DWFilterSelectTable(this, 'new');
        set(dwh.SLROptDataList, 'Value', find(strcmp(get(dwh.SLROptDataList, 'String'), 'Behavior data (raw)')));
        DWFlushData(this, 'all', false);
        
        % display the flushed table
        DWDisplayTable(this);
        
        % set back original plot
        set(this.GUI.handles.an.plotList, 'Value', 11);
        
    end;
    
end
