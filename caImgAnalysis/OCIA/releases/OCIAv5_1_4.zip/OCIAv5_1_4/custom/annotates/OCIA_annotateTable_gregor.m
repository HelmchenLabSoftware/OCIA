%% #OCIA:OCIA_annotateTable_gregor
function OCIA_annotateTable_gregor(this)

% match ROISets to imaging data
DWMatchROISetsToData(this);

% show the table
DWDisplayTable(this);

end

