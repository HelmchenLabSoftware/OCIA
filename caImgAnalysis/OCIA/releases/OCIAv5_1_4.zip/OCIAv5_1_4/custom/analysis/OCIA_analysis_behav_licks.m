%% #OCIA:AN:OCIA_analysis_behav_licks
function OCIA_analysis_behav_licks(this, iDWRows)

%% plotting parameter UI controls
paramConf = cell2table({ ...
... categ  id                   UIType      valueType               UISize      isLabAbove      label               tooltip
    'be',  'selTimes',          'list',     {  },                   [2 3],      true,           'Times',            'Selection of stimulus time points.';
    'be',  'allTimes',          'text',     { 'cellArray' },        [1 0],      false,          'All times',        'Time IDs for all the stimulus time points as a cell-array.';
    'be',  'selTrialTypes',     'list',     {  },                   [2 4],      true,           'Trial types',      'Selection of trial types.';
    'be',  'allTrialTypes',     'text',     { 'cellArray' },        [1 0],      false,          'All trial types',  'Trial types for all the trial type as a cell-array.';
    'be',  'sgFiltFrameSize',   'text',     { 'numeric' },          [1 0],      false,          'Sav.-Gol. filt.',  'Frame size of the Savitzky-Golay filter for the lick traces, value must be an odd number.';
    'be',  'PSPer',             'text',     { 'array' },            [0.75 0],   false,          'P.S. per.',        'Peri-stimulus period in seconds.';
    'be',  'plotLimits',        'text',     { 'array' },            [0.75 0],   false,          'Plot limits',      'Adjust the limits of the plot (color limit).';
    'be',  'colormap',          'dropdown', { 'gray', 'hot', 'gray_reverse', 'red_white_blue', 'jet' }', ...
                                                                    [0.75 0],   false,          'Colormap',         'Changes the coloring scheme (color map).';
    'be',  'normTrialsPrctile', 'text',     { 'array' },            [0.75 0],   false,          'Norm. trials %',   'Normalize the trials (percentile method).';
}, 'VariableNames', this.GUI.an.paramPanConfig.Properties.VariableNames);
% append the new configuration to the table and update the row names using the ids
this.GUI.an.paramPanConfig = [this.GUI.an.paramPanConfig; paramConf];
this.GUI.an.paramPanConfig.Properties.RowNames = this.GUI.an.paramPanConfig.id;

this.GUI.an.paramPanConfig{'selTimes', 'valueType'} = { this.an.be.allTimes };
this.GUI.an.paramPanConfig{'selTrialTypes', 'valueType'} = { this.an.be.allTrialTypes };

%% get the "raw" data structure from the rows
% get the behavior data: get the rows that have behavior data
selectedLoadedBehavRows = DWFilterTable(this, 'data.behav.loadStatus = full', this.dw.table(iDWRows, :));
% get the DataWatcher table indexes for these rows
selectedLoadedBehavRowsIndexes = str2double(get(this, 'all', 'rowNum', selectedLoadedBehavRows));
% get the data for these rows
allBehavStructs = getData(this, selectedLoadedBehavRowsIndexes, 'behav', 'data');
% make sure data is cell
if ~iscell(allBehavStructs); allBehavStructs = { allBehavStructs }; end;
nBehavStructs = numel(allBehavStructs); % count the number of strutures

% if no behavior data, abort with a warning
if isempty(allBehavStructs);
    showWarning(this, 'OCIA:OCIA_analysis_behav_licks:NoBehavData', 'No behavior data to plot in selected rows!');
    ANShowHideMessage(this, 1, 'No behavior data to plot in selected rows!');
    return;
end;


%% extract lick data
ANShowHideMessage(this, 1, 'Extracting licking data ...');

% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'dataType', 'lickData');
cachedData = ANGetCachedData(this, 'be', hashStruct);

% if the lick data is not in cache yet, create it
if isempty(cachedData) || iscell(cachedData);
    
    % calculate trial numbers
    nTotTrials = 0;
    nTrials = zeros(nBehavStructs, 1);
    for iBehav = 1 : nBehavStructs;
        behavStruct = allBehavStructs{iBehav};
        nTrials(iBehav) = find(~isnan(behavStruct.times.end) & ~isnan(behavStruct.resps), 1, 'last');
        nTotTrials = nTotTrials + nTrials(iBehav);
    end;

    % extract the lick data as a cell-array
    lickDataCell = cell(nTotTrials, 1);
    behavInd = nan(nTotTrials, 1); % behavior file index for each trial
    trialInd = nan(nTotTrials, 1); % trial number within a behavior file
    trialRespTypes = nan(nTotTrials, 1); % trial response type
    dateForTrials = cell(nTotTrials, 1); % date for each trial
    % go through all behavior files
    iTrialTot = 0;
    for iBehav = 1 : nBehavStructs;
        lickDataCell(iTrialTot + 1 : iTrialTot + nTrials(iBehav)) ...
            = allBehavStructs{iBehav}.record.piezo(1 : nTrials(iBehav));
        behavInd(iTrialTot + 1 : iTrialTot + nTrials(iBehav)) = iBehav;
        trialInd(iTrialTot + 1 : iTrialTot + nTrials(iBehav)) = 1 : nTrials(iBehav);
        trialRespTypes(iTrialTot + 1 : iTrialTot + nTrials(iBehav)) ...
            = allBehavStructs{iBehav}.respTypes(1 : nTrials(iBehav));
        dateForTrials(iTrialTot + 1 : iTrialTot + nTrials(iBehav)) ...
            = { datestr(unix2dn(allBehavStructs{iBehav}.expStartTime * 1000), 'yyyymmdd') };
        iTrialTot = iTrialTot + nTrials(iBehav);
    end;

    % store the licking data as a big matrix of nTrials x nSamples
    nMaxSamples = max(cellfun(@numel, lickDataCell));
    lickData = nan(nTotTrials, nMaxSamples);
    for iTrial = 1 : nTotTrials;
        lickData(iTrial, 1 : numel(lickDataCell{iTrial})) = lickDataCell{iTrial};
    end;
    
    % store the variables in the cached structure
    cachedData = struct('lickData', lickData, 'behavInd', behavInd, 'trialInd', trialInd, 'dateForTrials', { dateForTrials }, ...
        'trialRespTypes', trialRespTypes, 'nTotTrials', nTotTrials, 'nMaxSamples', nMaxSamples, 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'be', hashStruct, cachedData);

% if data was in memory, fetch it
else
    
    % fetch the data
    lickData = cachedData.lickData;
    behavInd = cachedData.behavInd;
    trialInd = cachedData.trialInd;
    trialRespTypes = cachedData.trialRespTypes;
    dateForTrials = cachedData.dateForTrials;
    nTotTrials = cachedData.nTotTrials;
    nMaxSamples = cachedData.nMaxSamples;
    
end;


%% extract PS lick data
ANShowHideMessage(this, 1, 'Extracting licking data peri-stimulus samples ...');

% get the stimulus IDs
selTimes = this.an.be.selTimes;
if isempty(selTimes);
    selTimes = this.an.be.allTimes;
    this.an.be.selTimes = selTimes;
end;
nStimTypes = numel(selTimes);
    
% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'PSPer', this.an.be.PSPer, 'selTimes', { selTimes }, 'dataType', 'PSLickData');
cachedData = ANGetCachedData(this, 'be', hashStruct);

% if the peri-stimulus lick data is not in cache yet, create it
if isempty(cachedData);

    % create the stimulus vector to splice up the matrix
    stimVects = zeros(nTotTrials, nMaxSamples);
    nanStimTypes = true(nStimTypes, nTotTrials);
    for iTrial = 1 : nTotTrials;
        % extract all times
        BETimes = allBehavStructs{behavInd(iTrial)}.times;
        % delay to add between the initial time and the starting time
        delay = BETimes.start(trialInd(iTrial)) - BETimes.init(trialInd(iTrial));
        % go through each stimulus
        for iStim = 1 : nStimTypes;
            % if the stimulus' time field exists and is not a NaN value, mark it as the stimulus sample
            if isfield(BETimes, selTimes{iStim}) && ~isnan(BETimes.(selTimes{iStim})(trialInd(iTrial)));
                stimSample = round((delay + BETimes.(selTimes{iStim})(trialInd(iTrial))) * this.an.be.anInSampleRate);
                nanStimTypes(iStim, iTrial) = false;
             
            % stimulus type is absent/invalid for this trial, mark it as not valid
            else
                % make sure the samples are not the same otherwise they overlap in the stim vector
                stimSample = 100 + iStim;
                
                % mark the non-valid trials
                nanStimTypes(iStim, iTrial) = true;
%                 o('#%s: problem with trial %d, stim %d (%s): using fake sample number %d ...', ...
%                     mfilename(), iTrial, iStim, selTimes{iStim}, stimSample, 0, this.verb);
                
            end;
            % if sample would be outside of the recording, ignore it
            if stimSample > nMaxSamples;
                o('#%s: problem with trial %d, stim %d (%s): outside of the recording (%d > %d), skipping.', ...
                    mfilename(), iTrial, iStim, selTimes{iStim}, stimSample, nMaxSamples, 3, this.verb);
                stimSample = 100 + iStim;
                nanStimTypes(iStim, iTrial) = true;
            end;
            % mark the stimulus sample as belonging to the current stimulus
            stimVects(iTrial, stimSample) = iStim;
        end;
    end;
    
    % transform lick data into the right format
    lickData = permute(lickData, [1, 3, 2]);
    % extract the peri-stimulus samples
    PSLickData = extractPSTrace(lickData, stimVects, round(this.an.be.PSPer * this.an.be.anInSampleRate), 1, 0, 1);
    PSLickData = reshape(PSLickData, [size(PSLickData, 1), size(PSLickData, 2) size(PSLickData, 4)]);
    % hide the non-valid trials so that the same line always represents the same trial
    for iTrial = 1 : nTotTrials;
        % go through each stimulus
        for iStim = 1 : nStimTypes;
            if nanStimTypes(iStim, iTrial);
                PSLickData(iStim, iTrial, :) = NaN;
            end;
        end;
    end;
    
    % store the variables in the cached structure
    cachedData = struct('PSLickData', PSLickData, 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'be', hashStruct, cachedData);

% if data was in memory, fetch it
else
    
    % fetch the data
    PSLickData = cachedData.PSLickData;
    
end;

%% pre-process the data
% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'PSPer', this.an.be.PSPer, 'selTimes', { selTimes }, ...
    'normTrialsPrctile', this.an.be.normTrialsPrctile, 'sgFilt', this.an.be.sgFiltFrameSize, ...
    'dataType', 'PSLickDataProc');
cachedData = ANGetCachedData(this, 'be', hashStruct);

% if the processed peri-stimulus lick data is not in cache yet, create it
if isempty(cachedData);
    
    ANShowHideMessage(this, 1, 'Pre-processing lick data ...');

    PSLickDataProc = PSLickData;
    
    sgFiltFrameSize = this.an.be.sgFiltFrameSize;
    if sgFiltFrameSize > 1;
        if mod(sgFiltFrameSize, 2) == 0;
            sgFiltFrameSize = sgFiltFrameSize + 1;
        end;
        parfor iStimType = 1 : nStimTypes;
            for iTrial = 1 : nTotTrials;
                PSLickDataProc(iStimType, iTrial, :) = sgolayfilt(PSLickDataProc(iStimType, iTrial, :), 1, sgFiltFrameSize);
            end;
        end;
    end;
        
    normTrialsPrctile = this.an.be.normTrialsPrctile;
    if ~isempty(normTrialsPrctile) && isnumeric(normTrialsPrctile) && all(normTrialsPrctile >= 0) ...
            && all(normTrialsPrctile <= 100);

        %% pre-process the data : find min/max
        % get the max and the min for each day
        uniqueDays = unique(dateForTrials);
        nDays = numel(uniqueDays);
        minMaxForTrials = zeros(nTotTrials, 2);
        for iDay = 1 : nDays;
            dayMask = strcmp(dateForTrials, uniqueDays{iDay});
            valuesForDayAllStim = reshape(permute(PSLickDataProc(:, dayMask, :), [3 1 2]), ...
                [nStimTypes * size(PSLickDataProc, 3), nansum(dayMask)]);
%             minMaxForTrials(dayMask, 1) = prctile(valuesForDayAllStim(1 : 2000, :), normTrialsPrctile(1), 1);
%             minMaxForTrials(dayMask, 2) = prctile(valuesForDayAllStim(1 : 2000, :), normTrialsPrctile(2), 1);
            minMaxForTrials(dayMask, 1) = nanmedian(valuesForDayAllStim, 1);
        end;
        
        %% pre-process the data : apply
        for iTrial = 1 : nTotTrials;
            PSLickDataForTrial = PSLickDataProc(:, iTrial, :);
%             minVal = minMaxForTrials(iTrial, 1);
%             maxVal = minMaxForTrials(iTrial, 2);
            trialRange = iTrial - 1 : iTrial + 1;
            trialRange(trialRange < 1 | trialRange > nTotTrials) = [];
%             minVal = nanmean(minMaxForTrials(trialRange, 1));
%             maxVal = nanmean(minMaxForTrials(trialRange, 2));
%             minVal = nanmean(minMaxForTrials(:, 1));
%             maxVal = nanmean(minMaxForTrials(:, 2));
%             PSLickDataForTrial(PSLickDataForTrial < minVal) = minVal;
%             PSLickDataForTrial(PSLickDataForTrial > maxVal) = maxVal;
            PSLickDataForTrial = PSLickDataForTrial - nanmean(minMaxForTrials(trialRange, 1));
            PSLickDataForTrial(PSLickDataForTrial < 0) = 0;
%             PSLickDataProc(:, iTrial, :) = linScale(PSLickDataForTrial);
            PSLickDataProc(:, iTrial, :) = PSLickDataForTrial;
        end;
        
    end;
    
    % store the variables in the cached structure
    cachedData = struct('PSLickDataProc', PSLickDataProc, 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'be', hashStruct, cachedData);

% if data was in memory, fetch it
else
    
    % fetch the data
    PSLickDataProc = cachedData.PSLickDataProc;
    
end;

%% plot the data
ANShowHideMessage(this, 1, 'Plotting ...');
% create time vector
t = ((1 : size(PSLickDataProc, 3)) ./ this.an.be.anInSampleRate) + this.an.be.PSPer(1);

% two numbers
if isnumeric(this.an.be.plotLimits) && numel(this.an.be.plotLimits) == 2;
    plotLimits = this.an.be.plotLimits;
    
% single number
elseif isnumeric(this.an.be.plotLimits) && numel(this.an.be.plotLimits) == 1;
    plotLimits = [-this.an.be.plotLimits, this.an.be.plotLimits];
    
% automatic plot limits
else
    plotLimits = [prctile(PSLickDataProc(:), 35), prctile(PSLickDataProc(:), 98)];
    
end;

% order trials by response type
[trialRespTypesSorted, respTypeSortIndex] = sort(trialRespTypes);
PSLickDataProc = PSLickDataProc(:, respTypeSortIndex, :);

% plot the data
[~, axeHandles] = plotPeriStimAverageHeatMap(this.GUI.handles.an.axe, PSLickDataProc, t, selTimes, '', {}, ...
    plotLimits, this.an.be.colormap, [], 'Lick rate [A.U.]');

respTypeNames = { 'HIT', 'CR', 'FA', 'MISS' };
for iRespType = 1 : 4;
    respTypeStartIndex = find(trialRespTypesSorted == iRespType, 1, 'first');
    respTypeStopIndex = find(trialRespTypesSorted == iRespType, 1, 'last');
    if isempty(respTypeStartIndex) || isempty(respTypeStopIndex); continue; end;
    meanRespTypeIndex = round(nanmean(find(trialRespTypesSorted == iRespType)));
    for iAxeHandle = 1 : numel(axeHandles);
        line([-1000, 1000], repmat(respTypeStartIndex - 0.5, 1, 2), 'Color', 'white', 'LineWidth', 3, ...
            'Parent', axeHandles(iAxeHandle));
        line([-1000, 1000], repmat(respTypeStopIndex + 0.5, 1, 2), 'Color', 'white', 'LineWidth', 3, ...
            'Parent', axeHandles(iAxeHandle));
    end;
    text(t(1) - 200 * (t(2) - t(1)), meanRespTypeIndex, respTypeNames{iRespType}, 'Color', 'black', ...
        'Parent', axeHandles(1), 'HorizontalAlignment', 'center', 'Interpreter', 'none', ...
        'FontSize', max(min(20 - (0.25 * nTotTrials), 20), 12), 'Rotation', 90);
end;

filterText = get(this.GUI.handles.an.rowFilt, 'String');
if ~isempty(filterText) && ~isempty(regexp(filterText, '^\d{4}\d{2}\d{2}$', 'once'));
    text(t(1) - 900 * (t(2) - t(1)), round(nTotTrials * 0.5), filterText, 'Color', 'black', ...
        'Parent', axeHandles(1), 'HorizontalAlignment', 'center', 'Interpreter', 'none', ...
        'FontSize', 25, 'Rotation', 90);
end;

% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');
end
