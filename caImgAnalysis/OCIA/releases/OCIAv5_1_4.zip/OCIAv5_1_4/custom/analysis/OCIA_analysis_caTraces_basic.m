%% #OCIA:AN:OCIA_analysis_caTraces_basic
function OCIA_analysis_caTraces_basic(this, iDWRows)

%% plotting parameter UI controls
paramConf = cell2table({ ...
... categ  id                   UIType      valueType               UISize    isLabAbove    label                    tooltip
    'img', 'traceTypeToShow',   'dropdown', {{ 'raw only', 'filtered only', 'raw and filtered' }}, ...
                                                                    [1 0],   false,         'Trace type',           'Selects which traces are displayed in case of filtering.';
}, 'VariableNames', this.GUI.an.paramPanConfig.Properties.VariableNames);
% append the new configuration to the table and update the row names using the ids
this.GUI.an.paramPanConfig = [this.GUI.an.paramPanConfig; paramConf];
this.GUI.an.paramPanConfig.Properties.RowNames = this.GUI.an.paramPanConfig.id;

%% get the data
% force the ROI combination to be true
this.an.img.combineROIs = true;

% get the concatenated trace (raw and filtered), the stimuli, the selected ROI names and the time vector
[concatCaTraces, concatStims, concatCaTracesSGFilt, ROINames, t] = OCIA_analysis_getConcatCaData(this, iDWRows);
% abort if no traces came out
if isempty(concatCaTraces); return; end;

% remove some option from the analysis parameters
this.GUI.an.paramPanConfig('combineROIs', :) = [];

% get the stimulus IDs to use
stimIDs = this.an.img.selStimIDs;
stimIDs = regexprep(reshape(stimIDs, 1, numel(stimIDs)), '_', ' ');
% rename stim IDs
stimIDs = OCIA_analysis_renameStimIDs(stimIDs);

%% plot
ANShowHideMessage(this, 1, 'Plotting ...');
plotTic = tic; % for performance timing purposes

% plot the data depending on the selected trace type to show
if strcmp(this.an.img.traceTypeToShow, 'raw and filtered');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', concatCaTraces, concatCaTracesSGFilt, concatStims, stimIDs, ROINames, t, t, []);
elseif strcmp(this.an.img.traceTypeToShow, 'filtered only');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', concatCaTracesSGFilt, [], concatStims, stimIDs, ROINames, t, [], []);
elseif strcmp(this.an.img.traceTypeToShow, 'raw only');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', concatCaTraces, [], concatStims, stimIDs, ROINames, t, [], []);
else
    ANShowHideMessage(this, 0, sprintf('Unknown trace type option: "%s". Cannot plot.', this.an.img.traceTypeToShow));
end;

o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

%% attach callback to quickly identify trials
childElems = get(this.GUI.handles.an.axe, 'Children');
stimLineElems = childElems(cellfun(@(cont)~isempty(regexp(cont, '^stimLine_', 'once')), get(childElems, 'Tag')));
for iElem = 1 : numel(stimLineElems);
    ownTag = get(stimLineElems(iElem), 'Tag');
    trialInfo = regexp(ownTag, 'stimLine_stim(?<trialNum>\d+)_(?<trialType>\w+)', 'names');
    selectedTableRows = get(this.GUI.handles.an.rowList, 'Value');
    set(stimLineElems(iElem), 'ButtonDownFcn', @(h, e)fprintf('%s, %s\n', DWGetRowID(this, ...
        this.an.selectedTableRows(selectedTableRows(str2double(trialInfo.trialNum)))), trialInfo.trialType));
end;

% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');


end
