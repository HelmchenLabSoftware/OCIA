function this = OCIA_dataConfig_whisk(this)
% adds the whisker data structures to the OCIA

%% whisker data type

% defines the data storage options
this.main.dataConfig = [this.main.dataConfig; cell2table({ ...
...     rowType         id              shortLabel      label                               saveFormat  defaultOn
        'Imaging data', 'whisk',        'Whisk.',       'Whisking data',                    'HDF5',     true;
}, 'VariableNames', this.main.dataConfig.Properties.VariableNames)];

% define the analysis parameters for this data type
this.an.whisk = struct();

% whisker traces processing method (raw, enveloppe, etc.)
this.an.whisk.procMethod = 'raw';
% scaling of the whisker traces for display
this.an.whisk.traceScaling = 500;
% fraction of the number of frames to use for the sliding window of the enveloppe
this.an.whisk.envWinSize = 0.01;

end
