function this = OCIA_modeConfig_intrinsic(this)
% adds the intrinsic mode to the OCIA

%% -- properties: path: Intrinsic
if ispc();
    docPath = winqueryreg('HKEY_CURRENT_USER', 'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders', 'Personal');
else
    docPath = char(java.lang.System.getProperty('user.home'));
end;
% path where the intrinsic data should be saved
this.path.intrSave = sprintf('%s/%s/intr/', docPath, datestr(date, 'yyyy_mm_dd'));

%% -- properties: GUI: Intrinsic
this.GUI.intr = struct();

% defines whether the axes should be drawn in a 1-1 aspect ratio
this.GUI.in.axisEqual = true;

% defines the frame rate of the preview in Hertz
this.GUI.in.prevFrameRate = 30;
% defines whether to show a grayscale preview or a jet-colored one
this.GUI.in.prevUseGrayscale = true;
% defines whether to show the saturation on the preview
this.GUI.in.prevShowSaturation = true;
% defines whether to show the saturation on the preview
this.GUI.in.prevSaturationBounds = [110, 4094];
% defines the number of frames to use for the reference image
this.GUI.in.nFramesRef = 25;
% default image dimension (optional)
this.GUI.in.imDim = [347, 427];
% shrinking factor for the outline
this.GUI.in.shrinkFactor = 0.9;
% color of the outline
this.GUI.in.refROIOutlineColor = [1 0 0];

% image filter
this.GUI.in.filt = fspecial('gauss', [10, 10], 1.5);

% handles of the Region Of Interest
this.GUI.in.ROIHandle = {};

% table describing how the parameter panel should be created
this.GUI.in.paramPanConfig = cell2table({ ...
    
... categ       id                      UIType  valueType       UISize  isLabAbove  label               tooltip
    'common',   'cLim',                 'text', { 'array' },    [1 0],  false,      'Col. lim.',        'Color limits for the images.';
    'common',   'saveName',             'text', { 'text' },     [1 0],  true,       'Save name',        'Save name root.';
    'common',   'expNumber',            'text', { 'array' },    [1 0],  false,      'Exp. num.',        'Experiment number.';
    'common',   'useTDT',               'dropdown', { 'false', 'true' }, [1 0], false, 'Use TDT',       'Whether to play sounds using TDT or standard sound output.';
    'common',   'startDelay',           'text', { 'array' },    [1 0],  false,      'Start delay',      'Duration (in seconds) of the waiting period at the begining of the experiment (only once).';
    
... categ       id                      UIType  valueType       UISize  isLabAbove  label               tooltip
    'standard', 'nRuns',                'text', { 'array' },    [1 0],  false,      'Num. runs',        'Number of runs (cycles).';
    'standard', 'baselineAvgDur',       'text', { 'array' },    [1 0],  false,      'Baseline avg.',    'Duration (in seconds) of the averaging for the baseline condition.';
    'standard', 'baseline1ToBaseline2Delay', 'text', { 'array' }, [1 0], false,     'Inter-b. delay',   'Duration (in seconds) of the waiting period between the two baseline averagings.';
    'standard', 'baselineToStimDelay',  'text', { 'array' },    [1 0],  false,      'Baseline delay',   'Duration (in seconds) of the waiting period between the baseline averaging and the stimulus.';
    'standard', 'stdStimDur',              'text', { 'array' },    [1 0],  false,      'Stim. dur.',       'Duration (in seconds) of the stimulus.';
    'standard', 'stimToStimAvgDelay',   'text', { 'array' },    [1 0],  false,      'Stim. delay',      'Duration (in seconds) of the waiting period between the stimulus'' end and the stimulus'' averaging.';
    'standard', 'stimAvgDur',           'text', { 'array' },    [1 0],  false,      'Stim. avg.',       'Duration (in seconds) of the averaging for the stimulus condition.';
    'standard', 'waitPeriod',           'text', { 'array' },    [1 0],  false,      'Wait period',      'Duration (in seconds) of the waiting period at the end of each run (recovery period).';
    'standard', 'stdBaseFreq',          'text', { 'array' },    [1 0],  false,      'COT baseFreq',     'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'standard', 'stdNFreqs',            'text', { 'array' },    [1 0],  false,      'COT nFreqs',       'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'standard', 'stdPowOf2',            'text', { 'array' },    [1 0],  false,      'COT powOf2',       'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'standard', 'stdToneDur',           'text', { 'array' },    [1 0],  false,      'COT toneDur',      'Duration (in seconds) of single tone within a cloud.';
    'standard', 'stdToneISI',           'text', { 'array' },    [1 0],  false,      'COT toneISI',      'Duration (in seconds) of overlap between tones within a cloud.';
    'standard', 'stdCloudDispersion',   'text', { 'array' },    [1 0],  false,      'COT dispersion',   'Dispersion (broadness) of the clouds in number of adjacent frequencies on each side (2 => 5 freqs).';
    'standard', 'stdCloudCenter',       'text', { 'array' },    [1 0],  false,      'COT center',       'Index of center frequency of the cloud of tones.';
     
... categ       id                      UIType  valueType       UISize  isLabAbove  label               tooltip
    'fourier',  'nSweeps',              'text', { 'array' },    [1 0],  false,      'Num. runs',        'Number of sweeps.';
    'fourier',  'fouBaseFreq',          'text', { 'array' },    [1 0],  false,      'COT baseFreq',     'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'fourier',  'fouNFreqs',            'text', { 'array' },    [1 0],  false,      'COT nFreqs',       'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'fourier',  'fouPowOf2',            'text', { 'array' },    [1 0],  false,      'COT powOf2',       'Parameter for the cloud-of-tones frequencies based on the formula: baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2))).';
    'fourier',  'sweepDur',             'text', { 'array' },    [1 0],  false,      'Sweep dur.',       'Duration (in seconds) of a single stimulus sweep.';
    'fourier',  'fouStimDur',           'text', { 'array' },    [1 0],  false,      'Stim. dur.',       'Duration (in seconds) of single tone/cloud within a sweep.';
    'fourier',  'camFPS',               'text', { 'array' },    [1 0],  false,      'Camera FPS',       'Expected frequency (in Hertz) of the camera.';
    'fourier',  'stimDurDiffTolerance', 'text', { 'array' },    [1 0],  false,      'Stim. toler.',     'Tolerance (in seconds) between the expected and real duration of stimulus cycle.';
    
}, 'VariableNames', { 'categ', 'id', 'UIType', 'valueType', 'UISize', 'isLabelAbove', 'label', 'tooltip' });
% append the new configuration to the table and update the row names using the ids
this.GUI.in.paramPanConfig.Properties.RowNames = this.GUI.in.paramPanConfig.id;
% specifies which page of the parameter pannels is currently shown
this.GUI.in.paramPage = 1;

%% - properties: Intrinsic
this.in = struct();

% defines the connection state with the camera
this.in.connected = false;
% defines whether we are in preview mode or not
this.in.previewRunning = false;
% defines whether we are in an experiment or not
this.in.expRunning = false;

% handle to the camera's viedeoinput object
this.in.camH = [];
% string defining the camera's adaptor name
this.in.adaptorName = 'ni';
% number defining the camera's device ID
this.in.deviceID = 1;
% handle to ActiveX control of the TuckerDavis
this.in.RP = [];

% defines by how much the image should be spatially down-sampled
this.in.spatialDSFactor = 3;

% stores the reference image
this.in.data.refImg = [];
% stores the baseline frames
this.in.data.baseline1Frames = {};
% stores the baseline frames
this.in.data.baseline2Frames = {};
% stores the stimulus frames
this.in.data.stimulusFrames = {};
% stores the baseline DRR average images
this.in.data.baselineDRRAvg = {};
% stores the stimulus DRR average images
this.in.data.stimulusDRRAvg = {};
% stores the include property of each run
this.in.data.includeInAverage = [];

% experiment mode: 'standard' (stimulus-average-wait cycles) vs 'fourier' (continuous stimulus steps with fourier
%   transform and power at stimulus frequency)
this.in.expMode = 'standard';
% sampling frequencies (TDT and standard sound speakers)
this.in.TDTSampFreq = 97656.25;
this.in.standardSampFreq = 44100;


%% - properties: Intrinsic: common properties
% defines the color limits for the images
this.in.common.cLim = [0.05, 0.15];

% defines the number of frames to use for the reference image
this.in.common.saveName = 'intr[common.expNumber]_[expMode]';
% defines the number of experiments that have been run from start
this.in.common.expNumber = 0;

% defines whether to use the TuckerDavisTechnologies sound system or just normal speakers
this.in.common.useTDT = true;

% defines the duration (in seconds) of the waiting period at the begining of the experiment (only once)
this.in.common.startDelay = 5;

%% - properties: Intrinsic: standard mode
% defines the properties for the standard intrinsic imaging (stimulus-average-wait cycles)
% the sequence of the experiment is the following:
% startDelay - [baseline1Avg -> baseline1ToBaseline2Delay -> baseline2Avg -> baselineToStimDelay -> stimulus
%   -> stimToStimAvgDelay -> stimAvg -> waitPeriod] x nRuns

% defines the number of runs for the stimulus/waiting cycle
this.in.standard.nRuns = 10;
% defines the duration (in seconds) of the averaging for the baseline condition (used both for baseline 1 and 2)
this.in.standard.baselineAvgDur = 4;
% defines the duration (in seconds) of the waiting period between the two baseline averagings
this.in.standard.baseline1ToBaseline2Delay = 2;
% defines the duration (in seconds) of the waiting period between the baseline averaging and the stimulus
this.in.standard.baselineToStimDelay = 2;
% defines the duration (in seconds) of the stimulus
this.in.standard.stdStimDur = 4;
% defines the duration (in seconds) of the waiting period between the stimulus' end and the stimulus' averaging
this.in.standard.stimToStimAvgDelay = 2;
% defines the duration (in seconds) of the averaging for the stimulus condition
this.in.standard.stimAvgDur = 4;
% defines the duration (in seconds) of the waiting period at the end of each run (recovery period)
this.in.standard.waitPeriod = 15;

% defines the list of frequencies for the cloud-of-tones stimulation based on the following formula:
%   baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2)))
this.in.standard.stdBaseFreq = 4000;
this.in.standard.stdNFreqs = 33;
this.in.standard.stdPowOf2 = -4;
% defines the duration (in seconds) of single tone within a cloud
this.in.standard.stdToneDur = 0.03;
% defines the duration (in seconds) of overlap between tones within a cloud
this.in.standard.stdToneISI = 0.01;
% defines the dispersion (broadness) of the clouds in number of adjacent frequencies on each side (2 => 5 freqs)
this.in.standard.stdCloudDispersion = 5;
% defines the center frequency of the cloud of tones
this.in.standard.stdCloudCenter = 15;

%% - properties: Intrinsic: fourier mode
% defines the properties for the fourier intrinsic imaging (continuous stimulus steps with fourier transform and power
%   at stimulus frequency)
% the sequence of the experiment is the following:
% startDelay - [stim1 delay stim2 delay ... stimN delay] x nRuns

% defines the number of runs for the stimulus/waiting cycle
this.in.fourier.nSweeps = 50;

% defines the list of frequencies for the stimulation based on the following formula:
%   baseFreq * (2 .^ ((0 : nFreqs) * (2 ^ powOf2)))
this.in.fourier.fouBaseFreq = 4000;
this.in.fourier.fouNFreqs = 33;
this.in.fourier.fouPowOf2 = -4;
% defines the duration (in seconds) of single tone within a cloud
this.in.fourier.fouToneDur = 0.03;
% defines the duration (in seconds) of overlap between tones within a cloud
this.in.fourier.fouToneISI = 0.01;
% defines the dispersion (broadness) of the clouds in number of adjacent frequencies on each side (2 => 5 freqs)
this.in.fourier.fouCloudDispersion = 5;
% defines the center frequency of the cloud of tones
this.in.fourier.fouCloudCenter = 20;
% defines the tolerance (in seconds) between the expected and real duration of stimulus cycle
this.in.fourier.stimDurDiffTolerance = 0.001;
% defines the duration (in seconds) of a single stimulus sweep
this.in.fourier.sweepDur = 6;
% defines the duration (in seconds) of single tone/cloud within a sweep
this.in.fourier.fouStimDur = 0.05;
% defines the frequency (in Hertz) of stimulation for a single frequency
this.in.fourier.stimFreqSingle = [];
% defines the frequency (in Hertz) of stimulation for all frequencies (general stimulation frequency)
this.in.fourier.stimFreqAll = [];
% defines the expected frequency (in Hertz) of the camera
this.in.fourier.camFPS = 30;
% defines the real frequency (in Hertz) of the camera
this.in.fourier.realCamFPS = [];

% defines by how much the image should be termporally down-sampled (1 = no down-sampling)
this.in.fourier.temporalDSFactor = 1;

end
