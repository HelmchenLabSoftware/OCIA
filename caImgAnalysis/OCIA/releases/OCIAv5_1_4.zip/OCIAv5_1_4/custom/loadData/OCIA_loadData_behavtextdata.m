%% #OCIA:OCIA_loadData_behavtextdata
function OCIA_loadData_behavtextdata(this, iDWRow, loadType)

loadTic = tic; % for performance timing purposes
o('#%s: iDWRow: %03d, loadType: %s.', mfilename, iDWRow, loadType, 3, this.verb);

% get the load status
loadStatus = getData(this, iDWRow, 'behavtext', 'loadStatus');

% only load the data if not already loaded
if ~strcmp(loadStatus, 'full');

    % load the behavior structure arrays
    behavData = import_trial_log(get(this, iDWRow, 'path'));

    % store the data
    setData(this, iDWRow, 'behavtext', 'data', behavData);
    
    % mark row as loaded
    setData(this, iDWRow, 'behavtext', 'loadStatus', 'full');
    
end;

o('  #%s: iDWRow %03d, loadType: %s done (%3.1f sec).', mfilename, iDWRow, loadType, toc(loadTic), 4, this.verb);

end
