%% #OCIA:OCIA_preprocess_alex
function tableRows = OCIA_preprocess_alex(this, tableRows, varargin)

preProcRowsTic = tic; % for performance timing purposes

% make sure input argument is not a non-empty cell with empty content
if ~isempty(varargin) && iscell(varargin) && isempty(varargin{1}); varargin = []; end;

% check whether there is a need to create the tableRows
doCreateTable = nargout > 0;

nRows = size(tableRows, 1); % get the number of rows

% update the waiting bar
nSteps = 4; iStep = 1; p = 0;
DWWaitBar(this, p);
p = 100 * (1 / (nSteps * nRows));

% get the jTable if in GUI mode
if isGUI(this);
    jTable = getJTable(this, 'DWTable');
end;

% initialize the DataWatcher table row number
iDWRow = [];
                
% analyse the type of each row
for iRow = 1 : nRows;
    
    preProcSingleRowTic = tic; % for performance timing purposes
    
    % if required, flush some of the data between the runs to avoir memory overflow
    if ~isempty(this.dw.savedDataToFlushBetweenRuns);
        DWFlushData(this, iDWRow, this.dw.savedDataToFlushBetweenRuns{:});
    end;
    
    iDWRow = tableRows{iRow, 11}; % get the current row in the DataWatcher's table reference
    rowType = DWGetRowType(this, iDWRow); % get the row type
    % get the rowID as "YYYYMMDD_HHMMSS"
    rowID = sprintf('%s__%s', this.dw.table{iDWRow, 2 : 3});
        
    % process differently depending on the row type
    switch rowType;

        case 'imgData';
        %% - #OCIA:OCIA_preprocess_alex : imaging data

            dimTag = tableRows{iRow, 5}; % get the dimension tag
            % if no dimtag from meta-data, try to get dimtag from the notebook
            if isempty(dimTag); dimTag = tableRows{iRow, 10}; end;
            % get the number of frames
            nFrames = str2double(strrep(regexp(dimTag, 'x\d+$', 'match'), 'x', ''));

            % only process functional movies that have at least "funcMovieNFrames" frames
            if nFrames > this.an.img.funcMovieNFramesLimit;
                
                % create a display text if required
                if doCreateTable;
                    tableRows{iRow, 12} = sprintf('%03d: %s - %s__%s - %s%s_%s', ...
                        tableRows{iRow, [11, 6, 2, 3, 7, 8, 9]});
                    tableRows{iRow, 12} = regexprep(tableRows{iRow, 12}, '_Trial_', '_');
                end;
                
                %% -- #OCIA:OCIA_preprocess_alex : imaging data : load/pre-process the data
                validRow = 1; % default is valid                

                % if load the data is required
                if validRow && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'load', 'once'))) ...
                    && isempty(this.data.img.caTraces{iDWRow});
                    % load all frames for the row
                    DWLoadRow(this, iDWRow, 'full', sprintf(', %03d/%03d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));
                end;
                
                % only do pre-processing steps if the caTraces data is not ready set and pre-processing is required
                if validRow && isempty(this.data.img.caTraces{iDWRow}) ...
                        && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'preProc', 'once')));

                    % remove frames with a lot of motion artifacts
                    ANMotionDetection(this, iDWRow, 0, sprintf(', %03d/%03d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));

                    % correct for motion artifacts
                    validRow = ANMotionCorrection(this, iDWRow, 0, sprintf(', %03d/%03d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));

                end;

                % if row is not valid, abort and flush data
                if ~validRow;
                    DWFlushData(this, iDWRow, 'raw,preproc,img,catraces');
                    % adjust the wait bar
                    DWWaitBar(this, 100 * (iRow / nRows));
                    continue;
                end;
                
                % if pre-processing is required
                if validRow && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'preProc', 'once'))) ...
                        && isempty(this.data.img.caTraces{iDWRow});
                    
                    showMessage(this, 'Creating generic stimulus vector', 'yellow');
                    stimVect = this.an.img.genericStimVect;
                    switch this.dw.table{iDWRow, 8};
                        case 'aH';
                        case 'dH'; stimVect(stimVect == 1) = 2;
                        case 'cH'; stimVect(stimVect == 1) = 3;
                        case 'aL'; stimVect(stimVect == 1) = 4;
                        case 'dL'; stimVect(stimVect == 1) = 5;
                        case 'cL'; stimVect(stimVect == 1) = 6;
                        case 'spontaneous'; stimVect(stimVect == 1) = 7;
                    end;
                    % store the stim vector
                    this.data.img.stim{iDWRow} = stimVect;
                    
                    % calculate the dFF/dRR trace for the row
                    ANCalcDRRForRow(this, iDWRow, 0, sprintf(', %03d/%03d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));
                end;
                
                % update the row's loading and processing status
                DWUpdateRowStatus(this, iDWRow, jTable);
            end;
            
        otherwise;
        % otherwise do nothing :-/
        
    end;
    showMessage(this, sprintf('Preprocessing %s (%03d) done (%.1f sec).', rowID, iDWRow, toc(preProcSingleRowTic)));
end;

% update waiting bar
DWWaitBar(this, 100);

showMessage(this, sprintf('Preprocessing %03d rows done (%.1f sec).', nRows, toc(preProcRowsTic)));

end
