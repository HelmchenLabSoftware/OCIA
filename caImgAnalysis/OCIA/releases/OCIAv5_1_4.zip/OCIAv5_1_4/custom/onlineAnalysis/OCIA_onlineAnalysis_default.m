%% #OCIA:OCIA_onlineAnalysis_default
function OCIA_onlineAnalysis_default(this)

    % go to DataWatcher mode
    OCIAChangeMode(this, 'DataWatcher');
    
    % process the selected folder and extract the notebook informations
    DWProcessWatchFolder(this);
    
end
