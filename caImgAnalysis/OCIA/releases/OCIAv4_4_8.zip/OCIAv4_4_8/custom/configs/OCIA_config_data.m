function [this, inputParams] = OCIA_config_data(this)
% adds the data structures to the OCIA

inputParams = [];

%% - properties: Data
% structure holding all the data with :
%   - cell-array fields that have one cell per run/row
%   - structure for each data mode added
this.data = struct();
% raw data as cell array for each run/row
this.data.raw = cell(this.dw.dataNMaxRuns, 1);
% load type of the raw data as cell array for each run/row: can be either 'prev' (preview) or 'full' (fully loaded)
this.data.rawLoadType = cell(this.dw.dataNMaxRuns, 1);
% pre-processed data as cell array for each run/row
this.data.preProc = cell(this.dw.dataNMaxRuns, 1);
% pre-processing type of the pre-processed data as cell array for each run/row. Can contain any pre-processing
%   strings (example for imaging data: skipFrame, fShift, fJitt, moCorr, moDet, etc.)
this.data.preProcType = cell(this.dw.dataNMaxRuns, 1);

% apply different data modes' configuration
for iMode = 1 : numel(this.dw.dataModes);
    % call the data save configuration function
    modeName = lower(this.dw.dataModes{iMode});
    [~, argsOut] = OCIAGetCallCustomFile(this, 'config_data', modeName, 1, { this }, 0);
    this = argsOut{1};
    
end;

end
