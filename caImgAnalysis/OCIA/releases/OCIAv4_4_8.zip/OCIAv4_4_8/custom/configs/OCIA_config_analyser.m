function [this, inputParams] = OCIA_config_analyser(this)
% adds the analyser mode to the OCIA

inputParams = [];

%% - properties: Analyser
this.an = struct();
% cell array containing the data as runTable for the currently analysed runTable rows
this.an.runTable = {};
% defines whether to set 0-value pixels to NaN when loading images
this.an.loadImageSetValueToNaNWhenZero = true;
% behavior data, loaded when processing the behavior folders. 4 columns: { date, time, spot, Matlab "out" struct }
if ismember('behav', this.dw.dataModes);
    this.an.behav = cell(0, 4);
end;
% result of the calcium analysis
this.an.caTracesOut = [];
% available plot types in the analyser panel
% this.an.plotTypes = { 'ROICaTraces', 'ROICaTracesHeatMap', 'CaTraceBehavior', 'CaTracesWhisk', ...
%     'CaTracesWhiskCorrHeatMap', 'CaTracesWhiskCorrDistr', 'PSAverage', ...
%     'PSAverageHeatMap', 'PSAverageOdd', 'PSAverageOddHeatMap', 'RawTraces', 'DPrime', 'BehavFrac' };
this.an.plotTypes = { 'caTraces', 'caTracesHeatMap', 'caTraceBehavior', 'caTracesWhisk', ...
    'caTracesWhiskCorrHeatMap', 'caTracesWhiskCorrDistr', 'PSAverage', 'PSAverageHeatMap', 'rawTraces', ...
    'DPrime', 'behavFrac' };

%% -- properties: GUI: Analyser
% cell-array describing how the parameter panel should be created for each plot
this.GUI.an.plotParamConfig = {};

%% -- properties: data: Analyser
% create a structure for storing the data of the analyser
this.data.an = struct();

%% -- properties: Analyser: Imaging
this.an.img = struct();
% number of channel(s) to load; also the number of data files that should be in a data folder
this.an.img.nChans = 2;
% index of the channel on which the pre-processing should be calculated (motion correction/detection, etc.)
this.an.img.preProcChan = 1;
% channels to use for the RGB image display
this.an.img.colVect = [0 1 2];
% channels to use for the dFF/dRR calculations
this.an.img.chanVect = [1 2];
% frame rate of the imaging in hertz
this.an.img.defaultFrameRate = 77.67;
% fixed/default dimensions of the imaging data in pixels
this.an.img.defaultImDim = [200 200];
% minimum number of frames for a row to be considered as a functional movie
this.an.img.funcMovieNFramesLimit = this.dw.previewNMaxFrameToLoad + 1;
% F0/R0 method index. Methods are mean, median, prctile, polyfit, polyfitMean
this.an.img.f0method = 3;
% F0/R0 parameter (can be empty), for percentile: Nth percentile; for polyfit: polyfit degree
this.an.img.f0params = 25;
% background substraction percentile
this.an.img.bgPrctile = 1;
% degree of the polyfit correction for bleaching. Set to 0 for no correction.
this.an.img.polyfitCorrect = 0;
% percent of the trace where the polyfit correction should be calculated
this.an.img.polyfitFraction = 0.0;

%% -- properties: Analyser: Analysis
this.an.an = struct();
% plotting limits. Leave empty for auto limits.
this.an.an.plotLimits = [];
% colormap to use for heatmap plots
this.an.an.colormap = 'gray';
% name of the stimuli
this.an.an.stimIDs = {'low', 'high'};
% duration of the stimulus in seconds
this.an.an.stimDur = 0.5;
% list of stimulus IDs to set to 0 before processing data (those stimuli are ignored for analysis)
this.an.an.ignoreStim = [];
% number of frames to remove in the begining of the imaging data (shutter artifact)
this.an.an.nSkipFrame = 1;
% determines which transformation should be used for the turboReg registration, which can be one
%   of: translation/rigidBody/affine/bilinear
this.an.an.regTransf = 'rigidBody';
% determines which type of motion correction should be applied (TurboReg, HMM)
this.an.an.moCorrType = 'TurboReg';
% determines whether a filter should be applied on the images before motion correction
this.an.an.moCorrFilt = false;
% determines the minimum difference of the 5th percentile of the frame-wise correlation of each aligned frame to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorMeanFrameCorrDiffThresh = -0.05;
% determines the minimum difference of correlation of the average of the aligned frames to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorFrameCorrToRefDiffThresh = -0.1;
% determines the minimum correlation (absolute number) of the average of the aligned frames to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorFrameCorrToRefAbsThresh = 0.85;
% determines whether to use the non-aligned stacks if the quality control failed
this.an.an.moCorUseNonCorrectedIfQualityControlFailed = false;
% determines whether a filter should be applied on the images before motion detection
this.an.an.moDetFilt = true;
% determines at which threshold is a frame consider out of focus
this.an.an.moDetOOFThreshFactor = 1.6;
% determines whether single frames that are out of focus (with previous and next frame in focus) should be excluded
this.an.an.moDetRemoveSingleFrames = false;
% determines which pre-processing options should be applied. Should be a cell array containing one or
%   more of: 'skipFrame', 'fShift', 'fJitt', 'moCorr', 'moDet'
this.an.an.preProcOptions = { 'skipFrame', 'fShift', 'fJitt', 'moDet', 'moCorr' };
% number of seconds for the peri-stimulus averaging (peri-stimulus period): base and evoked
this.an.an.PSPer = [1.2, 1.2];
% fraction of the image that should excluded on the borders for the neuropil mask
this.an.an.nPilMaskBord = 0.15;
% down-sampling factor to apply to the functional data to the functional data (DRR or DFF)
this.an.an.downSampFactor = 1;
% frame size of the Savitzky-Golay filter to apply to the functional data (DRR or DFF)
this.an.an.sgFiltFrameSize = 1;
% determines whether a temporal filter (Savitzky-Golay) should be applied on the ROI time series of each channel
%   before ratio (DFF/DRR) calculation
this.an.an.channelSFGiltFrameSize = 1;
% determines whether a down sampling factor should be applied on the ROI time series of each channel
%   before ratio (DFF/DRR) calculation
this.an.an.channelDownSampFactor = 1;


%% -- properties: Analyser: Behavior
this.an.be.binWidth = 150;

end
