%% #OCIA:AN:OCIA_analysis_caTracesWhisk
function OCIA_analysis_caTracesWhisk(this, DWRows)

% remove rows where there is not caTraces data and set the run selecter accordingly
emptyRows = cellfun(@isempty, this.data.img.caTraces(DWRows));
if any(emptyRows)
    DWRows(emptyRows) = [];
    set(this.GUI.handles.an.runTable, 'Value', find(~emptyRows));
    ANShowHideMessage(this, 1, 'Some runs do not have imaging data.');
    pause(1);
end;

if isempty(DWRows);
    ANShowHideMessage(this, 1, 'Problem during plotting.');
    return;
end;

% if numel(DWRow) > 1;
%     ANShowHideMessage(this, 1, 'This plot is not available for multiple runs.');
%     return;
% end;

if ~isfield(this.data, 'whisk');
    ANShowHideMessage(this, 1, 'This plot is not available for this dataset.');
    return;
end;

this.GUI.an.plotParamConfig = { ...
    'sgfilter', 'an', 'sgFiltFrameSize', 'text',  'numeric', 'Savitzky-Golay filter', ...
        'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'downsamp', 'an', 'downSampFactor',  'text',  'numeric', 'Down-sampling factor', ...
        'Temporal down-sampling factor, value must be bigger than 0.';
};

% get the axe handle where all the plotting elements should be displayed
axeH = this.GUI.handles.an.axe;

% get the ROISet of the first row
ROISet = ANGetROISetForRow(this, DWRows(1));

% convert to 3-digits format
nROIs = size(ROISet, 1);
for iROI = 1 : nROIs;
    if strcmp(ROISet{iROI, 1}, 'NPil'); continue; end;
    ROISet{iROI, 1} = sprintf('%03d', str2double(ROISet{iROI, 1}));
end;

% if no ROI list exists yet, fill the list
if isempty(get(this.GUI.handles.an.selROIList, 'String'));
    set(this.GUI.handles.an.selROIList, 'String', ROISet(:, 1), 'Value', 1 : nROIs);
% otherwise, restrict the ROIs for the analysis to the selected ones
else
    ROISelRange = get(this.GUI.handles.an.selROIList, 'Value'); % get the selected range
    ROISet = ROISet(ROISelRange, :); % restrict the ROISet
    nROIs = size(ROISet, 1); % update the number of ROIs
end;

% if nROIs > 1;
%     ANShowHideMessage(this, 1, 'This plot is not available for multiple ROIs.');
%     return;
% end;

% get the number of runs
nRuns = numel(DWRows);

% get the calcium traces
caTracesCell = this.data.img.caTraces(DWRows);
nImgFrames = size(caTracesCell{1}, 2);
% restrisct the data to the selected ROIs
caTracesCell = cellfun(@(caTrace) caTrace(ROISelRange, :), caTracesCell, 'UniformOutput', false);
% reshape in a matrix of nROIs x nRuns x nFrames
caTraces = reshape(cell2mat(caTracesCell), nROIs, nRuns, nImgFrames);

% get the imaging frame rate and number of frames
imgFrameRate = this.an.img.defaultFrameRate;
nImgFrames = size(caTraces, 3);
% get the sampling rate of the whisker data
whiskSampRate = this.data.whisk(DWRows(1)).frameRate;

% get the whisker data and truncate it
whiskAngles = arrayfun(@(iRow)this.data.whisk(iRow).angle, DWRows, 'UniformOutput', false);
% calculate the real number of points it should contain
nRealPointsWhiskData = round((nImgFrames / imgFrameRate) * whiskSampRate);
% only take the last points
whiskAngles = arrayfun(@(iRow)whiskAngles{iRow}(end - nRealPointsWhiskData + 1 : end), 1 : numel(whiskAngles), ...
    'UniformOutput', false);
% calculate the new number of frames for the whisker data
nWhiskFrames = size(whiskAngles{1}, 2);

% loop through each run and calculate the enveloppe
whiskAngleEnvs = cell(whiskAngles);
for iRun = 1 : nRuns;    
    % calculate the envelope
    whiskAngle = whiskAngles{iRun};
    winSize = round(nWhiskFrames * 0.005);
    whiskAngleEnvs{iRun} = zeros(1, nWhiskFrames);
    for iFrame = 1 : nWhiskFrames;    
        r = iFrame - winSize : iFrame + winSize;
        r(r < 1 | r > nWhiskFrames) = [];
        whiskAngleEnvs{iRun}(iFrame) = max(whiskAngle(r));    
    end;
end;
% get the concataneted version for all runs
allWhiskAngles = cell2mat(whiskAngles);
allWhiskAngleEnvs = cell2mat(whiskAngleEnvs);
nWhiskFrames = numel(allWhiskAngles);

if isempty(whiskAngle) || all(isnan(whiskAngle));
    ANShowHideMessage(this, 1, 'Missing whisker angle data.');
    return;
end;

% create a save name
saveName = 'Whisker angle and calcium trace';

% generate config for plotting
toPlots = { ...
    allWhiskAngles,     'angle',    [0 0 1],    '-', 1, 'Whisker angle',            (1 : nWhiskFrames) / whiskSampRate;
    allWhiskAngleEnvs,  'envelope', [0 0 1],    '-', 1, 'Whisker angle envelope',   (1 : nWhiskFrames) / whiskSampRate;
};

for iROI = 1 : nROIs;
    % up-sample the calcium trace for this run and this ROI
    caTraceUS = interp1DS(imgFrameRate, whiskSampRate, reshape(squeeze(caTraces(iROI, :, :))', nRuns * nImgFrames, 1)');
    caTraceUS(end + 1 : nWhiskFrames) = 0;
    % filter the trace if required
    if this.an.an.sgFiltFrameSize > 1 && mod(this.an.an.sgFiltFrameSize, 2) ~= 0;
        caTraceUS = sgolayfilt(caTraceUS, 1, this.an.an.sgFiltFrameSize);
    end;
    
    toPlots(end + 1, :) = { caTraceUS,  'DFF',      [1 0 0],    '-', 1, 'RFP [%DFF]',   (1 : nWhiskFrames) / whiskSampRate; }; %#ok<AGROW>

    % calculate the correlation
    corrValue = corr([caTraceUS', allWhiskAngleEnvs'], 'rows', 'pairwise');
    corrValue = corrValue(1, 2);

end;

% remove empty cells
toPlots(cellfun(@isempty, toPlots(:, 1)), :) = [];

% get the number of plots and axes
nPlots = size(toPlots, 1);
nAxes = sum(cell2mat(toPlots(:, 5)));
% get the basic position and axe handle
basePos = get(axeH, 'Position'); baseAxeH = axeH;
% get height of the axes
pad = basePos(4) * 0.03; baseHeight = ((basePos(4) - pad) / nAxes) - pad;
currPos = basePos; currPos(4) = baseHeight; currPos(2) = currPos(2) - baseHeight;
currAxe = [];

if baseHeight <= pad;
    ANShowHideMessage(this, 1, 'Too many ROIs selected.');
    return;
end;

% set the axes and do the plots
axeHandles = [];
for iPlot = 1 : nPlots;

    if toPlots{iPlot, 5} || isempty(currAxe);
        currPos(2) = currPos(2) + baseHeight + pad;
        currAxe = copyobj(baseAxeH, get(baseAxeH, 'Parent'));
        set(currAxe, 'Position', currPos, 'Tag', sprintf('TemporaryAxe%02d_analyser', iPlot));            
        hold(currAxe, 'on');
        axeHandles(end + 1) = currAxe; %#ok<AGROW>

        if iPlot == 1;
            xlabel(currAxe, 'Time [s]');
        else
            set(currAxe, 'XTick', []);
        end;
        ylabel(currAxe, toPlots{iPlot, 6});

        if iPlot == nPlots;
            title(currAxe, sprintf('%s, correlation: %.4f', saveName, corrValue), 'Interpreter', 'none');
        end;
    else
        hold(currAxe, 'on');
    end;
    t = toPlots{iPlot, 7};
    plot(currAxe, t, toPlots{iPlot, 1}, 'Color', toPlots{iPlot, 3}, 'LineStyle', toPlots{iPlot, 4});
    hold(currAxe, 'off');
    xlim(currAxe, [t(1) t(end)]);

end;
linkaxes(axeHandles, 'x');
delete(axeH);
axis(axeHandles, 'on');
this.GUI.handles.an.axe = axeHandles(1);

ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
end
