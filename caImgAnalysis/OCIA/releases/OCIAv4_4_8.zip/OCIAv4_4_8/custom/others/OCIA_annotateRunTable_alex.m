%% #OCIA:OCIA_annotateRunTable_alex
function OCIA_annotateRunTable_alex(this)

% extract the notebook's informations
DWExtractNotebookInfo(this);

% get the different run types from the table
runTypes = unique(this.dw.runTable(~cellfun(@isempty, this.dw.runTable(:, 8)), 8));

% use these run types as stimulus IDs: store them and set them in the GUI's drop-down list
this.dw.stimtypeIDs = ['-'; runTypes];
set(this.GUI.handles.dw.filt.stimtypeID, 'String', this.dw.stimtypeIDs);

% match the ROISets to the data
DWMatchROISetsToData(this);

DWDisplayRunTable(this); % display the table's display
    
end
