%% #OCIA:OCIA_annotateRunTable_default
function OCIA_annotateRunTable_default(this)

% extract the notebook's informations
DWExtractNotebookInfo(this);

% if there is an Analyser module and it has a behavior field
if ismember('an', fields(this)) && isfield(this.an, 'behav') && ~isempty(this.an.behav);
    
    DWMatchBehavTrialsToDataFiles(this); % match the behavior trial numbers to the imaging data
    DWMatchROISetsToData(this); % match the ROISets to the data
    DWMatchBehavDataToSpot(this); % match the behavior data to the spots
    
% otherwise just match the ROISets to the data and extract the spot's identity
else
    DWMatchROISetsToDataNoBehav(this);
    DWExtractSpotIdentity(this);
end;

DWDisplayRunTable(this); % display the table's display
    
end
