%% #OCIA_dataWatcherProcess_preProcRows
function OCIA_dataWatcherProcess_preProcRows(this, ~, ~, varargin)

% prepare the input variables
if numel(varargin) > 0;
    rowRange = varargin{1};
    if numel(varargin) > 1;
        preProcOpts = varargin{2};
    else
        preProcOpts = [];
    end;
else
    rowRange = this.dw.selRunTableRows;
    preProcOpts = [];
end;

% prepare a fake run table row to tell which rows should be process
runTableRows = this.dw.runTable(rowRange, 1 : 10);
runTableRows(:, 11) = num2cell(rowRange);

% call the pre-processing function in "parse" mode, which just prepares the rows
OCIAGetCallCustomFile(this, 'preprocess', this.dw.preProcessFunctionName, 1, ...
    { this, runTableRows, preProcOpts }, 1);

end
