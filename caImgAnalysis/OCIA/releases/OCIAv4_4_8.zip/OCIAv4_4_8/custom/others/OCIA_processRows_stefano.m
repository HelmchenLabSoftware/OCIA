%% #OCIA:OCIA_processRows_stefano
function OCIA_processRows_stefano(this)

processRowsTic = tic;

% empty/reset the run table, the plot list and the ROI list
set(this.GUI.handles.an.runTable, 'String', [], 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.plotList, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.selROIList, 'String', [], 'Value', [], 'ListBoxTop', 1);

classifyRowsTic = tic;
% gather information on selected rows in a new run table
runTableRows = this.dw.runTable(this.dw.selRunTableRows, 1 : 10);
% count the number of selected rows
nRows = size(runTableRows, 1);
% if no row selected, select all rows
if nRows == 0;
    DWSelRunTableRows(this, 1 : size(this.dw.runTable, 1));
    runTableRows = this.dw.runTable(this.dw.selRunTableRows, 1 : 10); % get all selected rows
    nRows = size(runTableRows, 1);
end;

% if still no row selected, abort with a warning
if nRows == 0;
    showWarning(this, 'OCIA:OCIA_processRows_stefano:NoRows', 'No rows selected.');
    return;
end;
    
% extend the runTable with 4 columns which will be:
%    data watcher's run table index, rowType, runID-text for listBox display and behavData
runTableRows(:, 11 : 14) = cell(nRows, 4);
runTableRows(:, 11) = num2cell(this.dw.selRunTableRows); % store the data watcher's run table index
o('#OCIA:AN:OCIA_processRows_stefano(): selected rows (%d): %s', nRows, sprintf('%d ', this.dw.selRunTableRows), 2, this.verb);

%% - #OCIA:AN:OCIA_processRows_stefano : parse/classify selected rows
% go through the selected rows, classify them and build a string to display for each of them
% add a * in the name of the files to show their loading state (* = not loaded)

% analyse the type of each row
for iRow = 1 : nRows;
    % get the row type
    rowType = DWGetRowType(this, runTableRows{iRow, 11});
    
    % process differently depending on the row type
    switch rowType;
            
        % imaging data
        case 'imgData';
%             dimTag = runTableRows{iRow, 5}; % get the dimension tag
            % if no dimtag from meta-data, try to get dimtag from the notebook
%             if isempty(dimTag); dimTag = runTableRows{iRow, 10}; end;
            % get the number of frames
%             nFrames = str2double(strrep(regexp(dimTag, 'x\d+$', 'match'), 'x', ''));
            nFrames = 200;
            % functional movies have at least "funcMovieNFrames"
            if nFrames > this.an.img.funcMovieNFramesLimit;
                % create a display text, with a star * on the front to show the row is not laoded yet
                runTableRows{iRow, 13} = sprintf('*%d: %s__%s', runTableRows{iRow, [11, 2, 3]});
                % store the row type
                runTableRows{iRow, 12} = 'imgData';
            end;
    end;
end;

% remove empty rows
runTableRows(cellfun(@isempty, runTableRows(:, 12)), :) = [];
nRows = size(runTableRows, 1);

%% - #OCIA:AN:OCIA_processRows_stefano : prepare analyser panel
% fill in the listBox items of the analyser panel
set(this.GUI.handles.an.runTable, 'String', runTableRows(:, 13), 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.plotList, 'Value', [], 'ListBoxTop', 1);

o('#OCIA:AN:OCIA_processRows_stefano(): classifing rows done (%3.1f sec).', toc(classifyRowsTic), 2, this.verb);
loadDataTic = tic;

% clear the plot area and show the loading message
ANClearPlot(this);
ANShowHideMessage(this, 1);
OCIAChangeMode(this, 'Analyser');

%% - #OCIA:AN:OCIA_processRows_stefano : load/process rows
% process and load each row one by one
for iRow = 1 : nRows;
    iDWRow = runTableRows{iRow, 11}; % get the current row in the data watcher's run table reference
    % process differently depending on the row type
    switch runTableRows{iRow, 12};
        
        % imaging data
        case 'imgData';
            
            % only do pre-processing steps if the caTraces data is not ready set
            if isempty(this.data.img.caTraces{iDWRow});
                
                % load all frames for the row
                DWLoadRow(this, iDWRow, 'full');
                
            end;
            
            % calculate the dFF/dRR trace for the row
            ANCalcDRRForRow(this, iDWRow);
            
    end;

    % update listBox items of the analyser panel to remove the loading-star
    runTableTexts = get(this.GUI.handles.an.runTable, 'String');
    runTableTexts{iRow} = regexprep(runTableTexts{iRow}, '^\*', ''); % remove the loading-star
    set(this.GUI.handles.an.runTable, 'String', runTableTexts, 'Value', [], 'ListBoxTop', 1);
    pause(0.005);

end;

% update listBox items of the analyser panel
runTableTexts = get(this.GUI.handles.an.runTable, 'String');
for iRow = 1 : nRows; runTableTexts{iRow} = regexprep(runTableTexts{iRow}, '^\*', ''); end; % remove all stars
set(this.GUI.handles.an.runTable, 'String', runTableTexts, 'Value', [], 'ListBoxTop', 1);

o('#OCIA:AN:OCIA_processRows_stefano(): loading data done (%3.1f sec).', toc(loadDataTic), 2, this.verb);

% reset the lists
set(this.GUI.handles.an.plotList, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.runTable, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.selROIList, 'Value', [], 'ListBoxTop', 1);

%% - #OCIA:AN:OCIA_processRows_stefano : plot
plotDataTic = tic;
currPlot = [];
% select a default first plot to display depending on the data type
switch runTableRows{1, 12};
    case 'imgData';
        currPlot = find(strcmp(this.an.plotTypes, 'ROICaTraces'));
    case 'behavData';
        currPlot = find(strcmp(this.an.plotTypes, 'DPrime'));
end;

% select the first row and the default plot
set(this.GUI.handles.an.runTable, 'Value', 1);
set(this.GUI.handles.an.plotList, 'Value', currPlot);

% save the analysis run table
this.an.runTable = runTableRows;

% do the plot
ANUpdatePlot(this, 'force');

o('#OCIA:AN:OCIA_processRows_stefano(): plotting done (%3.1f sec).', toc(plotDataTic), 2, this.verb);
o('#OCIA:AN:OCIA_processRows_stefano(): analyse rows done (%3.1f sec).', toc(processRowsTic), 2, this.verb);

end
