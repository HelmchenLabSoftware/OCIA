%% #OCIA:OCIA_startFunction_dataWatcherLoadAnalyse
function OCIA_startFunction_dataWatcherLoadAnalyse(this)

    % go to data watcher mode
    OCIAChangeMode(this, 'DataWatcher');

    % process the selected folder and extract the notebook informations
    DWProcessWatchFolder(this);

    % if there are any filters for row type or run type, select them
    GUIDWFiltH = this.GUI.handles.dw.filt;
    if ~isempty(get(GUIDWFiltH.rowtype, 'String')) || ~isempty(get(GUIDWFiltH.runtype, 'String'));
        DWFilterRunTable(this, 'new');
    end;

    % show welcome message
    showMessage(this, sprintf('Welcome to the OCIA v%s ! :-)', this.version));
    
    % check the right data types and load options
    SLRHandles = this.GUI.handles.dw.SLRDataOpts;
    set([SLRHandles.behav, SLRHandles.caTraces, SLRHandles.stim], 'Value', 1);
    set(this.GUI.handles.dw.SLROpts.SLRSelOnly, 'Value', 1);
    
    % load the data
    animalID = regexprep(this.dw.runTable{this.dw.selRunTableRows(1), 6}, '_', '');
    loadPath = sprintf('%s%s.h5', this.path.OCIASave, animalID);
    DWLoad(this, loadPath);
    
    % filter the table for available data only
    set(GUIDWFiltH.status, 'String', 'Proc$');
    DWFilterRunTable(this, 'new');
    
    % analyse the data
    OCIA_dataWatcherProcess_analyseRows(this);
    
end
