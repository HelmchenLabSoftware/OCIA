%% #OCIA:GUI:OCIA_createWindow_datawatcher
function OCIA_createWindow_datawatcher(this, pad)

BGWhite = {'Background', 'white'}; %#ok<*CCAT>
NormUnits = {'Units', 'normalized'};

%% - #OCIACreateWindow: DataWatcher
nHoriGroup = 8;
% width and height for standard elements within the data watcher panel
stdElemW = (1 - (nHoriGroup + 1) * pad) / nHoriGroup; stdElemH = 0.025;
PBElemH = 0.04; % height for the pushbuttons within the data watcher panel

%% -- #OCIACreateWindow: DataWatcher: watch type check boxes settings
watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypeLabels = this.dw.watchTypes(:, 2); % get all watch type labels
watchTypeVisibs = this.dw.watchTypes(:, 4); % get all watch type GUI visibilities
watchTypeToolTips = this.dw.watchTypes(:, 5); % get all watch type tooltips
% define the max number of rows and the number of items to place (+ 1 for the select all/none button)
nMaxRows = 5; nWatchTypes = sum(cell2mat(watchTypeVisibs)) + 1;
% calculate the number of acutal columns and rows
nCols = ceil(nWatchTypes / nMaxRows); nRows = min(nMaxRows, nWatchTypes);
%% #OCIACreateWindow: DataWatcher: watch type check boxes group
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, BGWhite{:}, NormUnits{:}};
watchTypeGroupW = stdElemW * 1.2; watchTypeGroupH = stdElemH * (nMaxRows + 1);
watchTypeGroupX = pad; watchTypeGroupY = 1 - watchTypeGroupH;
this.GUI.handles.dw.watchTypeGroup = uibuttongroup(commons{:}, 'Title', 'Watch type', ...
    'Tag', 'DWWatchTypeGroup', 'Position', [watchTypeGroupX, watchTypeGroupY, watchTypeGroupW, watchTypeGroupH]);
%% #OCIACreateWindow: DataWatcher: watch type check boxes
commons = {'Parent', this.GUI.handles.dw.watchTypeGroup, 'Style', 'checkbox', BGWhite{:}, NormUnits{:}};
inPad = 0.01; % inner padding for the radio group
elemW = (1 - (nCols + 1) * inPad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * inPad) / nRows; % height depends on the number of rows
elemPosX = inPad;       % initial X position
elemPosY = 1 - inPad;   % initial Y position
iRow = 1; iCol = 1; % init the row and column indexes
% go through all elements, create them and place them
for iType = 1 : numel(watchTypeIDs) + 1;
    
    % only update position for visible items
    if (iType == numel(watchTypeIDs) + 1) || (iType <= numel(watchTypeVisibs) && watchTypeVisibs{iType});
        visible = 'on';
        value = 0;
        if iRow > nMaxRows; iRow = 1; iCol = iCol + 1; end;
        elemPosX = (iCol - 1) * (inPad + elemW) + inPad; % calculate X position
        elemPosY = 1 - iRow * (elemH + inPad) + inPad; % calculate Y position
    else
        visible = 'off';
        value = 1;
    end;
    
    % select all/none checkbox
    if iType == numel(watchTypeIDs) + 1;
        commons = {'Parent', this.GUI.handles.dw.watchTypeGroup, 'Style', 'pushbutton', NormUnits{:}};
        this.GUI.handles.dw.watchTypesAllNone = uicontrol(commons{:}, 'String', 'All/None', ...
            'Tag', 'DWWatchTypeAllNone', 'Position', [elemPosX, elemPosY, elemW, elemH], 'ToolTipString', ...
            'Toggle between selecting all elements or none', 'Value', 0);
    % normal watch type checkbox
    else
        % create the GUI element
        this.GUI.handles.dw.watchTypes.(watchTypeIDs{iType}) = uicontrol(commons{:}, 'String', watchTypeLabels{iType}, ...
            'Tag', sprintf('DWWatchType_%s', watchTypeIDs{iType}), 'Position', [elemPosX, elemPosY, elemW, elemH], ...
            'ToolTipString', watchTypeToolTips{iType}, 'Visible', visible, 'Value', value);
    end;
    
    % only update position for visible items
    if iType <= numel(watchTypeVisibs) && watchTypeVisibs{iType};
        iRow = iRow + 1;
    end;
end;

%% -- #OCIACreateWindow: DataWatcher: raw/local button group
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, BGWhite{:}, NormUnits{:}};
rawLocSelW = watchTypeGroupW; rawLocSelH = stdElemH * 2;
rawLocSelX = watchTypeGroupX; rawLocSelY = watchTypeGroupY - pad - rawLocSelH;
this.GUI.handles.dw.rawLocGroup = uibuttongroup(commons{:}, 'Title', 'Raw/Local folder', ...
    'Position', [rawLocSelX rawLocSelY rawLocSelW rawLocSelH]);
%% -- #OCIACreateWindow: DataWatcher: raw/local radio buttons
commons = {'Parent', this.GUI.handles.dw.rawLocGroup, 'Style', 'radiobutton', BGWhite{:}, NormUnits{:}};
elemH = 1 - 2 * pad; elemW = (1 - 3 * pad) / 2;
this.GUI.handles.dw.rawLocSel.loc = uicontrol(commons{:}, 'String', 'local', 'Tag', 'DWLocSel', ...
    'Position', [pad, 1 - elemH, elemW, elemH], 'ToolTipString', 'Switch to local path');
this.GUI.handles.dw.rawLocSel.raw = uicontrol(commons{:}, 'String', 'raw', 'Tag', 'DWRawSel', ...
    'Position', [pad + elemW + pad, 1 - elemH, elemW, elemH], 'ToolTipString', 'Switch to raw path');
% set the change function and set the first "mode" to be selected 
set(this.GUI.handles.dw.rawLocGroup, 'SelectionChangeFcn', @(h, e)DWChangeRawLoc(this, h, e), ...
    'SelectedObject', this.GUI.handles.dw.rawLocSel.loc);

%% -- #OCIACreateWindow: DataWatcher: process folders button
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, 'Style', 'pushbutton'};
alignOffset = 0.0032; % small offset for better alignment
procFoldW = stdElemW * 0.8; procFoldH = 2 * PBElemH; procFoldX = watchTypeGroupX + watchTypeGroupW + pad;
procFoldY = 1 - pad - procFoldH - alignOffset;
this.GUI.handles.dw.procFold = uicontrol(commons{:}, 'String', 'UPDATE TABLE', 'Tag', 'DWProcFold', ...
    'Callback', @(h, e)DWProcessWatchFolder(this, h, e), 'Position', [procFoldX, procFoldY, procFoldW, procFoldH], ...
    'ToolTipString', ['Scan for relevant files and folders in the watch folder and its sub-folders and' ...
        'fill/update the run table accordingly.']);
   
%% -- #OCIACreateWindow: DataWatcher: skipMeta checkbox
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, BGWhite{:}};
skipMetaW = procFoldW; skipMetaH = stdElemH; skipMetaX = procFoldX; skipMetaY = procFoldY - pad - skipMetaH;
this.GUI.handles.dw.skipMeta = uicontrol(commons{:}, 'Style', 'checkbox', 'Tag', 'DWSkipMetadata', ...
    'String', 'Skip metadata proc.', 'Value', 1, 'Position', [skipMetaX, skipMetaY, skipMetaW, skipMetaH], ...
    'ToolTipString', 'Skip metadata processing: .xml header file, imaging file size estimation, etc. can be time consuming.');
 
%{
%% -- #OCIACreateWindow: DataWatcher: add new rows
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, BGWhite{:}};
addNewRowsW = stdElemW; addNewRowsH = stdElemH; addNewRowsX = procFoldX; addNewRowsY = skipMetaY - pad - addNewRowsH;
this.GUI.handles.dw.addNewRows = uicontrol(commons{:}, 'Style', 'checkbox', 'Tag', 'DWAddNewRows', ...
    'String', 'Add new rows', 'Value', 0, 'Position', [addNewRowsX, addNewRowsY, addNewRowsW, addNewRowsH], ...
    'ToolTipString', 'Add new rows to the current table instead of starting over a new table.', ...
    'Enable', 'off');
%}

%% -- #OCIACreateWindow: DataWatcher: runTable filtering
%% #OCIACreateWindow: DataWatcher: runTable filtering: filtering panel
alignOffset = 0.005;
nFilt = size(this.GUI.dw.filtElems, 1); nFiltY = sum(cell2mat(this.GUI.dw.filtElems(:, 3))) + 1;
filtPanW = stdElemW; filtPanH = stdElemH * 8 + alignOffset;
filtPanX = procFoldX + procFoldW + pad; filtPanY = 1 - pad - filtPanH + alignOffset;
this.GUI.handles.dw.filterPanel = uipanel('Parent', this.GUI.handles.panels.DataWatcherPanel, BGWhite{:}, ...
    NormUnits{:}, 'Title', 'Row filters', 'Tag', 'DWFiltPanel', 'Position', [filtPanX, filtPanY, filtPanW, filtPanH]);
%% #OCIACreateWindow: DataWatcher: runTable filtering: filtering elements
inPad = 0.025; % inner padding for the filter "group"
filtElemH = (1 - (nFiltY + 1) * inPad) / nFiltY;
filtElemX = inPad; filtElemY = 1 - inPad - filtElemH;
% adjust the font sizes
fontSizeValues = [52 60];
if nFilt < 4; fontSizeValues = [32 40]; end;
commons = {'Parent', this.GUI.handles.dw.filterPanel,BGWhite{:}, NormUnits{:}};
commonsDropDown = [commons, 'Style', 'popupmenu', 'FontSize', filtElemH * fontSizeValues(1)];
commonsTextField = [commons, 'Style', 'edit', 'FontSize', filtElemH * fontSizeValues(2)];

for iFilt = 1 : nFilt;
    filtName = this.GUI.dw.filtElems{iFilt, 1};
    filtType = this.GUI.dw.filtElems{iFilt, 2};
    filtWidth = this.GUI.dw.filtElems{iFilt, 3};
    filtW = filtWidth - (filtWidth * inPad * 2);

    switch filtType;
        
        case 'dropdown';
            this.GUI.handles.dw.filt.([filtName 'ID']) = uicontrol(commonsDropDown{:}, ...
                'String', this.dw.([filtName 'IDs']), 'Tag', ['DW_' filtName 'IDs'], ...
                'Position', [filtElemX, filtElemY, filtW, filtElemH], 'ToolTipString', ['Filter for ' filtName]);
            
        case 'textfield';
            this.GUI.handles.dw.filt.(filtName) = uicontrol(commonsTextField{:}, 'String', '', ...
                'Tag', ['DW_' filtName 'IDs'], 'Position', [filtElemX, filtElemY, filtW, filtElemH], ...
                'ToolTipString', ['Filter for ' filtName ' using regular expressions']);
        
    end;
    
    if filtElemX + filtWidth >= 1;
        filtElemY = filtElemY - inPad - filtElemH;
        filtElemX = inPad;
    else
        filtElemX = filtElemX + filtW;
    end;
    
end;
%% ---- #OCIACreateWindow: DataWatcher: runTable filtering: filter buttons
commons = {'Parent', this.GUI.handles.dw.filterPanel, NormUnits{:}, 'Style', 'pushbutton'};
filtElemX = inPad;
filtPushButW = (1 - 3 * inPad) / 2; filtPushButRightX = filtElemX + inPad + filtPushButW;
this.GUI.handles.dw.filtNew = uicontrol(commons{:}, 'String', 'Filter - new', 'Tag', 'DWFiltNew', ...
    'Position', [filtElemX, filtElemY, filtPushButW, filtElemH], ...
    'Callback', @(~, ~)DWFilterRunTable(this, 'new'), ...
    'ToolTipString', 'Filter with the current settings, making a *NEW* selection');
this.GUI.handles.dw.filtAdd = uicontrol(commons{:}, 'String', 'Filter - add', 'Tag', 'DWFiltNew', ...
    'Position', [filtPushButRightX, filtElemY, filtPushButW, filtElemH], ...
    'Callback', @(~, ~)DWFilterRunTable(this, 'add'), ...
    'ToolTipString', 'Filter with the current settings, *ADDING* to current selection');

%% -- #OCIACreateWindow: DataWatcher: save and load
%% #OCIACreateWindow: DataWatcher: save/load buttons
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, 'Style', 'pushbutton'};
alignOffsetY = 0.0032; saveW = stdElemW; saveH = PBElemH;
saveX = filtPanX + filtPanW + pad; saveY = 1 - pad - saveH - alignOffsetY;
this.GUI.handles.dw.save = uicontrol(commons{:}, 'String', 'Save', 'Tag', 'DWSave', ...
    'Position', [saveX, saveY, saveW, saveH], 'Callback', @(~, ~)DWSave(this, []));
loadW = stdElemW; loadH = saveH; loadX = saveX + saveW + pad; loadY = saveY;
this.GUI.handles.dw.load = uicontrol(commons{:}, 'String', 'Load', ...
    'Callback', @(~, ~)DWLoad(this, []), 'Tag', 'DWLoad', 'Position', [loadX, loadY, loadW, loadH]);
resetW = stdElemW; resetH = saveH; resetX = loadX + loadW + pad; resetY = saveY;
this.GUI.handles.dw.reset = uicontrol(commons{:}, 'String', 'Reset', ...
    'Callback', @(~, ~)DWReset(this, []), 'Tag', 'DWLoad', 'Position', [resetX, resetY, resetW, resetH]);

%% #OCIACreateWindow: DataWatcher: save/load data options group
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, BGWhite{:}};
alignOffsetY = 0.005;
SLROptDataGroupW = stdElemW * 3 + 2 * pad; SLROptDataGroupH = PBElemH * 2.2;
SLROptDataGroupX = saveX; SLROptDataGroupY = saveY - SLROptDataGroupH - pad + alignOffsetY;
this.GUI.handles.dw.SLROptDataGroup = uibuttongroup(commons{:}, 'Title', 'To save / load / reset elements', ...
    'Tag', 'SLROptDataGroup', 'Position', [SLROptDataGroupX, SLROptDataGroupY, SLROptDataGroupW, SLROptDataGroupH]);
%% #OCIACreateWindow: DataWatcher: save/load data options checkboxes
commons = {'Parent', this.GUI.handles.dw.SLROptDataGroup, 'Style', 'checkbox', ...
    BGWhite{:}, NormUnits{:}, 'Value', 0};
% options with their tooltip
optIDs = this.dw.dataSaveConfig(:, 1);
optNames = this.dw.dataSaveConfig(:, 2);
optTooltips = this.dw.dataSaveConfig(:, 3);
% define the max number of rows and the number of items to place
nMaxRows = 3; nMaxCols = 3; nOpts = numel(optNames); %#ok<NASGU>
% calculate the number of acutal columns and rows
% nCols = ceil(nOpts / nMaxRows); nRows = min(nMaxRows, nOpts);
nRows = ceil(nOpts / nMaxCols); nCols = min(nMaxCols, nOpts);
inPad = 0.01; % inner padding for the radio group
elemW = (1 - (nCols + 1) * inPad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * inPad) / nRows; % height depends on the number of rows
iRow = 1; iCol = 1; % init the row and column indexes
% go through all elements, create them and place them
for iOpt = 1 : nOpts;
%     if iRow > nRows; iRow = 1; iCol = iCol + 1; end;
    if iCol > nCols; iCol = 1; iRow = iRow + 1; end;
    elemPosX = (iCol - 1) * (inPad + elemW) + inPad; % calculate X position
    elemPosY = 1 - iRow * (elemH + inPad) + inPad; % calculate Y position
    % create the GUI element
    this.GUI.handles.dw.SLRDataOpts.(optIDs{iOpt}) = uicontrol(commons{:}, 'String', optNames{iOpt}, ...
        'Tag', sprintf('DWSLRDataOpts%s', optIDs{iOpt}), 'Position', [elemPosX, elemPosY, elemW, elemH], ...
        'ToolTipString', optTooltips{iOpt});
%     iRow = iRow + 1;
    iCol = iCol + 1;
end;

%% #OCIACreateWindow: DataWatcher: save/load options group
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, BGWhite{:}};
alignOffsetY = 0.006;
SLROptGroupW = stdElemW * 3 + 2 * pad; SLROptGroupH = PBElemH * 1.7;
SLROptGroupX = saveX; SLROptGroupY = SLROptDataGroupY - SLROptGroupH - pad + alignOffsetY;
this.GUI.handles.dw.SLROptGroup = uibuttongroup(commons{:}, 'Title', 'Save / load options', 'Tag', ...
    'SLROptGroup', 'Position', [SLROptGroupX, SLROptGroupY, SLROptGroupW, SLROptGroupH]);
%% #OCIACreateWindow: DataWatcher: save/load options checkboxes
commons = {'Parent', this.GUI.handles.dw.SLROptGroup, 'Style', 'checkbox', BGWhite{:}, NormUnits{:}, 'Value', 0};
% options with their tooltip
optIDs = this.dw.dataSaveOptionsConfig(:, 1);
optNames = this.dw.dataSaveOptionsConfig(:, 2);
optTooltips = this.dw.dataSaveOptionsConfig(:, 3);
% define the max number of rows and the number of items to place button
nMaxRows = 2; nOpts = numel(optNames);
% calculate the number of acutal columns and rows
nCols = ceil(nOpts / nMaxRows); nRows = min(nMaxRows, nOpts);
inPad = 0.01; % inner padding for the radio group
elemW = (1 - (nCols + 1) * inPad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * inPad) / nRows; % height depends on the number of rows
iRow = 1; iCol = 1; % init the row and column indexes
% go through all elements, create them and place them
for iOpt = 1 : nOpts;
    if iRow > nRows; iRow = 1; iCol = iCol + 1; end;
    elemPosX = (iCol - 1) * (inPad + elemW) + inPad; % calculate X position
    elemPosY = 1 - iRow * (elemH + inPad) + inPad; % calculate Y position
    % create the GUI element
    this.GUI.handles.dw.SLROpts.(optIDs{iOpt}) = uicontrol(commons{:}, 'String', optNames{iOpt}, ...
        'Tag', sprintf('SLROpts%s', optIDs{iOpt}), 'Position', [elemPosX, elemPosY, elemW, elemH], ...
        'ToolTipString', optTooltips{iOpt});
    iRow = iRow + 1;
end;

%% -- #OCIACreateWindow: DataWatcher: draw ROIs
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, 'Style', 'pushbutton'};
alignOffset = -0.003;
stepButtons = this.GUI.dw.dataWatcherProcessStepButtons;
stepButtonW = stdElemW; stepButtonH = PBElemH;
stepButtonX = resetX + resetW + pad; stepButtonY = 1 - pad - stepButtonH + alignOffset;
for iStep = 1 : size(stepButtons, 1);
    this.GUI.handles.dw.(stepButtons{iStep, 1}) = uicontrol(commons{:}, 'String', stepButtons{iStep, 2}, ...
        'Tag', stepButtons{iStep, 3}, 'Position', [stepButtonX, stepButtonY, stepButtonW, stepButtonH], ...
        'ToolTipString', stepButtons{iStep, 4});
    stepButtonY = stepButtonY - stepButtonH - pad;
    
    % get the DataWatcher process function's handle
    callBackFun = OCIAGetCallCustomFile(this, 'dataWatcherProcess', stepButtons{iStep, 1}, 0, {}, 0);    
    % add callback if it exists
    if ~isempty(callBackFun);
        set(this.GUI.handles.dw.(stepButtons{iStep, 1}), 'Callback', @(h, e)callBackFun(this, h, e));
    end;
end;
% stepButtonY = stepButtonY + stepButtonH + pad; % remove last modification so that Y position is correctly set for later

%% -- #OCIACreateWindow: DataWatcher: preview image (thumbnail)
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel};
prevImW = 1.58 * stdElemW; prevImH = prevImW; alignOffsetX = 0.035; alignOffsetY = -0.004;
prevImX = stepButtonX + stepButtonW + pad - alignOffsetX; prevImY = 1 - pad - prevImH + alignOffsetY;
this.GUI.handles.dw.prevImAx = axes(commons{:}, ...
    'Position', [prevImX, prevImY, prevImW, prevImH], 'Color', 'white', 'XColor', 'white', 'YColor', 'white', ...
    'XGrid', 'off', 'YGrid', 'off', 'XTick', [], 'YTick', []);
% the creation of the image is done later to avoid weird flickering effect due to imshow
this.GUI.handles.dw.prevIm = [];
%% -- #OCIACreateWindow: DataWatcher: preview image (thumbnail) open as figure button
openPrevW = 0.1 * prevImW; openPrevH = openPrevW; alignOffsetX = 0.032;
openPrevX = prevImX + prevImW - pad - openPrevW - alignOffsetX; openPrevY = prevImY + prevImH - openPrevH - pad;
this.GUI.handles.dw.openPrevAx = uicontrol(commons{:}, NormUnits{:}, 'Style', 'pushbutton', 'String', '^', ...
    'Position', [openPrevX, openPrevY, openPrevW, openPrevH], 'Callback', @(h, e) DWOpenPreviewAsFigure(this, h, e), ...
    'ToolTipString', 'Open preview in an external figure.');

%% -- #OCIACreateWindow: DataWatcher: runTable table
% define dimensions for watch folder display
tableX = pad; tableW = 1 - tableX - pad; tableY = pad;
watchFoldDispH = 0.02; watchFoldDispW = tableW * 0.475;
figBorder = 9; scrollBarW = 18; randomOffset = 0;
tableH = min(rawLocSelY, procFoldY) - watchFoldDispH - 3 * pad;
watchFoldDispX = tableX; watchFoldDispY = tableY + tableH + pad;
tableWInPixel = tableW * this.GUI.pos(3) - scrollBarW - 2 * figBorder + randomOffset;
colW = cellfun(@(x) x * tableWInPixel, this.GUI.dw.runTableColW);
if isGUI(this);
    this.GUI.handles.dw.runTable = uitable('Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, ...
        'Position', [tableX tableY tableW tableH], 'Tag', 'DWRunTable', 'Data', this.dw.runTable, 'RowName', [], ...
        'ColumnName', this.GUI.dw.runTableColNames, 'ColumnWidth', num2cell(colW), ...
        'CellSelectionCallback', @(h, e)DWRunTableClick(this, h, e));
else
    this.GUI.handles.dw.runTable = uicontrol('Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}, ...
        'Position', [tableX tableY tableW tableH], 'Tag', 'DWRunTable');
end;
%% -- #OCIACreateWindow: DataWatcher: watchFolder path display
commons = {'Parent', this.GUI.handles.panels.DataWatcherPanel, NormUnits{:}};
this.GUI.handles.dw.watchFoldDisp = uicontrol(commons{:}, 'Style', 'text', 'Tag', 'DWWatchFoldDisp', ...
    'String', sprintf('Watch folder: %s', this.dw.watchFolder), 'HorizontalAlignment', 'left', ...
    'Position', [watchFoldDispX, watchFoldDispY, watchFoldDispW, watchFoldDispH], BGWhite{:});
%% -- #OCIACreateWindow: DataWatcher: change watchFolder button
alignOffset = 0.002;
changeWFW = tableW * 0.5 - watchFoldDispW - pad; changeWFH = watchFoldDispH + 2 * alignOffset;
changeWFX = watchFoldDispX + watchFoldDispW + pad; changeWFY = watchFoldDispY - alignOffset;
this.GUI.handles.dw.changeWatchFold = uicontrol(commons{:}, 'Style', 'pushbutton', 'Tag', 'DWChangeWatchFold', ...
    'String', '...', 'Position', [changeWFX, changeWFY, changeWFW, changeWFH], ...
    'Callback', @(h, e)DWUpdateWatchFolderPath(this, ''));
set(this.GUI.handles.dw.changeWatchFold, 'ToolTipString', 'Change watch folder''s path');
%% -- #OCIACreateWindow: DataWatcher: waitbar
alignOffset = 0.002;
waitBarW = 1 - 2 * pad - changeWFW - changeWFX - alignOffset; waitBarH = watchFoldDispH;
waitBarX = changeWFX + changeWFW + pad; waitBarY = watchFoldDispY;
this.GUI.handles.dw.waitBar = axes('Parent', this.GUI.handles.panels.DataWatcherPanel, 'Tag', 'DWWaitBar', ...
    'Position', [waitBarX, waitBarY, waitBarW, waitBarH], 'Color', 'black', 'XColor', 'black', 'YColor', 'black', ...
    'XGrid', 'off', 'YGrid', 'off', 'XTick', [], 'YTick', [], 'YLim', [0 1], 'XLim', [0 100]);
DWWaitBar(this, 0); % set to 0

%% -- #OCIACreateWindow: DataWatcher: update filters and watch types
DWUpdateFiltersAndWatchTypes(this)

end
