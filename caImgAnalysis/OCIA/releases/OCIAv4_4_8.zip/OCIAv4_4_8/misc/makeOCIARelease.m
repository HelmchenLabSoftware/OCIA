% make a release of the OCIA

% define target directory
targetDirRoot = 'E:/';

% get the version
FID = fopen(which('OCIA'));
A = regexp(fscanf(FID, '%s'), 'version=.(?<version>[\d\.]+).;', 'names');
fclose(FID);
version = regexprep(A.version, '\.', '_');

% get the target dir
targetDir = regexprep(sprintf('%sOCIAv%s\\', targetDirRoot, version), '\\', '/');

% get the OCIA folder
OCIASrcDir = regexprep(which('OCIA'), '\\', '/');
OCIASrcDir = regexprep(OCIASrcDir, '@OCIA/OCIA.m$', '');

% copy the OCIA files
copyfile([OCIASrcDir '*'], targetDir);

% make an 'etc' folder and copy all required functions for the main OCIA file
etcDir = [targetDir 'etc/'];
exportMfiles('OCIA', 0, 0, etcDir);

% make an 'etc' folder and copy all required functions for the custom files
customFolders = dir([OCIASrcDir 'custom/*']); % get custom folders
customFoldersNames = arrayfun(@(i)customFolders(i).name, 1 : numel(customFolders), 'UniformOutput', false);
customFoldersNames(1 : 2) = []; % remove '.' and '..'
% go through each folder and get each file's name
for iFolder = 1 : numel(customFoldersNames);
    customFiles = dir([OCIASrcDir 'custom/' customFoldersNames{iFolder} '/*']); % get custom files
    customFilesNames = arrayfun(@(i)customFiles(i).name, 1 : numel(customFiles), 'UniformOutput', false);
    customFilesNames(1 : 2) = []; % remove '.' and '..'
    for iHelperFile = 1 : numel(customFilesNames);
        exportMfiles(customFilesNames{iHelperFile}, 0, 0, etcDir);
    end;
    
    % remove files that are in the custom files
    etcFiles = dir([etcDir '*']); % get etc folder files
    etcFilesNames = arrayfun(@(i)etcFiles(i).name, 1 : numel(etcFiles), 'UniformOutput', false);
    etcFilesNames(1 : 2) = []; % remove '.' and '..'
    for iEtcFile = 1 : numel(etcFilesNames);
        if ismember(etcFilesNames{iEtcFile}, customFilesNames);
            delete([etcDir etcFilesNames{iEtcFile}]);
        end;
    end;    
end;

% remove files that are already in the @OCIA folder or in the custom files
OCIATargetDir = [targetDir '@OCIA/'];
OCIAFiles = dir([OCIATargetDir '*']); % get OCIA files
OCIAFileNames = arrayfun(@(i)OCIAFiles(i).name, 1 : numel(OCIAFiles), 'UniformOutput', false);
OCIAFileNames(1 : 2) = []; % remove '.' and '..'
etcFiles = dir([etcDir '*']); % get etc folder files
etcFilesNames = arrayfun(@(i)etcFiles(i).name, 1 : numel(etcFiles), 'UniformOutput', false);
etcFilesNames(1 : 2) = []; % remove '.' and '..'
for iEtcFile = 1 : numel(etcFilesNames);
    if ismember(etcFilesNames{iEtcFile}, OCIAFileNames);
        delete([etcDir etcFilesNames{iEtcFile}]);
    end;
end;

zipFilePath = regexprep(targetDir, '/$', '.zip');
zip(zipFilePath, regexprep(targetDir, '/$', ''));

copyfile(zipFilePath, regexprep(zipFilePath, targetDirRoot, 'W:/Neurophysiology/Software/Matlab/OCIA/'));
