function RP = playTDTSound(y, attenuation, fig)
% Runs a Tucker Davis circuit to play a sound.

if isempty(attenuation);
    attenuation = 0;
end;

% specify the path of the data-playing circuit
circuitPath = 'C:\TDT\Balazs_RPvdsEx_Circuits\PlayData.rcx';

% create the ActiveX control
if ~exist('fig', 'var') || isempty(fig);
    fig = gcf;
end;
RP = actxcontrol('RPco.x', [0 0 0 0], fig);
if RP.ConnectRZ6('GB', 1) == 0; error('TDT:Connect', 'Could not connect!'); end;

RP.Halt; % Stop any processing chains running
RP.ClearCOF; % Clear all the buffers and circuits

RP.LoadCOFsf(circuitPath, 4); % 4 corresponds to 100 kHz (97656.25 Hz)
% RP.LoadCOFsf(circuitPath, 5); % 5 corresponds to 200 kHz (195312.5 Hz)

% set tags
RP.SetTagVal('bufferSize', numel(y));
RP.SetTagVal('attenuation', attenuation);

RP.Run; % Start circuit

% set tags and load data
RP.SetTagVal('bufferSize', numel(y));
RP.WriteTagV('data', 0, y);

% pause(0.1);
% RP.SoftTrg(1);
% 
% try
%     while RP.GetTagVal('bufferPos');
%         pause(0.5);
%         o('  - bufferPos: %d, bufferSize: %d', RP.GetTagVal('bufferPos'), RP.GetTagVal('bufferSize'), 0, 0);
%     end;
% catch err; %#ok<NASGU>
% end;
% 
% RP.Halt;
% 
% RP.release;
% close(gcf);

end