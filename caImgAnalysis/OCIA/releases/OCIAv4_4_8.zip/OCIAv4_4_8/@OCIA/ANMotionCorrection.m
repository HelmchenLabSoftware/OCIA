%% #OCIA:AN:ANMotionCorrection
function validRow = ANMotionCorrection(this, iDWRow, varargin)

validRow = true; % default is valid

% if pre-processing not required or if data was already pre-processed, abort
if ~any(strcmp(this.an.an.preProcOptions, 'moCorr')) || any(strcmp(this.data.preProcType{iDWRow}, 'moCorr'));
    return;
end;

switch this.an.an.moCorrType;
    
    case 'TurboReg';
        
        validRow = ANMotionCorrectionTurboReg(this, iDWRow, varargin{:});
        
    case 'HMM';
    
        validRow = ANMotionCorrectionHMM(this, iDWRow, varargin{:});
        
    otherwise;
        
        validRow = false;
        showWarning('OCIA:AN:ANMotionCorrection:UnknownMotionCorrectionType', ...
            sprintf('Unknown motion correction type: %s', this.an.an.moCorrType));
end;


end
