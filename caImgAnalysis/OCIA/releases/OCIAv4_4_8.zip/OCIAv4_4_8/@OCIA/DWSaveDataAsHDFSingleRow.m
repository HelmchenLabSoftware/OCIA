function DWSaveDataAsHDFSingleRow(this, iDWRow, runID, saveText, savePath)
% saves the imaging data to the HDF5 file

% generate a configuration that specifies how the data should be saved as a cell-array with 7 columns:
%   { data field name, data to save, sub-cells save name, names of the attributes to save, attributes to save, display name }
dataConf = cell(0, 8);

% apply different data modes' save configuration
for iMode = 1 : numel(this.dw.dataModes);
    % call the data save configuration function
    modeName = lower(this.dw.dataModes{iMode});
    [~, dataConf] = OCIAGetCallCustomFile(this, 'dataSaveConfig', modeName, 1, { this, iDWRow, dataConf }, 0);    
end;
% get the number of fields and extend the config to store the data's size and the data save options
nFields = size(dataConf, 1);

% get the data's size or leave empty if no data
for iField = 1 : nFields;
    dataSetGetHandle = dataConf{iField, 2}; % get the handle of the set/get function for this field
    data = dataSetGetHandle(dataConf{iField, 1}, []); % get the data for this field
    if isempty(data); % if no data, set the size to empty
        dataConf{iField, 7} = [];
    elseif iscell(data); % if data is a cell-array, get the size of each element
        dataConf{iField, 7} = arrayfun(@(i)size(data{i}), 1 : numel(data), 'UniformOutput', false);
    elseif isstruct(data); % if data is a structure, get the size of each field
        dataConf{iField, 7} = cellfun(@(x)size(data.(x)), fieldnames(data), 'UniformOutput', false);
    else % otherwise just use the size of the data
        dataConf{iField, 7} = size(data);
    end;
end;

% get the data's save options
for iField = 1 : nFields;
    if ~isempty(this.dw.HDF5GZipLevel) && this.dw.HDF5GZipLevel ~= 0; % if data must be compressed
        dataSetGetHandle = dataConf{iField, 2}; % get the handle of the set/get function for this field
        data = dataSetGetHandle(dataConf{iField, 1}, []); % get the data for this field
        if iscell(data) || isstruct(data); % if data is a cell-array or a structure, use the size of each element
            dataConf{iField, 8} = cellfun(@(c) { c, 'ChunkSize', c / 4, 'Deflate', this.dw.HDF5GZipLevel }, ...
                dataConf{iField, 7}, 'UniformOutput', false);
        else % otherwise just use the size of the data
            dataConf{iField, 8} = { dataConf{iField, 7}, 'ChunkSize', dataConf{iField, 7} / 4, ...
                'Deflate', this.dw.HDF5GZipLevel };
        end;
    else % if data must *not* be compressed
        dataConf(iField, 8) = dataConf(iField, 7);
    end;
end;

% get the path parts for this run
pathParts = regexp(this.dw.runTable{iDWRow, 1}, '\w+', 'match');
% create the data set's path
dataSetRoot = sprintf(repmat('/%s', 1, numel(this.dw.savePathParts)), pathParts{this.dw.savePathParts});
% get the dataset's path with a replaceable item tag '_DATA:TYPE_'
datasetPath = sprintf('%s/_DATA:TYPE_/%s', dataSetRoot, runID);

% go through each field and save the data
for iField = 1 : nFields;
    
    % get the field name, the data and the data options for that field
    fieldName = dataConf{iField, 1};
    dataSetGetHandle = dataConf{iField, 2}; % get the handle of the set/get function
    data = dataSetGetHandle(fieldName, []); % get the data
    subCellName = dataConf{iField, 3};
    attribsToStoreNames = dataConf{iField, 4};
    attribsSetGetHandle = dataConf{iField, 5}; % get the handle of the set/get function
    displayName = dataConf{iField, 6};
    dataSize = dataConf{iField, 7};
    dataOpts = dataConf{iField, 8};
    
    % if the data should not be saved, skip this field
    if isempty(dataSize) || ~get(this.GUI.handles.dw.SLRDataOpts.(fieldName), 'value'); continue; end;
    
    % if the data is a cell-array, loop through and save each cell
    if iscell(data);
        % loop through and save each cell
        for iCell = 1 : numel(data);
            
            try % catch errors
                cellName = sprintf(subCellName, iCell);
                showMessage(this, sprintf('%s - %s - %s ...', saveText, displayName, cellName), 'yellow');
                datasetPathData = sprintf('%s/%s', strrep(datasetPath, '_DATA:TYPE_', fieldName), cellName);
                % make sure the group is not there anymore
                if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPathData); end;
                % save the data
                h5create(savePath, datasetPathData, dataOpts{iCell});
                h5write(savePath, datasetPathData, data{iCell});
            
            % if an error occured, pursue the saving but display an error message
            catch err;
                saveTextError = saveText; saveTextError(1) = lower(saveTextError(1));
                showWarning(this, 'OCIA:DWSaveDataAsHDFSingleRow:saveError', ...
                    sprintf('Error while %s - %s - %s: %s (%s)\n%s', saveTextError, displayName, cellName, ...
                    err.message, err.identifier, getStackText(err)), 'red');
                pause(1);
                continue;
            end;
        end;
        
    % if the data is a structure, loop through and save each field
    elseif isstruct(data);
        
        showMessage(this, sprintf('%s - %s ...', saveText, displayName), 'yellow');
        subFieldNames = fieldnames(data); % get the fields names of the structure
        for iSubField = 1 : numel(subFieldNames);
            subFieldName = subFieldNames{iSubField}; % get the sub-field's name
            
            try % catch errors
                
                % if not a single value (dimensions are 1x1x...), save as dataset
                if any(dataSize{iSubField} > 1);
%                     showMessage(this, sprintf('%s - %s - %s ...', saveText, displayName, subFieldName), 'yellow');
                    datasetPathData = sprintf('%s/%s', strrep(datasetPath, '_DATA:TYPE_', fieldName), subFieldName);
                    % make sure the group is not there anymore
                    if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPathData); end;
                    % save the data
                    h5create(savePath, datasetPathData, dataOpts{iSubField});
                    h5write(savePath, datasetPathData, data.(subFieldName));

                % if only a single value, save as attribute
                else                
                    % if field is empty, save as NaN
                    if isempty(data.(subFieldName)); data.(subFieldName) = NaN; end;
%                     showMessage(this, sprintf('%s - %s - %s (attribute) ...', saveText, displayName, subFieldName), 'yellow');
                    datasetPathAttrib = strrep(datasetPath, '_DATA:TYPE_', fieldName);
                    h5createIntermediateGroup(savePath, datasetPathAttrib); % make sure the intermediate group exists
                    h5writeatt(savePath, datasetPathAttrib, subFieldName, data.(subFieldName));

                end;
            
            % if an error occured, pursue the saving but display an error message
            catch err;
                saveTextError = saveText; saveTextError(1) = lower(saveTextError(1));
                showWarning(this, 'OCIA:DWSaveDataAsHDFSingleRow:saveError', ...
                    sprintf('Error while %s - %s - %s: %s (%s)\n%s', saveTextError, displayName, subFieldName, ...
                    err.message, err.identifier, getStackText(err)), 'red');
                pause(1);
                continue;
            end;
            
        end;
        
    % if data is not a cell-array, just save it normally
    else
        
        try % catch errors
            showMessage(this, sprintf('%s - %s ...', saveText, displayName), 'yellow');
            datasetPathData = strrep(datasetPath, '_DATA:TYPE_', fieldName);
            % make sure the group is not there anymore
            if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPathData); end;
                % save the data
            h5create(savePath, datasetPathData, dataOpts);
            h5write(savePath, datasetPathData, data);
            
        % if an error occured, pursue the saving but display an error message
        catch err;
            saveTextError = saveText; saveTextError(1) = lower(saveTextError(1));
            showWarning(this, 'OCIA:DWSaveDataAsHDFSingleRow:saveError', ...
                sprintf('Error while %s - %s: %s (%s)\n%s', saveTextError, displayName, ...
                err.message, err.identifier, getStackText(err)), 'red');
            pause(1);
            continue;
        end;
        
    end;
    
    % save the raw load type as an attribute of the runID group
    if ~isempty(attribsToStoreNames) && ~isempty(attribsSetGetHandle);
        
        for iAttrib = 1 : numel(attribsToStoreNames);
            try % catch errors
                
                dataSetGetHandle = attribsSetGetHandle; % get the handle of the set/get function
                attrib = dataSetGetHandle(attribsToStoreNames{iAttrib}, []); % get the data
                datasetPathAttrib = strrep(datasetPath, '_DATA:TYPE_', fieldName);
                h5createIntermediateGroup(savePath, datasetPathAttrib); % make sure the intermediate group exists
                h5writeatt(savePath, datasetPathAttrib, attribsToStoreNames{iAttrib}, attrib);
            
            % if an error occured, pursue the saving but display an error message
            catch err;
                saveTextError = saveText; saveTextError(1) = lower(saveTextError(1));
                showWarning(this, 'OCIA:DWSaveDataAsHDFSingleRow:saveError', ...
                    sprintf('Error while %s - %s attribute %s: %s (%s)\n%s', saveTextError, displayName, ...
                    attribsToStoreNames{iAttrib}, err.message, err.identifier, getStackText(err)), 'red');
                pause(1);
                continue;
            end;
        end;
    end;

end;

end