%% #OCIA:DWUpdateRowStatus
function DWUpdateRowStatus(this, iDWRow, jTable)
    
if isGUI(this) && (~exist('jTable', 'var') || isempty(jTable));
    jTable = getJTable(this, 'DWRunTable');
end;

if isGUI(this) && exist('jTable', 'var') && ~isempty(jTable);
    loadType = this.data.rawLoadType{iDWRow};
    if ~isempty(loadType);  loadState = [upper(loadType(1)) loadType(2:end)];
    else                    loadState = 'none';
    end;    
    if ~isempty(this.data.img.caTraces{iDWRow});
        loadState = [loadState ' | Proc'];
    end;
    this.dw.runTable{iDWRow, 17} = loadState;
    jTable.setValueAt(loadState, iDWRow - 1, 17 - 1);
end;
    
end
