function DWLoadDataAsHDFSingleRow(this, iDWRow, runID, loadText, loadPath)
% loads the data from the HDF5 file

% get the data save configuration
dataConf = cell(0, 8);
% get the different data modes' save configuration
for iMode = 1 : numel(this.dw.dataModes);
    % call the data save configuration function
    modeName = lower(this.dw.dataModes{iMode});
    [~, dataConf] = OCIAGetCallCustomFile(this, 'dataSaveConfig', modeName, 1, { this, iDWRow, dataConf }, 0);
end;
% get the number of fields and extend the config
nFields = size(dataConf, 1);

% get the path parts for this run
pathParts = regexp(this.dw.runTable{iDWRow, 1}, '\w+', 'match');
% create the data set's path
dataSetRoot = sprintf(repmat('/%s', 1, numel(this.dw.savePathParts)), pathParts{this.dw.savePathParts});
% get the dataset's path with a replaceable item tag '_DATA:TYPE_'
datasetPath = sprintf('%s/_DATA:TYPE_/%s', dataSetRoot, runID);

% go through each field and save the data
for iField = 1 : nFields;
    
    % get the field name, the data and the data options for that field
    [fieldName, dataSetGetHandle, subCellName, attribsToStoreNames, attribsSetGetHandle, displayName] ...
        = dataConf{iField, 1 : 6};
    
    % get the path where the data should be stored
    datasetPathData = strrep(datasetPath, '_DATA:TYPE_', fieldName);
    
    % if the data set does not exist, skip this field
    if ~h5exists(loadPath, datasetPathData); continue; end;
    
    % fetch the content of the file with the specific data set path        
    content = h5info(loadPath, datasetPathData);

    % if content contains sub-datasets
    if isfield(content, 'Datasets');
        % if fetching did not result in an error, extract the datasets
        dataSets = content.Datasets;
        % get the number of datasets inside
        nCells = numel(dataSets);
        % if there are sub-datasets
        if ~isempty(subCellName);
            % pre-allocate the place for the cell array
            loadedCell = cell(nCells, 1);
            % load each channel
            for iCell = 1 : nCells;
                cellName = sprintf(subCellName, iCell);
                showMessage(this, sprintf('%s - %s - %s ...', loadText, displayName, cellName), 'yellow');
                datasetPathDataCell = sprintf('%s/%s', datasetPathData, dataSets(iCell).Name);
                loadedCell{iCell} = h5read(loadPath, datasetPathDataCell);
            end;
            dataSetGetHandle(fieldName, loadedCell); % set the value using the set/get function

            % if there are some attributes to load
            if ~isempty(content.Attributes) && numel(attribsToStoreNames);
                % loop through the attributes to load
                for iAttribToFind = 1 : numel(attribsToStoreNames);
                    % loop through the available attributes
                    for iAttrib = 1 : numel(content.Attributes);
                        % check if they match
                        if strcmp(content.Attributes(iAttrib).Name, attribsToStoreNames{iAttrib});
                            % load the attribute using the set/get function
                            attribsSetGetHandle(attribsToStoreNames{iAttrib}, content.Attributes(iAttrib).Value); 
                        end;
                    end;
                end;
            end;

        % if content has no cell sub-datasets, it is a structure
        else
            % get the content's info
            h5info(loadPath, datasetPathData);
            % if fetching did not result in an error, show message and extract the datasets
            showMessage(this, sprintf('%s - %s ...', loadText, displayName), 'yellow');
            % load the data as a structure (including attributes)
            loadedStruct = h5readAsStruct(loadPath, datasetPathData);
            % load the data in memory using the set/get function
            dataSetGetHandle(fieldName, loadedStruct);
        end;

    % if there are no sub-datasets, load as a dataset
    else
        % get the content's info
        h5info(loadPath, datasetPathData);
        % if fetching did not result in an error, show message and extract the datasets
        showMessage(this, sprintf('%s - %s ...', loadText, displayName), 'yellow');
        % load the data using the set/get function
        loadedData = h5read(loadPath, datasetPathData);                
        dataSetGetHandle(fieldName, loadedData); % set the value using the set/get function
    end;
    
end;

end