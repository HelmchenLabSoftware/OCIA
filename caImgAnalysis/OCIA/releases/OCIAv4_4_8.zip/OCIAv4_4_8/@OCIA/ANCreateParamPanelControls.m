function ANCreateParamPanelControls(this)

% common inputs for all controls
commons = { 'Parent', this.GUI.handles.an.paramPan, 'Units', 'normalized', 'Enable', 'off' };
% common inputs for text controls
commonsTxt = [ commons, { 'Background', 'white', 'Style', 'edit', 'Callback', @(h, e) ANUpdatePlot(this, h, e) } ];
% common inputs for labels
commonsLab = [ commons, { 'Background', 'white', 'Style', 'text' } ];

% define the max number of rows and the number of items to place
nMaxRows = 6; nMaxCols = 2; nUICtrl = size(this.GUI.an.plotParamConfig, 1); %#ok<NASGU>
nMinRows = 4; nMinCols = 1; pad = 0.02; inPad = 0.01;

% calculate the number of acutal columns and rows
% nCols = ceil(nUICtrl / nMaxRows); nRows = min(nMaxRows, nUICtrl);
nRows = max(ceil(nUICtrl / nMaxCols), nMinRows); nCols = max(min(nMaxCols, nUICtrl), nMinCols);

elemW = (1 - (nCols + 1) * pad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * pad) / nRows; % height depends on the number of rows
iRow = 1; iCol = 1; % init the row and column indexes

% go through all elements, create them and place them
for iUICtrl = 1 : nUICtrl;
    % get the variables of the current control element
    [id, categ, name, UIType, valueType, label, tooltip] = this.GUI.an.plotParamConfig{iUICtrl, 1 : 7};
    
    % update rows/columns
    if iRow > nRows; iRow = 1; iCol = iCol + 1; end;
%     if iCol > nCols; iCol = 1; iRow = iRow + 1; end;

    elemPosX = (iCol - 1) * (pad + elemW) + pad; % calculate X position
    elemPosY = 1 - iRow * (elemH + pad) + pad; % calculate Y position
    
    % process the different UI types
    switch UIType;
        
        % text controls
        case 'text';
            
            % create the label
            labElemY = elemPosY + elemH * 0.25; labElemW = elemW * (0.7 - inPad); labElemH = elemH * 0.5;
            this.GUI.handles.an.paramPanElems.([id '_label']) = uicontrol(commonsLab{:}, 'String', label, ...
                'Position', [elemPosX labElemY labElemW labElemH], 'ToolTipString', tooltip, ...
                'Tag', sprintf('ANParam%s', id));
            
            % get the value from the storage variable
            val = this.an.(categ).(name);
            
            % if the value is not text and its an array
            if numel(val) > 1 && ~strcmp(valueType, 'text');
                % display as an array between brackets
                val = ['[', regexprep(num2str(val), '\s+', ','), ']'];
                
            % if the value is a text, keep it as a string so do nothing
            elseif numel(val) > 1 && strcmp(valueType, 'text');
                
            % otherwise the value is just a number
            else
                val = num2str(val);
            end;
            
            % create the GUI element
            ctrlElemX = elemPosX + elemW * (0.7 + inPad); ctrlElemW = elemW * (0.3 - inPad);
            this.GUI.handles.an.paramPanElems.(id) = uicontrol(commonsTxt{:}, 'String', val, ...
                'Tag', sprintf('ANParam%s', id), 'Position', [ctrlElemX elemPosY ctrlElemW elemH], ...
                'ToolTipString', tooltip);
    end;
    
    % update row/column index
    iRow = iRow + 1;
%     iCol = iCol + 1;

end;

% refresh the GUI
drawnow();

% only show the parameter panel if there are some controls to display
set(this.GUI.handles.an.paramPan, 'Visible', iff(nUICtrl > 0, 'on', 'off'));

end