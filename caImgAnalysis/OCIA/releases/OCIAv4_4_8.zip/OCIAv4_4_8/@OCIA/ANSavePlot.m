%% #OCIA:AN:ANSavePlot
function ANSavePlot(this, savePath, varargin)

if isempty(savePath);
    
    if exist(this.path.OCIASave, 'dir') ~= 7; mkdir(this.path.OCIASave); end;

    [saveName, savePath] = uiputfile('*.*', 'Select a path where to save the plot', this.path.OCIASave);
    if ischar(saveName)
        savePath = [savePath saveName];
        saveName = regexprep(saveName, '(\.\w{3})?$', '');
    else % otherwise abort the saving
        return;
    end;
else
    saveName = savePath;
end;
savePath = strrep(savePath, '\', '/');
showMessage(this, sprintf('Saving analyser plot to "%s" ...', savePath), 'yellow');
saveTic = tic;

figName = saveName;
if nargin > 2; figName = varargin{1}; end;
saveFig = figure('Name', figName, 'NumberTitle', 'off', 'Color', 'white', 'Units', 'pixels', ...
    'Position', get(this.GUI.figH, 'Position'), 'Visible', 'off');

anAxe = this.GUI.handles.an.axe;
anPanelChild = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
% gather everything that doesn't belong to the Analyser panel's GUI (buttons)
anPanelChild(~cellfun(@isempty, regexp(get(anPanelChild, 'Tag'), '^AN'))) = [];
% add the analyser plot axes if they are not already present
if ~ismember(anAxe, anPanelChild); anPanelChild(end + 1) = anAxe; end;

for iObj = 1 : numel(anPanelChild); % copy objects one by one
    copyobj(anPanelChild(iObj), saveFig);
end;

saveChild = get(saveFig, 'Children');
for iObj = 1 : size(saveChild, 1); % copy objects one by one
    saveObjH = saveChild(iObj);
    if strcmp(get(saveObjH, 'Type'), 'axes') && strcmp(get(saveObjH, 'Tag'), 'Colorbar');
        saveObjPos = get(saveObjH, 'Position');
        set(saveObjH, 'Position', [saveObjPos(1 : 2) + [saveObjPos(3) * 0.75 0] saveObjPos(3) * 0.5 1 - 2 * saveObjPos(2)]);
%         delete(saveObjH);
    elseif strcmp(get(saveObjH, 'Type'), 'axes') && ~strcmp(get(saveObjH, 'Tag'), 'Colorbar') ...
            && all(get(saveObjH, 'Position') > 0);
        saveObjPos = get(saveObjH, 'Position');
        newPos = [saveObjPos(1 : 2) 1 - 2 * saveObjPos(1 : 2)];
        if ~any(newPos < 0);
            set(saveObjH, 'Position', newPos);
        end;
    end;
end;

% copy the colormap
set(saveFig, 'Colormap', get(this.GUI.figH, 'Colormap'));

saveFolder = regexprep(savePath, '/[\w\.]+$', '');
if exist(saveFolder, 'dir') ~= 7; mkdir(saveFolder); end;

if regexp(savePath, '\.png$');
    if nargin > 3 && strcmpi(varargin{2}, 'noCrop');
        export_fig(savePath, '-png', '-r200', '-nocrop', saveFig); 
    else
        export_fig(savePath, '-png', '-r200', saveFig); 
    end;
else                            
    set(saveFig, 'Visible', 'on');
    saveas(saveFig, savePath);
end;
close(saveFig);

showMessage(this, sprintf('Saving analyser plot to "%s" done (%.3f sec).', savePath, toc(saveTic)));
    
end
