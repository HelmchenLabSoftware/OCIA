function ANToggleGUIEnableState(this, state)

% enable the Analyser panel's GUI  
if state;
    
    % enable all GUI elements of the analyser panel
    childElems = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
    inputElems = strcmp('uicontrol', get(childElems, 'Type'));
    set(childElems(inputElems), 'Enable', 'on');
    % enable all GUI elements of the analyser panel's parameter panel
    childElems = get(this.GUI.handles.an.paramPan, 'Children');
    inputElems = strcmp('uicontrol', get(childElems, 'Type'));
    set(childElems(inputElems), 'Enable', 'on');
  
% disable the Analyser panel's GUI  
else
    
    % disable all GUI elements of the analyser panel
    childElems = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
    inputElems = strcmp('uicontrol', get(childElems, 'Type'));
    set(childElems(inputElems), 'Enable', 'off');

    % disable all GUI elements of the analyser panel's parameter panel
    childElems = get(this.GUI.handles.an.paramPan, 'Children');
    inputElems = strcmp('uicontrol', get(childElems, 'Type'));
    set(childElems(inputElems), 'Enable', 'off');
    set(this.GUI.handles.an.message, 'Enable', 'on'); % do not disable the message display element
    
end;

end