%% #OCIA:DW:DWSelRunTableRows
function DWSelRunTableRows(this, toSelectRows)

this.dw.selRunTableRows = toSelectRows;

% if there is a GUI, select the rows in the uitable
if isGUI(this);
    jTable = getJTable(this, 'DWRunTable');
    jTable.clearSelection();
    for iSelRow = 1 : numel(toSelectRows);
        selRow = toSelectRows(iSelRow);
        jTable.addRowSelectionInterval(selRow - 1, selRow - 1);
    end;

    % if a thumbnail preview must be shown
    if this.GUI.dw.showThumbnailPreview && ~isempty(toSelectRows);

        % load the data in preview mode (only first couple frames)
        DWLoadRow(this, toSelectRows(1), 'prev');

        % if there is some imaging data to show
        if isfield(this.data, 'img');
            
            preProcData = this.data.preProc{toSelectRows(1)};

            % if some data was loaded
            if ~isempty(preProcData);

                % compensate absent pre-processed data with raw data
                for iChan = 1 : numel(preProcData);
                    if isempty(preProcData{iChan});
                        preProcData{iChan} = this.data.raw{toSelectRows(1)}{iChan};
                    end;
                end;

                % create the averaged RGB image
                RGBIm = cell2RGB(preProcData, this.an.img.colVect, true);

            % if no data, show a black image
            else
                RGBIm = zeros([this.an.img.defaultImDim, 3]);
            end;

            % show the image
            RGBIm(RGBIm < 0) = 0;
            RGBIm(RGBIm > 1) = 1;

            if size(RGBIm, 3) > 3;
                RGBIm = nanmean(RGBIm, 3);
            end;

            set(this.GUI.handles.dw.prevIm, 'CData', RGBIm);
            set(this.GUI.handles.dw.prevImAx, 'XLim', [-size(RGBIm, 2) * 0.05 size(RGBIm, 2) * 1.05], ...
                'YLim', [-size(RGBIm, 1) * 0.05 size(RGBIm, 1) * 1.05]);
            
        end;

    end;
    
end;

end
