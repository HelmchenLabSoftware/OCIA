%% #OCIA:DWReset
function DWReset(this, ~, ~)
    
    DWFlushData(this, this.dw.selRunTableRows, 'all');
    
end
