%% #OCIA:AN:ANUpdatePlot
function ANUpdatePlot(this, varargin)

%% process the inputs
h = [];
if numel(varargin) > 0; h = varargin{1}; end;
isHand = ~isempty(h) && isnumeric(h) && ishandle(h);
isAutoUp = get(this.GUI.handles.an.autoUpPlot, 'Value');

if isHand && h == this.GUI.handles.an.upPlot;
    % update plot anyways since the update plot button was pushed
elseif ~isHand && ischar(h) && strcmp(h, 'force');
    % update plot anyways since the force command was sent
elseif isAutoUp;
    % update plot since auto-update of the plot is activated
else
    % do not auto-update
    return;    
end;

% disable the Analyser panel's GUI
ANToggleGUIEnableState(this, 0);

% update the stored parameters from the parameter panel
ANUpdateVariablesFromParamPanel(this);

% reset the plot configuration       
this.GUI.an.plotParamConfig = { };

% clear the plot and show a message
ANClearPlot(this);
ANShowHideMessage(this, 1, 'Plotting ...');

% get the selected rows and their DataWatcher index
selRows = get(this.GUI.handles.an.runTable, 'Value');
DWRows = cell2mat(this.an.runTable(selRows, 11));

% get the selected plot
selPlot = get(this.GUI.handles.an.plotList, 'Value');
% if no exactly one plot is selected
if numel(selPlot) ~= 1;
    % if more that one plot is selected, only take the first selected one
    if numel(selPlot) > 1;
        selPlot = selPlot(1);
    % if no plot is selected, take the first one
    else
        selPlot = 1;
    end;
    set(this.GUI.handles.an.plotList, 'Value', selPlot); % re-set the selected plot in the GUI
end;

o('#OCIA:AN:ANUpdatePlot(): updating plot, plotType:%s, row(s):%s ...', ...
    sprintf(' %s', this.an.plotTypes{selPlot}), sprintf(' %d', selRows), 3, this.verb);

% catch errors to never end up with the GUI elements disabled
try    
    OCIAGetCallCustomFile(this, 'analysis', this.an.plotTypes{selPlot}, 1, { this, DWRows }, 0);
catch err;
    % show message and error
    ANShowHideMessage(this, 1, 'An error occured during the plotting. Sorry about that.');
    showWarning(this, 'OCIA:ANUpdatePlot:PlotError', ...
        sprintf('%s (%s)\n%s', err.message, err.identifier, getStackText(err)), 'red');
end;
    
    %{
    % process the selected plot
    switch this.an.plotTypes{selPlot};

        %% - #OCIA:AN:ANUpdatePlot: d' plot for the behavior data
        case 'DPrime';

            ANPlotDPrime(this, selRows);

        %% - #OCIA:AN:ANUpdatePlot: fraction of early/correct for behavior data
        case 'BehavFrac';

            ANPlotBehavFrac(this, selRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace-based plots
        case {'ROICaTraces', 'ROICaTracesHeatMap', 'PSAverage', 'PSAverageHeatMap', ...
                'PSAverageOdd', 'PSAverageOddHeatMap'};

            ANPlotCaTraces(this, DWRows, selPlot);

        %% - #OCIA:AN:ANUpdatePlot: raw traces with ratio and DFF/DRR calculation
        case 'RawTraces';

            ANPlotRawTraces(this, DWRows, selRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and behavior combining plot
        case 'CaTraceBehavior';

            ANPlotCaTracesBehav(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhisk';

            ANPlotCaTracesWhisk(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhiskCorrHeatMap';

            ANPlotCaTracesWhiskCorrHeatMap(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhiskCorrDistr';

            ANPlotCaTracesWhiskCorrDistr(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: unknown plot
        otherwise

            ANShowHideMessage(this, 1, 'Plot not available. Sorry about that.');
    end;
    
catch err;
    % show message and error
    ANShowHideMessage(this, 1, 'An error occured during the plotting. Sorry about that.');
    showWarning(this, 'OCIA:ANUpdatePlot:PlotError', ...
        sprintf('%s (%s)\n%s', err.message, err.identifier, getStackText(err)), 'red');    
end;
    
%}

% create the parameter panel and its controls, using specific parameters
%   for each plot (stored in this.GUI.an.plotParamConfig)
ANCreateParamPanelControls(this);

% enable the Analyser panel's GUI
ANToggleGUIEnableState(this, 1);
    
uicontrol(this.GUI.handles.an.selROIList);

end
