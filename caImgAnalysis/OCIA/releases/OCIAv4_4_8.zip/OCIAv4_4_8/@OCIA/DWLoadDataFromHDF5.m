%% #OCIA:DWLoadDataFromHDF5
function DWLoadDataFromHDF5(this, loadPath)
    
showMessage(this, sprintf('Loading data from "%s" ...', loadPath), 'yellow');

% select the appropriate runs, either all or only the current selection
if get(this.GUI.handles.dw.SLROpts.SLRSelOnly, 'Value');
    runs = this.dw.selRunTableRows;
else
    runs = 1 : size(this.dw.runTable, 1);
end;
% get the number of runs
nRuns = numel(runs);

loadDataTic = tic;
% go through each run   
for iRun = 1 : nRuns;

    % load the row
    iDWRow = runs(iRun);
    % get the runID as "YYYYMMDD_HHMMSS"
    runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');
    
    % ignore non-imaging data rows
    if ~strcmpi(DWGetRowType(this, iDWRow), 'imgData'); continue; end;
    
    % create the generic save text and show a message
    loadText = sprintf('Loading data for %s (%02d)', runID, iDWRow);
%     showMessage(this, sprintf('%s ...', loadText), 'yellow');

    % save the data for this single row
    DWLoadDataAsHDFSingleRow(this, iDWRow, runID, loadText, loadPath);

%     showMessage(this, sprintf('%s done.', loadText));
    DWWaitBar(this, 100 * (iRun / nRuns));

end;

%% --- #DWLoadDataFromHDF5: data sanity checks
showMessage(this, 'Data sanity check ...', 'yellow');
% go through each run   
for iRun = 1 : nRuns;

    % load the row
    iDWRow = runs(iRun);
    % get the runID as "YYYYMMDD_HHMMSS"
    runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');

    % ignore non-imaging data rows
    if ~strcmpi(DWGetRowType(this, iDWRow), 'imgData'); continue; end;

    % raw data loaded but no rawLoadType
    if ~isempty(this.data.raw{iDWRow}) && isempty(this.data.rawLoadType{iDWRow});
        % load the first "couple" of frames
        nMaxFrameLoad = this.dw.previewNMaxFrameToLoad;
        if size(this.data.raw{iDWRow}{1}, 3) > nMaxFrameLoad;
            this.data.rawLoadType{iDWRow} = 'full';
        else
            this.data.rawLoadType{iDWRow} = 'prev';
        end;

        showWarning(this, 'OCIA:DWLoadDataFromHDF5:RawLoadTypeMissing', ['RawLoadType is missing for ', ...
            '%s (%02d). Assuming "%s".'], runID, iDWRow, this.data.rawLoadType{iDWRow});
    end;
    
    % raw data loaded but not pre-processed data, fill in the pre-processed data with the raw
    if ~isempty(this.data.raw{iDWRow}) && isempty(this.data.preProc{iDWRow});   

        % store in the pre-processed holder with no pre-processing
        rawData = this.data.raw{iDWRow};
        this.data.preProc{iDWRow} = rawData;
        this.data.preProcType{iDWRow} = '';    

        % if skipping frame(s) is required, skip first "nSkipFrame" frames (shutter artifact)
        if any(strcmp(this.an.an.preProcOptions, 'skipFrame')) && this.an.an.nSkipFrame > 0;
            for iChan = 1 : numel(rawData);
                rawData{iChan} = rawData{iChan}(:, :, 1 + this.an.an.nSkipFrame : end);
            end;            
            % store in the pre-processed holder with no pre-processing
            this.data.preProc{iDWRow} = rawData;
            this.data.preProcType{iDWRow} = {'skipFrame'};
        end;

    end;    
end;

%% --- #DWLoadDataFromHDF5: Fill data load status
if isGUI(this);
    % go through each run  
    jTable = getJTable(this, 'DWRunTable'); 
    for iRun = 1 : nRuns;    
        iDWRow = runs(iRun);
        % update the row's loading and processing status
        DWUpdateRowStatus(this, iDWRow, jTable);
        pause(0.01);
    end
end;

% load the ROISets if requested
if get(this.GUI.handles.dw.SLRDataOpts.ROISets, 'Value');        
    DWLoadROISetAsHDF5(this, loadPath);        
end;

showMessage(this, sprintf('Loading data from "%s" done (%.3f sec).', loadPath, toc(loadDataTic)));
    
end
