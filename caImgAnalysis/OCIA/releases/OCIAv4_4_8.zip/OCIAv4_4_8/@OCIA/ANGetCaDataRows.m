%% #OCIA:AN:ANGetCaDataRows
function DWRows = ANGetCaDataRows(this, DWRows)

% get the rows that do not contain calcium data
emptyRows = cellfun(@isempty, this.data.img.caTraces(DWRows));
% if there are some rows with no calcium data
if any(emptyRows);    
    DWRows(emptyRows) = []; % remove those rows from the selected
    set(this.GUI.handles.an.runTable, 'Value', find(~emptyRows)); % update the selecter
    ANShowHideMessage(this, 1, 'Some selected runs do not have calcium data.'); % show a warning message
    pause(2);
end;

end
