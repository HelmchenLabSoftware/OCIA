%% #OCIA:RD:RDDrawROIsForRows
function RDDrawROIsForRows(this, ~, ~)

    DWRunTableClick(this); % update the selected rows
    
    o('#RDDrawROIsForRows(): selected row(s): %s ...', num2str(this.dw.selRunTableRows), 4, this.verb);
    
    % abort if no rows selected
    if isempty(this.dw.selRunTableRows);
        showWarning(this, 'OCIA:RDDrawROIsForRows:NoRowsMarked', 'No rows selected! Aborting.');
        return;
    end;

    % prepare/reset the ROIDrawer's variables
    nRowSelected = numel(this.dw.selRunTableRows);
    this.rd.runTable = cell(nRowSelected, 4); % reset the RD's runTable
    rcFields = fieldnames(this.rd.rc)';
    this.rd.rc = cell2struct(cell(1, numel(rcFields)), rcFields, 2); % reset the RD's ROI comparator structure
    % reset the image
    RDUpdateImage(this);
    
    % change the mode
    OCIAChangeMode(this, 'ROIDrawer');
    
    ROISetRows = DWFindRunTableRows(this, 'ROISet', '', '', '', '', '', '');
    ROISetRefRows = zeros(numel(ROISetRows), 1);
    for iROISetRow = 1 : numel(ROISetRows);
        [~, ~, ~, iDWRefRow, ~] = ANGetROISetForRow(this, ROISetRows(iROISetRow));
        if ~isempty(iDWRefRow) && iDWRefRow > 0;
            ROISetRefRows(iROISetRow) = iDWRefRow;
        end;
    end;

    % go through each row and create a display text (row labels)
    for iRDRow = 1 : nRowSelected;

        % get info about the row
        iDWRow = this.dw.selRunTableRows(iRDRow);
        filePath = DWGetRunTableRowFullPath(this, iDWRow);
%         folderName = cell2mat(regexprep(regexp(filePath, '\w+/$', 'match'), '/$', ''));
        % store the full file path in the ROIDrawer's run table
        this.rd.runTable{iRDRow, 2} = filePath;

        % extract information about the row: day, time, tag based on the runType and others
        day = strrep(this.dw.runTable{iDWRow, 2}, '_', '');
        time = strrep(this.dw.runTable{iDWRow, 3}, '_', '');
        comments = this.dw.runTable{iDWRow, end};
        tag = regexprep(sprintf('%s%s_%s', this.dw.runTable{iDWRow, 7 : 8}, this.dw.runTable{iDWRow, 9}), '_-?$', '');
        tag = regexprep(tag, 'Trial', 'Tr'); % make the tag shorter
        isROISet = '';
        if ismember(iDWRow, ROISetRefRows); isROISet = '*'; end;
        % build up the display text for this row
        this.rd.runTable{iRDRow, 1} = sprintf('%s%02d: %s_%s - %s - %s', isROISet, iRDRow, day, time, tag, comments);
        % clean up the text
        this.rd.runTable{iRDRow, 1} = regexprep(this.rd.runTable{iRDRow, 1}, ' - -', '');
        this.rd.runTable{iRDRow, 1} = regexprep(this.rd.runTable{iRDRow, 1}, '\s+', ' ');
        this.rd.runTable{iRDRow, 1} = regexprep(this.rd.runTable{iRDRow, 1}, ' / ', '/');

    end;
    
    % display the created row labels
    set(this.GUI.handles.rd.rowListNames, 'String', this.rd.runTable(:, 1), 'Value', 1, 'ListBoxTop', 1);
    set(this.GUI.handles.rd.runSel, 'String', num2cell(1 : nRowSelected), 'Value', [], 'ListBoxTop', 1);

    % determine whether to pre-load all images or not
    preloadImages = false;
    
    % go through each row and pre-load them if required
    for iRDRow = 1 : nRowSelected;

        % if pre-loading of the images was requested or if it is the first row, load the image
        if preloadImages || iRDRow == 1;
            RDChangeRow(this, iRDRow); % load the row
        else % if pre-load not required, abort pre-loading after first row is done
            break;
        end;
        
    end;
    
    if preloadImages;
        showMessage(this, sprintf('Loading images done (%02d/%02d).', nRowSelected, nRowSelected)); %#ok<UNRCH>
    else
        showMessage(this, 'Loaded first image.');
    end;

end
