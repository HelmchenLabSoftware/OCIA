function ANUpdateVariablesFromParamPanel(this)

% update the parameter panel depending on the plot using the plotParamConfig
nUICtrl = size(this.GUI.an.plotParamConfig, 1);

% go through all elements and update their associated parameters
for iUICtrl = 1 : nUICtrl;
    
    % extract the elements of the parameter config
    [id, categ, name, UIType, valueType] = this.GUI.an.plotParamConfig{iUICtrl, 1 : 5};
    
    % if no field corresponds to the id, skip this element
    if ~isfield(this.GUI.handles.an.paramPanElems, id); continue; end;
    
    % process the different UI types
    switch UIType;
        
        % text input elements
        case 'text';
            
            % get the text
            txt = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            
            % process the different value types
            switch valueType;
                
                case 'numeric'; % single number
                    dblValue = str2double(txt); % get the value as double
                    % unless the value is a NaN, store it in the right variable
                    if ~isnan(dblValue); this.an.(categ).(name) = dblValue; end;
                    
                case 'text'; % string
                    % unless the value is a empty, store it in the right variable
                    if ~isempty(txt); this.an.(categ).(name) = txt; end;
                    
                case 'array'; % array of numbers
                    % remove anything that is not a number, a comma, a colon, a dot, a minus, a space or square brackets
                    val = regexprep(txt, '[^\[\]\d ,:\.-]', '');
                    % if the text is not empty, evaluate the text to get the actual array, 
                    %   using try-catch to catch the eval errors
                    if ~isempty(val); try val = eval(val); catch e; val = []; end; end; %#ok<NASGU>
                    % if the array is not empty and does not contains NaNs, store its value
                    if ~isempty(val) && ~any(isnan(val)); this.an.(categ).(name) = val; end;
                    
            end; % end of valueType switch
    end; % end of UIType switch
    
end; % end of control element loop

end