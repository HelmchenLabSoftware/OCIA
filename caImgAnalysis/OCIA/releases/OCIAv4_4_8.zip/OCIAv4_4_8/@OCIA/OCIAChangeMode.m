%% #OCIA:GUI:OCIAChangeMode
function OCIAChangeMode(this, h, ~)

% remove zoom upon changing mode
for iMode = 1 : size(this.GUI.modes, 1);
    % get the two-character name
    mName = this.GUI.modes{iMode, 2};
    % if there is a zoom tool field in that mode
    if isfield(this.GUI.handles, mName) && isfield(this.GUI.handles.(mName), 'zTool') ...
            && ishandle(this.GUI.handles.(mName).zTool);
        % get the zoom state (activated or not)
        zoomState = get(this.GUI.handles.(mName).zTool, 'Value');
        % if zoom is enabled, disable it
        if zoomState;
            funcHandle = str2func(sprintf('%sActivateZoom', upper(mName)));
            funcHandle(this, 0);
        end;
    end;
end;

structfun(@(x)set(x, 'Visible', 'off'), this.GUI.handles.panels); % hide all panels
if ischar(h); % if change was requested by a string input
    currMode = h; % current mode
    o('#OCIAChangeMode(): h: %s, currentMode: %s.', h, 3, currMode, this.verb);
    % if there is a GUI, show the requested pannel
    if isGUI(this);
        set(this.GUI.handles.panels.([h 'Panel']), 'Visible', 'on');
    end;
    % change the OCIAChangeMode pop-up list value to the new mode
    set(this.GUI.handles.changeMode, 'Value', find(~cellfun(@isempty, strfind(this.GUI.modes(:, 1), h))));
else % if change was requested by the callback
    o('#OCIAChangeMode(): h: %d, value: %d.', h, get(h, 'Value'), 3, this.verb);
    currMode = this.GUI.modes{get(h, 'Value'), 1}; % get the current mode from the handle
    % if there is a GUI, show the requested pannel
    if isGUI(this);
        set(this.GUI.handles.panels.([currMode 'Panel']), 'Visible', 'on');
    end;
end;

% perform actions that should be done upon activation of new modes
toShowMessage = '';
switch currMode;
    
    case 'DataWatcher';
        
        % initialize the preview image's imshow handle
        if isempty(this.GUI.handles.dw.prevIm);
            % if there is a GUI, initialize the real imshow handle
            if isGUI(this);
                this.GUI.handles.dw.prevIm = imshow(zeros(100), 'Parent', this.GUI.handles.dw.prevImAx);
            end;
        end;
        
        % if no watch folder yet, set a new watch folder path
        if isempty(this.dw.watchFolder);
            
            % if there is a GUI, add some GUI interaction callbacks
            if isGUI(this);
                
                % get the java component of the the data watcher's runTable and enable multiple row selection
                try
                    jTable = getJTable(this, 'DWRunTable');
                catch e; %#ok<NASGU>
                    jTable = getJTable(this, 'DWRunTable');
                end;
                jTable.setNonContiguousCellSelection(false);
                % add a callback for the mouse click on the rows
                set(handle(jTable, 'CallbackProperties'), 'MouseReleasedCallback', ...
                    @(h, e)(DWRunTableClick(this, h, e)));
                % add a tooltip to the table's header row
                jTable.getTableHeader().setToolTipText('ZL = zoom level, ZS = z-step, S = load state');

                % add right click event for watch type checkboxes
                watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
                watchTypeVisibs = this.dw.watchTypes(:, 4); % get all watch type GUI visibilities
                for iType = 1 : numel(watchTypeIDs);
                    % only process visible elements
                    if watchTypeVisibs{iType};
                        jCheckBox = findjobj(this.GUI.handles.dw.watchTypes.(watchTypeIDs{iType}));
                        set(jCheckBox, 'MouseClickedCallback', @(h, e)DWChangeWatchType(this, h, e));
                    end;
                end;
                
                jAllNone = findjobj(this.GUI.handles.dw.watchTypesAllNone);
                set(jAllNone, 'MouseClickedCallback', @(h, e)DWChangeWatchType(this, h, e));
                
            end;
            
            % update the watch folder path
            DWUpdateWatchFolderPath(this);
            toShowMessage = sprintf('New watch folder path: ''%s''.', this.dw.watchFolder);
        end;
        
    case 'ROIDrawer';
        
        % if ROIDrawer was not activated before, initialize the image axes
        if isempty(this.GUI.handles.rd.img);
            
            this.GUI.rd.img = zeros(this.GUI.rd.defaultImDim, this.GUI.rd.defaultImDim, 3);
            
            % if there is a GUI, initialize the real imshow handle and add a callback for the frame setter
            if isGUI(this);
                
                this.GUI.handles.rd.img = imshow(this.GUI.rd.img, 'Parent', this.GUI.handles.rd.axe);
                
                % set tags and callbacks
                set(this.GUI.handles.rd.img, 'Tag', 'RDImg', 'ButtonDownFcn', @(h, e)RDDrawNewROI(this, h, e));
                set(this.GUI.handles.rd.axe, 'Tag', 'RDAxe');
                
                jObj = findjobj(this.GUI.handles.rd.frameSetter);
                set(jObj, 'AdjustmentValueChangedCallback', ...
                    @(~, ~)RDChangeFrame(this, this.GUI.handles.rd.frameSetter));
                
                % make setter horizontal
                setterNames = {'refROISetBSetter', 'refROISetASetter'};
                for iName = 1 : numel(setterNames);
                    jScrollPane = java(findjobj(this.GUI.handles.rd.(setterNames{iName})));
                    set(jScrollPane, 'VerticalScrollBarPolicy', jScrollPane.VERTICAL_SCROLLBAR_NEVER);
                    set(jScrollPane, 'HorizontalScrollBarPolicy', jScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                    jListbox = jScrollPane.getViewport().getView();
                    set(jListbox, 'LayoutOrientation', 1, 'VisibleRowCount', 1);
                end;
                
            end;
        end;
        
    case 'Analyser';
        
        %% Create the plot types list with icons
        nPlotTypes = numel(this.an.plotTypes);
        % Modify the listbox layout to display square icon cells
        jScrollPane = java(findjobj(this.GUI.handles.an.plotList));
        jListbox = jScrollPane.getViewport().getView();
        jListbox.setLayoutOrientation(jListbox.HORIZONTAL_WRAP);
        jListbox.setVisibleRowCount(round(nPlotTypes / 2));
        jListbox.setFixedCellWidth(64 + 10);   % icon width=16  + 2px margin
        jListbox.setFixedCellHeight(64 + 10);  % icon height=16 + 2px margin
        jListbox.repaint();  % refresh the display

        % create the HTML strings for icon-based list elements
        HTMLCellString = cell(nPlotTypes, 1);
        % go through each plot type
        for iPlotType = 1 : nPlotTypes;
            % get the plot type's name
            plotName = this.an.plotTypes{iPlotType};
            % get the icon for this plot type
            iconPath = strrep(which('OCIA'), 'OCIA.m', [plotName '.png']);
            % if the icon exists, use it as element
            if exist(iconPath, 'file');
                HTMLCellString{iPlotType} = sprintf('<html><img src="file:/%s"/>', iconPath);
            % otherwise just use the plot type's name as element
            else 
                % split word in several dash-separated words right before capital letters
                plotName = regexprep(plotName, '([A-Z])', ' $1');
                HTMLCellString{iPlotType} = sprintf('<html><font style="font-size:12"><b>%s', plotName);  
            end; 
        end;
        % add the HTML strings as string elements
        set(this.GUI.handles.an.plotList, 'String', HTMLCellString);
        
    case 'Behavior';
        
        % if behavior mode was not already activated before, initiate it
        if isempty(this.be.room);
            
            BEActivate(this);
            toShowMessage = sprintf('Mouse trainer v%s initiated.', this.be.version);  
            
        end;
        
    case 'JointTracker';

    % if ROIDrawer was not activated before, initialize the image axes
    if isempty(this.GUI.handles.jt.img);

        this.GUI.jt.img = zeros(1, 1);
        % if there is a GUI, initialize the real imshow handle
        if isGUI(this);
            
            this.GUI.handles.jt.img = imshow(this.GUI.jt.img, 'DisplayRange', [0 1], 'Parent', this.GUI.handles.jt.axe);
            
            % set tags
            set(this.GUI.handles.jt.img, 'Tag', 'JTImg');
            set(this.GUI.handles.jt.axe, 'Tag', 'JTAxe');

            % add a callback for the frame setter
            jObj = findjobj(this.GUI.handles.jt.frameSetter);
            set(jObj, 'AdjustmentValueChangedCallback', @(h, e)JTChangeFrame(this, this.GUI.handles.jt.frameSetter, e));
            set(jObj, 'MouseWheelMovedCallback', @(h, e)JTChangeFrame(this, this.GUI.handles.jt.frameSetter, e));
            
            % make setter horizontal
            setterNames = {'jointSelSetter', 'jointTypeSelSetter', 'jointSelDispSetter', 'jointTypeSelDispSetter'};
            for iName = 1 : numel(setterNames);
                jScrollPane = java(findjobj(this.GUI.handles.jt.(setterNames{iName})));
                set(jScrollPane, 'VerticalScrollBarPolicy', jScrollPane.VERTICAL_SCROLLBAR_NEVER);
                set(jScrollPane, 'HorizontalScrollBarPolicy', jScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                jListbox = jScrollPane.getViewport().getView();
                set(jListbox, 'LayoutOrientation', 1, 'VisibleRowCount', 1);
            end;
            
        end;
    end;
end;

showMessage(this, sprintf('Changed to %s mode. %s', currMode, toShowMessage));
pause(0.2); % required to let the GUI update itself

end
