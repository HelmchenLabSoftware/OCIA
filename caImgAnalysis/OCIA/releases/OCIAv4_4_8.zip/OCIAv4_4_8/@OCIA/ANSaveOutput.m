%% #OCIA:AN:ANSaveOutput
function ANSaveOutput(this, savePath, varargin)

if isempty(savePath);    
    if exist(this.path.OCIASave, 'dir') ~= 7; mkdir(this.path.OCIASave); end;
    [saveName, savePath] = uiputfile('*.*', 'Select a path where to save the analysis output', this.path.OCIASave);
    if ischar(saveName)
        savePath = [savePath saveName];
    else % otherwise abort the saving
        return;
    end;
end;

savePath = strrep(savePath, '\', '/');
showMessage(this, sprintf('Saving analyser output to "%s" ...', savePath), 'yellow');
saveTic = tic;

% store in a variable
caTracesOut = this.an.caTracesOut; %#ok<NASGU>

saveFolder = regexprep(savePath, '/[\w\.]+$', '');
if exist(saveFolder, 'dir') ~= 7; mkdir(saveFolder); end;
save(savePath, 'caTracesOut');

showMessage(this, sprintf('Saving analyser output to "%s" done (%.3f sec).', savePath, toc(saveTic)));
    
end
