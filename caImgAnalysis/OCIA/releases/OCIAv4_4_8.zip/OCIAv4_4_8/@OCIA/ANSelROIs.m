%% #OCIA:AN:ANSelROIs
function ANSelROIs(this, ROIsToSel)

nROIs = size(get(this.GUI.handles.an.selROIList, 'String'), 1);
if ischar(ROIsToSel) && strcmp(ROIsToSel, 'all');
    set(this.GUI.handles.an.selROIList, 'Value', 1 : nROIs);
elseif ischar(ROIsToSel) && strcmp(ROIsToSel, 'none');
    set(this.GUI.handles.an.selROIList, 'Value', []);
elseif ischar(ROIsToSel) && strcmp(ROIsToSel, 'up');
    selRuns = get(this.GUI.handles.an.selROIList, 'Value');
    selRun = selRuns(1);
    set(this.GUI.handles.an.selROIList, 'Value', max(selRun - 1, 1));
elseif ischar(ROIsToSel) && strcmp(ROIsToSel, 'down');
    selRuns = get(this.GUI.handles.an.selROIList, 'Value');
    selRun = selRuns(end);
    set(this.GUI.handles.an.selROIList, 'Value', min(selRun + 1, nROIs));
elseif isnumeric(ROIsToSel);
    set(this.GUI.handles.an.selROIList, 'Value', ROIsToSel(ROIsToSel >= 1 && ROIsToSel <= nROIs));
else
    showWarning(this, 'OCIA:ANSelROIs:InvalidCommand', sprintf('Unknown command: %s', ROIsToSel));
end;

ANUpdatePlot(this);

end
