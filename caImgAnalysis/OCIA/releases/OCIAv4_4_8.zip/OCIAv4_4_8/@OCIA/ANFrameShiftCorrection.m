%% #OCIA:AN:ANFrameShiftCorrection
function ANFrameShiftCorrection(this, iDWRow, varargin)

% if pre-processing not required or if data was already pre-processed, abort
if ~any(strcmp(this.an.an.preProcOptions, 'fShift')) || any(strcmp(this.data.preProcType{iDWRow}, 'fShift'));
    return;
end;

% get whether to do plots or not
if nargin > 2;  doPlots = varargin{1};
else            doPlots = 0;
end;
% get the progress fraction
if nargin > 3;  prog = varargin{2};
else            prog = '';
end;

%% - #OCIA:AN:ANFrameShiftCorrection: init
% get the runID
runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});
runIDTitle = sprintf('Frame shift correction for %s (%d%s)', runID, iDWRow, prog);

figCommons = {'NumberTitle', 'off'}; % figure options
    
% if data is not yet fully loaded, load it
if isempty(this.data.rawLoadType{iDWRow}) || ~strcmp(this.data.rawLoadType{iDWRow}, 'full');
    DWLoadRow(this, iDWRow, 'full');
end;

% get the imaging data
imgData = this.data.preProc{iDWRow};
imgDim = size(imgData{1});

% correct for frame shifting artifact by analysing the correlations in the average image of the selected channel
avgImg = nanmean(imgData{this.an.img.preProcChan}, 3);

% range on which the average image should be analysed (exclude side artifacts)
percExcl = 0.2;
xRange = round([imgDim(1) * percExcl, imgDim(1) * (1 - percExcl)]);
yRange = round([imgDim(2) * percExcl, imgDim(2) * (1 - percExcl)]);

% do a line-wise correlation
xCorrs = zeros(1, xRange(end) - xRange(1) + 1);
xIndOffset = xRange(1) - 1; % offset for indexing
parfor x = xRange(1) : xRange(end);
    xCorrs(x - xIndOffset) = corr(avgImg(:, x), avgImg(:, x - 1), 'rows', 'pairwise'); %#ok<*PFBNS>
end;
yCorrs = zeros(1, yRange(end) - yRange(1) + 1);
yIndOffset = yRange(1) - 1; % offset for indexing
parfor y = yRange(1) : yRange(end);
    yCorrs(y - yIndOffset) = corr(avgImg(y, :)', avgImg(y - 1, :)', 'rows', 'pairwise');
end;

% number of times the standard deviation
corrTheshFactor = 25;

% if the line-wise correlation is too bad, move the image chunks to recreate a normal image
corrThreshX = median(xCorrs) - corrTheshFactor * std(xCorrs);
corrThreshY = median(yCorrs) - corrTheshFactor * std(xCorrs);
corrDiffThresh = 0.1;
% correct on the X-axis
if any(xCorrs < corrThreshX);
    
    % get the "derivative" of the correlation
    diffXCorrs = abs(diff(xCorrs));
    
    if any(diffXCorrs > corrDiffThresh);
        
        % get a fresh copy of the data to change
        imgDataToCorrect = this.data.preProc{iDWRow};
        % get the line where the shift occured
        [maxXCorrDiff, maxXCorrDiffInd] = max(diffXCorrs);
        xLineInd = maxXCorrDiffInd + xRange(1) - 1;
        % reshape the images accordingly
        imgDataCorr = cellfun(@(imgs) horzcat(imgs(:, xLineInd : end, :), imgs(:, 1 : xLineInd - 1, :)), ...
            imgDataToCorrect, 'UniformOutput', false);
        
        % average image of the selected channel of the corrected data
        avgImgCorr = nanmean(imgDataCorr{this.an.img.preProcChan}, 3);
        
        % see if it actually made it better: re-do a line-wise correlation
        xCorrs2 = zeros(1, xRange(end) - xRange(1) + 1);
        parfor x = xRange(1) : xRange(end);
            xCorrs2(x - xIndOffset) = corr(avgImgCorr(:, x), avgImgCorr(:, x - 1), 'rows', 'pairwise'); %#ok<*PFBNS>
        end;
        % get the "derivative" of the correlation
        diffXCorrs2 = abs(diff(xCorrs2));
        % get the max correlation drop
        maxXCorrDiff2 = max(diffXCorrs2);
        % update the thresholds
        corrThreshX2 = median(xCorrs) - corrTheshFactor * std(xCorrs);

        % only apply the change if the "corrected" image is actually better than the original
        if ~any(xCorrs2 < corrThreshX2) || ~any(diffXCorrs2 > corrDiffThresh) || maxXCorrDiff2 < maxXCorrDiff;
            % store the change
            this.data.preProc{iDWRow} = imgDataCorr;
            % display message
            showMessage(this, sprintf('%s: shift correction done on X.', runIDTitle));
        else
            % keep the original image as "corrected"
            avgImgCorr = avgImg;
        end;
    end;
    
end;

% correct on the Y-axis
if any(yCorrs < corrThreshY);
    
    % get the "derivative" of the correlation
    diffYCorrs = abs(diff(yCorrs));
    
    if any(diffYCorrs > corrDiffThresh);
        % get a fresh copy of the data to change
        imgDataToCorrect = this.data.preProc{iDWRow};
        % get the line where the shift occured
        [maxYCorrDiff, maxYCorrDiffInd] = max(diffYCorrs);
        yLineInd = maxYCorrDiffInd + yRange(1) - 1;
        % reshape the images accordingly
        imgDataCorr = cellfun(@(imgs) vertcat(imgs(yLineInd : end, :, :), imgs(1 : yLineInd - 1, :, :)), ...
            imgDataToCorrect, 'UniformOutput', false);
        
        % average image of the selected channel of the corrected data
        avgImgCorr = nanmean(imgDataCorr{this.an.img.preProcChan}, 3);
        
        % see if it actually made it better: re-do a line-wise correlation
        yCorrs2 = zeros(1, yRange(end) - yRange(1) + 1);
        parfor y = yRange(1) : yRange(end);
            yCorrs2(y - yIndOffset) = corr(avgImgCorr(y, :)', avgImgCorr(y - 1, :)', 'rows', 'pairwise');
        end;
        % get the "derivative" of the correlation
        diffYCorrs2 = abs(diff(yCorrs2));
        % get the max correlation drop
        maxYCorrDiff2 = max(diffYCorrs2);
        % update the thresholds
        corrThreshY2 = median(yCorrs) - corrTheshFactor * std(xCorrs);

        % only apply the change if the "corrected" image is actually better than the original
        if ~any(yCorrs2 < corrThreshY2) || ~any(diffYCorrs2 > corrDiffThresh) || maxYCorrDiff2 < maxYCorrDiff;
            % store the change
            this.data.preProc{iDWRow} = imgDataCorr;
            % display message
            showMessage(this, sprintf('%s: shift correction done on Y.', runIDTitle));
        else
            % keep the original image as "corrected"
            avgImgCorr = avgImg;
        end;
    end;
    
end;

% mark row as processed for frame shift correction
this.data.preProcType{iDWRow} = unique([{'fShift'}, this.data.preProcType{iDWRow}]);

%% - #OCIA:AN:ANFrameShiftCorrection: plotting
if doPlots > 0; % if requested, plot a figure illustrating the shift correction procedure and result

    % correlation values
    figure('Name', sprintf('%s: line-wise correlations', runIDTitle), figCommons{:});
    legendTexts = {'Corr. on X', 'Corr. on Y', 'Corr. thresh. X', 'Corr. thresh. Y'};
    hold(gca, 'on');
    plot(xRange(1) : xRange(end), xCorrs, 'r');
    plot(yRange(1) : yRange(end), yCorrs, 'b');
    xLims = get(gca, 'XLim');
    plot(xLims(1) : xLims(end), repmat(corrThreshX, 1, xLims(end) - xLims(1) + 1), 'r:');
    plot(xLims(1) : xLims(end), repmat(corrThreshY, 1, xLims(end) - xLims(1) + 1), 'b:');
    if exist('diffXCorrs', 'var') || exist('diffYCorrs', 'var');
        plot(xLims(1) : xLims(end), repmat(corrDiffThresh + 0.5, 1, xLims(end) - xLims(1) + 1), 'g--');
        legendTexts{end + 1} = 'Corr. thresh. Diff.';
    end;
    if exist('diffXCorrs', 'var');
        plot(0.5 + (xRange(1) : xRange(end - 1)), diffXCorrs + 0.5, 'r.-');
        legendTexts{end + 1} = 'Diff. X corr.';
    end;
    if exist('diffYCorrs', 'var');
        plot(0.5 + (xRange(1) : xRange(end) - 1), diffYCorrs + 0.5, 'g.-');
        legendTexts{end + 1} = 'Diff. Y corr.';
    end;
    ylim([0 1]);
    legend(legendTexts);
    
    % if there was a correction done
    if exist('avgImgCorr', 'var');
        figure('Name', sprintf('%s: average images', runIDTitle), figCommons{:});
        subplot(1, 2, 1); imshow(linScale(avgImg));
        subplot(1, 2, 2); imshow(linScale(avgImgCorr));
        subplot(1, 2, 1); title('Original');
        subplot(1, 2, 2); title('Corrected');
        
    else
        % original image
        figure('Name', sprintf('%s: original average image (no correction done)', runIDTitle), figCommons{:});
        imshow(linScale(avgImg));
    end;
    
end;

end
