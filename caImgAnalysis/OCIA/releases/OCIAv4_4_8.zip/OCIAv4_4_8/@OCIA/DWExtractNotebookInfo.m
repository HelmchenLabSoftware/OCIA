%% --- #OCIA:DW:DWExtractNotebookInfo
function DWExtractNotebookInfo(this, ~, ~)

    extractTic = tic;
    DWWaitBar(this, 0);
    o('#DWExtractNotebookInfo()', 3, this.verb);
        
    if isempty(this.dw.notebookParsingFunctionName) || strcmp(this.dw.notebookParsingFunctionName, 'none');
        showMessage(this, 'No notebook parsing function: skipping notebook parsing.', 'yellow');
        return;
    end;

    if any(cellfun(@isempty, this.dw.runTable));
         showWarning(this, 'OCIA:DWExtractNotebookInfo:EmptyRunTable', ['Cannot extract informations from ' ...
             'notebook file because the runTable is empty and thus no notebook file/path can be found.']);
        return;
    end

    notebookRows = cellfun(@(x) ~isempty(strfind(x, 'notebook')), this.dw.runTable(:, 1));
    if ~any(notebookRows);
         showWarning(this, 'OCIA:DWExtractNotebookInfo:NotebookFileNotFound', ...
            ['Cannot extract informations from notebook file because there was no notebook row' ...
                ' in the runTable and thus no notebook file/path can be found.']);        
        return;        
    end;

    % get the notebook rows
    notebookRows = this.dw.runTable(notebookRows, :);
    % get each unique day
    uniqueDays = unique(notebookRows(:, 2));
    nUniqueDays = numel(uniqueDays);
    % go through the notebook files day by day
    for iDay = 1 : nUniqueDays;

        % get the notebook files for that day
        notebookRowsForDay = notebookRows(cellfun(@(x)strcmp(x, uniqueDays{iDay}), notebookRows(:, 2)), :);

        % just skip this run if no notebook rows are found
        if isempty(notebookRowsForDay);
             showWarning(this, 'OCIA:DWExtractNotebookInfo:NotebookFileNotFoundForSingleDay', ...
                sprintf(['Cannot extract informations from notebook file on the day "%s"' ...
                ' because there was no notebook row in the runTable and thus no notebook file/path can be found.'], ...
                uniqueDays{iDay}));
            continue;
        end;

        % get the number of notebook files and check if it exceeds 2 (which might mean that there are too many of them)
        nNBRowsForDay = size(notebookRowsForDay, 1);
        if nNBRowsForDay > 2; % more than 2, that's suspicious
            showWarning(this, 'OCIA:DWExtractNotebookInfo:TooManyNotebookRows', ...
                sprintf('A suspiciously big number of notebook rows (%d) have been found for day %s.', ...
                    nNBRowsForDay, uniqueDays{iDay}));
        end;
        
        % holder for spot depths
        spotDepths = [];
        
        % process every notebook file found for the current day
        for iNB = 1 : nNBRowsForDay;

            notebookRow = notebookRowsForDay(iNB, :);
            notebookTimeHits = regexp(notebookRow{1, 3}, '^(?<hour>\d{2})_(?<min>\d{2})_\d{2}$', 'names');
            noteBookParentFolder = regexprep(notebookRow{1, 1}, '^ ?\.', '');
            noteBookParentFolder = regexprep(noteBookParentFolder, ' / ', '/');
            noteBookParentFolder = regexprep(noteBookParentFolder, '( ?/ ?)?notebook$', '');
            notebookFilePath = sprintf('%s%s/notebook__%s__%sh_%sm.txt', this.dw.watchFolder, ...
                noteBookParentFolder, notebookRow{1, 2}, notebookTimeHits.hour, notebookTimeHits.min);
            notebookFilePath = regexprep(notebookFilePath, '/+', filesep);            
            
            % call the notebook parsing function
            [~, notebookInfo] = OCIAGetCallCustomFile(this, 'parseNotebookFile', ...
                this.dw.notebookParsingFunctionName, 1, { notebookFilePath }, 1);
                
            % try to extract the spot's depth from the notebook
            depthInfoRows = regexpi(notebookInfo(:, 5), ...
                'found( new)? spot\s?(?<iSpot>\d+) at (?<depth>\d+)um', 'names');
            depthInfoRows(cellfun(@isempty, depthInfoRows)) = [];
            
            if ~isempty(depthInfoRows);
                % go through all regexp hits and extract the depths
                for iRow = 1 : numel(depthInfoRows);
                    s = depthInfoRows{iRow}; % extract the structure
                    spotDepths(str2double(s.iSpot)) = str2double(s.depth); %#ok<AGROW>
                end;
            end;

            % try to find matching rows between runTable and notebook informations
            for iRow = 1 : size(this.dw.runTable, 1);

                runTableRow = this.dw.runTable(iRow, :);
                notebookInfoRows = notebookInfo(cellfun(@(x) strcmp(x, runTableRow{2}), ...
                    notebookInfo(:, 6)) & cellfun(@(x) strcmp(x, runTableRow{3}), ...
                    notebookInfo(:, 7)) & ~isempty(regexp(runTableRow{1}, '(imgD|d)ata', 'once')), :);

                % just skip this run if it was not found in the notebook
                if isempty(notebookInfoRows); continue; end;
                % keep only the first match
                if size(notebookInfoRows, 1) > 1;
                    showWarning(this, 'OCIA:DWExtractNotebookInfo:MultipleMatch', ...
                        sprintf(['For run on %s, several notebook-file rows are present! ' ...
                        'Taking the first one ...'], sprintf('%s:%s', notebookInfo{1, 6}, notebookInfo{1, 7})));
                    notebookInfoRow = notebookInfoRows(1, :);
                else
                    notebookInfoRow = notebookInfoRows(1, :);
                end;

                runTableRow(6 : 9) = notebookInfoRow(1 : 4);
                runTableRow{6} = regexprep(runTableRow{6}, this.dw.shortIDRegexpPattern, ''); % make ID shorter
                runTableRow(10) = notebookInfoRow(10);
                runTableRow(11) = notebookInfoRow(8);
                
                complementaryInfos = notebookInfoRow([13 : 14, 11 : 12]);
                if any(~cellfun(@isempty, complementaryInfos));
                    runTableRow(12 : 15) = complementaryInfos;
                end;

                % if the spotID is known, make a sanity check of the spot identity comparing it with the path
                if all(~strcmp({'unknown', this.GUI.dw.runTableEmptyCellContent}, runTableRow{7}));
                    spotFromFolder = regexp(runTableRow{1}, 'spot\d{2}', 'match');
                    if ~isempty(spotFromFolder) && ~strcmp(strrep(spotFromFolder{1}, 'ot', ''), runTableRow{7});
                        showWarning(this, 'OCIA:DWExtractNotebookInfo:SpotIdentity', ...
                            sprintf(['%s (row %d) has a mismatch in the spot identities: from path: %s, ', ...
                            'from notebook: %s.'], sprintf('%s__%s', runTableRow{2 : 3}), iRow, ...
                            strrep(spotFromFolder{1}, 'ot', ''), runTableRow{7}));
                    end;
                end;
                
                % figure out the spot identity from path if it is not known yet
                if any(strcmp({'unknown', this.GUI.dw.runTableEmptyCellContent}, runTableRow{7}));
                    spotLabel = strrep(regexp(runTableRow{1}, 'spot\d{2}', 'match'), 'spot', 'sp');
                    if ~isempty(spotLabel);
                        runTableRow(7) = spotLabel;
                    end;
                end;

                % append comments from notebook to comments from file:
                % if there was no comments, juste use the notebook comments
                if ~isempty(notebookInfoRow{5});
                    % if it's empty or the same, overwrite
                    if isempty(runTableRow{end}) || strcmp(runTableRow{end}, this.GUI.dw.runTableEmptyCellContent) ...
                            || strcmp(runTableRow{end}, notebookInfoRow{5});
                        runTableRow{end} = notebookInfoRow{5};
                    % if there was some different comments, append
                    elseif ~strcmp(runTableRow{end}, notebookInfoRow{5});
                        runTableRow{end} = sprintf('%s, %s', runTableRow{end}, notebookInfoRow{5});
                    else
                        showWarning(this, 'OCIA:DWExtractNotebookInfo:CommentProblem', ...
                            'Could not append notebook comment');
                    end;
                end;

                this.dw.runTable(iRow, :) = runTableRow;
            end;
        end;

        DWMatchSpotDepthsToSpot(this, uniqueDays{iDay}, spotDepths);
        
        DWWaitBar(this, (iDay / nUniqueDays) * 100);
        
    end;
        
    % fill the wait bar and update the display of the run table
    DWWaitBar(this, 100);
    DWDisplayRunTable(this);

    showMessage(this, sprintf('Extracted notebook information (%3.1f sec).', toc(extractTic)));
    o('      #extr..NotebookInfo(): done (%3.1f sec).', toc(extractTic), 3, this.verb);

end
