%% #OCIA:AN:ANGetROISetForRow
function [ROISets, runsValidities, iDWROISetRows, iDWRefRows, refImages] = ANGetROISetForRow(this, DWRows)

ROISets = []; % default is empty
runsValidities = []; % default is empty
iDWROISetRows = []; % default is empty
iDWRefRows = []; % default is empty
refImages = []; % default is empty
    
% try to match the ROISet for the requested row
ROISetTags = this.dw.runTable(DWRows, 16);
ROISetTags(cellfun(@isempty, ROISetTags)) = [];
ROISetHits = cell2mat(regexp(ROISetTags, '^RS(?<iROISet>\d+)', 'names'));
% if no ROISet information, try to find ROISet as the ROISet row itself
if isempty(ROISetHits);
    ROISetTags = this.dw.runTable(DWRows, 8);
    ROISetTags(cellfun(@isempty, ROISetTags)) = [];
    ROISetHits = cell2mat(regexp(ROISetTags, '^RS(?<iROISet>\d+)', 'names'));
end;

% if no ROISet information, return empty and show warning
if isempty(ROISetHits);
    if numel(DWRows) == 1;
        showWarning(this, 'OCIA:ANCalcDRRForRow:NoROISet', sprintf('No ROISet for %s__%s (%d)! Skipping.', ...
            this.dw.runTable{DWRows(1), 2 : 3}, DWRows(1)));
    else
        showWarning(this, 'OCIA:ANCalcDRRForRow:NoROISet', ...
            sprintf('No ROISet for runs from %s__%s (%d) to %s__%s (%d) ! Skipping.', ...
            this.dw.runTable{DWRows(1), 2 : 3}, DWRows(1), this.dw.runTable{DWRows(end), 2 : 3}, DWRows(1)));
    end;
    return;
else
    iROISets = unique(str2double({ ROISetHits.iROISet }));
end;

% initialize the output variables for each ROISet hit
ROISets = cell(numel(iROISets), 1);
runsValidities = cell(numel(iROISets), 1);
iDWROISetRows = cell(numel(iROISets), 1);
iDWRefRows = cell(numel(iROISets), 1);
refImages = cell(numel(iROISets), 1);

% go through each new ROISet
for iROISetLoop = 1 : numel(iROISets);
    
    iROISet = iROISets(iROISetLoop);

    if iROISet > size(this.data.img.ROISets, 1);
        showWarning(this, 'OCIA:ANGetROISetForRow:ROISetNotInMemory', ...
            sprintf('ROISet for %s__%s (%d) is not in memory anymore.', this.dw.runTable{iDWRow, 2 : 3}, iDWRow));
        return;
    end;

    % get the row index of this ROISet
    iDWROISetRows{iROISetLoop} = DWFindRunTableRows(this, 'ROISet', '', '', sprintf('RS%02d', iROISet), '', '', '');
    % get the rows which have of this ROISet as ROISet
    dataRowsForRef = DWFindRunTableRows(this, '[dD]ata', this.dw.runTable{iDWROISetRows{iROISetLoop}, 2}, ...
        '', '', '', '', sprintf('RS%02d', iROISet));
    % get the row index of the reference run of this ROISet (data row that has the same time)
    iDWRefRows{iROISetLoop} = dataRowsForRef(strcmp(this.dw.runTable(dataRowsForRef, 3), ...
        this.dw.runTable{iDWROISetRows{iROISetLoop}, 3}));


    % get the ROISet
    ROISets{iROISetLoop} = this.data.img.ROISets{iROISet, 1};
    % get the runs validity
    runsValidities{iROISetLoop} = this.data.img.ROISets{iROISet, 2};
    % get the reference image
    refImages{iROISetLoop} = this.data.img.ROISets{iROISet, 3};
    
end;

% do not output cell-arrays if only one ROISet was found
if numel(iROISets) == 1;    
    ROISets = ROISets{1};
    runsValidities = runsValidities{1};
    iDWROISetRows = iDWROISetRows{1};
    iDWRefRows = iDWRefRows{1};
    refImages = refImages{1};
end;

end
