
% % wolfgang
% this = OCIA('wolfgangCaData');
this = OCIA('behaviorH30_dayra');

%{

% Dayra's H30
this = OCIA('behaviorH30_dayra');

% Balazs's data
this = OCIA('default');

% Dayra's data
this = OCIA('dayra');

% Alex's data
this = OCIA('alex');

% Stefano's data
this = OCIA('stefano');

% Asli's data
this = OCIA('asli');
%}