function [this, inputParams] = OCIA_config_data_behav(this)
% adds the behavior data structures to the OCIA

inputParams = [];

%% - properties: Data: Behavior
% structure *array* with one element per row of the data watcher's run table
this.data.behav = struct();
% behavior data, extracted from the behavior files and/or the imaging data
% nAnalogIns-by-nSamples matrix of the recorded analog inputs
this.data.behav.rec = [];
% 1-by-nSamples vector of the extracted licking rate from the piezo sensor
this.data.behav.lickRate = [];
% delay in seconds between the imaging start given by the yscanner and the recorded imaging data
this.data.behav.imgDelays = [];
% frame rate of the imaging data based on the recorded behavior data
this.data.behav.imgFrameRate = [];
% sampling rate of the behavior data
this.data.behav.behavSampRate = [];
% stimulus start time based on the recorded behavior data
this.data.behav.stimStartTime = [];

% expand to a structure array
this.data.behav(this.dw.dataNMaxRuns) = this.data.behav(1);


% behavior data, loaded when processing the behavior folders. 4 columns: { date, time, spot, Matlab "out" struct }
if isfield(this, 'an');
    this.an.behav = cell(0, 4);
end;
   

end
