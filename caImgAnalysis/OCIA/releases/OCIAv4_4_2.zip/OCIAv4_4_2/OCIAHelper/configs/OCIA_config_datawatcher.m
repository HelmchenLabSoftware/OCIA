function [this, inputParams] = OCIA_config_datawatcher(this)
% adds the data watcher mode to the OCIA

inputParams = [];

%% -- properties: GUI: DataWatcher
this.GUI.dw = struct();
% names of the data watcher table's columns
this.GUI.dw.runTableColNames    = { 'Name', 'Date', 'Time', 'nFiles',   'Dim.', 'animalID', 'spotID',   'runType', ...
    'iRun', 'NB Dim.',  'imType',   'Laser',    'ZL',   'Rate', 'ZS',   'nROIs',    'St.',  'Comments' };
% widths of the data watcher table's columns
this.GUI.dw.runTableColW        = { 0.25    0.058   0.052   0.032       0.080   0.050       0.035       0.045 ...
    0.025   0.067        0.04        0.028       0.02   0.030   0.017   0.052       0.02,   0.11 };
% string that is placed in cells of the runTable that are empty
this.GUI.dw.runTableEmptyCellDisplayContent = '-';
% string that is placed in cells of the runTable that are empty
this.GUI.dw.runTableEmptyCellContent = [];
% defines whether to show a summary line for folders that were not processed
this.GUI.dw.showEmptyFolderSummary = true;
% defines whether to show a small thumbnail of the currently selected row
this.GUI.dw.showThumbnailPreview = true;
% defines whether to show or not a GUI
this.GUI.noGUI = false;
% defines which filter settings should be active at start
this.GUI.dw.DWFilt = { };
% defines which watch types should be activated at start
this.GUI.dw.DWWatchTypes = {};
% defines whether to skip meta-data processing
this.GUI.dw.DWSkiptMeta = true;
% defines whether to use the raw or local watch folder
this.GUI.dw.DWRawOrLocal = 'local';
% specifies which further processing step buttons are available as a cell array with 4 columns: { ID, label, tag, 
%   tooltip }
this.GUI.dw.dataWatcherProcessStepButtons = { ...
    'drawROIs',     'Draw ROIs',            'DWDrawROIs',       'Draw Regions Of Interest for selected rows';
    'preProcRows',  'Pre-process row(s)',   'DWPreProcRows',    'Pre-process selected rows';
    'analyseRows',  'Analyse row(s)',       'DWAnalyseRows',    'Analyse selected rows';
};

%% - properties: DataWatcher
this.dw = struct();
% path to the folder to 'watch' for data
this.dw.watchFolder = '';
% defines whether the watch folder should be automatically processed upon changing its path
this.dw.autoProcessWatchFolder = false;
% defines whether a warning of data flushing upon watch folder change should be displayed or not
this.dw.ignoreDataFlushWarning = true;
% HDF5 saving compression level. If empty or 0, no compression at all, otherwise specify values 
%   between 1 (best speed) and 9 (best compression)
this.dw.HDF5GZipLevel = [];
% data "types" that are to be flushed between runs once they are saved to avoid memory overflow
this.dw.savedDataToFlushBetweenRuns = { };
% specifies whether to overwrite the file where the data will be saved
this.dw.overwriteSaveFile = false;
% specifies whether to overwrite the data when saving it to HDF5 if it already exists
this.dw.overwriteHDF5Data = true;
% specifies which data should be saved in the HDF5 file
this.dw.dataAsHDF5 = { 'raw', 'preProc', 'caTraces', 'ROISets', 'stim', 'behav' };
% specifies which data should be saved in the HDF5 file
this.dw.dataAsMat = { };
% defines the maximum number of frames to load for the preview loading type
this.dw.previewNMaxFrameToLoad = 100;
% tells which parts of the raw path should be used for the saving
this.dw.savePathParts = [1, 3, 2];
% name of the function that parses the notebook file
this.dw.notebookParsingFunctionName = 'default';
% name of the function that do post-processing after the notebook file parsing
this.dw.extractNotebookPostProcessFunctionName = 'default';
% name of the function that do pre-processing of the selected rows
this.dw.preProcessFunctionName = 'default';
% pattern to make the ID of the animal column shorter for the display
this.dw.shortIDRegexpPattern = 'mou_[db]l_';
% cell-array holding the current watchFolder's content, displayed in a big table
this.dw.runTable = cell(100, 18);
% currently selected (highlighted) runTable row. Empty if none selected
this.dw.selRunTableRows = [];

%% -- properties: DataWatcher : watch types
% file/folder types that can be processed and will appear in the runTable with their regexp pattern, stored
%   as a cell-array with 6 columns: { ID, display name, parent folder, visible in GUI, tooltip text, 
%   regular expression pattern }
this.dw.watchTypes = {
    'animal',       'Animal',       [],         true,   'Animal folder',            '^mou_[db]l_\d{6}_\d{2}$';
    'day',          'Day',          'animal',   true,   'Day folder',               '^\d{4}_\d{2}_\d{2}$';
    'spot',         'Spot',         'day',      true,   'Spot folder',              '^spot\d{2}$';
    'img',          'Imag. data',   'spot',     true,   'Imaging data folder', ...
        '^(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h$';
    'notebook',     'Notebook',     'day',      true,   'Notebook file', ...
        '^notebook__(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}h_\d{2}m)\.txt$';
    'behav',        'Behav. data',  'day',      true,   'Behavior data folder',     '^behav$';
    'roiset',       'ROISet',       'day',      true,   'ROISet folder',            '^ROISets$';
    'intrinsic',    'Intrinsic',    'day',      true,   'Intrinsic folder',         '^intr_(?<date>\d{4}_\d{2}_\d{2})$';
};

%% -- properties: DataWatcher : watch type file patterns
% file patterns for files inside "watchType" folders (these are kind of "sub-watchTypes")
this.dw.watchTypeFilePatterns = struct();
this.dw.watchTypeFilePatterns.imgdata       = ['^(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h__', ...
    'channel_?(?<iChan>\d+)\.(tif|bin)$']; 
this.dw.watchTypeFilePatterns.imgmetadata   = '^(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h\.xml$';
this.dw.watchTypeFilePatterns.intrbinary    = ['^intr(?<intrNum>\d+)_(?<color>\w+)_(?<depth>\d+)um_' ...
    '(?<freq>(\d+|NOSOUND))?(kHz)?_(?<nSweeps>\d+)sweeps$'];
this.dw.watchTypeFilePatterns.intrvessel    = '^vessels(?<vesselNum>\d+)?.tif$';
this.dw.watchTypeFilePatterns.behavdata     = '^Behavior_(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2}).mat$'; 
this.dw.watchTypeFilePatterns.behavmovie    = '^(?<date>\d{4}-\d{2}-\d{2}) (?<time>\d{2}-\d{2}-\d{2}\.\d{3}).wmv$';
this.dw.watchTypeFilePatterns.roisetfile    = '^ROISet_(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h.mat$';

%% -- properties: DataWatcher : data configuration
% defines which data "modules" should be appended to the software
this.dw.dataModes = { 'img'; 'behav' };
% defines the maximum number of runs to store (can be extended)
this.dw.dataNMaxRuns = 300;
% defines the data saving options for each "type" of saving as a cell-array with 3 columns: { ID, label, tooltip text }
this.dw.dataSaveConfig = { ...
    'GUI',      'GUI',              'Save / load the GUI (run table, checkboxes'' values, etc.)';
    'raw',      'Raw data',         'Save / load the raw data';
    'preProc',  'Pre-proc. data',   'Save / load the pre-processed data';
    'caTraces', 'Calcium traces',   'Save / load the extracted calcium traces';
    'exclMask', 'Exclusion masks',  'Save / load the exclusion masks (from motion detection)';
    'stim',     'Stimulus'          'Save / load the stimulus vectors for the calcium traces';
    'ROISets',  'ROISets',          'Save / load the ROISets';
    'behav',    'Behavior data',    'Save / load the behavior data';
};
% defines the data saving general options as a cell-array with 3 columns: { ID, label, tooltip text }
this.dw.dataSaveOptionsConfig = { ...
    'loadBefSave',      'Fully load before save',       'Fully load the data from the raw files before saving to HDF5 (save-mode only)';
    'preProcBefSave',   'Pre-process before save',      'Pre-process the data before saving it to HDF5 (save-mode only)';
    'SLRSelOnly',       'Use selection only',           'Save / load / reset only the selected rows';
};

% apply data configuration
configHandle = str2func('OCIA_config_data');
this = configHandle(this);

%% -- properties: DataWatcher: filter elements and IDs
% defines the aspect of the filtering panel: cell array with one line per filter and 
%   5 columns: { filter name, GUI type, GUI width and DW runtable column where to apply the filter, supports range }
this.GUI.dw.filtElems = { ...
    'animal',   'dropdown',     1,      1,  false;
    'day',      'dropdown',     1,      2,  false;
    'spot',     'dropdown',     1,      7,  false;
    'rowtype',  'textfield',    1,      1,  false;
    'runtype',  'textfield',    0.5,    8,  false;
    'runindex', 'textfield',    0.5,    9,  true;
    'status',   'textfield',    1,      17, false;
};
% define the "IDs" field for each drop-down data watcher filter element
dropDownListFilterNames = this.GUI.dw.filtElems(strcmp(this.GUI.dw.filtElems(:, 2), 'dropdown'), 1);
for iName = 1 : numel(dropDownListFilterNames);
    filtName = dropDownListFilterNames{iName}; % get the filter name
    % create a list with only a dash element, which corresponds to no filtering
    this.dw.([filtName 'IDs']) = {'-'};
end;

end
