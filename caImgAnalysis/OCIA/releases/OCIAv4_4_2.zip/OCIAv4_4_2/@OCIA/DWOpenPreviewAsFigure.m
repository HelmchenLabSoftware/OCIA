%% #OCIA:DW:DWOpenPreviewAsFigure
function DWOpenPreviewAsFigure(this, varargin)
    
    if isempty(this.dw.selRunTableRows);
        return;
    end;
    
    % get the selected row and it's runID
    iDWRow = this.dw.selRunTableRows(1);
    runID =  regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');
    
    % extract the row's type
    rowType = DWGetRowType(this, iDWRow);
    
    switch rowType;
    
        case 'imgData';
            
            prevImg = get(this.GUI.handles.dw.prevIm, 'CData');
            figName = sprintf('%s - preview', runID);

            figH = figure('Name', figName, 'NumberTitle', 'off', 'Visible', 'off');
            imshow(prevImg);
            set(figH, 'Position', [0 0 785 685]);
            tightfig();
            set(figH, 'Position', [0 0 785 685]);
            movegui(figH, 'center');
            set(figH, 'Visible', 'on');
            
        case 'ROISet';

            [ROISet, ~, ~, ~, refImage] = ANGetROISetForRow(this, iDWRow);
            if iscell(refImage);
                refImage = refImage{this.an.img.chanVect(1)};
            end;                
            ROIRGBFig = doROIRGBPlot([], size(refImage), ROISet, [], {refImage}, ...
                sprintf('%s - %d ROI(s)', runID, size(ROISet, 1)), 0.7);
            tightfig(ROIRGBFig);
            set(ROIRGBFig, 'Position', [300 300 650 580]);
%             doROIRGBPlot([], size(refImage), ROISet, refImage, {refImage}, '', 0.7);

    end;
    
end
