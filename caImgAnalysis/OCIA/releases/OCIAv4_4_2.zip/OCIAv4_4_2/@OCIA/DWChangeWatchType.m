%% #OCIA:DW:DWChangeWatchType
function DWChangeWatchType(this, h, e)
 
    watchTypeHands = this.GUI.handles.dw.watchTypes; % get the watch type handles
    watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
    watchTypeLabels = this.dw.watchTypes(:, 2); % get the watch type text labels
    watchTypeParents = this.dw.watchTypes(:, 3); % get the watch type parents
        
    % if change was requested by a string input
    if ischar(h);
        o('#DWChangeWatchType(): h: %s.', h, 3, this.verb);
        % switch the checkbox value
        checkState = get(watchTypeHands.(h), 'Value');
        set(watchTypeHands.(h), 'Value', ~checkState);
    else
        
        watchTypeVisibs = this.dw.watchTypes(:, 4); % get all watch type GUI visibilities 
        selWatchTypeLabel = get(h, 'Text'); % get the clicked watch type
        
        % if the select all / none was clicked, select all or none of the watch types
        if strcmpi(selWatchTypeLabel, get(this.GUI.handles.dw.watchTypesAllNone, 'String'));
            % get the number of checked watch types
            nChecked = sum(cell2mat(get(cellfun(@(x)watchTypeHands.(x), watchTypeIDs), 'Value')));
            % set the value of the visible watch types to:
            %   - 0 if all of them are clicked
            %   - 1 if some or none are clicked
            set(cellfun(@(x)watchTypeHands.(x), watchTypeIDs(cell2mat(watchTypeVisibs))), ...
                'Value', nChecked ~= numel(watchTypeIDs));                
            
        % if right click, select only the right-clicked element and it's "parents"
        elseif e.getButton == 3;   
            % get the selected watch type's ID
            selWatchTypeID = watchTypeIDs{strcmp(watchTypeLabels, selWatchTypeLabel)};   
            % set all *visible* watch types to not checked
            for iType = 1 : numel(watchTypeIDs);
                set(watchTypeHands.(watchTypeIDs{iType}), 'Value', ~watchTypeVisibs{iType});
            end;
            % recursively check each watch type until the parent
            while ~isempty(selWatchTypeID);
                set(watchTypeHands.(selWatchTypeID), 'Value', 1); % check this watch type
                % get the parent ID
                selWatchTypeID = watchTypeParents{strcmp(watchTypeIDs, selWatchTypeID)};
            end;            
        end;
    end;

end