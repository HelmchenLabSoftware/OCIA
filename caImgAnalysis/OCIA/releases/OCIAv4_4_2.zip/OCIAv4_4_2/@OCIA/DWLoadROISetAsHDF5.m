%% #OCIA:DWLoadROISetAsHDF5
function DWLoadROISetAsHDF5(this, loadPath)
    
    showMessage(this, 'Loading ROISet ...', 'yellow');
        
    % store which ROISets should be loaded, corresponding to the ROISets of the imaging data that is loaded
    selRows = this.dw.selRunTableRows;
    nonEmptySelRows = selRows(~cellfun(@isempty, this.dw.runTable(selRows, 16)));
    nonEmptySelROISetRows = nonEmptySelRows(~cellfun(@isempty, regexp(this.dw.runTable(nonEmptySelRows, 16), 'RS\d+')));
    ROISetsToLoad = unique(this.dw.runTable(nonEmptySelROISetRows, 16));
    ROISetsToLoad = regexp(ROISetsToLoad, 'RS\d+', 'match');
        
    if isempty(ROISetsToLoad); return; end;

    % get the path parts for this run
    pathParts = regexp(this.dw.runTable{nonEmptySelROISetRows(1), 1}, '\w+', 'match');
    % create the data set's path
    dataSetRoot = sprintf(repmat('/%s', 1, numel(this.dw.savePathParts)), pathParts{this.dw.savePathParts});
   
    try

        % get the path where the masks and the runs validity should be stored
        datasetPathROISetMasks = sprintf('%s/ROISet/masks', dataSetRoot);
        datasetPathROISetROINames = sprintf('%s/ROISet/ROINames', dataSetRoot);
        datasetPathROISetRunsValid = sprintf('%s/ROISet/runsValidity', dataSetRoot);
        datasetPathROISetRefImage = sprintf('%s/ROISet/refImage', dataSetRoot);

        try % try to fetch the content of the file with the specific data set path
            contMasks = h5info(loadPath, datasetPathROISetMasks);
            % count the number of ROISets
            nROISets = numel(contMasks.Datasets);
        catch err;
            % only rethrow error if it is not an error thrown because the content could not be found
            if ~strcmpi(err.identifier, 'MATLAB:imagesci:h5info:objectDoesNotExist');
                rethrow(err);
            end;
            % no ROISets found
            nROISets = 0;
        end;

        % if some ROISets where found
        if nROISets;

            showMessage(this, 'Loading ROISets ...', 'yellow');
            % go through each ROISet to load   
            for iROISetLoop = 1 : numel(ROISetsToLoad);

                % get the ROISet index of this ROISet
                iROISet = str2double(regexprep(ROISetsToLoad{iROISetLoop}, 'RS', ''));
                % get the data watcher's run table row index of this ROISet
                iDWRow = DWFindRunTableRows(this, 'ROISet', '', '', ROISetsToLoad{iROISetLoop}, '', '', '');
                % get the runID as "YYYYMMDD_HHMMSS"
                runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');
                % get the ROISet's index in the data set
                ROISetInd = find(arrayfun(@(i) strcmp(contMasks.Datasets(i).Name, runID), 1 : nROISets), 1);
                if ~isempty(ROISetInd);
                    % load the masks, runsValidity and ROINames
                    masks = h5read(loadPath, sprintf('%s/%s', datasetPathROISetMasks, runID));
                    ROINames = h5read(loadPath, sprintf('%s/%s', datasetPathROISetROINames, runID));
                    runsValidity = h5read(loadPath, sprintf('%s/%s', datasetPathROISetRunsValid, runID));
                    refImage = h5read(loadPath, sprintf('%s/%s', datasetPathROISetRefImage, runID));
                    % extract the number of ROIs & runs and process the loaded data to its final ROISet-form
                    nROIs = size(masks, 3); nRuns = size(runsValidity, 1);
                    % cast matrix of logical into cell-array of logical
                    masks = arrayfun(@(iROI)masks(:, :, iROI), 1 : nROIs, 'UniformOutput', false)';
                    % cast matrix of doubles into a cell-array of strings ... in a single line! :D Take that clarity !
                    runsValidity = arrayfun(@(iRun)char(runsValidity(iRun, :)), 1 : nRuns, 'UniformOutput', false)';
                    % cast matrix of doubles into a cell-array of strings ... in a single line! :D Take that clarity !
                    ROINames = arrayfun(@(iROI)strtrim(char(ROINames(iROI, :))), 1 : nROIs, 'UniformOutput', false)';
                    % reshape the reference image in case it has multiple channels
                    if size(refImage, 3) > 1;
                        nChans = size(refImage, 3);
                        refSingleImageDim = [size(refImage, 1), size(refImage, 2)];
                        refImage = reshape(refImage, [refSingleImageDim(1), refSingleImageDim(2) * nChans]);
                        refImage = mat2cell(refImage, refSingleImageDim(1), refSingleImageDim);
                    end;
                    % create ROISet based on the loaded data
                    ROISet = [ROINames, masks];
                    this.data.img.ROISets{iROISet, 1} = ROISet;
                    this.data.img.ROISets{iROISet, 2} = runsValidity;
                    this.data.img.ROISets{iROISet, 3} = refImage;
                end;
            end;            
            showMessage(this, 'Loading ROISets done.');              
        end;

        showMessage(this, 'Loading ROISet done.');

    catch err;
        
        showWarning(this, 'OCIA:DWLoadROISetAsHDF5:saveError', sprintf('Error while loading ROISet: %s (%s)\n%s', ...
           err.message, err.identifier, getStackText(err)), 'red');
        pause(1);
        
    end;
    
end
