%% #BEChangePiezoThresh
function BEChangePiezoThresh(this, h, ~)

if this.GUI.handles.be.piezoThreshSetter ~= h; % if change was requested by a input value
    this.be.params.piezoThresh = h;
    o('#BEChangePiezoThresh(): h: %d, piezoThresh: %d.', h, this.be.params.piezoThresh, 4, this.verb);
    % change the GUI value to the right one
    set(this.GUI.handles.be.piezoThreshSetter, 'String', this.be.params.piezoThresh);
else % if change was requested by the callback
    o('#BEChangePiezoThresh(): h: %d, "value": %d.', h, get(h, 'String'), 4, this.verb);
    this.be.params.piezoThresh = str2double(get(h, 'String'));
end;
showMessage(this, sprintf('Piezo threshold: %4.4f', this.be.params.piezoThresh));

end
