%% #OCIA:AN:ANPlotDPrime
function ANPlotDPrime(this, selRows)

%% plotting parameter UI controls
% configuration for all the plots        
this.GUI.an.plotParamConfig = { };

% get the axe handle where all the plotting elements should be displayed
anAxe = this.GUI.handles.an.axe;

% plotTrialImaged = true;
plotTrialImaged = false;
plotDays = true;
% plotDays = false;

% get the behavior data of the non-empty selected rows
behavDataBool = ~cellfun(@isempty, this.an.runTable(:, 14));
selRowBool = false(size(this.an.runTable, 1), 1);
selRowBool(selRows) = true;
% extract the day, time, spotID and behavior out file for the non-empty selected rows
selBehavData = this.an.runTable(behavDataBool & selRowBool, [1 2 7 14]);

% if any behavior data
if ~isempty(selBehavData);

    % gather all response types and classify behavior files by dates and morning/afternoon sessions
    allRespTypes = [];
    allBehavInds = [];
    allBehavDates = {};
    allNImgTrials = []; % number of imaged trials for each beahvior session

    o('#an..atePlot(): gathering info about %d behavior files ...', size(selBehavData, 1), 2, this.verb);
    for iOut = 1 : size(selBehavData, 1);
        respTypes = selBehavData{iOut, 4}.respTypes;
        respTypes = respTypes(~isnan(respTypes));
        nRespTypes = size(respTypes, 2);
        allRespTypes = [allRespTypes respTypes]; %#ok<AGROW>
        allBehavInds = [allBehavInds repmat(iOut, 1, nRespTypes)]; %#ok<AGROW>
        dateStrDay = datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd');
        dateNumMidDay = datenum([dateStrDay '__14_00'], 'yyyy_mm_dd__HH_MM');
        dateNumWithHour = datenum(datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd__HH'), 'yyyy_mm_dd__HH');
        if dateNumMidDay > dateNumWithHour; dateStrDayWithSess = [dateStrDay '_am'];
        else                                dateStrDayWithSess = [dateStrDay '_pm'];
        end;
        allBehavDates = [allBehavDates, repmat({dateStrDayWithSess}, 1, nRespTypes)]; %#ok<AGROW>

        imgDataRows = DWFindRunTableRows(this, '(imgD|d)ata', '', '', sprintf('B%02d', iOut), '', '', '');
        trialNums = this.dw.runTable(imgDataRows, 9);
        trialImaged = zeros(1, nRespTypes);
        for iTrial = 1 : nRespTypes;
            trialImaged(iTrial) = ismember(sprintf('%02d', iTrial), trialNums);
        end;
        allNImgTrials = [allNImgTrials trialImaged]; %#ok<AGROW>
    end;
    
    if ~plotTrialImaged;
        allNImgTrials = [];
    end;
    if ~plotDays;
        allBehavDates = [];
    end;
    

    nTrials = size(allRespTypes, 2);
    if nTrials;
        o('#an..atePlot(): analyzing %d trials ...', nTrials, 2, this.verb);
        countTic = tic;
        binWidth = 150;
        if nTrials <= 100; binWidth = 7; end;
        counts = analyseBehavPerf(allRespTypes, [], binWidth, 1);
        o('#an..atePlot(): analyzing %d trials done (%3.1f sec)', nTrials, toc(countTic), 2, this.verb);
%         saveName = this.animalIDs{get(this.GUI.handles.DataWatcherMouseID, 'Value')};
        saveName = 'Behavior performance';
        plotBehavPerfCurves(anAxe, saveName, counts.TGOs, counts.NTGOs, counts.RESPs, ...
            counts.DPRIMEs, 5, 1.95, allBehavDates, allNImgTrials);
        
        % calculate mean d' for each day
        if ~isempty(allBehavDates);
            allBehavDatesWholeDay = regexprep(allBehavDates, '_[ap]m', '');
            uniqueDates = unique(allBehavDatesWholeDay);
            meanDPrimes = nan(numel(uniqueDates), 1);
            for iDate = 1 : numel(uniqueDates);
                meanDPrimes(iDate) = nanmean(counts.DPRIMEs(strcmp(uniqueDates{iDate}, allBehavDatesWholeDay)));
            end;
            meanDPrimesAndDates = [num2cell(roundn(meanDPrimes, -2)), uniqueDates']; %#ok<NASGU>
        end;
        
        ANShowHideMessage(this, 0, 'Update analyser plot done.');
    end;
else
    showWarning(this, 'OCIA:ANUpdatePlot:NoBehavDataToPlot', ...
        'No behavior data to plot in selected rows!');
    ANShowHideMessage(this, 1, 'No behavior data to plot in selected rows !');
end;
    
end
