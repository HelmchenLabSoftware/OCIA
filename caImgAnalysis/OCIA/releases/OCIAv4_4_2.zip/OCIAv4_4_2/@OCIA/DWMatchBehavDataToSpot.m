%% - #DWMatchBehavDataToSpot
function DWMatchBehavDataToSpot(this)

    behavDataRows = DWFindRunTableRows(this, 'behavData', '', '', 'B\d+', '', '', '');
    nBehavRows = size(behavDataRows, 2);
    for iBehavRow = 1 : nBehavRows;
        runType = this.dw.runTable{behavDataRows(iBehavRow), 8};
        dataRowsForBehav = DWFindRunTableRows(this, '(imgD|d)ata', '', '', [runType '_Trial'], '', '', '');
        uniqueSpots = unique(this.dw.runTable(dataRowsForBehav, 7));
        uniqueSpotLabel = regexprep(sprintf('%s/', uniqueSpots{:}), '/$', '');
        this.dw.runTable{behavDataRows(iBehavRow), 7} = uniqueSpotLabel;
        this.an.behav{iBehavRow, 3} = uniqueSpotLabel;
    end;

end