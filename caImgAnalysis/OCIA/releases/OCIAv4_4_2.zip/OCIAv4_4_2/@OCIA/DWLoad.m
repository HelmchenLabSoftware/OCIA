%% #OCIA:DWLoad
function DWLoad(this, loadPath)
    
    % if no load path specified, try to get one via the user interface
    if isempty(loadPath);
        [loadName, loadPath] = uigetfile('*.*', 'Select a file to load the OCIA', this.path.OCIASave);
        % if a path was specified, use that one
        if ischar(loadName);
            loadPath = [loadPath loadName];
        else % otherwise abort the saving
            return;
        end;
    end;
    
    % clean up the load path
    loadPath = strrep(loadPath, '\', '/');
    loadPath = [regexprep(loadPath, '\.\w+$', ''), '']; % remove extension
    loadPath = sprintf('%s.h5', loadPath); % add .h5 extension
    
    % if no checkbox is selected, select them all
    SLRHands = this.GUI.handles.dw.SLRDataOpts;
    if ~any(cell2mat(get(cellfun(@(x)SLRHands.(x), fieldnames(SLRHands)), 'Value')));
        set(cellfun(@(x)SLRHands.(x), fieldnames(SLRHands)), 'Value', 1);
    end;
    
    % if GUI is required to be loaded, load it from the HDF5 file
    if get(SLRHands.GUI, 'Value');
        DWLoadGUIFromHDF5(this, loadPath);
    end;
    
    % if any mat-saved data is required to be loaded, load it from the mat file
    if get(cellfun(@(x)SLRHands.(x), this.dw.dataAsMat), 'Value');
        loadPathData = regexprep(loadPath, '\.\h5$', '.mat'); % replace extension by .mat
        DWLoadDataFromMat(this, loadPathData);
    end;
    
    % if any HDF5-saved data is required to be loaded, load it from the HDF5 file
    if any(cell2mat(get(cellfun(@(x)SLRHands.(x), this.dw.dataAsHDF5), 'Value')));
        DWLoadDataFromHDF5(this, loadPath);
    end;
    
end
