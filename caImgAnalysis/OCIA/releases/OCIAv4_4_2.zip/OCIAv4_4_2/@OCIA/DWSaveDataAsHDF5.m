%% #OCIA:DWSaveDataAsHDF5
function DWSaveDataAsHDF5(this, savePath)
    
    showMessage(this, sprintf('Saving data to "%s" ...', savePath), 'yellow');
        
    % select the appropriate runs, either all or only the current selection
    if get(this.GUI.handles.dw.SLROpts.SLRSelOnly, 'Value');
        runs = this.dw.selRunTableRows;
    else
        runs = 1 : size(this.dw.runTable, 1);
    end;
    
    % get the number of runs
    nRuns = numel(runs);
    iDWRow = []; % initialize to empty
        
    % init wait bar
    DWWaitBar(this, 0);
    
    saveDataTic = tic;
    % go through each run   
    for iRun = 1 : nRuns;
        
        % if required, flush some of the data between the runs to avoir memory overflow
        if ~isempty(this.dw.savedDataToFlushBetweenRuns);
            DWFlushData(this, iDWRow, this.dw.savedDataToFlushBetweenRuns{:});
        end;

        % load the row
        iDWRow = runs(iRun);
        % get the runID as "YYYYMMDD_HHMMSS"
        runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');

        % ignore non-imaging data rows
        if ~strcmpi(DWGetRowType(this, iDWRow), 'imgData'); continue; end;

        % get the pre-processing options to use
        preProcOpts = '';            
        % if requested, pre-load the row
        if get(this.GUI.handles.dw.SLROpts.loadBefSave, 'Value'); preProcOpts = 'load'; end;            
        % if requested, pre-process the row
        if get(this.GUI.handles.dw.SLROpts.preProcBefSave, 'Value'); preProcOpts = [preProcOpts ',preProc']; end; %#ok<AGROW>
        preProcOpts = regexprep(preProcOpts, '^,', ''); % clean-up

        % pre-process the rows with the requested options
        OCIA_dataWatcherProcess_preProcRows(this, [], [], iDWRow, preProcOpts);

        % create the generic save text and show a message
        saveText = sprintf('Saving data for %s (%02d)', runID, iDWRow);
        showMessage(this, sprintf('%s ...', saveText), 'yellow');
            
        % save the data for this single row
        DWSaveDataAsHDFSingleRow(this, iDWRow, runID, saveText, savePath);

        showMessage(this, sprintf('%s done.', saveText));
        DWWaitBar(this, 100 * (iRun / nRuns));
        
    end;
        
    % save the ROISets if requested
    if get(this.GUI.handles.dw.SLRDataOpts.ROISets, 'Value');        
        DWSaveROISetAsHDF5(this, savePath);        
    end;
    
    % get information about the saved file
    saveFile = dir(savePath);    
    showMessage(this, sprintf('Saving data to "%s" done (%.3f sec, %.3f MB).', savePath, ...
        toc(saveDataTic), saveFile.bytes / (2^10 * 2^10)));
    
end
