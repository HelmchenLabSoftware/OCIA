%% #OCIA:DW:DWDisplayRunTable
function nRowsInRunTable = DWDisplayRunTable(this)

nRowsInRunTable = size(this.dw.runTable, 1);
% 32 is the minimum number of rows so that the scrollbar is displayed
runTable = cell(max(32, nRowsInRunTable), size(this.dw.runTable, 2));

% fill the empty cells with the 'empty cell content'
emptyCells = find(cellfun(@isempty, this.dw.runTable(:)));
this.dw.runTable(emptyCells) = repmat({this.GUI.dw.runTableEmptyCellContent}, 1, numel(emptyCells));

% this.dw.runTable(:, 1) = regexprep(this.dw.runTable(:, 1), '^\. \/ mou_bl_', '. / ');

if nRowsInRunTable; % if there is a content to the watchFolder, display it
    % copy the rows into the display table
    runTable(1 : nRowsInRunTable, :) = this.dw.runTable;
    % fill the empty cells with the 'empty cell display content'
    emptyCells = find(cellfun(@isempty, runTable(:)));
    runTable(emptyCells) = repmat({this.GUI.dw.runTableEmptyCellDisplayContent}, 1, numel(emptyCells));
else % if there is no content to the watchFolder, display warning
    showWarning(this, 'OCIA:DWDisplayRunTable:WatchFolderEmpty', 'Watch folder is empty!');
end;

% only set data if there is a GUI
if isGUI(this); set(this.GUI.handles.dw.runTable, 'Data', runTable); end;
this.dw.selRunTableRows = [];

end
