%% #OCIA:RD:RDRenameROI
function RDRenameROI(this, ~, ~)

% get the selected ROIs
selROIs = RDGetSelectedROIs(this);
% abort if no selection
if isempty(selROIs); return; end;

% get the names of the ROIs
for iROI = 1 : numel(selROIs);
    ROIID = get(this.GUI.handles.rd.ROIName, 'String');
    %% TODO: remove old position callback ...
    this.rd.ROIs{selROIs(iROI), 1}.addNewPositionCallback(@(h)RDUpdateImage(this, [], [], ROIID));
    this.rd.ROIs{selROIs(iROI), 2} = ROIID;
    this.rd.ROIs{selROIs(iROI), 6} = true; % mark as modified
end;

% sort ROIs by name
[~, sortInd] = sort(this.rd.ROIs(:, 2));
this.rd.ROIs = this.rd.ROIs(sortInd, :);

% update the display
RDUpdateGUI(this);
    
end




