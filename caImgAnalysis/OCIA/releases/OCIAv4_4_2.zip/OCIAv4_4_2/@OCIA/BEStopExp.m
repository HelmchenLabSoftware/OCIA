%% #BEStopExp
function BEStopExp(this, ~, ~)

if this.be.isRunning;
    this.be.isRunning = false;
    this.be.isToReset = true;
%     this.be.iTrial = 0;
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    BESaveOutput(this);
else
    showWarning(this, 'OCIA:Behavior:CannotStopNotRunning', ...
        'Cannot stop because experiment is not running.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
end

end

