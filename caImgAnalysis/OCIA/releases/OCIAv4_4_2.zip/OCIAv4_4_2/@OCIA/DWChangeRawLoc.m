%% #OCIA:DW:DWChangeRawLoc
function DWChangeRawLoc(this, h, ~)

    radioGroupH = this.GUI.handles.dw.rawLocGroup;
    if ischar(h); % if change was requested by a string input
        o('#DWChangeRawLoc(): h: %s.', h, 3, this.verb);
        % change the radiobutton to the requested one
        set(radioGroupH, 'SelectedObject', this.GUI.handles.dw.rawLocSel.lower(h));
    end;
    
    o('#DWChangeRawLoc(): changed to %s.', get(get(radioGroupH, 'SelectedObject'), 'String'), 3, this.verb);
    
    % update the watch folder according to the new settings
    DWUpdateWatchFolderPath(this);

end

