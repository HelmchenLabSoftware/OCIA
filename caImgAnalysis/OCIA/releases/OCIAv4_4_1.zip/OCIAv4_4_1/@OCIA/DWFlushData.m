%% #OCIA:DWFlushData
function DWFlushData(this, rowRange, varargin)
    
    o('#DWFlushData()', 4, this.verb);
    
    toFlush = ''; % by default flush nothing
    % if no arguments were provided, flush all data types
    if nargin <= 2; toFlush = 'all';
    % if arguments were provided, flush the data types requested
    elseif nargin > 2; toFlush = cell2mat(varargin);
    end;
    
    % if string 'all' was provided, flush all rows
    if ischar(rowRange) && strcmp(rowRange, 'all');
        rowRange = 1 : this.dw.dataNMaxRuns;
    end;
    % make sure the range is right
    rowRange(rowRange < 1 | rowRange > this.dw.dataNMaxRuns) = [];
    
    % flush selected raw data if requested
    if ~isempty(regexpi(toFlush, 'raw|all', 'once'));
        this.data.raw(rowRange) = cell(numel(rowRange), 1);
        this.data.rawLoadType(rowRange) = cell(numel(rowRange), 1);
    end;
    
    % flush selected pre-processed imaging data if requested
    if ~isempty(regexpi(toFlush, 'preproc|all', 'once'));
        this.data.preProc(rowRange) = cell(numel(rowRange), 1);
        this.data.preProcType(rowRange) = cell(numel(rowRange), 1);
    end;
    
    % if imaging data exist
    if isfield(this.data, 'img');
        % flush selected calcium traces if requested
        if ~isempty(regexpi(toFlush, 'catraces?|all', 'once'));
            this.data.img.caTraces(rowRange)= cell(numel(rowRange), 1);
            this.data.img.stim(rowRange)= cell(numel(rowRange), 1);
        end;
        % flush selected ROISets if requested
        if ~isempty(regexpi(toFlush, 'roisets?', 'once'));
            this.data.img.ROISets = {};
        end;
    end;
    
    % if behavior data exist
    if isfield(this.data, 'behav');
        % flush selected behavior data if requested
        if ~isempty(regexpi(toFlush, 'behav|all', 'once'));
            names = fieldnames(this.data.behav);
            this.data.behav(rowRange) = repmat(cell2struct(cell(1, numel(names)), names, 2), 1, numel(rowRange));
        end;
    end;
    
    % if whisker data exist
    if isfield(this.data, 'whisk');
        % flush selected whisker data if requested
        if ~isempty(regexpi(toFlush, 'whisk|all', 'once'));
            names = fieldnames(this.data.whisk);
            this.data.whisk(rowRange) = repmat(cell2struct(cell(1, numel(names)), names, 2), 1, numel(rowRange));
        end;
    end;
    
    % if analyser data exist
    if isfield(this.an, 'behav');
        % flush behavior data if requested
        if ~isempty(regexpi(toFlush, 'behavExtr|all', 'once'));
            % also flush the extracted behavior data
            iExtrBehavRange = rowRange(rowRange <= size(this.an.behav, 1));
            this.an.behav(iExtrBehavRange, :) = [];
        end;
    end;
    
end
