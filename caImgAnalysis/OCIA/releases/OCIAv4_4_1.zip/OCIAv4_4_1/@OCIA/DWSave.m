%% #OCIA:DWSave
function DWSave(this, savePath)
    
    % if no save path specified, try to get one via the user interface
    if isempty(savePath);
        [saveName, savePath] = uiputfile('*.*', 'Select a file to save the OCIA', this.path.OCIASave);
        % if a path was specified, use that one
        if ischar(saveName);
            savePath = [savePath saveName];
        else % otherwise abort the saving
            return;
        end;
    end;
    
    % clean up the save path
    savePath = strrep(savePath, '\', '/');
    savePath = regexprep(savePath, '\.\w+$', ''); % remove extension
    savePath = sprintf('%s.h5', savePath); % add .h5 extension
    
    % overwrite the file if required
    if exist(savePath, 'file') && this.dw.overwriteSaveFile;
        showMessage(this, sprintf('Overwritting file "%s" ...', savePath), 'yellow');
        delete(savePath);
    end;
        
    % if GUI is required to be saved, save it in the HDF5 file
    SLRHands = this.GUI.handles.dw.SLRDataOpts;
    if get(SLRHands.GUI, 'Value');
        DWSaveGUIAsHDF5(this, savePath);
    end;
    
    % if any HDF5-type data is required to be saved, save the data in a HDF5 file
    handNames = fieldnames(SLRHands);
    dataToSave = this.dw.dataAsHDF5; dataToSave(~cellfun(@(name)ismember(name, handNames), dataToSave)) = [];
    if any(cell2mat(get(cellfun(@(x)SLRHands.(x), dataToSave), 'Value')));
        DWSaveDataAsHDF5(this, savePath);
    end;
    
    % if any mat-type data is required to be saved, save the data in a mat file
    dataToSave = this.dw.dataAsMat; dataToSave(~cellfun(@(name)ismember(name, handNames), dataToSave)) = [];
    if get(cellfun(@(x)SLRHands.(x), dataToSave), 'Value');
        savePath = regexprep(savePath, '\.\h5$', '.mat'); % replace extension by .mat
        DWSaveDataAsMat(this, savePath);
    end;
    
end
