%% #OCIA:GUI:OCIACloseGUI
function OCIACloseGUI(this, ~, ~)

o('#OCIACloseGUI()', 4, this.verb);

% disconnect the behavior mode if it exist and is connected
if isfield(this.be, 'hw') && this.be.hw.connected;
    BEConnHW(this);
end;

% stop the GUI update timer if it exists
if isfield(this.GUI, 'be') && ~isempty(this.GUI.be.updateTimer);
    stop(this.GUI.be.updateTimer);
end;

delete(this);
    
end