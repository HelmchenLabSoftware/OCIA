%% #OCIA:DW:DWCreateToKeepWatchTypeStruct
function toKeepWatchTypes = DWCreateToKeepWatchTypeStruct(this, useGUI, defaultValue)
% creates a structure which defines which watch types should be included in the runTable. If useGUI is
%   true, the structure is initiated with values based on the GUI checkboxes. If useGUI is false, the "defaultValue"
%   is used for all watch types

toKeepWatchTypes = struct();

% go through all watch types
watchTypeIDs = this.dw.watchTypes(:, 1);
for iWatchType = 1 : numel(watchTypeIDs);
    watchTypeID = watchTypeIDs{iWatchType}; % get the watch type's name
    if useGUI; % update using GUI
        toKeepWatchTypes.(watchTypeID) = get(this.GUI.handles.dw.watchTypes.(watchTypeID), 'Value');
    else % update using input value
        toKeepWatchTypes.(watchTypeID) = defaultValue;
    end;
end;

end















