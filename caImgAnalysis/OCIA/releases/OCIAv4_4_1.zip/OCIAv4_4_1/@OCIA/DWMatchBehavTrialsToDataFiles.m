%% #OCIA:DW:DWMatchBehavTrialsToDataFiles
function DWMatchBehavTrialsToDataFiles(this)

% match the behavior trials and the data files
daysList = this.dw.runTable(:, 2);
daysList(cellfun(@isempty, daysList)) = [];
uniqueDays = unique(daysList); % go day by day
for iDay = 1 : numel(uniqueDays);
    day = uniqueDays{iDay};
    % get all the non-empty spot IDs
    nonEmptySpotIDs = this.dw.runTable(~cellfun(@isempty, this.dw.runTable(:, 7)), 7);
    uniqueSpots = unique(nonEmptySpotIDs); % get all unique spots
    % remove non-spot matches
    uniqueSpots(cellfun(@(x) isempty(regexp(x, '^sp\d{2}$', 'once')), uniqueSpots)) = [];
    % go spot by spot
    for iSpot = 1 : numel(uniqueSpots);
        spotID = strrep(uniqueSpots{iSpot}, 'sp', 'spot');
        % get the spot rows without a run-type for the current day
        [~, spotDataRows] = DWFindRunTableRows(this, spotID, day, uniqueSpots{iSpot}, '', '', '', '');
        [~, spotRefRows] = DWFindRunTableRows(this, spotID, day, uniqueSpots{iSpot}, '.+', '', '', '');
        % get the spot rows that have no run type
        rows = find(spotDataRows & ~spotRefRows);
        if isempty(rows);
            continue;
        elseif numel(rows) == 1;
            sessIDs = 1;
        else
            sessIDs = clusterRowsBySession(this, rows);
        end;
        % go through session by session
        for iSess = 1 : size(unique(sessIDs), 1);
            % get the indexes of this session
            sessRows = rows(sessIDs == iSess);
            matchBehavTrialsToDataFilesForSession(this, spotID, day, iSess, sessRows);
        end;
    end;
end;


%% - #matchBehavTrialsToDataFilesForSession
function matchBehavTrialsToDataFilesForSession(this, spotID, day, iSess, sessRows)

nTrialsFound = size(sessRows, 2);

% abort if no rows
if ~nTrialsFound;
    return;
end;

% find the right behavior out file
nBehavOuts = size(this.an.behav, 1);
% go through all behavior files by comparing beahvior trial and data file times
allBehavUNIXTimes = []; % behaviorally recorded times
allBehavBelongInds = []; % behavior file IDs (B01, B02, etc.)
% extract all behavior times from the behavior files
for iBehavOut = 1 : nBehavOuts;
    out = this.an.behav{iBehavOut, 4};
    fieldName = 'endImagExp';
    if ~isfield(out.times, fieldName); fieldName = 'endImagExpect'; end;
    % extract the behavior UNIX times
    behavUNIXTimes = (out.times.(fieldName) + out.times.start) * 1000;
    behavUNIXTimes(behavUNIXTimes == 0) = [];
    % concatenate the times
    allBehavUNIXTimes = [allBehavUNIXTimes behavUNIXTimes]; %#ok<AGROW>
    allBehavBelongInds = [allBehavBelongInds repmat(iBehavOut, 1, size(behavUNIXTimes, 2))]; %#ok<AGROW>
end;

% minimum time differences between behavior timestamps and data file timestamps
[allMinTDiffs, allMinTInds] = compareImgFileTimeWithBehavTimes(this, allBehavUNIXTimes, sessRows);

% abort if no rows to process
if isempty(allMinTDiffs) || isempty(allMinTInds);
    return;
end;

% best fitting behavior file are the ones with less than 3 hours 
iBestBehavOut = unique(allBehavBelongInds(allMinTDiffs < 3 * 60 * 60));
nMatchBehavOuts = size(iBestBehavOut, 2);
iBestBehavMask = ismember(allBehavBelongInds, iBestBehavOut);

% extract the adjusted time differences
minTDiff = allMinTDiffs(iBestBehavMask) - nanmedian(allMinTDiffs(iBestBehavMask));
nTrialsExp = 0;
for iBehavOut = 1 : nMatchBehavOuts;
    out = this.an.behav{iBestBehavOut(iBehavOut), 4};
    nTrialsExp = nTrialsExp + min(out.config.training.nTrials, out.iTrial);
end;

diffTrials = nTrialsExp - nTrialsFound;

timeThresh = 5000;
missExtraInd = [];
missExtra = '';
if diffTrials == 0 && ~any(minTDiff > timeThresh); % no trial number missmatch
    % nothing to do
elseif diffTrials ~= 0; % missing trials
    if diffTrials > 0;
        missExtra = 'missing';
        while size(missExtraInd, 1) < diffTrials;
            missExtraInd = find(minTDiff > timeThresh);
            timeThresh = timeThresh - 100;
        end;
        % get the most different missing trials
        [~, missExtraIndOrdered] = sort(minTDiff(missExtraInd));
        missExtraInd = missExtraInd(missExtraIndOrdered(end - diffTrials + 1 : end));
    else
        missExtra = 'extra';
        diffTrials = -diffTrials;
        missExtraInd = find(~ismember(1 : nTrialsExp, allMinTInds(iBestBehavMask)), diffTrials);
        if isempty(missExtraInd); missExtraInd = setdiff(1 : nTrialsFound, allMinTInds); end;
        missExtraInd = missExtraInd(1 : abs(diffTrials));
    end;

    missList = sprintf('%02d ', missExtraInd);
    if size(missList, 2) > 20; missList = [missList(1 : 5) ' ... ' missList(end - 5 : end)]; end;
    showWarning(this, 'OCIA:DWExtractNotebookInfo:MissingTrials', ...
        sprintf('Found %d %s trial(s) ( %s) for %s %s session %d.', diffTrials, missExtra, ...
        missList, day, spotID, iSess));
end;

if strcmp(out.taskType, 'cotOdd');
    stimLabels = { 'lowStd ', 'highStd' };
else
    stimLabels = { 'low', 'high' };
end;
spotNames = repmat({strrep(spotID, 'spot', 'sp')}, nTrialsExp, 1);
runTypes = cell(nTrialsExp, 1);
trialNums = cell(nTrialsExp, 1);
behavInfo = cell(nTrialsExp, 1);
iBehavOut = 1;
out = this.an.behav{iBestBehavOut(iBehavOut), 4};
currMaxTrial = min(out.config.training.nTrials, out.iTrial);
iTrial = 1;
for iTotTrial = 1 : nTrialsExp;
    runTypes{iTotTrial} = sprintf('B%02d_Trial', iBestBehavOut(iBehavOut));
    trialNums{iTotTrial} = sprintf('%02d', iTrial);

    % gather some information about the behavior
    behavInfo{iTotTrial} = sprintf('[ %s', stimLabels{out.stims(iTrial)});
    
    if ~isnan(out.respTypes(iTrial));
        
        if ismember(out.respTypes(iTrial), [1 4]);
            behavInfo{iTotTrial} = sprintf('%s / targ', behavInfo{iTotTrial});
        elseif ismember(out.respTypes(iTrial), [2 3]);
            behavInfo{iTotTrial} = sprintf('%s / distr', behavInfo{iTotTrial});
        end;
        
        if ismember(out.respTypes(iTrial), [1 2]);
            behavInfo{iTotTrial} = sprintf('%s / corr', behavInfo{iTotTrial});
        elseif ismember(out.respTypes(iTrial), [3 4]);
            behavInfo{iTotTrial} = sprintf('%s / false', behavInfo{iTotTrial});
        end;
        
    end;
    
    if strcmp(out.taskType, 'cotOdd') && numel(out.nTones) >= iTrial;
        behavInfo{iTotTrial} = sprintf('%s / %02d tones', behavInfo{iTotTrial}, out.nTones(iTrial));
    end;
    
    behavInfo{iTotTrial} = sprintf('%s ]', behavInfo{iTotTrial});

    iTrial = iTrial + 1;
    if iTrial > currMaxTrial && iBehavOut < nMatchBehavOuts;
        iTrial = 1;
        iBehavOut = iBehavOut + 1;
        out = this.an.behav{iBestBehavOut(iBehavOut), 4};
        currMaxTrial = min(out.config.training.nTrials, out.iTrial);
    end;
end;

if strcmp(missExtra, 'missing');
    spotNames(missExtraInd) = [];
    runTypes(missExtraInd) = [];
    trialNums(missExtraInd) = [];
    behavInfo(missExtraInd) = [];
else
    sessRows(missExtraInd) = [];
end;
this.dw.runTable(sessRows, [7 : 9, end]) = [spotNames, runTypes, trialNums, behavInfo];

end


%% - #clusterRowsBySession
function sessIDs = clusterRowsBySession(this, rows)
    
% do not process if not at least 2 rows
if numel(rows) < 2;
    sessIDs = repmat('1', numel(rows), 1);
    return;
end;
    
% separate rows into morning and afternoon sessions
nUnknRows = size(rows, 2);
dateNums = zeros(nUnknRows, 1);
for iUnknRow = 1 : nUnknRows;
    dateNums(iUnknRow) = datenum(sprintf('%s__%s', this.dw.runTable{rows(iUnknRow), 2}, ...
        this.dw.runTable{rows(iUnknRow), 3}), 'yyyy_mm_dd__HH_MM_SS');
end;
sessIDs = clusterdata(dateNums, 'maxclust', 2);
nearbySessDiffInHours = (dn2unix(dateNums(find(sessIDs == sessIDs(end), 1, 'first'))) ...
    - dn2unix(dateNums(find(sessIDs == sessIDs(1), 1, 'last')))) / 1000 / 60 / 60;
% if sessions are too close, it means that it was a single session with a missing trial/interruption
if nearbySessDiffInHours < 3; % minimum 3 hours between sessions
    sessIDs = clusterdata(dateNums, 'maxclust', 1);
end;

end

%% - #compareImgFileTimeWithBehavTimes
function [minTDiffs, minTInds] = compareImgFileTimeWithBehavTimes(this, behavUNIXTimes, runTableRowInds)

% do not process if no rows
if isempty(runTableRowInds);
    minTDiffs = [];
    minTInds = [];
    return;   
end;

nTrialsExp = size(behavUNIXTimes, 2);
nTrialsFound = size(runTableRowInds, 2);
fileTimes = arrayfun(@(i) dn2unix(datenum(sprintf('%s__%s', ...
    this.dw.runTable{runTableRowInds(i), 2}, this.dw.runTable{runTableRowInds(i), 3}), ...
    'yyyy_mm_dd__HH_MM_SS')), 1 : nTrialsFound);
minTDiffs = zeros(nTrialsExp, 1);
minTInds = zeros(nTrialsExp, 1);
for iTrial = 1 : nTrialsExp;
    tDiffs = behavUNIXTimes(iTrial) - fileTimes;
    [minTDiffs(iTrial), minTInds(iTrial)] = min(abs(tDiffs));
end;

end

end
