%% - #DWExtractSpotIdentity
function DWExtractSpotIdentity(this)

% get the spot folder pattern but remove the starting and ending signs
spotIndex = strcmp(this.dw.watchTypes(:, 1), 'spot');
if ~any(spotIndex); return; end;
spotPattern = this.dw.watchTypes{spotIndex, 6};
spotPattern = regexprep(spotPattern, '^\^', '');
spotPattern = regexprep(spotPattern, '\$$', '');

% figure out spot identity from path
for iRow = 1 : size(this.dw.runTable, 1);
    % figure out the spot identity from path if it is not known yet
    if isempty(this.dw.runTable{iRow, 7}) && strcmp(DWGetRowType(this, iRow), 'imgData');
        spotLabel = regexp(this.dw.runTable{iRow, 1}, spotPattern, 'match');
        if ~isempty(spotLabel);
            this.dw.runTable(iRow, 7) = spotLabel;
        end;
    end;                
end;

end