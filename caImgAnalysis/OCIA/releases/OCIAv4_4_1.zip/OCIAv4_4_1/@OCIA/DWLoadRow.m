%% #OCIA:DW:DWLoadRow
function DWLoadRow(this, iDWRow, loadType, varargin)

% get the progress fraction
if nargin > 3;  prog = varargin{1};
else            prog = '';
end;

DWLoadRowTic = tic;

% get the runID as "YYYYMMDD_HHMMSS"
runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');

o('#DWLoadRow(): loading %s (%02d%s) (loadType: %s) ...', runID, iDWRow, prog, loadType , 4, this.verb);

% extract the row's type
rowType = DWGetRowType(this, iDWRow);

% process the row depending on its type
switch rowType;

    % imaging data
    case 'imgData';

        isDataLoaded = false;
        rawDataLoadType = this.data.rawLoadType{iDWRow};

        % process the row depending on the requested loading type
        switch loadType;

            % preview
            case 'prev';

                % load the first "couple" of frames
                nMaxFrameLoad = this.dw.previewNMaxFrameToLoad;

                % check whether data is loaded
                isDataLoaded = ~isempty(rawDataLoadType) && any(strcmp(rawDataLoadType, {'prev', 'full'}));

            case 'full';

                % set to -1, which means to load all frames
                nMaxFrameLoad = -1;
                % check whether data is loaded
                isDataLoaded = ~isempty(rawDataLoadType) && strcmp(rawDataLoadType, 'full');

        end;
        
        % if skipping frame(s) is required, pre-compensate the number of frames to load for skipped frames
        if any(strcmp(this.an.an.preProcOptions, 'skipFrame')) && this.an.an.nSkipFrame > 0 && nMaxFrameLoad ~= -1;
           nMaxFrameLoad = nMaxFrameLoad + this.an.an.nSkipFrame;
        end;
        
        % if it is not already done, load the data and store it !
        if ~isDataLoaded;
            
            showMessage(this, sprintf('Loading data for %s (%02d%s) ("%s") ...', runID, iDWRow, prog, ...
                loadType), 'yellow');

            % extract the path of the current row
            dataFolderPath = DWGetRunTableRowFullPath(this, iDWRow);

            % load the data
            data = loadData(dataFolderPath, 'nMaxFrameLoad', nMaxFrameLoad, ...
                'imgXYDim', this.an.img.defaultImDim, 'skipMeta', true, ...
                'zeroToNaN', this.an.loadImageSetValueToNaNWhenZero);
            
            % store the data
            this.data.raw{iDWRow} = data;
            this.data.rawLoadType{iDWRow} = loadType;
            
            % store in the pre-processed holder with no pre-processing
            this.data.preProc{iDWRow} = data;
            this.data.preProcType{iDWRow} = '';
            
            % if skipping frame(s) is required, skip first "nSkipFrame" frames (shutter artifact)
            if any(strcmp(this.an.an.preProcOptions, 'skipFrame')) && this.an.an.nSkipFrame > 0;
                for iChan = 1 : numel(data);
                    data{iChan} = data{iChan}(:, :, 1 + this.an.an.nSkipFrame : end);
                end;
            
                % store in the pre-processed holder with no pre-processing
                this.data.preProc{iDWRow} = data;
                this.data.preProcType{iDWRow} = {'skipFrame'};
            end;
            
            % fill in the state column
            if isGUI(this);
                loadState = upper(loadType(1));
                if ~isempty(this.data.img.caTraces{iDWRow});
                    loadState = [loadState '|P'];
                end;
                this.dw.runTable{iDWRow, 17} = loadState;
                jTable = getJTable(this, 'DWRunTable');
                if numel(loadState) == 1; loadState = [loadState ' ']; end;
                jTable.setValueAt(loadState, iDWRow - 1, 17 - 1);
            end;

            showMessage(this, sprintf('Loading data row %s (%02d%s) done (%3.1f sec).', ...
                runID, iDWRow, prog, toc(DWLoadRowTic)));

        else
            
            showMessage(this, sprintf('Data for %s (%02d%s) already loaded ("%s").', runID, iDWRow, prog, ...
                rawDataLoadType));
            
            % fill in the state column
            if isGUI(this);
                loadState = upper(rawDataLoadType(1));
                if ~isempty(this.data.img.caTraces{iDWRow});
                    loadState = [loadState '|P'];
                end;
                this.dw.runTable{iDWRow, 17} = loadState;
                jTable = getJTable(this, 'DWRunTable');
                if numel(loadState) == 1; loadState = [loadState ' ']; end;
                jTable.setValueAt(loadState, iDWRow - 1, 17 - 1);
            end;
            
        end;
        
    % ROISet: load reference image if any
    case 'ROISet';
        
        % get the ROISet index
        ROISetHits = regexp(char(this.dw.runTable{iDWRow, 8}), '^RS(?<iROISet>\d+)', 'names');
        if ~isempty(ROISetHits);
            iROISet = str2double(ROISetHits.iROISet);
            if iscell(this.data.img.ROISets{iROISet, 3});
                this.data.preProc{iDWRow} = this.data.img.ROISets{iROISet, 3};
            else
                for iChan = 1 : this.an.img.nChans;
                    if iChan == this.an.img.preProcChan;
                        this.data.preProc{iDWRow}{iChan, 1} = this.data.img.ROISets{iROISet, 3};
                    else
                        this.data.preProc{iDWRow}{iChan, 1} = zeros(size(this.data.img.ROISets{iROISet, 3}));
                    end;
                end;
            end;
            this.data.preProcType{iDWRow} = {};
        end;

    otherwise

        % do nothing

end;

end
