%% #OCIA:DW:DWWaitBar
function DWWaitBar(this, percent)

    o('#DWWaitBar(): %d%% ...', percent, 5, this.verb);
    
    if ~isGUI(this); return; end;
    
    % clear previous progress
    cla(this.GUI.handles.dw.waitBar);
    
    % set boundaries of percent to minimum 0 and maximum 100
    percent = min(max(percent, 0), 100);
    
    % if percent is more than 0, draw the progress bar filling
    if percent;
        this.GUI.handles.dw.waitBarRect = rectangle('Parent', this.GUI.handles.dw.waitBar, ...
            'FaceColor', 'red', 'EdgeColor', 'black', 'Position', [0 0 percent 1]);
    end;
    
    % display text
    text('Parent', this.GUI.handles.dw.waitBar, 'Position', [50, 0.5, 0], 'FontSize', 9, 'Color', 'white', ...
        'String', sprintf('%04.1f%%', percent), 'HorizontalAlignment', 'center');
    
    pause(0.01); % required to let the GUI update itself
    
    o('#DWWaitBar(): %d%% done.', percent, 5, this.verb);
    
end