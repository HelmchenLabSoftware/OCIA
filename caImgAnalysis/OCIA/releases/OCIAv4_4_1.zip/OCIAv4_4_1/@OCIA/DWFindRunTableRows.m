%% #OCIA:DW:DWFindRunTableRows
function varargout = DWFindRunTableRows(this, pathFilter, dayFilter, spotFilter, runTypeFilter, ...
        iRunFilter, commentFilter, ROIFilter)

o(['#findRunTableRows(): pathFilter: %s, dayFilter: %s, spotFilter: %s, runTypeFilter: %s, iRunFilter: %s, ' ...
    'commentFilter: %s, ROIFilter: %s ...'], pathFilter, dayFilter, spotFilter, runTypeFilter, iRunFilter, ...
    commentFilter, ROIFilter, 4, this.verb);

rowBools = true(1, size(this.dw.runTable, 1)); % get all rows

% filter for each type
if ~isempty(pathFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, pathFilter, 'once')), this.dw.runTable(:, 1)');
end;
if ~isempty(dayFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, dayFilter, 'once')), this.dw.runTable(:, 2)');
end;
if ~isempty(spotFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, spotFilter, 'once')), this.dw.runTable(:, 7)');
end;
if ~isempty(runTypeFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, runTypeFilter, 'once')), this.dw.runTable(:, 8)');
end;
if ~isempty(iRunFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, iRunFilter, 'once')), this.dw.runTable(:, 9)');
end;
if ~isempty(commentFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, commentFilter, 'once')), this.dw.runTable(:, end)');
end;
if ~isempty(ROIFilter);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, ROIFilter, 'once')), this.dw.runTable(:, 16)');
end;

if nargout == 1;
    varargout = {find(rowBools)};
else
    varargout = {find(rowBools), rowBools};
end;

end