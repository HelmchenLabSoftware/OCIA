%% #BEImagingTTL
function BEImagingTTL(this, h, ~)

if get(this.GUI.handles.be.imageEnableOff, 'Value');
    set(this.GUI.handles.be.imagTTL, 'Value', 0);
    if nargin > 2;
        showWarning(this, 'OCIA:Behavior:ImagingDisabled', 'Imaging is disabled.');
    end;
    return;
end;

if this.be.hw.connected && isfield(this.be.hw, 'anOut');
    if this.GUI.handles.be.imagTTL ~= h; % if change was requested by a input value
        imagTTLState = h;
        o('#BEImagingTTL(): h: %d, imagTTLState: %d.', h, imagTTLState, 3, this.verb);
    else % if change was requested by the callback
        imagTTLState = get(this.GUI.handles.be.imagTTL, 'Value');
        o('#BEImagingTTL(): h: %d, value: %d.', h, get(h, 'Value'), 3, this.verb);
    end;
    if this.be.hw.anOut.IsRunning();
%         tic;
%         o('#BEImagingTTL(): pre-stopping analog out...', 2, this.verb);
        this.be.hw.anOut.stop();
%         o('#BEImagingTTL(): pre-stopping analog out done (%.2f sec).', toc, 2, this.verb);
    end;
%     tic;
%     o('#BEImagingTTL(): queuing analog out...', 2, this.verb);
    this.be.hw.anOut.queueOutputData(imagTTLState * 5);
%     o('#BEImagingTTL(): queuing analog out done (%.2f sec).', toc, 2, this.verb);
%     tic;
%     o('#BEImagingTTL(): starting analog out...', 2, this.verb);
    this.be.hw.anOut.startForeground();
%     this.be.hw.anOut.startBackground();
%     o('#BEImagingTTL(): starting analog out done (%.2f sec).', toc, 2, this.verb);
    if this.be.hw.anOut.IsRunning();
%         tic;
%         o('#BEImagingTTL(): stopping analog out...', 2, this.verb);
        this.be.hw.anOut.stop();
%         o('#BEImagingTTL(): stopping analog out done (%.2f sec).', toc, 2, this.verb);
    end;
    if imagTTLState;
%         showMessage(this, 'Imaging on.');
        set(this.GUI.handles.be.imagTTL, 'BackgroundColor', 'green', 'Value', 1);
    else
%         showMessage(this, 'Imaging off.');
        set(this.GUI.handles.be.imagTTL, 'BackgroundColor', 'red', 'Value', 0);
    end;
else
    showWarning(this, 'OCIA:Behavior:ImagingTTLHardwareDisconnected', 'Hardware is disconnected.');
    set(this.GUI.handles.be.imagTTL, 'BackgroundColor', 'red', 'Value', 0);
end;

end
