%% #OCIA:OCIA_startFunction_behavior
function OCIA_startFunction_behavior(this)

    OCIAChangeMode(this, 'Behavior');     
    
    set(this.GUI.handles.be.imageEnableGroup, 'SelectedObject', this.GUI.handles.be.imageEnableOff); % off
%     set(this.GUI.handles.be.imageEnableGroup, 'SelectedObject', this.GUI.handles.be.imageEnableOn);  % on       
    
    % BEChangePunishDur(this, 0.4);
    BEChangePunishDur(this, 0.0001);

    BEChangeAutoRewardMode(this, 'On');
%     BEChangeAutoRewardMode(this, 'Auto');
%     BEChangeAutoRewardMode(this, 'Off');
    
    BEChangePiezoThresh(this, 0.008);
    
end
