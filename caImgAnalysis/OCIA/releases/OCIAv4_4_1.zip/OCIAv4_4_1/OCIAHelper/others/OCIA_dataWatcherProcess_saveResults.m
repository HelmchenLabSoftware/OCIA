%% #OCIA_dataWatcherProcess_saveResults
function OCIA_dataWatcherProcess_saveResults(this, ~, ~)

% get imaging rows
imgRows = DWFindRunTableRows(this, 'imgData', '', '', '', '', '', '');
% loop trough all rows
for iRow = 1 : numel(imgRows);
    
    % get the path for this row and modify it
    fullFolderPath = DWGetRunTableRowFullPath(this, imgRows(iRow));
    newPath = regexprep(fullFolderPath, '/$', '_MF/');
    
    % get the ROISet for this row
    ROISet = ANGetROISetForRow(this, imgRows(iRow));
    
    % get the data for this row
    caData = this.data.img.caTraces{iRow};
    
    % create the structure
    Ca = struct();
    Ca.roiLabel = ROISet(:, 1);
    
    % if there is some data
    if ~isempty(caData);
    
        % create the directory if needed
        if exist(newPath, 'dir') ~= 7; mkdir(newPath); end;
    
        % load the calcium data in the right format
        Ca.dRR = cell(numel(Ca.roiLabel), 1);
        for iROI = 1 : numel(Ca.roiLabel);
            Ca.dRR{iROI, 1} = repmat(caData(iROI, :), 2, 1);
        end;

        % save the data
        save(sprintf('%somlortest_%s__%s.mat', newPath, this.dw.runTable{imgRows(iRow), 2 : 3}), 'Ca');
        
    end;
    
end;


o('#OCIA_dataWatcherProcess_saveResults(): saving results done.', 2, this.verb);

end
