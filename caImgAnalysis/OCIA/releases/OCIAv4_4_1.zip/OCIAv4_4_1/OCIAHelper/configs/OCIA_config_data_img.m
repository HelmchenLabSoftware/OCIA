function [this, inputParams] = OCIA_config_data_img(this)
% adds the imaging data structures to the OCIA

inputParams = [];

%% -- properties: Data: Imaging
% structure with cell-array fields (except "ROISets") that have one cell per run/row
this.data.img = struct();
% extracted calcium imaging traces (DFF/DRR) for each run/row
this.data.img.caTraces = cell(this.dw.dataNMaxRuns, 1);
% exclusion mask for each run/row (from motion detection)
this.data.img.exclMask = cell(this.dw.dataNMaxRuns, 1);
% stimulus vector for each run/row
this.data.img.stim = cell(this.dw.dataNMaxRuns, 1);
% ROISets for the imaging data. The 3 columns are: { ROISet cell array, runsValidity, refImage }
this.data.img.ROISets = cell(0, 3);
   

end
