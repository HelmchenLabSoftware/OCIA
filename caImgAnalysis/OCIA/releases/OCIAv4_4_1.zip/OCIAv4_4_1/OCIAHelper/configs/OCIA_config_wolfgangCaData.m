function [this, inputParams] = OCIA_config_wolfgangCaData(this)

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

%% - input parameters
inputParams.startFunctionName = 'dataWatcher';

% defines whether to show or not a GUI
this.GUI.noGUI = false;
% defines the values of the data watcher filters at start
this.GUI.dw.DWFilt = { '' };
% defines which watch types should be activated at start
this.GUI.dw.DWWatchTypes = 'all';
% defines whether to skip meta-data processing
this.GUI.dw.DWSkiptMeta = false;
% defines whether to use the raw or local watch folder
this.GUI.dw.DWRawOrLocal = 'local';

%% -- properties: general: paths to relevant locations (raw data, ect.)
% path of the raw data (usually stored on the server)
this.path.rawData = 'F:/RawData/WolfgangCa/';
% path of the local data
this.path.localData = 'F:/RawData/WolfgangCa/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'F:/RawData/WolfgangCa/';

%% - properties: GUI
% initial position of the main window
this.GUI.pos = [300, 300, 1220, 805]; % default
this.GUI.modes = { 'DataWatcher', 'dw'; 'ROIDrawer', 'rd'; 'Analyser', 'an' };

%% -- properties: DataWatcher
% tells which parts of the raw path should be used for the saving
this.dw.savePathParts = [1, 2];% defines whether the watch folder should be automatically processed upon changing its path
% name of the function that parses the notebook file
this.dw.notebookParsingFunctionName = '';
% name of the function that do post-processing after the notebook file parsing
this.dw.extractNotebookPostProcessFunctionName = 'default';
% name of the function that do pre-processing of the selected rows
this.dw.preProcessFunctionName = 'wolfgangCaData';
% specifies whether to overwrite the file where the data will be saved
this.dw.overwriteSaveFile = false;
% specifies whether to overwrite the data when saving it to HDF5 if it already exists
this.dw.overwriteHDF5Data = true;
% specifies which data should be saved in the HDF5 file
this.dw.dataAsHDF5 = { 'raw', 'preProc', 'caTraces', 'ROISets' };
% file patterns for files inside "watchType" folders (these are kind of "sub-watchTypes")
this.dw.watchTypeFilePatterns = struct();
this.dw.watchTypeFilePatterns.roisetfile = '^ROISet_(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h.mat$';
this.dw.watchTypeFilePatterns.imgdata       = ['^(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h__', ...
    'channel_?(?<iChan>\d+)\.(tif|bin)$'];
this.dw.watchTypeFilePatterns.imgmetadata   = '';

% specifies which further processing step buttons are available as a cell array with 4 columns: { ID, label, tag, 
%   tooltip }
this.GUI.dw.dataWatcherProcessStepButtons = { ...
    'drawROIs',     'Draw ROIs',            'DWDrawROIs',       'Draw Regions Of Interest for selected rows';
    'preProcRows',  'Pre-process row(s)',   'DWPreProcRows',    'Pre-process selected rows';
    'analyseRows',  'Analyse row(s)',       'DWAnalyseRows',    'Analyse selected rows';
    'saveResults',  'Save results',         'DWSaveResults',    'Save results';
};

%% -- properties: DataWatcher : watch types
% file/folder types that can be processed and will appear in the runTable with their regexp pattern, stored
%   as a cell-array with 6 columns: { ID, display name, parent folder, visible in GUI, tooltip text, 
%   regular expression pattern }
this.dw.watchTypes = {
    'day',          'Day',          [],         true,   'Day folder',               '^\d{4}_\d{2}_\d{2}$';
    'img',          'Imag. data',   'day',     true,   'Imaging data folder', ...
        '^(?<date>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h$';
    'roiset',       'ROISet',       'day',      true,   'ROISet folder',            '^ROISets$';
};  

%% -- properties: DataWatcher : data configuration
% defines which data "modules" should be appended to the software
this.dw.dataModes = { 'img'; };
% define the data saving options for each "type" of saving
this.dw.dataSaveConfig = { ...
    'GUI',      'GUI',              'Save / load the GUI (run table, checkboxes'' values, etc.)';
    'raw',      'Raw data',         'Save / load the raw data';
    'preProc',  'Pre-proc. data',   'Save / load the pre-processed data';
    'caTraces', 'Calcium traces',   'Save / load the extracted calcium traces';
    'ROISets',  'ROISets',          'Save / load the ROISets';
};

% apply data configuration
configHandle = str2func('OCIA_config_data');
this = configHandle(this);

%% -- properties: DataWatcher: filter elements and IDs
% defines the aspect of the filtering panel: cell array with nFilt lines and 
%   5 columns: { filter name, GUI type, GUI width and DW runtable column where to apply the filter, supports range }
this.GUI.dw.filtElems = { ...
    'day',      'dropdown',     1,      2,  false;
    'spot',     'dropdown',     1,      1,  false;
    'rowtype',  'textfield',    1,      1,  false;
    'runtype',  'textfield',    1,      9,  true;
};
% define the "IDs" field for each drop-down data watcher filter element
dropDownListFilterNames = this.GUI.dw.filtElems(strcmp(this.GUI.dw.filtElems(:, 2), 'dropdown'), 1);
for iName = 1 : numel(dropDownListFilterNames);
    filtName = dropDownListFilterNames{iName}; % get the filter name
    % create a list with only a dash element, which corresponds to no filtering
    this.dw.([filtName 'IDs']) = {'-'};
end;

%% -- properties: Analyser
% available plot types in the analyser panel
this.an.plotTypes = { 'ROICaTraces', 'ROICaTracesHeatMap', 'RawTraces' };

%% -- properties: Analyser: Imaging
% number of channel(s) to load; also the number of data files that should be in a data folder
this.an.img.nChans = 2;
% index of the channel on which the pre-processing should be calculated (motion correction/detection, etc.)
this.an.img.preProcChan = 1;
% channels to use for the RGB image display
this.an.img.colVect = [0 1 2];
% channels to use for the dFF/dRR calculations
this.an.img.chanVect = [1 2];
% frame rate of the imaging in hertz
this.an.img.defaultFrameRate = 10;
% fixed/default dimensions of the imaging data in pixels
this.an.img.defaultImDim = [128 64];
% minimum number of frames for a row to be considered as a functional movie
this.an.img.funcMovieNFramesLimit = 2;
% F0/R0 method index. Methods are mean, median, prctile, polyfit, polyfitMean
this.an.img.f0method = 3;
% F0/R0 parameter (can be empty), for percentile: Nth percentile; for polyfit: polyfit degree
this.an.img.f0params = 12;
% degree of the polyfit correction for bleaching. Set to 0 for no correction.
this.an.img.polyfitCorrect = 0;
% percent of the trace where the polyfit correction should be calculated
this.an.img.polyfitFraction = 0;
%% -- properties: Analyser: Analysis
% name of the stimuli
this.an.an.stimIDs = {};
% duration of the stimulus in seconds
this.an.an.stimDur = 0;
% number of frames to remove in the begining of the imaging data (shutter artifact)
this.an.an.nSkipFrame = 1;
% determines which transformation should be used for the turboReg registration, which can be one
%   of: translation/rigidBody/affine/bilinear
this.an.an.regTransf = 'rigidBody';
% determines whether a filter should be applied on the images before motion correction
this.an.an.moCorrFilt = false;
% determines the minimum difference of the 5th percentile of the frame-wise correlation of each aligned frame to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorMeanFrameCorrDiffThresh = -0.05;
% determines the minimum difference of correlation of the average of the aligned frames to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorFrameCorrToRefDiffThresh = -0.1;
% determines the minimum correlation (absolute number) of the average of the aligned frames to the reference
% frame for the motion correction to pass the quality control
this.an.an.moCorFrameCorrToRefAbsThresh = 0.85;
% determines whether to use the non-aligned stacks if the quality control failed
this.an.an.moCorUseNonCorrectedIfQualityControlFailed = false;
% determines whether a filter should be applied on the images before motion detection
this.an.an.moDetFilt = true;
% determines at which threshold is a frame consider out of focus
this.an.an.moDetOOFThreshFactor = 1.6;
% determines which pre-processing options should be applied. Should be a cell array containing one or
%   more of: 'skipFrame', 'fShift', 'fJitt', 'moCorr', 'moDet'
this.an.an.preProcOptions = { 'skipFrame', 'moCorr' };
% number of seconds for the peri-stimulus averaging (peri-stimulus period): base and evoked
this.an.an.PSPer = [0 0];
% fraction of the image that should excluded on the borders for the neuropil mask
this.an.an.nPilMaskBord = 0.15;
% down-sampling factor to apply to the functional data to the functional data (DRR or DFF)
this.an.an.downSampFactor = 1;
% frame size of the Savitzky-Golay filter to apply to the functional data (DRR or DFF)
this.an.an.sgFiltFrameSize = 1;
% determines whether a temporal filter (Savitzky-Golay) should be applied on the ROI time series of each channel
%   before ratio (DFF/DRR) calculation
this.an.an.channelSFGiltFrameSize = 1;
% determines whether a down sampling factor should be applied on the ROI time series of each channel
%   before ratio (DFF/DRR) calculation
this.an.an.channelDownSampFactor = 1;

end
