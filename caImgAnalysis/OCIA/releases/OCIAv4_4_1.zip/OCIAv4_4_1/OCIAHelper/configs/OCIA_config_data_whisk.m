function [this, inputParams] = OCIA_config_data_whisk(this)
% adds the whisker data structures to the OCIA

inputParams = [];

%% - properties: Data: Whisker
% structure *array* with one element per row of the data watcher's run table
this.data.whisk = struct();
% average whisker angle
this.data.whisk.angle = [];
% frame rate of the whisker angle data
this.data.whisk.frameRate = [];

% expand to a structure array
this.data.whisk(this.dw.dataNMaxRuns) = this.data.whisk(1);
   

end
