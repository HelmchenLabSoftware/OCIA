function [this, inputParams] = OCIA_config_roidrawer(this)
% add the ROI drawer mode to the OCIA

inputParams = [];

%% -- properties: GUI: ROIDrawer
this.GUI.rd = struct();
% default size of the first empty left and right images
this.GUI.rd.defaultImDim = 200;
% the different tools for the ROIDRawer
this.GUI.rd.drawTools = { 'ellipse', 'freehand' };
% currently displayed image
this.GUI.rd.img = zeros(this.GUI.rd.defaultImDim, this.GUI.rd.defaultImDim, 3);
% currently applied image corrections
this.GUI.rd.applImCorr = { };
% current zoom level
this.GUI.rd.zoomLevel = 1;

%% -- properties: ROIDrawer
this.rd = struct();
% cell array continaing the data for each loaded runTable row with 3 columns:
%   { displayText, full file path, RGB image (not modified) }
this.rd.runTable = cell(0, 3);
% ROIMask mask defined by the drawn ROIs
this.rd.ROIMask = [];
% current number of ROIs
this.rd.nROIs = 0;
% cell-array continaing the data for the drawn ROIS. Columns are: {handles of the drawn ROIs (imroi objects),
    % ROI IDs, ROI's position, ROI type (ellipse, freehand, etc.), text handles, modified flag.
this.rd.ROIs = {};
% ROISet comparator's temporary files
this.rd.rc = struct('ROISetIDs', [], 'ROISets', [], 'refImgs', [], 'ROINamesUnion', [], 'displayedRef', -1);
% vectors of displacement when moving all ROIs at the same time
this.rd.moveROIVects = struct('up', [0 -1 0 0], 'down', [0 1 0 0], 'left', [-1 0 0 0], 'right', [1 0 0 0]);
% number of pixels/units to move ROIs when adjusting the position of ROIs
this.rd.moveROIsStep = 2;
% angle in degrees to rotate ROIs when adjusting the position of ROIs
this.rd.rotateROIsStep = 1;
% possible image corrections
this.rd.imCorr = { 'imAdj', 'pseudFF', 'mask' };


end
