%% #OCIA:DW:OCIA_processFolder_behav
function runTable = OCIA_processFolder_behav(this, folderPath, ~, folderName, ~, ~, ~)

behavProcessTic = tic;
o('#OCIA_processFolder_behav(): in ''%s''.', folderPath, 3, this.verb);

runTable = cell(20, size(this.dw.runTable, 2)); % create an information row
iRow = 1;
behavFolderPath = [folderPath '/'];

% check what's in the watchfolder and exclude irrelephant files
dirParseTic = tic;
files = dir(behavFolderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) ...
        isempty(regexp(x.name, this.dw.watchTypeFilePatterns.behavdata, 'once')) && ...
        isempty(regexp(x.name, this.dw.watchTypeFilePatterns.behavmovie, 'once')), files)) = [];

nFiles = numel(files); % count the number of remaining files
o('#OCIA_processFolder_behav(): found %d file(s) (%3.1f sec).', nFiles, toc(dirParseTic), 5, this.verb);

% loop trough all existing files
for iFolder = 1 : nFiles;
    fileName = files(iFolder).name;
    o('  #OCIA_processFolder_behav(): found file ''%s''.', fileName, 5, this.verb);

    % behavior mat-file
    if regexp(fileName, this.dw.watchTypeFilePatterns.behavdata, 'once');

        % extract the information using regexp and store them in the runTable
        behavFileHits = regexp(fileName, this.dw.watchTypeFilePatterns.behavdata, 'names');
        runTable{iRow, 1} = ' / behavData';
        runTable{iRow, 2} = behavFileHits.date;
        runTable{iRow, 3} = behavFileHits.time;
        runTable{iRow, 4} = '01'; % number of files

        behavDataStruct = load([folderPath '/' fileName]);
        out = behavDataStruct.out;

        this.an.behav(end + 1, 1 : 2) = runTable(iRow, 2 : 3);
        this.an.behav{end, 3} = ''; % place for spotID, filled in after notebook infos extraction
        this.an.behav{end, 4} = out;
        runTable{iRow, 5} = sprintf('%02d/%02d trials', out.config.training.nTrials, out.iTrial);
        
        % find the right fieldname
        animalIDFieldNames = {'animalID', 'mouseID', 'mouseId'};
        animalIDFieldName = animalIDFieldNames{isfield(out, {'animalID', 'mouseID', 'mouseId'})};
        runTable{iRow, 6} = out.(animalIDFieldName);
        
%       behavRunTable{iRow, 7} = spotID; % spotID will be retrieved from notebook infos extraction
        runTable{iRow, 8} = sprintf('B%02d', size(this.an.behav, 1));
        runTable{iRow, 10} = sprintf('%.1f MB', files(iFolder).bytes / 1E6);
        runTable{iRow, end} = sprintf('task: %s, phase: %s', out.taskType, out.phase);

    % behavior movie
    elseif regexp(fileName, this.dw.watchTypeFilePatterns.behavmovie, 'once');

        % extract the information using regexp and store them in the runTable
        behavMovieHits = regexp(fileName, this.dw.watchTypeFilePatterns.behavmovie, 'names');
        runTable{iRow, 1} = ' / behavMovie';
        runTable{iRow, 2} = strrep(behavMovieHits.date, '-', '_');
        runTable{iRow, 3} = regexprep(strrep(behavMovieHits.time, '-', '_'), '\.\d{3}$', '');

    else % if no file pattern matched, show warning

        showWarning(this, 'OCIA:OCIA_processFolder_behav:UnknownFileFound', ...
            sprintf('Unknown file type found: ''%s''! Skipping it.', fileName));
        continue;
    end;

    iRow = iRow + 1; % increment the counter
end;

% clean up runTables: delete empty cells
o('  #OCIA_processFolder_behav(): folder(s) processing done, cleaning up runTables ...', 5, this.verb);
runTable(cellfun(@isempty, (runTable(:, 1))), :) = [];

o('  #OCIA_processFolder_behav: %s done (%3.1f sec).', folderName, toc(behavProcessTic), 4, this.verb);

end
