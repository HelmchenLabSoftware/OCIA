%% #OCIA:DW:OCIA_processFolder_intrinsic
function runTable = OCIA_processFolder_intrinsic(this, folderPath, ~, folderName, ~, ~, ~)

intrProcessTic = tic;
o('#OCIA_processFolder_intrinsic(): in ''%s'', folderName: %s.', folderPath, folderName, 4, this.verb);

runTable = cell(100, size(this.dw.runTable, 2)); % create an information row
iRow = 1;
intrFolderPath = [folderPath '/'];

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns
intrinsicPattern = watchTypePatterns{strcmp(watchTypeIDs, 'intrinsic')};

% extract date from the intrinsic folder's name
intrHits = regexp(folderName, intrinsicPattern, 'names');

% if there was a match, fill in the cells 
if ~isempty(intrHits);
    intrDate = intrHits.date;
% if there was no match, show a warning and leave empty
else
    showWarning(this, 'OCIA:OCIA_processFolder_intrinsic:IntrFolderDateMatchFailure', ...
        sprintf('Cannot match date to intrinsic folder name: ''%s'' with pattern ''%s''.', ...
            folderName, intrinsicPattern));
    intrDate = this.dw.runTableEmptyCellContent;
end;

% check what's in the watchfolder and exclude irrelephant files
dirParseTic = tic;
files = dir(intrFolderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) ...
        isempty(regexp(x.name, this.dw.watchTypeFilePatterns.intrbinary, 'once')) && ...
        isempty(regexp(x.name, this.dw.watchTypeFilePatterns.intrvessel, 'once')), files)) = [];


nFiles = numel(files); % count the number of remaining files
o('#OCIA_processFolder_intrinsic(): found %d file(s) (%3.1f sec).', nFiles, toc(dirParseTic), 5, this.verb);

% loop trough all existing files
for iFile = 1 : nFiles;
    fileName = files(iFile).name;
    o('  #OCIA_processFolder_intrinsic(): found file ''%s''.', fileName, 5, this.verb);

    % intrinsic binaryfile
    if regexp(fileName, this.dw.watchTypeFilePatterns.intrbinary, 'once');

        % extract the information using regexp and store them in the runTable
        intrFileHits = regexp(fileName, this.dw.watchTypeFilePatterns.intrbinary, 'names');
        runTable{iRow, 1} = ' / intrBinary';
        runTable{iRow, 2} = intrDate;
        runTable{iRow, 4} = intrFileHits.intrNum;

        % make a nicer display for the frequency or no sound
        if regexp(intrFileHits.freq, '\d+', 'once'); freqOrNoSound = [intrFileHits.freq 'kHz'];
        else freqOrNoSound = 'no sound'; end

        runTable{iRow, end} = sprintf('%s, %sum deep, %s, %s sweeps', intrFileHits.color, ...
            intrFileHits.depth, freqOrNoSound, intrFileHits.nSweeps);

    % vessels file
    elseif regexp(fileName, this.dw.watchTypeFilePatterns.intrvessel, 'once');

        % extract the information using regexp and store them in the runTable
        vesselsFileHits = regexp(fileName, this.dw.watchTypeFilePatterns.intrvessel, 'names');
        runTable{iRow, 1} = ' / intrVessel';
        runTable{iRow, 2} = intrDate;
        runTable{iRow, 4} = vesselsFileHits.vesselNum;
        if isempty(runTable{iRow, 4}); runTable{iRow, 4} = '00'; end; % do not leave empty

        % if required, get the dimension informations
        if ~get(this.GUI.handles.dw.skipMeta, 'Value');
            imInfo = imfinfo([folderPath '/' fileName]);
            dims = [imInfo(1).Width imInfo(1).Height];
            % create and store a dimension tag like : '256x256' or '100x100x3'
            runTable{iRow, 5} = regexprep(sprintf(repmat('%dx', 1, numel(dims)), dims), 'x$', '');
        end

    else % if no file pattern matched, show warning

        showWarning(this, 'OCIA:OCIA_processFolder_intrinsic:UnknownFileFound', ...
            sprintf('Unknown file type found: ''%s''! Skipping it.', fileName));
        continue;
    end;

    iRow = iRow + 1; % increment the counter
end;

% clean up runTables: delete empty cells
o('  #OCIA_processFolder_intrinsic(): folder(s) processing done, cleaning up runTables ...', 5, this.verb);
runTable(cellfun(@isempty, (runTable(:, 1))), :) = [];

o('  #OCIA_processFolder_intrinsic: %s done (%3.1f sec).', folderName, toc(intrProcessTic), 4, this.verb);

end
