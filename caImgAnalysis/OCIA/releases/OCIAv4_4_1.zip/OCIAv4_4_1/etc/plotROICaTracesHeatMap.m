function fig = plotROICaTracesHeatMap(axeH, iRun, saveName, ~, caTraces, stim, ROISet, t, ~, cLim, colormapName)

% created by B. Laurenczy - 2013

dbgLevel = 0;
% init the size of the data set
nROIs = size(ROISet, 1);
nFrames = size(caTraces, 2);
o('    #plotROICaTracesHeatMap: run %d ''%s'', %d ROI(s), %d frames ...', iRun, saveName, nROIs, nFrames, 2, dbgLevel);

% init the title and the figure
if iRun;
    titleStr = sprintf('%s_run%02d', saveName, iRun);
else
    titleStr = saveName;
end;
if isempty(axeH);
    fig = figure('Name', titleStr, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', fig);
    colormap('hot');
else
    fig = getParentFigure(axeH);
end;

% extract the stimulus 'IDs' by converting the stim index into a string (the index of the stimuli)
stimIDIndexes = stim(stim > 0);
stimIDs = cell(1, numel(stimIDIndexes));
for n = 1 : numel(stimIDIndexes);
    stimIDs{n} = num2str(stimIDIndexes(n));
end

o('    #plotRO..Map: run %d, variables initialized.', iRun, 2, dbgLevel);
% init variables for plotting
normFiltCaTraces = zeros(nROIs, nFrames);

% go through each ROI to extract the ROI's ID and to normalize the data
iROI = 1;
for iROILoop = 1 : nROIs;
    
    ROICaTrace = caTraces(iROILoop, :);
    % if the ROI trace is not empty/null
    if nansum(ROICaTrace);
        % normalize by removing the minimum value and add the maximum so far
        normFiltCaTraces(iROI, :) = ROICaTrace;
        iROI = iROI + 1;
    else
        nROIs = nROIs - 1;
        normFiltCaTraces(iROI, :) = [];
        o('      #plotRO..Map: run %d, ROI %d is null (no value above 0).', iRun, iROI, 0, dbgLevel);
    end;
end;
o('    #plotRO..Map: run %d, caTraces normalized.', iRun, 2, dbgLevel);

normFiltCaTraces = flipud(normFiltCaTraces);
ROIIDs = flipud(ROISet(:, 1));

imagesc(t, 1 : nROIs, normFiltCaTraces, 'Parent', axeH);
if ~isempty(cLim); set(axeH, 'CLim', cLim); end;
hColBar = colorbar('peer', axeH);
set(get(hColBar, 'YLabel'), 'String', 'DFF/DRR [%]');
% colormap(fig, 'hot');
colormap(axeH, colormapName); close(gcf);
% colormap(axeH, 'jet');

% adjust the axes of the calcium traces
imagescAxe = axeH;
xlabel(axeH, 'Time [s]');
ylabel(axeH, 'ROIs');

% maxT = t(end); % sec
% if maxT > 200; roundTo = 20;
% elseif maxT > 50; roundTo = 10;
% elseif maxT > 20; roundTo = 5;
% elseif maxT > 10; roundTo = 2;
% else roundTo = 1;
% end;

% timeTicks = round(t(1)) : roundTo : round(t(end));
% frameRate = 1 / (t(2) - t(1));
% ticks = timeTicks * frameRate;
% ticks(1) = 1;
% set(imagescAxe, 'XTick', ticks, 'XTickLabel', timeTicks);

nROIs = size(ROIIDs, 1);
if nROIs > 300; roundTo = 20;
elseif nROIs > 150; roundTo = 10;
elseif nROIs > 80; roundTo = 5;
elseif nROIs > 40; roundTo = 2;
else roundTo = 1;
end;

ROITicks = numel(ROIIDs) - (-1 : roundTo : numel(ROIIDs));
ROITicks(end) = 1;
ROITicks(1) = numel(ROIIDs);
ROITicks = unique(ROITicks);
ROIIDLabels = ROIIDs(ROITicks);
% create and adjust the axes of the stims labels 
set(imagescAxe, 'YTick', ROITicks, 'YTickLabel', ROIIDLabels);
% title(titleStr, 'Interpreter', 'none');
o('    #plotRO..Map: run %d, axes initialized.', iRun, 2, dbgLevel);

if ~isempty(stim);
    yLimits = get(axeH, 'YLim');
    hold(axeH, 'on');
    uniqueStims = unique(stimIDIndexes);
    % colors for the simuli
    stimColors = lines(numel(unique(stimIDIndexes)));
    % plot the stimuli in the appropriate colors
    for n = 1 : numel(stim);
        if stim(n);
            stimColor = stimColors(stim(n) == uniqueStims, :);
            plot(axeH, [n n], yLimits, 'LineStyle', '--', 'Color', stimColor, 'LineWidth', 3);
            text(n, yLimits(1) - 0.025 * nROIs, num2str(stim(n)), 'Color', stimColor, 'Parent', axeH, ...
                'HorizontalAlignment', 'center');
            
%             text(n, 0.1, '\downarrow', 'Color', stimColor, 'Parent', axeH);
%             text(n, -0.2, num2str(stim(n)), 'Color', stimColor, 'Parent', axeH);
%             text(n, nROIs + 0.75, '\uparrow', 'Color', stimColor, 'Parent', axeH);
%             text(n, nROIs + 1.05, num2str(stim(n)), 'Color', stimColor, 'Parent', axeH);
        end;
    end
    hold(axeH, 'off');
    o('    #plotRO..Map: run %d, stims plotted.', iRun, 2, dbgLevel);
end;

o('    #plotRO..Map: run %d ''%s'', %d ROI(s), %d frame(s) done.', ...
    iRun, saveName, nROIs, nFrames, 1, dbgLevel);

end