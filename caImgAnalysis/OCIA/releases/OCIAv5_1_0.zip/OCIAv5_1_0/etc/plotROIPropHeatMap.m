function figHand = plotROIPropHeatMap(axeH, PSCaTraceMeans, stimIDs, saveName, ROINames, plotLimits, colorMapName, colBarLab, titleString)

%% init
% get the size of the data set
[nStimTypes, nROIs] = size(PSCaTraceMeans); %#ok<ASGLU>

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
    axeParent = get(axeH, 'Parent');
end;

%% plot
nStimIDs = numel(stimIDs);
% plot the matrix as heat map
imagesc(1 : nStimIDs, 1 : nROIs, PSCaTraceMeans', 'Parent', axeH);
% if there are plot limits, apply them
if ~isempty(plotLimits);
    set(axeH, 'CLim', plotLimits);
end;
% change the colormap
colormap(axeH, colorMapName); close(gcf);
% remove ticks
set(axeH, 'XTick', 1 : nStimIDs, 'XTickLabel', stimIDs, 'YTick', [], 'FontSize', max(min(15 - (0.166 * nStimIDs), 20), 6));

% add the color bar on the last axe
hColBar = colorbar('peer', axeH);
set(get(hColBar, 'YLabel'), 'String', colBarLab);

% create the ROI label axe
textAxeH = axes('Parent', axeParent, 'Color', 'blue', 'Position', get(axeH, 'Position'), 'Visible', 'off', ...
    'XLim', get(axeH, 'XLim'), 'YLim', get(axeH, 'YLim'));
% add ROI labels
ROINamesFlipped = flipud(ROINames);
for iROI = 1 : nROIs;
    text(0.5 - nStimIDs / 50, iROI, ROINamesFlipped{iROI}, 'Parent', textAxeH, 'HorizontalAlignment', 'right', ...
        'Interpreter', 'none', 'FontSize', max(min(15 - (0.166 * nROIs), 20), 6));
end;
% link all these axes
linkaxes([axeH, textAxeH], 'y');
% put the label axe at the bottom
restackAxes(textAxeH, 'bottom');
% add title
title(axeH, titleString);

end
