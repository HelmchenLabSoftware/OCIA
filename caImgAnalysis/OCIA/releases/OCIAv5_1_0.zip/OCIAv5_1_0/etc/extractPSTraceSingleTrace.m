function PSData = extractPSTraceSingleTrace(data, stimVector, stimTypes, baseFrames, evokedFrames)
% extracts the peri-stimulus average of a single trace for different stimulus types

% number of stimulus types
nStimTypes = numel(stimTypes);
% number of frames
nFrames = numel(stimVector);
nPeriStimFrames = baseFrames + evokedFrames;
% maximum number of stimulus in the stimulus vector for a given stimulus type
nStims = max(arrayfun(@(i) sum(stimVector == stimTypes(i)), 1 : nStimTypes));

% peri-stimulus data for each stimulus type
PSData = nan(nStimTypes, nStims, nPeriStimFrames);

% go through each stimulus type
for iStimType = 1 : nStimTypes;
    
    % get the current stimulus type
    currStimType = stimTypes(iStimType);
    % get the number of stimuli for this type
    nCurrStims = numel(find(stimVector == currStimType));
    
    % if no stimulus of this type exists, skip
    if isempty(nCurrStims); continue; end;
    
    iStim = 0; % current index of stimulus for the current stimulus type
    
    % go through each frame and check if it contains a stimulus
    for iFrame = 1 : nFrames;
        
        % if current frame is a stimulus frame
        if stimVector(iFrame) == currStimType;
            
            iStim = iStim + 1; % update the counter
            nanPad = 0; % set the nan-padding to 0
            startFrame = iFrame - baseFrames; % find the start frame
            
            % if the start frame is before the first frame, add a nan-padding
            if startFrame < 1;
                nanPad = startFrame - 1; % will be negative
                startFrame = 1;
            end
            
            stopFrame = iFrame + evokedFrames - 1; % find the stop frame
            % if the stop frame is after the last frame, add a nan-padding
            if stopFrame > nFrames;
                nanPad = stopFrame - nFrames; % will be positive
                stopFrame = nFrames;
            end
            
            % create the trace with the eventual nan-padding
            if nanPad == 0; % no nan-padding
                currentTrace = data(1, startFrame : stopFrame);
            elseif nanPad < 0; % nan-padding before the trace
                currentTrace = [nan(1, abs(nanPad)), data(1, startFrame : stopFrame)];
            elseif nanPad > 0; % nan-padding after the trace
                currentTrace = [data(1, startFrame : stopFrame), nan(1, nanPad)];
            end
            
            % store the trace in the cell-array
            PSData(iStimType, iStim, :) = currentTrace;
            
        end; % end of stimulus frame if
        
    end; % end of frame loop
    
end; % end of stimulus type loop

end