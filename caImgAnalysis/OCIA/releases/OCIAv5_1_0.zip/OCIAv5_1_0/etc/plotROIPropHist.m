function figHand = plotROIPropHist(axeH, ROIProp, grouping, groupLabels, ~, saveName, plotLimits, yLab, titleString, groupCurves)

%% init
% get the size of the data set
[nStimTypes, ~] = size(ROIProp); %#ok<ASGLU>

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
end;

% get the number of groups
uniqueGroups = unique(grouping);
nGroups = numel(uniqueGroups);
nROIsPerGroup = arrayfun(@(iGroup) sum(grouping == uniqueGroups(iGroup)), 1 : nGroups);

%% plot
% gather infos about original axe
axeHParent = get(axeH, 'Parent');
basePos = get(axeH, 'Position');
% get subplot sizes
M = ceil(sqrt(nGroups)); N = iff(M * (M - 1) >= nGroups, M - 1, M);
% get the dimensions of the subplots
WPad = basePos(3) * 0.1; W = (basePos(3) - (M - 1) * WPad) / M;
HPad = basePos(4) * 0.1; H = (basePos(4) - (N - 1) * HPad) / N;
X = basePos(1); Y = basePos(2);

% get maximum y axe
maxY = -1;
if isempty(plotLimits);
    plotLimits = [min(ROIProp(:)), max(ROIProp(:))];
end;

% group colors
groupCols = jet(nGroups);

% go through each group
axeHandles = zeros(nGroups, 1);
curveHandles = zeros(nGroups, 1);
iGroupLoop = 1;
for iGroup = 1 : max(uniqueGroups);
    % do not plot not represented groups
    if ~ismember(iGroup, uniqueGroups); continue; end;
    
    % if more than one group/plot, create other axes
    if nGroups ~= 1 && ~groupCurves;
        currAxeH = axes('Parent', axeHParent, 'Color', 'white', 'Position', [X Y W H], 'Visible', 'on');
        % hide the original axe
        set(axeH, 'YTick', [], 'XTick', [], 'XColor', 'white', 'YColor', 'white');
        
    % if only one plot, do not create other axes
    else
        currAxeH = axeH;
    end;
    
    if groupCurves;
        hold(currAxeH, 'on');
    end;
    
    % store the axe handle
    axeHandles(iGroupLoop) = currAxeH;
    
    %% plot
    ROIPropForGroup = ROIProp(grouping == iGroup);
    nBins = round(sqrt(numel(ROIPropForGroup)));
    plotLimRange = abs(diff(plotLimits));
    binCenters = plotLimits(1) : (plotLimRange / nBins) : plotLimits(2);
    [counts, xPos] = hist(currAxeH, ROIPropForGroup, binCenters);
    curveHandles(iGroup) = plot(currAxeH, xPos, counts / nROIsPerGroup(iGroupLoop), 'LineWidth', 2);
    
    % color each curve
    if groupCurves;
        set(curveHandles(iGroup), 'Color', groupCols(iGroup, :));
    end;
    
    % set X limits
    xlim(currAxeH, plotLimits * 1.05);
    
    % add title and axe labels
    set(currAxeH, 'FontSize', 15);
    if Y == basePos(2); xlabel(currAxeH, yLab, 'FontSize', 15); end;
    if X == basePos(1); ylabel(currAxeH, 'Fraction of neurons', 'FontSize', 15); end;
    if groupCurves;
        
    else
        if isempty(titleString) && ~isempty(groupLabels{iGroup});
            title(currAxeH, groupLabels{iGroup}, 'FontSize', 15);
        else
            title(currAxeH, titleString, 'FontSize', 15);
        end;
    end;
    
    % update max y limit
    maxY = max([get(currAxeH, 'YLim'), maxY]);
    
    % if more than one group/plot, update position
    if nGroups ~= 1;
        X = X + W + WPad;
        if X >= basePos(1) + basePos(3);
            X = basePos(1); 
            Y = Y + H + HPad;
        end;
    end;
    iGroupLoop = iGroupLoop + 1;
    
    if groupCurves;
        hold(currAxeH, 'off');
    end;
    
end;

if groupCurves;
    hLeg = legend(currAxeH, curveHandles, groupLabels);
    set(hLeg, 'FontSize', 16);
end;
    
% update Y limit
for iHandle = 1 : numel(axeHandles);
    currYLim = get(axeHandles(iHandle), 'YLim');
    set(axeHandles(iHandle), 'YLim', [currYLim(1), maxY * 1.1]);
end;

end
