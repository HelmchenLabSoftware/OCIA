%% #OCIA:AN:ANGetRawStims
function rawStims = ANGetRawStims(this, selRows)

    % store the "'UniformOutput' false" argument pair in a more convenient form
    UF = { 'UniformOutput', false };
        
    % get the DataWatcher table's index of all rows currently analysed
    allDWRows = cell2mat(this.an.table(:, 11));

    % get the total number of runs analysed
    nTotRuns = numel(allDWRows);
        
    % if the raw stimulus matrix does not exist yet or is empty or only NaNs, create it
    if ~isfield('rawStims', this.data.an) || isempty(this.data.an.rawStims) ...
            || ~any(~isnan(this.data.an.rawStims(:)));

        % get the number of frames for each run
        nFramesEachRun = arrayfun(@(iRun)size(this.data.img.stim{allDWRows(iRun)}, 2), 1 : nTotRuns, UF{:});
        % get the maximum number of frames of the currently analysed data set
        nMaxFrames = max(cell2mat(nFramesEachRun));
        
        % (re-)create the raw stimulus matrix as a nRuns x nFrames matrix with NaNs where there is no data
        this.data.an.rawStims = nan(nTotRuns, nMaxFrames);

        % fill-in the raw stimulus vector for each run
        for iRun = 1 : nTotRuns;
            this.data.an.rawStims(iRun, 1 : nFramesEachRun{iRun}) = this.data.img.stim{allDWRows(iRun)};
        end;
    end;
    
    % get the selected calcium traces
    rawStims = this.data.an.rawStims(selRows, :);

end