%% #BESpoutPos
function BESpoutPos(this, h, ~)

if this.be.hw.connected && isfield(this.be.hw, 'anOut');
    
%     set(this.GUI.handles.be.spoutPos, 'Enable', 'off');
    
    if (islogical(h) || isnumeric(h)) && this.GUI.handles.be.spoutPos ~= h; % if change was requested by a input value
        spoutPosState = get(this.GUI.handles.be.spoutPos, 'Value');
        if spoutPosState == h;
            o('#BESpoutPos(): h: %d, spoutPosState: %d => nothing to do.', h, spoutPosState, 3, this.verb);
            return;
        end;
        spoutPosState = h;
        o('#BESpoutPos(): h: %d, spoutPosState: %d.', h, spoutPosState, 3, this.verb);
    else % if change was requested by the callback
        spoutPosState = get(this.GUI.handles.be.spoutPos, 'Value');
        o('#BESpoutPos(): h: %d, value: %d.', h, get(h, 'Value'), 3, this.verb);
    end;
    
    imagTTLState = get(this.GUI.handles.be.imagTTL, 'Value');
            
    spoutUpTime = 0.01; % seconds
    nSteps = 1;
    maxV = 4.6;
    spoutPosSteps = 0 : 1 / nSteps : 1;
%     spoutPosSteps = logsig((spoutPosSteps * 12) - 6) * maxV;
    spoutPosSteps = spoutPosSteps * maxV;
    if ~spoutPosState; spoutPosSteps = fliplr(spoutPosSteps); end;
    for iStep = 1 : nSteps;
        stepStart = tic;
        this.be.hw.anOut.outputSingleScan([imagTTLState * 5, spoutPosSteps(iStep)]);
        pause((spoutUpTime / nSteps) - toc(stepStart));
    end;
    this.be.hw.anOut.outputSingleScan([imagTTLState * 5, spoutPosSteps(end)]);

    if spoutPosState;        
%         showMessage(this, 'Spout on.');
        set(this.GUI.handles.be.spoutPos, 'BackgroundColor', 'green', 'Value', 1);
    else    
%         showMessage(this, 'Spout off.');
        set(this.GUI.handles.be.spoutPos, 'BackgroundColor', 'red', 'Value', 0);
    end;
    
%     set(this.GUI.handles.be.spoutPos, 'Enable', 'on');
    
else
    showWarning(this, 'OCIA:Behavior:SpoutPosHardwareDisconnected', 'Hardware is disconnected.');
    set(this.GUI.handles.be.spoutPos, 'BackgroundColor', 'red', 'Value', 0);
end;

end
