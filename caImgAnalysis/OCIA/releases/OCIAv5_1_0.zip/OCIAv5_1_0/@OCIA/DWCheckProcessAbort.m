%% #OCIA:DW:ProcessAbort
function [doAbort, isValid, unvalidReason] = DWCheckProcessAbort(this, isValid, unvalidReason)

% if processing is not going on anymore, abort and returned cancelled message
if ~this.GUI.dw.isProcessingOnGoing;
    doAbort = true;
    isValid = false;
    unvalidReason = 'cancelled by user';

% otherwise do not abort and go on with unchanged validity and unvalidity reason
else
    doAbort = false;
end;

end
