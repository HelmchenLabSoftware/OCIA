%% #OCIA:DW:DWExtractBehavDataForImagingRow
function behavDataImg = DWExtractBehavDataForImagingRow(this, iTrial, behavData) %#ok<INUSL>

% create a structure that will hold the behavior data for the imaging rows
behavDataImg = struct();

% extract the recorded behavior data from each analog input
fieldNames = fieldnames(behavData.record);
nSamples = size(behavData.record.(fieldNames{1}){iTrial}, 1);
% if no samples, abort
if nSamples == 0; return; end;
bRecData = zeros(size(fieldNames, 1), nSamples);
for iFieldName = 1 : size(fieldNames, 1);
    bRecData(iFieldName, :) = behavData.record.(fieldNames{iFieldName}){iTrial};
end

% store the analog in data and its name
behavDataImg.analogInData = bRecData;
behavDataImg.analogInNames = fieldNames;

%% - #OCIA:DW:DWExtractBehavDataForImagingRow : general informations about imaging
if isfield(behavData, 'anInSampRate');      behavDataImg.analogInSampRate = behavData.anInSampRate; end;
if isfield(behavData, 'anInSampleRate');      behavDataImg.analogInSampRate = behavData.anInSampleRate; end;

%% - #OCIA:DW:DWExtractBehavDataForImagingRow : general informations about behavior
behavDataImg.ISI = behavData.config.tone.ISI;
behavDataImg.taskType = behavData.taskType;
if isfield(behavData, 'piezoThresh');
    behavDataImg.piezoThresh = behavData.piezoThresh;
elseif isfield(behavData, 'params') && isfield(behavData.params, 'piezoThresh');
    behavDataImg.piezoThresh = behavData.params.piezoThresh;
end
if isfield(behavData, 'nTones');     behavDataImg.nTones = behavData.nTones; end;
if isfield(behavData, 'resps');      behavDataImg.resp = behavData.resps(iTrial); end;
if isfield(behavData, 'respTypes');  behavDataImg.respType = behavData.respTypes(iTrial); end;
if isfield(behavData, 'stims');      behavDataImg.stim = behavData.stims(iTrial); end;
if isfield(behavData, 'oddPos');     behavDataImg.oddPos = behavData.oddPos(iTrial); end;
if isfield(behavData, 'respDelays'); behavDataImg.respDelay = behavData.respDelays(iTrial); end;
if isfield(behavData, 'times');
    if isfield(behavData.times, 'respTime'); behavDataImg.respTime = behavData.times.respTime(iTrial); end;
    if isfield(behavData.times, 'rewStart'); behavDataImg.rewTime = behavData.times.rewStart(iTrial); end;
end;
if isfield(behavData, 'stims') && isfield(behavData, 'config') && isfield(behavData.config, 'tone') && isfield(behavData.config.tone, 'goStim');
    behavDataImg.target = double(isempty(behavData.config.tone.goStim) || any(behavData.stims(iTrial) == find(behavData.config.tone.goStim)));
end;


end
