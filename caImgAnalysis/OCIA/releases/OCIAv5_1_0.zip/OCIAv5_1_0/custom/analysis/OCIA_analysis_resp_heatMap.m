function OCIA_analysis_resp_heatMap(this, iDWRows)

%% plotting parameter UI controls       
this.GUI.an.analysisParamConfig = { ...
    'img', 'sgFiltFrameSize',   'text',     'numeric',      [1 1 0],    'Sav.-Gol. filt.',      'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'img', 'exclFrames',        'dropdown', { 'show', 'mask' }', [1 1 0], 'Excluded frames',    'Show or mask (hide) the excluded frames (z-motion).';
    'img', 'stimIDs',           'text',     'cellArray',    [1 1 0],    'Stimulus IDs',             '';
    'img', 'plotLimits',        'text',     'array',        [1 1 0],    'Plot limits',              '';
    'img', 'colormap',          'dropdown', { 'gray', 'hot', 'gray_reverse', 'red_white_blue' }', ...
                                                            [1 1 0],    'Colormap',                 '';
    'img', 'PSPer',             'text',     'array',        [1 1 0],    'Peri-stim. period',        '';
    'img', 'sortMethod',        'dropdown', { 'none', 'mean', 'mean_evoked', 'max', 'max_evoked' }, ...
                                                            [1 1 0],    'Sorting method',           '';
    'img', 'sortDirection',     'dropdown', { 'ascending', 'descending' }, ...
                                                            [1 1 0],    'Sorting direction',        '';
    'img', 'sortStim',          'dropdown', { },            [1 1 0],    'Sorting stimulus',         '';
    'img', 'selStimTypeNames',  'list',     { },            [3 1 1],    'Selected stimulus types',  '';
    'img', 'respMethod',        'dropdown', { 'mean', 'max', '3ppmax' }', ...
                                                            [1 1 0],    'Resp. method',             '';
    'img', 'showTrials',        'dropdown', { 'true', 'false' }', [1 1 0], 'Show trials',           'Specifies whether to show the single trials or only the mean';
    'img', 'selROINames',       'list',     { },            [4 1 1],    'Selected ROIs',            '';
};

%% get the imaging data
ANShowHideMessage(this, 1, 'Loading data ...');
loadDataTic = tic; % for performance timing purposes
% get the per-stimulus calcium traces
[PSCaTraces, ROINames, ~, allStimTypeNames, allROINames] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows);
% set the ROINames in the param. config to be displayed
this.GUI.an.analysisParamConfig{end , 4} = unique(allROINames);
% set the stimulus types in the param. config to be displayed
this.GUI.an.analysisParamConfig{end - 3, 4} = allStimTypeNames;
% get the size of the dataset
[nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces); %#ok<NASGU>

showMessage(this, sprintf('Loading data done (%3.1f sec).', toc(loadDataTic)));

% check data consistency
if nStimTypes + nStims == 2;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot average a single ROI on a single Trial.');
    return;
end;
if nROIs == 1;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot show this plot for a single ROI.');
    return;
end;

%% prepare data
% get the stimulus IDs to use
stimIDs = this.an.img.stimIDs(this.an.img.selStimIDs{1}, this.an.img.selStimIDs{2});
% set the stimulus types in the param. config to be displayed
this.GUI.an.analysisParamConfig{end - 4, 4} = stimIDs;

% make sure not to average ROIs
this.an.img.averageROI = 'false';

% get the averaged peri-stimulus traces, the selected ROI names and the time vector
[~, ~, ROIRespsTrial, ~, ROINames, ~] = OCIA_analysis_getPSCaTraceMeans(this, iDWRows, PSCaTraces, ROINames);

% use specified plot limits
plotLimits = this.an.img.plotLimits;

% if showing the single trials is required
if strcmp(this.an.img.showTrials, 'true');
    ROIResps = nan(nStimTypes * nStims, nROIs);
    for iROI = 1 : nROIs;
        for iStimType = 1 : nStimTypes;
            ROIResps(((iStimType - 1) * nStims + 1) : (iStimType * nStims), iROI) = ROIRespsTrial(iStimType, :, iROI);
        end;
    end;
    % create column names
    colNames = repmat(stimIDs, nStims, 1);
    % if no plot limits specified, bound lower end to 0
    if isempty(plotLimits);
        plotLimits = [0 max(ROIResps(:)) * 0.9];
    end;
else
    % get the mean responsiveness for each ROI
    ROIResps = reshape(nanmean(ROIRespsTrial, 2), nStimTypes, nROIs);
    ROIResps(ROIResps < 0) = NaN;
    colNames = stimIDs;
end;

%% plot
plotTic = tic; % for performance timing purposes
plotROIPropHeatMap(this.GUI.handles.an.axe, ROIResps, colNames, '', ROINames, plotLimits, this.an.img.colormap, 'DFF/DRR [%]', '');
o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

% % make NaNs appear red
% cMap = get(this.GUI.figH, 'Colormap');
% cMap(1, :) = [1, 0, 0];
% colormap(this.GUI.handles.an.axe, cMap); close(gcf);
        
% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
end
