function OCIA_analysis_SI_heatMap(this, iDWRows)

%% plotting parameter UI controls       
this.GUI.an.analysisParamConfig = { ...
    'img', 'sgFiltFrameSize',   'text',     'numeric',      [1 1 0],    'Sav.-Gol. filt.',      'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'img', 'exclFrames',        'dropdown', { 'show', 'mask' }', [1 1 0], 'Excluded frames',    'Show or mask (hide) the excluded frames (z-motion).';
    'img', 'stimIDs',           'text',     'cellArray',    [1 1 0],    'Stimulus IDs',             '';
    'img', 'plotLimits',        'text',     'array',        [1 1 0],    'Plot limits',              '';
    'img', 'PSPer',             'text',     'array',        [1 1 0],    'Peri-stim. period',        '';
    'img', 'sortMethod',        'dropdown', { 'none', 'mean', 'mean_evoked', 'max', 'max_evoked' }, ...
                                                            [1 1 0],    'Sorting method',           '';
    'img', 'sortDirection',     'dropdown', { 'ascending', 'descending' }, ...
                                                            [1 1 0],    'Sorting direction',        '';
    'img', 'sortStim',          'dropdown', { },            [1 1 0],    'Sorting stimulus',         '';
    'img', 'selStimTypeNames',  'list',     { },            [3 1 1],    'Selected stimulus types',  '';
    'img', 'respMethod',        'dropdown', { 'mean', 'max', '3ppmax' }', ...
                                                            [1 1 0],    'Resp. method',             '';
    'img', 'selROINames',       'list',     { },            [5 1 1],    'Selected ROIs',            '';
};

%% get the imaging data
ANShowHideMessage(this, 1, 'Loading data ...');
loadDataTic = tic; % for performance timing purposes
% get the per-stimulus calcium traces
[PSCaTraces, ROINames, ~, allStimTypeNames, allROINames] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows);
% set the ROINames in the param. config to be displayed
this.GUI.an.analysisParamConfig{end , 4} = unique(allROINames);
% set the stimulus types in the param. config to be displayed
this.GUI.an.analysisParamConfig{end - 2, 4} = allStimTypeNames;
% get the size of the dataset
[nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces); %#ok<NASGU>

showMessage(this, sprintf('Loading data done (%3.1f sec).', toc(loadDataTic)));

% check data consistency
if nStimTypes + nStims == 2;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot average a single ROI on a single Trial.');
    return;
end;
if nROIs == 1;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot show this plot for a single ROI.');
    return;
end;

%% prepare data
% get the averaged peri-stimulus traces, the selected ROI names and the time vector
[~, ~, ROIResps, ~, ROINames, ~] = OCIA_analysis_getPSCaTraceMeans(this, iDWRows, PSCaTraces, ROINames);
ROIResps = reshape(nanmean(ROIResps, 2), nStimTypes, nROIs);

% get the stimulus IDs to use
stimIDs = this.an.img.stimIDs(this.an.img.selStimIDs{1}, this.an.img.selStimIDs{2});
% set the stimulus types in the param. config to be displayed
this.GUI.an.analysisParamConfig{end - 3, 4} = stimIDs;

% calculate SI
SI = (ROIResps(1, :) - ROIResps(2, :)) ./ (ROIResps(1, :) + ROIResps(2, :));

% plot limits
plotLims = this.an.img.plotLimits;
if isempty(plotLims);
    plotLims = [-1 1];
end;

%% plot
plotTic = tic; % for performance timing purposes
plotROIPropHeatMap(this.GUI.handles.an.axe, SI, { }, '', ROINames, plotLims, 'red_white_blue', 'SI', ...
    sprintf('SI \\color{blue}%s\\color{black}/\\color{red}%s', stimIDs{:}));
o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

        
% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
end
