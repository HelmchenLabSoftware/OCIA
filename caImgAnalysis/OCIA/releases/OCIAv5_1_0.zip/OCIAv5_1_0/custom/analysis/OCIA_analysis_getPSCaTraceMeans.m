function [PSCaTraceMeans, PSCaTraceErrors, ROIRespsTrial, ROIRespProb, ROINames, t, NStims] = OCIA_analysis_getPSCaTraceMeans(this, iDWRows, PSCaTraces, ROINames)

totalTic = tic; % for performance timing purposes

%% fetch or extract data from memory
% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'selStimTypeNames', this.an.img.selStimTypeNames, 'PSPer', this.an.img.PSPer, ...
    'sgFiltFrameSize', this.an.img.sgFiltFrameSize, 'exclFrames', this.an.img.exclFrames, 'respMethod', this.an.img.respMethod, ...
    'combineROIs', this.an.img.combineROIs, 'averageROI', this.an.img.averageROI, 'selStimIDs', { this.an.img.selStimIDs }, ...
    'nStimsThreshold', this.an.img.nStimsThreshold, 'normBaseline', this.an.img.normBaseline, 'ROINames', { ROINames }, 'dataType', 'selectedPSCaTracesStats');
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the per-stimulus calcium traces matrix is not in cache yet, create it
if isempty(cachedData);

    %% prepare
    % get the size of the dataset
    [nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces);

    % create a time vector
    t = ((1 : nPSFrames) / this.an.img.defaultFrameRate) - this.an.img.PSPer(1);

    %% average the traces
    stimAverageTic = tic; % for performance timing purposes

    % if averaging the ROIs together is requested
    if strcmp(this.an.img.averageROI, 'true');
        ROINames = { sprintf('Pop. of %02d ROIs', nROIs) };
        PSCaTraces = nanmean(PSCaTraces, 3);
        nROIs = 1;
    end;

    % average each stimulus
    PSCaTraceMeans = reshape(nanmean(PSCaTraces, 2), [nStimTypes, nROIs, nPSFrames]);
    PSCaTraceErrors = nan(size(PSCaTraceMeans));
    for iStimType = 1 : nStimTypes;
        for iROI = 1 : nROIs;
            PSCaTraceErrors(iStimType, iROI, :) = nansem(squeeze(PSCaTraces(iStimType, :, iROI, :)));
        end;
    end;
    o('#%s: stimulus averaging done (%3.1f sec).', mfilename(), toc(stimAverageTic), 2, this.verb);

    % calculate the number of stimulus that where averaged for each ROI/stimType pair
    NStims = zeros(nStimTypes, nROIs);
    for iStimType = 1 : nStimTypes;
        for iROI = 1 : nROIs;
            for iStim = 1 : nStims;
                % count this stimulus only if at least 5% of the frames are not nans
                NStims(iStimType, iROI) = NStims(iStimType, iROI) ...
                    + double(sum(~isnan(PSCaTraces(iStimType, iStim, iROI, :))) > (nPSFrames * 0.05));
            end;
        end;
    end;

    % remove ROIs that do not have enough stimulus for averaging
    badROIs = any(NStims < this.an.img.nStimsThreshold);
    badROIsString = regexprep(sprintf('%s,', ROINames{badROIs}), ',$', '');
    if ~isempty(badROIsString);
        o('#%s: removing ROI(s) %s because they do not have at least %d stimuli.', mfilename(), badROIsString, ...
            this.an.img.nStimsThreshold, 2, this.verb);
    end;
    % remove from ROINames, mean traces and NStims matrix
    ROINames(badROIs) =  []; nROIs = numel(ROINames);
    PSCaTraceMeans(:, badROIs, :) = [];
    PSCaTraceErrors(:, badROIs, :) = [];
    NStims(:, badROIs) = [];

    % normalize by base frames if required
    if strcmp(this.an.img.normBaseline, 'true');
        baseFrames = t < 0;
        baseLineMeans = nanmean(PSCaTraceMeans(:, :, baseFrames), 3);
        PSCaTraceMeans = PSCaTraceMeans - repmat(baseLineMeans, [1 1 nPSFrames]);
    end;

    % get the stimulus IDs to use
    stimIDs = this.an.img.stimIDs(this.an.img.selStimIDs{1}, this.an.img.selStimIDs{2});
    nStimTypes = numel(stimIDs);

    % get the evoked frames
    evokedFramesMask = t > 0 & t < this.an.img.PSPer(2);
    nEvFrames = sum(evokedFramesMask);

    %% get responsiveness
    % go trough each stim and each ROI
    ROIRespsTrial = nan(nStimTypes, nStims, nROIs); 
    for iStimType = 1 : nStimTypes;
        for iStim = 1 : nStims;
            for iROI = 1 : nROIs;
                allFrames = squeeze(PSCaTraces(iStimType, iStim, iROI, :));
                baseFrames = allFrames(~evokedFramesMask);
                evokedFrames = allFrames(evokedFramesMask);

                switch this.an.img.respMethod;
                    case 'mean';
                        ROIRespsTrial(iStimType, iStim, iROI) = nanmean(evokedFrames) - nanmean(baseFrames);
                    case 'max';
                        ROIRespsTrial(iStimType, iStim, iROI) = nanmax(evokedFrames) - nanmean(baseFrames);
                    case '3ppmax';
                        ROIRespsTrial(iStimType, iStim, iROI) = nanmean(maxnpp(evokedFrames, 3)) - nanmean(maxnpp(baseFrames, 3));
                    otherwise
                        ANShowHideMessage(this, 1, sprintf('Problem during plotting: unknown responsiveness calculating method: "%s".', ...
                            this.an.img.respMethod));
                end;

    %             % calculate tStat
    %             ROIRespsTrial(iStimType, iStim, iROI) = (nanmean(maxnpp(evoked, 3)) - nanmean(maxnpp(base, 3))) ...
    %                 / (0.5 * (nanvar(maxnpp(evoked, 3)) + nanvar(maxnpp(base, 3))));
            end;
        end;
    end;

    %{

    %% get response probability
    ROIRespsBinary = ROIRespsTrial > 4;

    % calculate response probability for all trials
    ROIRespProb = reshape(nanmean(ROIRespsBinary, 2), [nStimTypes, nROIs]);

    %}

    ROIRespProb = [];
    
    if ~strcmp(this.an.img.combineROIs, 'true');
        % get the grouping from ROISet number
        ROISetIndexes = cellfun(@(ROIName)str2double(regexprep(regexp(ROIName, '^RS\d+_', 'match'), '[^\d]', '')), ROINames);
        % get the days from the rows and from the ROISet IDs
        allDays = regexprep(unique(get(this, iDWRows, 'day')), '_', '');
        allROISetsDays = regexprep(unique(get(this, iDWRows, 'ROISet')), '_\d+$', '');
        % re-map the grouping using the actual unique days
        for iROISetDay = 1 : numel(allROISetsDays);
            ROISetIndexes(ROISetIndexes == iROISetDay) = find(strcmp(allROISetsDays{iROISetDay}, allDays));    
        end;

        % get the group labels phases
        uniquePhases = { 'baseline', 'na�ve', 'expert', 'lateExpert' };
        ROIPhases = uniquePhases(ROISetIndexes);
        
    else
        
        ROIPhases = {};
        
    end;
    
    % store the variables
    cachedData = struct('PSCaTraceMeans', PSCaTraceMeans, 'PSCaTraceErrors', PSCaTraceErrors, ...
        'ROIRespsTrial', ROIRespsTrial, 'ROIRespProb', ROIRespProb, 't', t, 'NStims', NStims, ...
        'dataType', 'selectedPSCaTracesStats', 'ROINames', { ROINames }, 'ROIPhases', { ROIPhases }, 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);
    
    
% if data was in memory, fetch it
else
    
    % fetch the data
    PSCaTraceMeans = cachedData.PSCaTraceMeans;
    PSCaTraceErrors = cachedData.PSCaTraceErrors;
    ROIRespsTrial = cachedData.ROIRespsTrial;
    ROIRespProb = cachedData.ROIRespProb;
    ROINames = cachedData.ROINames;
    t = cachedData.t;
    NStims = cachedData.NStims;
    
end;

%% sort
% if sorting is required
if ~isempty(this.an.img.sortMethod) && ~strcmp(this.an.img.sortMethod, 'none');
    sortTic = tic; % for performance timing purposes

    % get the sorting parameters
    sortMethod = this.an.img.sortMethod;
    sortStimIndex = find(strcmp(stimIDs, this.an.img.sortStim));
    if sortStimIndex == 0; sortStimIndex = 1; end;
    sortDirection = iff(strcmp(this.an.img.sortDirection, 'ascending'), -1, 1);

    % get the evoked evoked activity for the sorting stimulus
    sortStimEvokedPSCaTraceMeans = reshape(PSCaTraceMeans(sortStimIndex, :, evokedFramesMask), [nROIs, nEvFrames]);
    sortStimBasePSCaTraceMeans = reshape(PSCaTraceMeans(sortStimIndex, :, ~evokedFramesMask), [nROIs, nPSFrames - nEvFrames]);

    % get sorted values with the specified method on the specified stimulus
    if strcmp(sortMethod, 'mean');
        sortValues = mean(sortStimEvokedPSCaTraceMeans, 2);
    elseif strcmp(sortMethod, 'mean_evoked');
        sortValues = mean(sortStimEvokedPSCaTraceMeans, 2) - mean(sortStimBasePSCaTraceMeans, 2);
    elseif strcmp(sortMethod, 'max');
        sortValues = max(sortStimEvokedPSCaTraceMeans, [], 2);
    elseif strcmp(sortMethod, 'max_evoked');
        sortValues = max(sortStimEvokedPSCaTraceMeans, [], 2) - max(sortStimBasePSCaTraceMeans, [], 2);
    else
        sortValues = [];
    end;

    % if there is something to sort
    if ~isempty(sortValues);
        [~, sortIndexes] = sort(sortDirection * sortValues);
        % apply the sorting
        PSCaTraceMeans = PSCaTraceMeans(:, sortIndexes, :);
        PSCaTraceErrors = PSCaTraceErrors(:, sortIndexes, :);
        ROINames = ROINames(sortIndexes);
        NStims = NStims(:, sortIndexes);
        ROIRespsTrial = ROIRespsTrial(:, :, sortIndexes);
    end;
    o('#%s: sorting done (%3.1f sec).', mfilename(), toc(sortTic), 2, this.verb);
end;
    
o('#%s: done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);
    

end