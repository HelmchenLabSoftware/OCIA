%% #OCIA:AN:OCIA_analysis_caTraces_heatMap
function OCIA_analysis_caTraces_heatMap(this, iDWRows)

%% plotting parameter UI controls       
this.GUI.an.analysisParamConfig = { ...
    'img', 'sgFiltFrameSize',   'text',     'numeric',      [1 1 0],    'Sav.-Gol. filt.',      'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'img', 'exclFrames',        'dropdown', { 'show', 'mask' }', [1 1 0], 'Excluded frames',    'Show or mask (hide) the excluded frames (z-motion).';
    'img', 'stimIDs',           'text',     'cellArray',    [1 1 0],    'Stimulus IDs',             '';
    'img', 'plotLimits',        'text',     'array',        [1 1 0],    'Plot limits',              '';
    'img', 'colormap',          'dropdown', { 'gray', 'hot', 'gray_reverse', 'red_white_blue' }', [1 1 0], 'Colormap', '';
    'img', 'selStimTypeNames',  'list',     { },            [2 1 1],    'Selected stimulus types',  '';
    'img', 'traceTypeToShow',   'dropdown', { 'raw only', 'filtered only', 'raw and filtered' }, [1 1 0],  'Trace type',  '';
    'img', 'selROINames',       'list',     { },            [4 1 1],    'Selected ROIs',            '';
};

% force the ROI combination to be true
this.an.img.combineROIs = 'true';

%% get the data
% get the concatenated trace (raw and filtered), the stimuli, the selected ROI names and the time vector
[~, concatStims, concatCaTracesSGFilt, ROINames, t] = OCIA_analysis_getConcatCaData(this, iDWRows);

% get the stimulus IDs to use
stimIDs = this.an.img.stimIDs(this.an.img.selStimIDs{1}, this.an.img.selStimIDs{2});

%% plot
plotTic = tic; % for performance timing purposes
plotCaTracesHeatMap(this.GUI.handles.an.axe, 0, '', [], concatCaTracesSGFilt, concatStims, ...
    stimIDs, ROINames, t, [], this.an.img.plotLimits, this.an.img.colormap);
o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');

end
