function [PSCaTraces, ROINames, allPSCaTraces, allStimTypeNames, allROINames] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows)

totalTic = tic; % for performance timing purposes

% get the list of all rows
allIDWRows = this.an.selectedTableRows;

% get the calcium traces
[~, stims, ROINames, ~, ~, allCaTraces, ~, allStimTypeNames, allROINames] = OCIA_analysis_getCaTracesMatrix(this, ...
    iDWRows, strcmp(this.an.img.combineROIs, 'true'));

% get the selected calcium traces, stimulus vectors and ROIs
PSCaTraces = allCaTraces(ismember(allIDWRows, iDWRows), :, :);

% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'selStimTypeNames', this.an.img.selStimTypeNames, 'PSPer', this.an.img.PSPer, ...
    'sgFiltFrameSize', this.an.img.sgFiltFrameSize, 'exclFrames', this.an.img.exclFrames, ...
    'combineROIs', this.an.img.combineROIs, 'dataType', 'PSCaTraces');
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the per-stimulus calcium traces matrix is not in cache yet, create it
if isempty(cachedData);

    % apply filtering if required
    if this.an.img.sgFiltFrameSize > 1;
        fliterTic = tic; % for performance timing purposes
        % get the size of the dataset
        [nTrials, nTotROIs, ~] = size(PSCaTraces);
        caTracesSGFilt = nan(size(PSCaTraces));
        for iTrial = 1 : nTrials;
            for iROI = 1 : nTotROIs;
                caTracesSGFilt(iTrial, iROI, :) = sgolayfilt(PSCaTraces(iTrial, iROI, :), 1, this.an.img.sgFiltFrameSize);
            end;
        end;
        PSCaTraces = caTracesSGFilt;
        o('#%s filtering done (%3.1f sec).', mfilename(), toc(fliterTic), 2, this.verb);
    end;
    
    % extract the peri-stimulus calcium traces
    PSExtractTic = tic; % for performance timing purposes
    allPSCaTraces = extractPSTrace(PSCaTraces, stims, round(this.an.img.PSPer * this.an.img.defaultFrameRate));
    o('#%s extract PS-trace done (%3.1f sec).', mfilename(), toc(PSExtractTic), 2, this.verb);
    
    % store the variables
    cachedData = struct('allPSCaTraces', allPSCaTraces, 'dataType', 'PSCaTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);

% if data was in memory, fetch it
else
    % fetch the data
    allPSCaTraces = cachedData.allPSCaTraces;

end;


%% prepare data
% fetch or extract data from memory
hashStruct.dataType = 'selectedPSCaTraces';
hashStruct.ROINames = ROINames;
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the processed peri-stimulus calcium traces are not in cache yet, create it
if isempty(cachedData);    

    % get the indexes of the selected ROIs
    selROIs = find(ismember(allROINames, ROINames));
    % if none selected, select all of them
    if isempty(selROIs);
        selROIs = 1 : numel(allROINames);
    end;

    % exclude the ROIs that have no data
    emptyROIs = false(numel(selROIs), 1);
    for iSelROI = 1 : numel(emptyROIs);
        PSTracesForROI = allPSCaTraces(:, :, selROIs(iSelROI), :);
        emptyROIs(iSelROI) = ~any(~isnan(PSTracesForROI(:)));
    end;
    selROIs(emptyROIs) = [];


    % combine ROIs if needed
    if strcmp(this.an.img.combineROIs, 'true');

        % get the size of the big matrix
        [nStimTypes, nStims, ~, nPSFrames] = size(allPSCaTraces);
        nROIs = numel(ROINames);

        % create the combined matrix line by line
        PSCaTraces = nan(nStimTypes, 200, nROIs, nPSFrames);
        iMaxStim = -Inf;
        for iCombROI = 1 : nROIs;
            for iStimType = 1 : nStimTypes;
                iStim = 0;
                sameNameROIs = find(strcmp(ROINames{iCombROI}, allROINames));
                for iRefROILoop = 1 : numel(sameNameROIs);
                    % get the current reference ROIs' stims
                    refROIsStims = reshape(allPSCaTraces(iStimType, :, sameNameROIs(iRefROILoop), :), [nStims, nPSFrames]);
                    refROIsStims(~any(~isnan(refROIsStims), 2), :) = []; % remove NaN stims
                    PSCaTraces(iStimType, iStim + 1 : iStim + size(refROIsStims, 1), iCombROI, :) = refROIsStims;
                    iStim = iStim + size(refROIsStims, 1);
                end;
                iMaxStim = max(iMaxStim, iStim);
            end;
        end;
        % remove useless rows
        PSCaTraces(:, (iMaxStim + 1) : end, :, :) = [];

    % if no ROI combination is required
    else
        % get the selected calcium traces, stimulus vectors and ROIs
        PSCaTraces = allPSCaTraces(:, :, selROIs, :);
    end;
    
    % store the variables
    cachedData = struct('PSCaTraces', PSCaTraces, 'dataType', 'selectedPSCaTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);
    
    
% if data was in memory, fetch it
else
    % fetch the data
    PSCaTraces = cachedData.PSCaTraces;

end;


o('#%s done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);

end