%% #OCIA:OCIA_startFunction_loadDataAndOpenAnalyser
function OCIA_startFunction_loadDataAndOpenAnalyser(this)

%% get all the imaging data
OCIAChangeMode(this, 'DataWatcher');

% get the DataWatcher's GUI handle
dwh = this.GUI.handles.dw;

animalID = this.dw.animalIDs{get(dwh.filt.animalID, 'Value')};
shortAnimalID = regexprep(regexprep(animalID, 'mou_bl_', ''), '_', '');
spotID = this.dw.spotIDs{get(dwh.filt.spotID, 'Value')};

% set the watch types
set(dwh.watchTypes.animal,      'Value', 1);
set(dwh.watchTypes.day,         'Value', 1);
set(dwh.watchTypes.spot,        'Value', 1);
set(dwh.watchTypes.img,         'Value', 1);
set(dwh.watchTypes.notebook,    'Value', 1);
set(dwh.watchTypes.behav,       'Value', 1);
set(dwh.watchTypes.roiset,      'Value', 1);
set(dwh.watchTypes.intrinsic,   'Value', 0);

% set the filters
set(dwh.filt.animalID,          'Value', 2, 'String', { '-', animalID });
set(dwh.filt.dayID,             'Value', 1, 'String', { '-' });
set(dwh.filt.spotID,            'Value', 2, 'String', { '-', spotID });
set(dwh.filt.rowTypeID,         'Value', 1, 'String', { '-' });
set(dwh.filt.dataLoadStatus,    'Value', 0, 'String', '');
set(dwh.filt.rowNum,            'Value', 0, 'String', '');
set(dwh.filt.runNum,            'Value', 0, 'String', '');
set(dwh.filt.all,               'Value', 0, 'String', '');

% update the table
DWProcessWatchFolder(this);

%% load data
% set the filters and select the rows
set(dwh.filt.all,               'Value', 0, 'String', 'runType = Trial AND day != 2014_10_25');
set(dwh.SLROptDataList,         'Value', find(ismember(get(dwh.SLROptDataList, 'String'), ...
    { 'Calcium traces', 'Stimulus vectors', 'Exclusion masks' })));
DWFilterSelectTable(this, 'new');  
% load the data from the right file
DWLoad(this, sprintf('%s%s_%s.h5', this.path.OCIASave, shortAnimalID(1 : 6), shortAnimalID(7 : 8)));        

%% switch to analyser
% set the filters and select the rows
set(dwh.filt.all,               'Value', 0, 'String', 'runType = Trial');
set(dwh.filt.dataLoadStatus,    'Value', 0, 'String', 'caTraces = full');
DWFilterSelectTable(this, 'new');
% go to analyser mode
OCIA_dataWatcherProcess_analyseRows(this);
    
end  
