%% #OCIA:DW:OCIA_processFolder_whisk
function tableRow = OCIA_processFolder_whisk(this, tableRow, fullPath, patternName, ~)

whiskProcessTic = tic; % for performance timing purposes
o('#OCIA_processFolder_whisk(): in "%s", folderName: %s.', folderPath, folderName, 4, this.verb);

localTable = cell(100, size(this.dw.table, 2)); % create an information row
iRow = 1;
folderPath = [folderPath '/'];

localTable{iRow, 1} = ' / whiskdata';

% check what's in the watchfolder and exclude irrelephant files
dirParseTic = tic; % for performance timing purposes
files = dir(folderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) isempty(regexp(x.name, this.dw.watchTypeFilePatterns.whiskdata, 'once')), files)) = [];

nFiles = numel(files); % count the number of remaining files
o('#OCIA_processFolder_whisk(): found %d file(s) (%3.1f sec).', nFiles, toc(dirParseTic), 5, this.verb);

% clean up local tables: delete empty cells
o('  #OCIA_processFolder_whisk(): folder(s) processing done, cleaning up local tables ...', 5, this.verb);
localTable(cellfun(@isempty, (localTable(:, 1))), :) = [];

o('  #OCIA_processFolder_whisk: %s done (%3.1f sec).', folderName, toc(whiskProcessTic), 4, this.verb);

end
