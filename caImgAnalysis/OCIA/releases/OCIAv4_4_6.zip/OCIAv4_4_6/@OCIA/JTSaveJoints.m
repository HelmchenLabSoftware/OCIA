%% #OCIA:JT:JTSaveJoints
function JTSaveJoints(this, ~, ~)

saveTic = tic;
showMessage(this, 'Saving joints ...', 'yellow');

% get what to save
jointCoords = this.jt.joints; %#ok<NASGU>

% create save directory path and save path
moviePath = DWGetRunTableRowFullPath(this, this.dw.selRunTableRows(1));
% extract file name and change extension
fileName = regexprep(regexp(moviePath, '/[^/]+$', 'match'), '\.[^\.]+$', '.mat');
day = this.dw.runTable{this.dw.selRunTableRows(1), 2};
saveDirPath = sprintf('%s%s', this.path.OCIASave, day);
savePath = sprintf('%s%s', saveDirPath, fileName{1});

% create save directory if not existing and save data
if exist(saveDirPath, 'dir') ~= 7; mkdir(saveDirPath); end;
save(savePath, 'jointCoords');

showMessage(this, sprintf('Saving joints to "%s" done. (%.1f sec)', savePath, toc(saveTic)));

% set the focus to the frame setter
uicontrol(this.GUI.handles.jt.frameSetter);

end
