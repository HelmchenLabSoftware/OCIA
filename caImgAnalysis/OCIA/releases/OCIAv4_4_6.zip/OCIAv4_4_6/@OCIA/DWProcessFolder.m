%% #OCIA:DW:DWProcessFolder
function localRunTable = DWProcessFolder(this, folderPath, mainFolderName, parentFolder, ~, toKeepWatchTypes, ...
    percentToFill)

processTic = tic;
o('#DWProcessFolder(): in ''%s'', mainFolderName: ''%s'', parentFolder: ''%s''.', folderPath, ...
    mainFolderName, parentFolder, 3, this.verb);

% make sure there's a backslash at the end of the path
if isempty(regexp(folderPath, '/$', 'once')); folderPath = [folderPath '/']; end;
if exist(folderPath, 'dir') ~= 7;
    localRunTable = -1;
    showWarning(this, 'OCIA:DWProcessFolder:FolderNotFound', ...
        sprintf('Cannot find the specified folder at ''%s''! Aborting.', folderPath));
    return;
end;

dirParseTic = tic;
% get the content of the curent day folder
items = dir(folderPath);

% exclude everything that is not in one of the required formats or that 
%   shouldn't be included in the runTable
items(arrayfun(@(x)~DWKeepFile(this, toKeepWatchTypes, x.name), items)) = [];

% get the folders out by name so that the 'spot' folders come last
sortedItemNames = sort(arrayfun(@(x)x.name, items, 'UniformOutput', false));

nItems = numel(sortedItemNames); % count the number of folders
o('#DWProcessFolder(): found %d file(s)/folder(s) (%3.1f sec).', nItems, toc(dirParseTic), 3, this.verb);

% initialize the counter and the local runTable for this 'day' folder
localRunTable = cell(100, size(this.dw.runTable, 2));
iRow = 1;

currPercent = 0;
if isfield(this.GUI.handles.dw, 'waitBarRect') && ishandle(this.GUI.handles.dw.waitBarRect);
    percentPos = get(this.GUI.handles.dw.waitBarRect, 'Position');
    currPercent = percentPos(3);
end;

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypeParents = this.dw.watchTypes(:, 3); % get the watch type parents
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns

% loop trough all existing folders and process them depending on the type of the folder
for iItem = 1 : nItems;
    % get the name of the file/folder, without the full path
    itemName = sortedItemNames{iItem};
    foundWatchTypeMatch = false; % set to true when a watch type is matched
    
    % go through all file types
    for iWatchType = 1 : numel(watchTypeIDs);
        watchTypeID = watchTypeIDs{iWatchType}; % get the current file types        
        
        % try to match the current file type
        if regexp(itemName, watchTypePatterns{strcmp(watchTypeIDs, watchTypeID)});
            
            % mark that a matching watchType was found
            foundWatchTypeMatch = true;
            
            % check whether the current item is in the right place regarding the file structure:
            % get the parent watch type where this item should be
            parentWatchTypeID = watchTypeParents{strcmp(watchTypeIDs, watchTypeID)};
            % if the parent watch type is empty (root watch type), or if the parent folder is the root folder ('.'), 
            % then it is okay. Otherwise check the parent folder
            if ~isempty(parentWatchTypeID) && ~strcmp(parentFolder, '.');
                % only process this item if the parent watch type matches the parent folder (otherwise its misplaced)
                if isempty(regexp(parentFolder, watchTypePatterns{strcmp(watchTypeIDs, parentWatchTypeID)}, 'once'));
                    continue;
                end;
            end;

            % do not process again any potential folders of the same watch type: so make a copy of the 
            %   toKeepWatchTypes structure and set current watch type to 0. 
            localToKeepWatchTypes = toKeepWatchTypes;
            localToKeepWatchTypes.(watchTypeID) = 0;
            
            if exist(['OCIA_processFolder_' watchTypeID], 'file');                
                o('  #DWProcessFolder(): found "%s": "specific" folder: "%s".', watchTypeID, itemName, 4, this.verb);
                % get the right function handle
                funcHandle = str2func(['OCIA_processFolder_' watchTypeID]);
                
            elseif exist(['OCIA_processFile_' watchTypeID], 'file');                
                o('  #DWProcessFolder(): found "%s": "specific" file: "%s".', watchTypeID, itemName, 4, this.verb);
                % get the right function handle
                funcHandle = str2func(['OCIA_processFile_' watchTypeID]);
                
            elseif exist([folderPath itemName], 'dir');
                o('  #DWProcessFolder(): found "%s": "generic" folder: "%s".', watchTypeID, itemName, 4, this.verb);
                % get the default function handle
                funcHandle = str2func('DWProcessFolder');
                
            else
                showWarning(this, 'OCIA:DWProcessFolder:NoFunctionAndNotFolder', ...
                    sprintf('Cannot find a processing function for "%s" and item is not a folder. Skipping.', ...
                    [folderPath itemName]));
                continue;
            end;
            
            % update filter with new element if it is not already in there
            if isfield(this.dw, [watchTypeID 'IDs']) && ~ismember(itemName, this.dw.([watchTypeID 'IDs']));
                % append the new element to the list
                this.dw.([watchTypeID 'IDs']) = sort([this.dw.([watchTypeID 'IDs']), {itemName}]);
            end;
            
            if isfield(this.GUI.handles.dw.filt, [watchTypeID 'ID']);
                % check for the filters to eventually interrupt search: get all items from the list
                filtIDs = get(this.GUI.handles.dw.filt.([watchTypeID 'ID']), 'String');
                % get the currently selected item
                filtID = filtIDs{get(this.GUI.handles.dw.filt.([watchTypeID 'ID']), 'Value')};
                % if it is not the dash (meaning no filtering) and the ID does not match, skip this folder
                if ~strcmp(filtID, '-') && ~strcmp(itemName, filtID);
                    continue;
                end;
            end;
            
            % process the folder
            newRunTable = funcHandle(this, [folderPath itemName], itemName, itemName, parentFolder, ...
                localToKeepWatchTypes, percentToFill / nItems);
            nNewRows = size(newRunTable, 1);

            % add the parent's name
            for iNewRow = 1 : nNewRows;
                newRunTable{iNewRow, 1} = [mainFolderName ' / ' newRunTable{iNewRow, 1}];
            end;
            localRunTable(iRow : iRow + nNewRows - 1, :) = newRunTable;
            iRow = iRow + size(newRunTable, 1);

            % increment the counter and stop looping the file types as only one can be matched
            iRow = iRow + 1; 
            break;

        end; % end of watch type regexp match

    end; % end of watch type loop

    % if the current file didn't match any file types, display a warning
    if ~foundWatchTypeMatch;
        showWarning(this, 'OCIA:DWProcessFolder:UnknownFolderType', ...
            sprintf('Unknown folder type found: ''%s''! Skipping it.', itemName));
    end;
    
    o('%40s: %d / %d, %.3f * %.3f = %.3f local, %.3f current, %.3f new', ...
        sprintf('%s%s', folderPath, itemName), iItem, nItems, iItem / nItems, percentToFill, ...
        percentToFill * (iItem / nItems), currPercent, currPercent + percentToFill * (iItem / nItems), 5, this.verb);
    DWWaitBar(this, currPercent + percentToFill * (iItem / nItems));
    pause(0.001);

end;

% clean up runTables: delete empty cells
o('  #DWProcessFolder(): folder(s) processing done, cleaning up runTables ...', 4, this.verb);
localRunTable(cellfun(@isempty, (localRunTable(:, 1))), :) = [];

% get the number of new rows
nNewRows = size(localRunTable, 1);

% if nothing was found inside the folder and summary line is required and the current folder
%   is not the watchFolder (parent = '.'), display a single row for this folder
if ~nNewRows && this.GUI.dw.showEmptyFolderSummary && ~strcmp(parentFolder, '.');

    localRunTable = cell(1, size(this.dw.runTable, 2));
    localRunTable{1} = parentFolder;
    % number of folders before filter (without '.', '..' and spot/expression summary files)
    itemContent = dir(folderPath);
    nItem = 0;
    for iItem = 1 : numel(itemContent);
        if isempty(regexp(itemContent(iItem).name, '^\.+$', 'once')) ...
            && isempty(regexp(itemContent(iItem).name, '^(expr|spot_loc)\.(tif|png)$', 'once')) ...
            && isempty(regexp(itemContent(iItem).name, '^spot\d{2}(_surface)?.(tif|png)$', 'once'));
            nItem = nItem + 1;
        end;
    end;
    localRunTable{4} = sprintf('%02d', nItem);

end;

o('  #DWProcessFolder(): done (%3.1f sec).', toc(processTic), 3, this.verb);

end
