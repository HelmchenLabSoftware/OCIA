%% #OCIA:DWSaveROISetAsHDF5
function DWSaveROISetAsHDF5(this, savePath)
    
    showMessage(this, 'Saving ROISet ...', 'yellow');
        
    % store which ROISets should be saved, corresponding to the ROISets of the imaging data that is saved
    selRows = this.dw.selRunTableRows;
    nonEmptySelRows = selRows(~cellfun(@isempty, this.dw.runTable(selRows, 16)));
    nonEmptySelROISetRows = nonEmptySelRows(~cellfun(@isempty, regexp(this.dw.runTable(nonEmptySelRows, 16), 'RS\d+')));
    ROISetsToSave = unique(this.dw.runTable(nonEmptySelROISetRows, 16));
    ROISetsToSave = regexp(ROISetsToSave, 'RS\d+', 'match');
        
    if isempty(ROISetsToSave); return; end;

    % get the path parts for this run
    pathParts = regexp(this.dw.runTable{nonEmptySelROISetRows(1), 1}, '\w+', 'match');
    % create the data set's path
    dataSetRoot = sprintf(repmat('/%s', 1, numel(this.dw.savePathParts)), pathParts{this.dw.savePathParts});
   
    try

        for iROISetLoop = 1 : numel(ROISetsToSave);

            % get the ROISet index of this ROISet
            iROISet = str2double(regexprep(ROISetsToSave{iROISetLoop}, 'RS', ''));
            % get the ROISet and its size
            ROISet = this.data.img.ROISets{iROISet, 1};
            nROIs = size(ROISet, 1);
            % get the size of the ROIs' mask (= size of the image)
            imgDim = size(ROISet{1, 2});
            % get the masks as a 3D array: dimX x dimY x nROIs
            masks = permute(reshape(cell2mat(ROISet(:, 2)), imgDim(1), nROIs, imgDim(2)), [1 3 2]);
            masksDim = size(masks);
            % get the names as a char matrix
            ROINameMaxLength = max(cellfun(@(name) size(name, 2), ROISet(:, 1)));
            ROINames = cell2mat(regexp(sprintf(sprintf('%%-%ds:', ROINameMaxLength), ROISet{:, 1}), ':', 'split')');
            ROINamesDim = size(ROINames);
            % get the runs validity (= which runs this ROISet is valid for)
            runsValidity = cell2mat(this.data.img.ROISets{iROISet, 2});
            runsValDim = size(runsValidity);
            % get the reference image
            refImage = this.data.img.ROISets{iROISet, 3};
            if iscell(refImage); % get cell array into a matrix
                nChans = numel(refImage);
                refSingleImageDim = size(refImage{1});
                refImage = reshape(cell2mat(refImage)', [refSingleImageDim, nChans]);
            end;
            refImageDim = size(refImage);

            % get the data watcher's row index of this ROISet
            iDWRow = DWFindRunTableRows(this, 'ROISet', '', '', ROISetsToSave{iROISetLoop}, '', '', '');

            
            % create the data set's path
            dataSetPath = sprintf('%s/ROISet', dataSetRoot);
            % get the runID as "YYYYMMDD_HHMMSS"
            runID = regexprep(regexprep(sprintf('%s:%s', this.dw.runTable{iDWRow, 2 : 3}), '_', ''), ':', '_');

            % specify the options (including data's size), depending on whether a compression is required or not
            maskOpts = {masksDim};
            ROINamesOpts = {ROINamesDim};
            runsValOpts = {runsValDim};
            refImageOpts = {refImageDim};
            if ~isempty(this.dw.HDF5GZipLevel) && this.dw.HDF5GZipLevel ~= 0;
                maskOpts = [masksDim, 'ChunkSize', [masksDim(1 : 2), 1], deflOpt];
                ROINamesOpts = [ROINamesDim, 'ChunkSize', [ROINamesDim(1) / 4, 1], deflOpt];
                runsValOpts = [runsValDim, 'ChunkSize', runsValDim / 4, deflOpt];
                refImageOpts = [refImageDim, 'ChunkSize', [refImageDim(1 : 2) ./ 4, 1], deflOpt];
            end;

            % save the masks
            datasetPath = sprintf('%s/masks/%s', dataSetPath, runID);
            % make sure the group is not there anymore
            if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPath); end;
            h5create(savePath, datasetPath, maskOpts{:});
            h5write(savePath, datasetPath, int8(masks));
            % save the ROINames as doubles
            datasetPath = regexprep(datasetPath, 'masks', 'ROINames'); % change data set path
            % make sure the group is not there anymore
            if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPath); end;
            h5create(savePath, datasetPath, ROINamesOpts{:});
            h5write(savePath, datasetPath, double(ROINames));
            % save the runs validity as doubless
            datasetPath = regexprep(datasetPath, 'ROINames', 'runsValidity'); % change data set path
            % make sure the group is not there anymore
            if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPath); end;
            h5create(savePath, datasetPath, runsValOpts{:});
            h5write(savePath, datasetPath, double(runsValidity));
            % save the reference image
            datasetPath = regexprep(datasetPath, 'runsValidity', 'refImage'); % change data set path
            % make sure the group is not there anymore
            if this.dw.overwriteHDF5Data; h5deleteGroup(savePath, datasetPath); end;
            h5create(savePath, datasetPath, refImageOpts{:});
            h5write(savePath, datasetPath, refImage);

        end;

        showMessage(this, 'Saving ROISet done.');

    catch err;
        
        showWarning(this, 'OCIA:DWSaveROISetAsHDF5:saveError', sprintf('Error while saving ROISet: %s (%s)\n%s', ...
           err.message, err.identifier, getStackText(err)), 'red');
        pause(1);
        
    end;
    
end
