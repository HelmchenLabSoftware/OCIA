%% - #DWMatchROISetsToDataStefano
function DWMatchROISetsToDataStefano(this)

    nROISets = size(this.data.img.ROISets, 1);
    ROISetRows = DWFindRunTableRows(this, 'ROISet', '', '', '', '', '', '');
    for iROISet = 1 : nROISets;
       spotID = '';
       ROISetPath = DWGetRunTableRowFullPath(this, ROISetRows(iROISet));
       for iSpot = 1 : numel(this.dw.spotIDs);
            spotDataFolderPath = regexprep(ROISetPath, 'ROISets', this.dw.spotIDs{iSpot});
            spotDataFolderPath = regexprep(spotDataFolderPath, 'ROISet_', '');
            spotDataFolderPath = regexprep(spotDataFolderPath, '.mat', '/');
            
            spotDataFolderPath = regexprep(spotDataFolderPath, '/$', '.exp*');
            if ~isempty(dir(spotDataFolderPath));
                spotID = this.dw.spotIDs{iSpot};
            end;
            
        end;

        if isempty(spotID);
            showWarning(this, 'OCIA:DWExtractNotebookInfo:DWMatchROISetsToDataNoData:ROISetSpotNotFound', ...
                sprintf('Could not find to which spot ROISet "%s_%s" (RS%02d) belongs to !', ...
                    this.dw.runTable{ROISetRows(iROISet), 2 : 3}, iROISet));
        else
            this.dw.runTable{ROISetRows(iROISet), 7} = spotID;
            if ~ismember(this.dw.spotIDs, spotID);
                this.dw.spotIDs{end + 1} = spotID;
                set(this.GUI.handles.dw.filt.spotID, 'String', this.dw.spotIDs, 'Value', 2);
            end;
        end;
        
        % try to apply the ROISet's ID to the data (if any data)
        runValidity = this.data.img.ROISets{iROISet, 2};
        nMatchROIs = size(this.data.img.ROISets{iROISet, 1}, 1);
        for iRunTableRow = 1 : size(this.dw.runTable, 1);
            ROISearchRunID = sprintf('%s__%s', this.dw.runTable{iRunTableRow, 2}, this.dw.runTable{iRunTableRow, 3});

            % compare the runs validity but only for the data rows
            if any(strcmp(runValidity, ROISearchRunID)) ...
                    && ~isempty(regexp(this.dw.runTable{iRunTableRow, 1}, '(imgD|d)ata', 'once'));
                this.dw.runTable{iRunTableRow, 16} = sprintf('RS%02d / %03d', iROISet, nMatchROIs);
            end;
        end;
        
    end;

end

