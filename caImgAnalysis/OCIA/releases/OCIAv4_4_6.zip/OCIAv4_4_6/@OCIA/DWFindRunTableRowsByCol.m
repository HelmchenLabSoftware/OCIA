%% #OCIA:DW:DWFindRunTableRowsByCol
function varargout = DWFindRunTableRowsByCol(this, filtText, filtCol)

o('#DWFindRunTableRowsByCol(): filtText: %s, filtCol: %d ...', filtText, filtCol, 4, this.verb);

rowBools = true(1, size(this.dw.runTable, 1)); % get all rows

% filter for each type
if ~isempty(filtText);
    rowBools = rowBools & cellfun(@(x) ~isempty(x) && ~isempty(regexp(x, filtText, 'once')), ...
        this.dw.runTable(:, filtCol)');
end;

if nargout == 1;
    varargout = {find(rowBools)};
else
    varargout = {find(rowBools), rowBools};
end;

end