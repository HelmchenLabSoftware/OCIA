%% #OCIA:RD:RDRDSaveROIs
function RDSaveROIs(this, ~, ~)

o('#RDSaveROIs(): saving %d ROI(s) ...', this.rd.nROIs, 3, this.verb);

% if there are no ROIs, abort
if ~this.rd.nROIs;
    showWarning(this, 'RDSaveROIs:NoROI', 'There are no ROIs to be saved !');
    return;
end;

% find redundant ROIs: ROIs that have the exact same name
redundantROIIndexes = cell2mat(cellfun(@(ROIID) sum(strcmp(ROIID, this.rd.ROIs(:, 2))), ...
    unique(this.rd.ROIs(:, 2)), 'UniformOutput', false)) > 1;
redundantROIIDs = this.rd.ROIs(redundantROIIndexes, 2);
% if there are redundant ROIs, show a warning and abort
if ~isempty(redundantROIIDs);
    showWarning(this, 'RDSaveROIs:DuplicatedROIs', sprintf('Identically labelled ROIs :%s !', ...
        sprintf(' %s', redundantROIIDs{:})));
    return;
end;

% if not in RDCompareROIs mode
if ~get(this.GUI.handles.rd.refROISet, 'Value');
    iRDRow = get(this.GUI.handles.rd.rowListNames, 'Value');
    if isempty(iRDRow);
        warning('OCIA:RD:RDSaveROIs:NoRowSelected', 'No rows are selected!');
        return;
    end;
    if numel(iRDRow) > 1;
        showWarning(this, 'RDSaveROIs:MultipleRowsSelected', 'Several rows selected as reference, please choose one.');
        return;
    end;
else
    iRDRows = get(this.GUI.handles.rd.rowListNames, 'Value');
    iRDRow = iRDRows(get(this.GUI.handles.rd.refROISetASetter, 'Value'));
end;

o('#RDSaveROIs(): iRDRow: %d', iRDRow, 4, this.verb);

% extract the path where the ROISet should be saved
dataFolderPath = this.rd.runTable{iRDRow, 2};

% check whether selected row is a ROISet row
isROISetRow = ~isempty(regexp(dataFolderPath, 'ROISets/ROISet_', 'once'));

% if selected row is a ROISet row, use directly its path
if isROISetRow;
    
    ROISetFilePath = dataFolderPath;
    
% if selected row is not a ROISet row, get the associated ROISet path
else
    
    % get the run validity from the run selector
    selRuns = get(this.GUI.handles.rd.runSel, 'Value');
    if isempty(selRuns); % if none selected, display warning and abort
        showWarning(this, 'RDSaveROIs:NoRunsSelected', 'No runs selected !');
        return;
    else % if not empty, get the run IDs for the selected runs
        selDWRuns = this.dw.selRunTableRows(selRuns);
        runsValidity = arrayfun(@(iDWRow) sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3}), selDWRuns, ...
            'UniformOutput', false);
        o('#RDSaveROIs(): ROIs valid for %d run(s).', numel(runsValidity), 4, this.verb);
    end;
    dataFolderName = cell2mat(regexp(dataFolderPath, '[\w\.]+/$', 'match'));
    o('#RDSaveROIs(): dataFolderName: %s', dataFolderName, 4, this.verb);
    
    spotIndex = strcmp(this.dw.watchTypes(:, 1), 'spot');
    spotFolderPath = strrep(dataFolderPath, dataFolderName, '');
    if any(spotIndex);
        spotFolderName = cell2mat(regexp(spotFolderPath, '(\w+)/$', 'match'));
        o('#RDSaveROIs(): spotFolderName: %s', spotFolderName, 4, this.verb);
    else
        spotFolderName = dataFolderName;
    end;
    
    dataFolderName = regexprep(dataFolderName, '\.exp\d+/$', '/');
    dataFolderName = regexprep(dataFolderName, '_X.*/$', '/');
    
    if ~isempty(spotFolderName); % if data is in a spot folder, remove that spot folder name
        dayFolderPath = strrep(spotFolderPath, spotFolderName, '');
    else % otherwise just consider the spot folder is actually a day folder
        dayFolderPath = spotFolderPath;
    end;
    ROISetFolderPath = sprintf('%sROISets/', dayFolderPath);
    o('#RDSaveROIs(): ROISetFolderPath: %s', ROISetFolderPath, 4, this.verb);

    % create the directory if needed
    if exist(ROISetFolderPath, 'dir') ~= 7; mkdir(ROISetFolderPath); end;
    ROISetFilePath = sprintf('%sROISet_%s.mat', ROISetFolderPath, regexprep(dataFolderName, '/$', ''));
    o('#RDSaveROIs(): ROISetFilePath: %s', ROISetFilePath, 4, this.verb);
    
end;
    
% extract the variables that need to be saved
ROIMask = this.rd.ROIMask; %#ok<NASGU>
ROIs = cell(this.rd.nROIs, 3);
% extract the imroi object type, the ROI ID and the positions
ROIs(:, 1) = this.rd.ROIs(:, 4);
ROIs(:, 2) = this.rd.ROIs(:, 2);
ROIs(:, 3) = this.rd.ROIs(:, 3); %#ok<NASGU>
o('#RDSaveROIs(): generated saveable ''ROIs'' structure', 4, this.verb);

% get the reference image from the appropriate row
iDWRow = this.dw.selRunTableRows(iRDRow);
DWLoadRow(this, iDWRow, 'full'); % load row if required
refImage = cellfun(@(img)nanmean(img, 3), this.data.preProc{iDWRow}, 'UniformOutput', false); %#ok<NASGU>

% save the ROIs, the mask and the runs where this ROISet applies
if isROISetRow;
    % do not save refImage and runsValidity
    save(ROISetFilePath, 'ROIs', 'ROIMask', '-append');
    
    % get the plural marks for the display
    plurROIs = ''; if this.rd.nROIs > 1;        plurROIs = 's'; end;
    showMessage(this, sprintf('Saved %d ROI%s under ''%s''.', this.rd.nROIs, plurROIs, ROISetFilePath));
    
else
    
    % save everything
    save(ROISetFilePath, 'ROIs', 'ROIMask', 'runsValidity', 'refImage');
    
    % get the plural marks for the display
    plurROIs = ''; if this.rd.nROIs > 1;        plurROIs = 's'; end;
    plurRuns = ''; if numel(runsValidity) > 1;  plurRuns = 's'; end;
    showMessage(this, sprintf('Saved %d ROI%s (%d run%s) under ''%s''.', this.rd.nROIs, plurROIs, numel(runsValidity), ...
        plurRuns, ROISetFilePath));

end;

end
