%% #BEStoreData
function BEStoreData(this, ~, event)

nRecChans = size(event.Data, 2);
newFig = 0;
doPlot = 0;
for iChan = 1 : nRecChans;
    anInName = this.be.hw.analogIns{iChan};
    prevData = this.be.anInData.(anInName);
    currChanData = event.Data(:, iChan) - mean(event.Data(:, iChan));
    allChanData = [prevData; currChanData];
    nSamples = size(allChanData, 1);
    currentDur = nSamples / this.be.hw.anInSampRate;
    if ~this.be.isRunning && currentDur > this.be.hw.maxRecDur;
        if doPlot > 0;
            if ~newFig; figure('Name', 'RecordedData'); newFig = 1; hold all; end; %#ok<UNRCH>
            t = (0 : (nSamples - 1)) / this.be.hw.anInSampRate;
            plot(t, allChanData * this.be.hw.anInMagnifs(iChan), this.be.hw.anInColors{iChan});
        end;
        this.be.anInData.(anInName) = currChanData;
    else    
        this.be.anInData.(anInName) = allChanData;
    end;
end;
if doPlot > 0 && newFig; legend(this.be.hw.analogIns); ylim([-3 3]); end;

end

