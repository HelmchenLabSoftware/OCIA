function [this, inputParams] = OCIA_config_OoPC(this)

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

inputParams.startFunctionName = 'dataWatcher';

% path of the raw data (usually stored on the server)
this.path.rawData = 'Z:/RawData/Balazs_Laurenczy/2014/2014_chronic/1402_chronic/';
% path of the local data
this.path.localData = 'D:/Users/BaL/PhD/RawData/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'D:/Users/BaL/PhD/Analysis/';

% initial position of the main window
this.GUI.pos = [330, 185, 1220, 805];

this.GUI.dw.DWFilt = { 'mou_bl_140110_02', '2014_02_08', 'spot01', 'data', 'B' };
this.GUI.dw.DWWatchTypes = 'all';
this.GUI.dw.DWSkiptMeta = false;
this.GUI.dw.DWRawOrLocal = 'local';
this.an.an.preProcOptions = { 'skipFrame', 'fShift', 'fJitt', 'moCorr' };

end
