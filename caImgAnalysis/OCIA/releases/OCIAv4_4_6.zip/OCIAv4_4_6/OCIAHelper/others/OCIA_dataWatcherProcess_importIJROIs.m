%% #OCIA_dataWatcherProcess_importIJROIs
function OCIA_dataWatcherProcess_importIJROIs(this, ~, ~)

keepROIName = false;

importIJROIsTic = tic;

% get the index(es) of the ImageJ ROIs row
ijROISetRows = DWFindRunTableRows(this, 'ROIs', '', '', '', '', '', '');
fullFolderPath = DWGetRunTableRowFullPath(this, ijROISetRows(1));

% check what's in the watchfolder and exclude irrelephant files
files = dir(fullFolderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) isempty(regexp(x.name, this.dw.watchTypeFilePatterns.ijroisetfile, 'once')), files)) = [];

nFiles = numel(files); % count the number of remaining files
o('#OCIA_dataWatcherProcess_importIJROIs(): found %d roiset zip file(s).', nFiles, 3, this.verb);

% loop trough all existing files
for iFile = 1 : nFiles;
    % get the file name
    
    fileName = files(iFile).name;    
    o('  #OCIA_dataWatcherProcess_importIJROIs(): processing file ''%s''.', fileName, 5, this.verb);
    % extract the spot number
    spotHit = regexp(fileName, this.dw.watchTypeFilePatterns.ijroisetfile, 'names');
    
    if isempty(spotHit);
        showWarning(this, 'OCIA:OCIA_dataWatcherProcess_importIJROIs:UnknownSpot', ...
            sprintf('Could not find spot match for file "%s" using expression "%s". Skipping it.', ...
            fileName, this.dw.watchTypeFilePatterns.ijroisetfile));
        continue;
    end;
    
    % extract the ImageJ ROISet
    ijROISet = ij_roiDecoder(sprintf('%s%s', fullFolderPath, fileName), this.an.img.defaultImDim);
    nROIs = size(ijROISet, 1); % count the number of ROIs
    
    % pre-allocate a cell-array to store the imported/converted ROIs
    ROIs = cell(nROIs, 3);
    % pre-allocate a matrix for the ROI mask
    ROIMask = zeros(size(ijROISet{1, 4}));
    
    % go trough each ROI and convert it to the required form
    for iROI = 1 : nROIs;
        
        ROIs{iROI, 1} = sprintf('im%s', ijROISet{iROI, 2}); % create the ROI type
        if keepROIName; % keep ROI's name but clean it up
            ROIs{iROI, 2} = regexprep(ijROISet{iROI, 1}, '[^A-Za-z0-9]', ''); %#ok<UNRCH>
        else % give a new name
            ROIs{iROI, 2} = sprintf('%03d', iROI); % give ROI a name
        end;
        
        % store the coordinates
        ROIs{iROI, 3} = ijROISet{iROI, 3};
        
        % update the mask
        ROIMask(ijROISet{iROI, 4}) = iROI;
        
    end;
        
    % get the data watcher indexes of the imaging data rows of that spot
    spotFilter = '';
    if isfield(spotHit, 'spot');
        spotFilter = sprintf('Spot%s', spotHit.spot);
    end;
    imgDataRuns = DWFindRunTableRows(this, 'imgData', '', spotFilter, '', '', '', '');
    
    if isempty(imgDataRuns);
        showWarning(this, 'OCIA:OCIA_dataWatcherProcess_importIJROIs:NoImgData', ...
            sprintf('Could not find any imaging data for file "%s". Skipping it.', ...
            fileName));
        continue;
    end;
    
    % get the runs validity
    runsValidity = arrayfun(@(iRow) sprintf('%s__%s', this.dw.runTable{iRow, 2 : 3}), imgDataRuns, ...
        'UniformOutput', false)'; %#ok<NASGU>
        
    % create the ROISet file's name using the first imaging data row
    dataFolderPath =  DWGetRunTableRowFullPath(this, imgDataRuns(1));    
    dataFolderName = cell2mat(regexp(dataFolderPath, '[\w\.]+/$', 'match'));
    o('#RDSaveROIs(): dataFolderName: %s', dataFolderName, 4, this.verb);
    
    spotIndex = strcmp(this.dw.watchTypes(:, 1), 'spot');
    spotFolderPath = strrep(dataFolderPath, dataFolderName, '');
    if any(spotIndex);
        dataFolderName = regexprep(dataFolderName, '\.exp\d+/$', '/');
        spotFolderName = cell2mat(regexp(spotFolderPath, '(\w+)/$', 'match'));
        o('#RDLoadROIs(): spotFolderName: %s', spotFolderName, 4, this.verb);
    else
        spotFolderName = dataFolderName;
    end; 
    
    if ~isempty(spotFolderName); % if data is in a spot folder, remove that spot folder name
        dayFolderPath = strrep(spotFolderPath, spotFolderName, '');
    else % otherwise just consider the spot folder is actually a day folder
        dayFolderPath = spotFolderPath;
    end;
    ROISetFolderPath = sprintf('%sROISets/', dayFolderPath);
    o('#RDSaveROIs(): ROISetFolderPath: %s', ROISetFolderPath, 4, this.verb);

    % create the directory if needed
    if exist(ROISetFolderPath, 'dir') ~= 7; mkdir(ROISetFolderPath); end;
    ROISetFilePath = sprintf('%sROISet_%s.mat', ROISetFolderPath, regexprep(dataFolderName, '/$', ''));
    ROISetFilePath = regexprep(ROISetFilePath, '\.exp\d+', '');
    o('#RDSaveROIs(): ROISetFilePath: %s', ROISetFilePath, 4, this.verb);
    
    % get the reference image from the appropriate row
    iDWRow = imgDataRuns(1);
    DWLoadRow(this, iDWRow, 'full'); % load row if required
    refImage = cellfun(@(img)nanmean(img, 3), this.data.preProc{iDWRow}, 'UniformOutput', false); %#ok<NASGU>

    % save everything
    save(ROISetFilePath, 'ROIs', 'ROIMask', 'runsValidity', 'refImage');
    
end;


o('#OCIA_dataWatcherProcess_importIJROIs(): importing ImageJ ROIs done (%3.1f sec).', toc(importIJROIsTic), 2, this.verb);

end
