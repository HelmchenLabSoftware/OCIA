%% #OCIA:OCIA_notebookPostProcess_stefano
function OCIA_notebookPostProcess_stefano(this)

DWMatchROISetsToDataStefano(this);
DWExtractSpotIdentity(this);

% extract the spot's depth:
% get the spot folder pattern
spotPattern = this.dw.watchTypes{strcmp(this.dw.watchTypes(:, 1), 'spot'), 6};
for iRow = 1 : size(this.dw.runTable, 1);
    if ~isempty(this.dw.runTable{iRow, 7}) && strcmp(DWGetRowType(this, iRow), 'imgData');
        spotLabel = regexp(this.dw.runTable{iRow, 7}, spotPattern, 'names');
        if ~isempty(spotLabel);
            depth = str2double(spotLabel.depth);
            if depth < 500;
                this.dw.runTable{iRow, 8} = '500-';
            elseif depth < 600;
                this.dw.runTable{iRow, 8} = '500+';
            elseif depth < 700;
                this.dw.runTable{iRow, 8} = '600+';
            elseif depth < 800;
                this.dw.runTable{iRow, 8} = '700+';
            elseif depth < 900;
                this.dw.runTable{iRow, 8} = '800+';
            elseif depth < 1000;
                this.dw.runTable{iRow, 8} = '900+';
            else
                this.dw.runTable{iRow, 8} = '1000+';
            end;
        end;
    end;                
end;

end
