%% #OCIA:DW:OCIA_processFile_notebook
function runTableRow = OCIA_processFile_notebook(this, ~, ~, fileName, parentFolder, ~, ~)

notebookTic = tic;
o('  #OCIA_processFile_notebook: parentFolder: ''%s'', fileName: ''%s''.', ...
    parentFolder, fileName, 4, this.verb);

runTableRow = cell(1, size(this.dw.runTable, 2)); % create an information row
runTableRow{1, 1} = ' / notebook';

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns
notebookPattern = watchTypePatterns{strcmp(watchTypeIDs, 'notebook')};

% extract date and time from the notebook's file name
notebookHits = regexp(fileName, notebookPattern, 'names');

% if there was a match, fill in the cells 
if ~isempty(notebookHits);
    runTableRow{1, 2} = notebookHits.date;
    % remove the 'h' and the 'm' and add '00' as seconds to keep the same format
    runTableRow{1, 3} = [regexprep(notebookHits.time, '[hm]', '') '_00'];
% if there was no match, show a warning and leave empty
else
    showWarning(this, 'OCIA:OCIA_processFile_notebook:NotebookFileDateTimeMatchFailure', ...
        sprintf('Cannot match date-time to notebook file name: ''%s'' with pattern ''%s''.', ...
        fileName, notebookPattern));
end;

o('  #OCIA_processFile_notebook: %s done (%3.1f sec).', fileName, toc(notebookTic), 4, this.verb);

end
