%% #OCIA:DW:OCIA_processFolder_whisk
function runTable = OCIA_processFolder_whisk(this, folderPath, ~, folderName, ~, ~, ~)

whiskProcessTic = tic;
o('#OCIA_processFolder_whisk(): in ''%s'', folderName: %s.', folderPath, folderName, 4, this.verb);

runTable = cell(100, size(this.dw.runTable, 2)); % create an information row
iRow = 1;
folderPath = [folderPath '/'];

runTable{iRow, 1} = ' / whiskdata';

% check what's in the watchfolder and exclude irrelephant files
dirParseTic = tic;
files = dir(folderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) isempty(regexp(x.name, this.dw.watchTypeFilePatterns.whiskdata, 'once')), files)) = [];

nFiles = numel(files); % count the number of remaining files
o('#OCIA_processFolder_whisk(): found %d file(s) (%3.1f sec).', nFiles, toc(dirParseTic), 5, this.verb);

% store the number of files
runTable{iRow, 4} = sprintf('%02d', nFiles);

% clean up runTables: delete empty cells
o('  #OCIA_processFolder_whisk(): folder(s) processing done, cleaning up runTables ...', 5, this.verb);
runTable(cellfun(@isempty, (runTable(:, 1))), :) = [];

o('  #OCIA_processFolder_whisk: %s done (%3.1f sec).', folderName, toc(whiskProcessTic), 4, this.verb);

end
