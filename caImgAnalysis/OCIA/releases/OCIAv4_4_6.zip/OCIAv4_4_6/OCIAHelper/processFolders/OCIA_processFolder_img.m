%% #OCIA:DW:OCIA_processFolder_img
function dataRunTableRow = OCIA_processFolder_img(this, folderPath, ~, folderName, ~, ~, ~)

extractTic = tic;
o('    #OCIA_processFolder_img(): ''%s'' (at ''%s'').', folderName, folderPath, 4, this.verb);

% create an information row
dataRunTableRow = cell(1, size(this.dw.runTable, 2));
dataRunTableRow{1, 1} = ' / imgData';

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns
imgFolderPattern = watchTypePatterns{strcmp(watchTypeIDs, 'img')};

% extract date and time from the folder's name
dateTimeHits = regexp(folderName, imgFolderPattern, 'names');

% if there was a match, fill in the cells 
if ~isempty(dateTimeHits);
    dataRunTableRow{1, 2} = dateTimeHits.date;
    dataRunTableRow{1, 3} = dateTimeHits.time;
    if isfield(dateTimeHits, 'exp');
        dataRunTableRow{1, 9} = dateTimeHits.exp;
    end;
    if isfield(dateTimeHits, 'add');
        dataRunTableRow{1, 9} = dateTimeHits.add;
    end;
% if there was no match, show a warning and leave empty
else
    showWarning(this, 'OCIA:OCIA_processFile_img:ImgFolderDateTimeMatchFailure', ...
        sprintf('Cannot match date-time to imaging folder''s name: ''%s'' with pattern ''%s''.', ...
        folderName, imgFolderPattern));
end;

% save the date and the time from the folder's name

%% get the data folder's content
files = dir(folderPath);
nFiles = numel(files) - 2; % do not count '.' and '..' folders 

% if no files, stop here
if ~nFiles;
    o('      #OCIA_processFolder_img(): no file in the folder at "%s", skipping.', folderPath, 3, this.verb);
    dataRunTableRow{1, 4} = sprintf('%02d', nFiles); % store the number of files found
    return;
end;

% exclude everything that is not imaging data file or associated metadata
files(arrayfun(@(iFile) isempty(regexp(files(iFile).name, this.dw.watchTypeFilePatterns.imgdata, 'names')) ...
    & isempty(regexp(files(iFile).name, this.dw.watchTypeFilePatterns.imgmetadata, 'names')), 1 : numel(files))) = [];
nFiles = numel(files);

% get the number of imaging files
imgFiles = files;
imgFiles(arrayfun(@(iFile) isempty(regexp(files(iFile).name, this.dw.watchTypeFilePatterns.imgdata, 'names')), 1 : nFiles)) = [];
nImgFiles = numel(imgFiles);
dataRunTableRow{1, 4} = sprintf('%02d', nImgFiles); % store the number of files found

%% process the dimension tag
% if required, get the dimension information from the first file
if ~get(this.GUI.handles.dw.skipMeta, 'Value');
    
    % loop through all files
    for iFile = 1 : nFiles;
        
        fileName = files(1).name; % get the first file's name
        dataExt = cell2mat(regexprep(regexp(fileName, '\.\w+$', 'match'), '^\.', '')); % get the file's extension

        switch dataExt;
            
            % imaging tif files
            case 'tif';

                % get the dimension information
                imInfoTic = tic;
                o('      #OCIA_processFolder_img(): checking dims with ''%s'' ...', fileName, 4, this.verb);
                imInfo = imfinfo([folderPath '\' fileName]);
                dims = [imInfo(1).Width imInfo(1).Height numel(imInfo)];
                o('      #OCIA_processFolder_img(): checking dims done (%3.1f sec).', toc(imInfoTic), 5, this.verb);

                % skip the 3rd dimension if it's 1 (display '256x256' and not '256x256x1')
                if dims(3) == 1; dims = dims(1 : 2); end;

                % create and store a dimension tag like : '256x256' or '100x100x3'
                dimTag = regexprep(sprintf(repmat('%dx', 1, numel(dims)), dims), 'x$', '');
                dataRunTableRow{1, 5} = dimTag;
                o('      #OCIA_processFolder_img(): found dimTag: ''%s'' (%s) ...', folderName, dimTag, 4, this.verb);
                
                % stop if something was found
                break;

             % binary data files
            case 'bin';
                
                % skip
                
            % binary data files
            case 'xml';

                DOMnode = xmlread(sprintf('%s/%s', folderPath, fileName));
                fileDims = [str2double(DOMnode.getElementsByTagName('ResolutionX').item(0).getTextContent()), ...
                    str2double(DOMnode.getElementsByTagName('ResolutionY').item(0).getTextContent())];
                if isempty(this.an.img.defaultImDim); this.an.img.defaultImDim = fileDims; end;

                % skip if no imaging files
                if isempty(imgFiles); continue; end;
                
                % use dimensions from the xml file
                dimTag = sprintf('%dx%dx%d', fileDims, floor(imgFiles(1).bytes / (prod(fileDims) * 2)));
                laserInt = sprintf('%.1f', ...
                    str2double(DOMnode.getElementsByTagName('Intensity').item(0).getTextContent()));
                zoomLevel = char(DOMnode.getElementsByTagName('Zoom').item(1).getTextContent());
                fileFrameRate = sprintf('%.2f', ...
                    str2double(DOMnode.getElementsByTagName('FrameScanRate').item(0).getTextContent()));
                zStep = char(DOMnode.getElementsByTagName('StepSize').item(0).getTextContent());
                dataRunTableRow(1, [5, 12 : 15]) = [{dimTag}, {laserInt}, {zoomLevel}, {fileFrameRate}, {zStep}];
                o('      #OCIA_processFolder_img(): found dimTag: ''%s'' (%s) ...', folderName, dimTag, 4, this.verb);

                % stop if something was found
                break;
        end;
    end;
    
% if dimension checking is not required, skip it
else
    o('      #OCIA_processFolder_img(): skipping dimTag check for ''%s'' ...', folderName, 4, this.verb);
end;

o('      #OCIA_processFolder_img(): %s done (%3.1f sec).', folderName, toc(extractTic), 4, this.verb);

end
