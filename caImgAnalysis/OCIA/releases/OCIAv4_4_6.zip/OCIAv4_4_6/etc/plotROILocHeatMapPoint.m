function fig = plotROILocHeatMapPoint(ROIValues, cLims, refImg, dimX, dimY, ROIPos, saveName, colorBarLabel, pointSize)

    fig = figure('Name', saveName, 'NumberTitle', 'off');
    nCols = 50;
    cMap = jet(nCols);
    imagesc(reshape(repmat(refImg(:, :, 2), 1, 3), dimX, dimY, 3));
    hold on;
    ROICenter = zeros(numel(ROIPos), 2);
    for iROI = 1 : numel(ROIPos);
        
        [x, y] = find(ROIPos{iROI});
        ROICenter(iROI, 1) = mean(y);
        ROICenter(iROI, 2) = mean(x);
        if ROIValues(iROI) == cLims(1)
            cInd = 1;
        else
            cInd = round((ROIValues(iROI) - cLims(1)) / (cLims(end) - cLims(1)) * nCols);
        end;
        if isnan(cInd);
            hScatter = scatter(ROICenter(iROI, 1), ROICenter(iROI, 2), pointSize, 'o');
            set(hScatter, 'MarkerFaceColor', ones(1, 3) * 0.5, 'MarkerEdgeColor', 'k');
        else
            if cInd < 1 || cInd > nCols;
                warning('plotROILocHeatMapPoint:cIndOutOfRange', 'cInd out of range: %d.', cInd);
                cInd = min(max(cInd, 1), nCols);
            end;
            col = cMap(cInd, :);
            hScatter = scatter(ROICenter(iROI, 1), ROICenter(iROI, 2), pointSize, 'o');
            set(hScatter, 'MarkerFaceColor', col, 'MarkerEdgeColor', 'k');
        end;
    end;
    hColBar = colorbar();
    caxis([0 1]);
    set(hColBar, 'YTick', 0 : 0.1 : 1, 'YTickLabel', cLims(1) : (cLims(end) - cLims(1)) / 10 : cLims(end));
    set(get(hColBar,'YLabel'), 'String', colorBarLabel);
    
    titleHandle = title(saveName, 'Interpreter', 'none');
    makePrettyFigure(gcf);
    set(titleHandle, 'FontSize', 8);
    set(gca, 'FontSize', 8, 'YTick', [], 'XTick', []);
    set(get(hColBar,'YLabel'), 'FontSize', 8);
    
end