function INUpdateGUI(this, ~, ~)
% INUpdateGUI - [no description]
%
%       INUpdateGUI(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

updateGUITic = tic;
o('#%s ...', mfilename, 3, this.verb);

% check if there is anything to display
if isempty(this.in.data.baselineDRRAvg); return; end;

% get the size of the images
[H, W] = size(this.in.data.refImg);

% get the number of images already collected
arrayBaseline = cell2mat(this.in.data.baselineDRRAvg');
nBaselineAvgs = size(arrayBaseline, 2) / W;
arrayStimulus = cell2mat(this.in.data.stimulusDRRAvg');
nStimulusAvg = size(arrayStimulus, 2) / W;

% if average image is requested
if get(this.GUI.handles.in.showAvg, 'Value');
    
    % disable the run chooser
    set(this.GUI.handles.in.runChooser, 'Enable', 'off');
    set(this.GUI.handles.in.inclRun, 'Enable', 'off');
    
    % calculate average for baseline frames
    baselineDRRAvgAllRuns = reshape(arrayBaseline, H, W, nBaselineAvgs);
    baselineDRRAvgAllRuns(:, :, ~this.in.data.includeInAverage) = [];
    baselineDRRAvgAll = nanmean(baselineDRRAvgAllRuns, 3);
    baselineDRRAvgAll = imfilter(baselineDRRAvgAll, this.GUI.in.filt);
    % set the image
    set(this.GUI.handles.in.expLeftImg, 'CData', 100 * baselineDRRAvgAll);
    set(this.GUI.handles.in.expAxeLeft, 'XLim', [0 W], 'YLim', [0 H]);
    
    % calculate average for stimulus frames
    stimulusDRRAvgAllRuns = reshape(arrayStimulus, H, W, nStimulusAvg);
    stimulusDRRAvgAllRuns(:, :, ~this.in.data.includeInAverage) = [];
    stimulusDRRAvgAll = nanmean(stimulusDRRAvgAllRuns, 3);
    stimulusDRRAvgAll = imfilter(stimulusDRRAvgAll, this.GUI.in.filt);
    % set the image
    set(this.GUI.handles.in.expRightImg, 'CData', 100 * stimulusDRRAvgAll);
    set(this.GUI.handles.in.expAxeRight, 'XLim', [0 W], 'YLim', [0 H]);
 
% no averaging
else
    
    nRuns = max(max(nBaselineAvgs, nStimulusAvg), 2);
    set(this.GUI.handles.in.runChooser, 'Enable', 'on', 'Min', 1, 'Max', nRuns, ...
        'SliderStep', [1 / (nRuns - 1) 1 / (nRuns - 1)]);
    iRun = round(get(this.GUI.handles.in.runChooser, 'Value'));
    iRun = min(max(iRun, 1), nRuns); % make sure iRun does not exceed limits
    o('#%s: iRun: %.1f, value: %.1f', mfilename, iRun, get(this.GUI.handles.in.runChooser, 'Value'), 4, this.verb);
    set(this.GUI.handles.in.runChooser, 'Value', iRun);
    showMessage(this, sprintf('Intrinsic: showing run %02d/%02d', iRun, nRuns));

    % set the include check box state
    set(this.GUI.handles.in.inclRun, 'Enable', 'on', 'Value', this.in.data.includeInAverage(iRun));
    
    % set the image
    baselineDRRAvgForRun = 100 * imfilter(this.in.data.baselineDRRAvg{iRun}, this.GUI.in.filt);
    set(this.GUI.handles.in.expLeftImg, 'CData', baselineDRRAvgForRun);
    set(this.GUI.handles.in.expAxeLeft, 'XLim', [0 W], 'YLim', [0 H]);
    % set the image
    stimulusDRRAvgForRun = 100 * imfilter(this.in.data.stimulusDRRAvg{iRun}, this.GUI.in.filt);
    set(this.GUI.handles.in.expRightImg, 'CData', stimulusDRRAvgForRun);
    set(this.GUI.handles.in.expAxeRight, 'XLim', [0 W], 'YLim', [0 H]);
    
end;

% update color limits
cLim = this.in.common.cLim;
if numel(cLim) == 1; cLim = [-abs(cLim) abs(cLim)]; end;
if cLim(1) >= cLim(2);
    cLim(1) = cLim(2) - 0.01;
    set(this.GUI.handles.in.paramPanElems.cLim, 'String', sprintf('[%.2f, %.2f]', cLim));
end;
set(this.GUI.handles.in.expAxeLeft, 'CLim', cLim);
set(this.GUI.handles.in.expAxeRight, 'CLim', cLim);

% set back the reference image
set(this.GUI.handles.in.refImg, 'CData', this.in.data.refImg);

o('#%s: updating GUI done: %.1f sec', mfilename, toc(updateGUITic), 3, this.verb);

end
