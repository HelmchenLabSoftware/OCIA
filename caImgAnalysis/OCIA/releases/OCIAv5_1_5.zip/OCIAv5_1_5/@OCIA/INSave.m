function INSave(this, savePath)
% INSave - [no description]
%
%       INSave(this, savePath)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

% if no save path provided, generate it
if isempty(savePath);
    % get the save path
    savePath = sprintf('%s%s.mat', this.path.intrSave, this.in.common.saveName);
    while strfind(savePath, '[');
        savePath = regexprep(savePath, '\[([\w\.]+)\]', '[this\.in\.$1]', 'once');
        replaceVal = eval(cell2mat(regexp(savePath, '\[([\w\.]+)\]', 'tokens', 'once')));
        if isnumeric(replaceVal); replaceVal = sprintf('%02d', replaceVal); end;
        savePath = regexprep(savePath, '\[([\w\.]+)\]', replaceVal, 'once');
    end;
end;

% check if a file already exists
if exist(savePath, 'file');
    % open a confirmation dialog
    doOverWrite = questdlg(sprintf('Intrinsic saving: an existing file has been found at "%s". Do you want to overwrite it?', ...
        savePath), '/!\ Warning !', 'Yes', 'No', 'No');    
    % if the decision is to not overwrite
    if ~strcmp(doOverWrite, 'Yes');
        showMessage(this, sprintf('Intrinsic: *NOT* overwriting file at "%s". Saving aborted !', savePath), 'red');        
        return;        
    end;
    
    showMessage(this, sprintf('Intrinsic: overwriting file at "%s" ...', savePath), 'yellow');
    pause(0.1);
end;

% create directory if it does not exist
if exist(this.path.intrSave, 'dir') ~= 7; mkdir(this.path.intrSave); end;

% create the save structure
intrSave = struct();
intrSave.data = this.in.data;
if strcmp(this.in.expMode, 'standard');
    intrSave.data.baseline1Frames = {};
    intrSave.data.baseline2Frames = {};
    intrSave.data.stimulusFrames = {};
elseif strcmp(this.in.expMode, 'standard');
    intrSave.data.baseline1Frames = {};
    intrSave.data.baseline2Frames = {};
    intrSave.data.baselineDRRAvg = {};
    intrSave.data.stimulusDRRAvg = {};
    intrSave.data.includeInAverage = {};
end;
intrSave.params = this.in;
intrSave.params = rmfield(intrSave.params, 'data');
intrSave.params = rmfield(intrSave.params, 'camH');
intrSave.params = rmfield(intrSave.params, 'RP');
if ~isempty(this.GUI.in.ROIHandle);
    intrSave.params.ROIPos = this.GUI.in.ROIHandle{1}.getPosition();
end;


s = whos('intrSave');
sizeInMegaBytes = s.bytes / 1024 / 1024;

showMessage(this, sprintf('Intrinsic: saving intrinsic data to "%s" (~%.1f MB) ...', savePath, sizeInMegaBytes), 'yellow');  
pause(0.1);

% save the file
save(savePath, 'intrSave');

showMessage(this, sprintf('Intrinsic: saving intrinsic data to "%s" done !', savePath));

end
