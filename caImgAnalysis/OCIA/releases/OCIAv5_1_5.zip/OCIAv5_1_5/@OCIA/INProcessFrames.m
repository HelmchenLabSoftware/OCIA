%% #INProcessFrames
function frames = INProcessFrames(this, frames)

if isempty(frames); return; end;

% rotate frames
frames = flip(frames, 1);

% spatial down-sampling
if this.in.spatialDSFactor > 1;

    spatialDSTic = tic;

    o('#%s: spatially down-sampling frames by a factor of %d ...', mfilename, this.in.spatialDSFactor, 4, this.verb);
    frames = imresize(frames, 1 / this.in.spatialDSFactor, 'nearest');

    o('#%s: spatial down-sampling done: %.1f sec', mfilename, toc(spatialDSTic), 4, this.verb);
end;

end
