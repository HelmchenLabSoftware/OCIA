function BEStopExp(this, ~, ~)
% BEStopExp - [no description]
%
%       BEStopExp(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

if this.be.isRunning;
    this.be.isRunning = false;
    this.be.isToReset = true;
%     this.be.iTrial = 0;
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    BESaveOutput(this);
else
    showWarning(this, 'OCIA:Behavior:CannotStopNotRunning', ...
        'Cannot stop because experiment is not running.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
end

end

