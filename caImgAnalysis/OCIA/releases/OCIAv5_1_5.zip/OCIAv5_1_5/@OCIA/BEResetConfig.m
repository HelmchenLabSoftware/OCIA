function BEResetConfig(this, ~, ~)
% BEResetConfig - [no description]
%
%       BEResetConfig(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

this.be.room = '';
BEActivate(this);

end
