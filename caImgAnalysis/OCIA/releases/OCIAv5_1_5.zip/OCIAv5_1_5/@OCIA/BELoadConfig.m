function BELoadConfig(this, ~, ~)
% BELoadConfig - [no description]
%
%       BELoadConfig(this, ~, ~)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

showMessage(this, 'Loading configuration ...');
set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'yellow');
pause(0.01);

if isempty(this.GUI.be.selConfigRow); % attempt to fetch again the selected row
    jTable = getJTable(this, 'BEConfTable');
    this.GUI.be.selConfigRow = jTable.getSelectedRows() + 1;
    if isempty(this.GUI.be.selConfigRow);
        showWarning(this, 'OCIA:Behavior:loadConfig:NoMouseIdSelected', ...
            'Cannot load config because no mouse ID is selected.');
        set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'red', 'Value', 0);
        return;
    end;
end;

configCell = this.be.configs.animals;
this.be.animalID = configCell{this.GUI.be.selConfigRow, 1};
this.be.taskType = configCell{this.GUI.be.selConfigRow, 2};
this.be.phase = configCell{this.GUI.be.selConfigRow, 3};

% if > 0, sets the number of seconds to wait before a new run of mtrainer
% this.be.automode = 5;
this.be.iTrial = 0;
this.be.config = this.be.configs.behavior.(this.be.taskType).(this.be.phase);

%% - #BELoadConfig - stimuli and trials
o('  #BELoadConfig: setup stimuli and trials... ', 3, this.verb);
% set up stimulus vector
if isfield(this.be.config.tone, 'stimMatrix');
    
%     if this.be.config.training.nTrials ~= size(this.be.config.tone.stimMatrix, 2);
%         showWarning(this, 'OCIA:Behavior:loadConfig:NumberOfTrialsMismatch', ...
%             sprintf('nTrials in the "training" (%d) ~= nTrials in "stimMatrix" (%d). Overwriting.', ...
%             this.be.config.training.nTrials, size(this.be.config.tone.stimMatrix, 2)));
%         pause(1);
%         this.be.config.training.nTrials = size(this.be.config.tone.stimMatrix, 2);
%     end;

    this.be.stimMatrixRandomIndex = randi(size(this.be.config.tone.stimMatrix, 1));
    stims = this.be.config.tone.stimMatrix(this.be.stimMatrixRandomIndex, :);
    stims = stims(1 : this.be.config.training.nTrials); % only take first nTrials, hoping that the block hashing is okay

else
    
    showWarning(this, 'OCIA:Behavior:loadConfig:NoStimMatrix', 'Behavior: no stimulus matrix found ! Aborting.');
    set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'red', 'Value', 0);
    return;
    
%     stims = [];
%     for iFreq = 1 : numel(this.be.config.tone.freqs);
%         stimForFreq = repmat(iFreq, 1, round(this.be.config.tone.stimProba(iFreq) * this.be.config.training.nTrials));
%         stims = [stims, stimForFreq]; %#ok<AGROW>
%     end
% 
%     % stim vector should not be randomly permuted
%     stims = stims(randperm(numel(stims)));
%     stims = stims(1 : this.be.config.training.nTrials);

end;

% set up spot sequence: get the number of spots
spotTable = get(this.GUI.handles.be.ETLTable, 'Data');
nSpots = size(spotTable, 1);

% by default, spotMatrix is empty so there is no spot switching
this.be.spotMatrix = [];

% if spots exist and a spot matrix exists
if nSpots > 0 && isfield(this.be.config.training, 'spotMatrix');

    % if more spots exist that the number of elements in the spot matrix
    if nSpots > numel(this.be.config.training.spotMatrix);
        showWarning(this, 'OCIA:Behavior:loadConfig:SpotMatrixTooSmall', 'Behavior: spot matrix too small ! Aborting.');
        set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'red', 'Value', 0);
        return;
    end;
    
    % get the spot matrix for the correct number of spots
    this.be.spotMatrix = this.be.config.training.spotMatrix{nSpots};
    
% some spots exist but no spot matrix
elseif nSpots > 0;    
    showWarning(this, 'OCIA:Behavior:loadConfig:NoSpotMatrix', 'Behavior: no spot matrix found ! Aborting.');
    set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'red', 'Value', 0);
    return;
    
end;

switch this.be.taskType;
    
    case {'freqDiscr', 'oddDiscr'};
        % set up oddball vector by altering stims with a certain probability
        odds = stims;
        oddPos = zeros(size(odds));
        uniqueStims = unique(stims);
        isOdd = rand(1, numel(stims)) < this.be.config.tone.oddProba;
        % last 2 tones can be odd
        uniqueOddPos = this.be.config.tone.nTones - 1 : this.be.config.tone.nTones;
        for iStim = 1 : numel(isOdd);
            if isOdd(iStim);
                otherStims = uniqueStims(uniqueStims ~= stims(iStim));
                otherStims = otherStims(randperm(numel(otherStims)));
                mixedOddPos = uniqueOddPos(randperm(numel(uniqueOddPos)));
                odds(iStim) = otherStims(1);
                oddPos(iStim) = mixedOddPos(1);
            end;
        end;
        
        % only one number of tones
        if numel(this.be.config.tone.nTones) == 1;
            nTones = this.be.config.tone.nTones;
        % multiple number of tones, with a nTonesMatrix to randomly choose
        elseif isfield(this.be.config.tone, 'nTonesMatrix');
            nTonesRand = randi(size(this.be.config.tone.nTonesMatrix, 1));
            nTones = this.be.config.tone.nTonesMatrix(nTonesRand, :);
        % multiple number of tones but no nTonesMatrix so just use the first number of tones
        else
            nTones = this.be.config.tone.nTones(1);
        end;

        % set up tone array
        this.be.toneArray = MakePureMultiToneOddballArray(this.be.config.tone.freqs, ...
            stims, odds, oddPos, nTones, this.be.config.tone.stimDur, this.be.config.tone.ISI, ...
            this.be.config.tone.samplingFreq);
    
    case 'cotOdd';
                
        % only one number of tones
        if numel(this.be.config.tone.nTones) == 1;
            nTones = this.be.config.tone.nTones;
        % multiple number of tones, with a nTonesMatrix to randomly choose
        elseif isfield(this.be.config.tone, 'nTonesMatrix');
            nTonesRand = randi(size(this.be.config.tone.nTonesMatrix, 1));
            nTones = this.be.config.tone.nTonesMatrix(nTonesRand, :);
        % multiple number of tones but no nTonesMatrix so just use the first number of tones
        else
            nTones = this.be.config.tone.nTones(1);
        end;
        
        % set up sound array with last tone as odd 
        odds = ones(size(stims));
        oddPos = nTones;
        isOdd = ones(size(stims));
        sampFreq = this.be.config.tone.samplingFreq;
        
        this.be.toneArray = cell(1, numel(stims));
        
        for iStim = 1 : numel(stims);
            
            freqList = this.be.config.tone.uniqueFreqs;
            
            if stims(iStim) == 1;
                cotStimVector = [ones(1, nTones(iStim) - 1) 2];
            else
                cotStimVector = [ones(1, nTones(iStim) - 1) * 2 1];
            end;
            
            % create cell array of cloud of tones
            cot = MakeCloudOfTonesSound(freqList, this.be.config.tone.freqIndexes, ...
                this.be.config.tone.cloudDispersion, cotStimVector, this.be.config.tone.toneDur, ...
                this.be.config.tone.toneISI, this.be.config.tone.stimDur, 0, sampFreq, 0, 0);
            
            cotAll = cell2mat(cot); % get cell array as a matrix
            cotDim = size(cotAll); % get dimension
            silenceDur = round(sampFreq * this.be.config.tone.ISI); % get silence duration
            cotAll = [zeros(cotDim(1), silenceDur) cotAll]; %#ok<AGROW> % insert silences
            cotAll = reshape(cotAll', 1, numel(cotAll)); % make linear
            cotAll = cotAll(silenceDur + 1 : end); % remove first silence
            this.be.toneArray{iStim} = cotAll; % store
            
        end;

    case 'cotDiscr';

        nTones = this.be.config.tone.nTones;
        odds = zeros(size(stims));
        oddPos = zeros(size(stims));
        isOdd = zeros(size(stims));
        
        atten = 0;
        this.be.toneArray = MakeCloudOfTonesSound(this.be.config.tone.uniqueFreqs, ...
            this.be.config.tone.freqIndexes, this.be.config.tone.cloudDispersion, stims, ...
            this.be.config.tone.toneDur, this.be.config.tone.toneISI, ...
            this.be.config.tone.stimDur, atten, this.be.config.tone.samplingFreq, 0, 0);
        
end;

this.be.nTones = nTones;
this.be.stims = stims;
this.be.odds = odds;
this.be.oddPos = oddPos;
this.be.isOdd = isOdd;

% set the reward duration to the one of the config file
BEChangeRewDur(this, this.be.config.training.rewDur);

this.be.configLoaded = true;
set(this.GUI.handles.be.loadConf, 'BackgroundColor', 'green', 'Value', 1);

BEInitExp(this);

o('  #BELoadConfig: setup stimuli and trials done. ', 3, this.verb);
showMessage(this, sprintf('Loading configuration done for mouse "%s".', this.be.animalID));


end
