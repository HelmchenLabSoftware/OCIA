function OCIA_createWindow_intrinsic(this, pad)
% OCIA_createWindow_intrinsic - [no description]
%
%       OCIA_createWindow_intrinsic(this, pad)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

BGWhite = {'Background', 'white'}; %#ok<*CCAT>
NormUnits = {'Units', 'normalized'};
bPad = 0.005;

%% - #OCIACreateWindow: Intrinsic panels
commons = {'Parent', this.GUI.handles.panels.IntrinsicPanel, BGWhite{:}, 'Units', ...
    'normalized', 'Visible', 'on', 'FontSize', this.GUI.pos(4) / 95};

totWTop = (1 - 4 * pad);
totWBottom = (1 - 3 * pad);
prevPanW = 1/3 * totWTop; prevPanH = 0.5 - 0.5 * pad; prevPanX = pad; prevPanY = 1 - pad - prevPanH;
expPanW = 1/3 * totWTop; expPanH = 0.5 - 0.5 * pad;
expPanLX = prevPanX + prevPanW + pad; expPanLY = prevPanY;
expPanRX = expPanLX + expPanW + pad; expPanRY = prevPanY;
refPanW = 1/3 * totWBottom; refPanH = 0.5 - 0.5 * pad; refPanX = pad; refPanY = pad;
paramPanW = 2/3 * totWBottom; paramPanH = 0.5 - 0.5 * pad; paramPanX = refPanX + refPanW + pad; paramPanY = pad;

this.GUI.handles.in.panels.prev = uipanel(commons{:}, 'Title', 'Preview image', 'Tag', 'INPrev', ...
    'Position', [prevPanX prevPanY prevPanW prevPanH]);
this.GUI.handles.in.panels.expLeft = uipanel(commons{:}, 'Title', 'Average image BASELINE', 'Tag', 'INExpLeft', ...
    'Position', [expPanLX expPanLY expPanW expPanH]);
this.GUI.handles.in.panels.expRight = uipanel(commons{:}, 'Title', 'Average image STIMULUS', 'Tag', 'INExpRight', ...
    'Position', [expPanRX expPanRY expPanW expPanH]);
this.GUI.handles.in.panels.ref = uipanel(commons{:}, 'Title', 'Reference image', 'Tag', 'INRef', ...
    'Position', [refPanX refPanY refPanW refPanH]);
this.GUI.handles.in.panels.param = uipanel(commons{:}, 'Title', 'Parameters', 'Tag', 'INParam', ...
    'Position', [paramPanX paramPanY paramPanW paramPanH]);

%% - #OCIACreateWindow: Intrinsic: preview imadjust axe
axePadX = 0.01; axePadY = 0.01;
sliderCommons = { 'Parent', this.GUI.handles.in.panels.prev, NormUnits{:}, 'Style', 'slider', 'SliderStep', [0.01 0.1] };
prevAxeW = 1 - 2 * axePadX - 2 * bPad; prevAxeH = 1 - 2 * axePadY - 2 * bPad; prevAxeX = axePadX + bPad;
imAdjPrevSliderW = (prevAxeW - bPad) * 0.5; imAdjPrevSliderH = axePadY * 3;
imAdjPrevSliderX = prevAxeX; imAdjPrevSliderY = axePadY + bPad;
this.GUI.handles.in.imAdjMinPrev = uicontrol(sliderCommons{:}, 'Min', 0, 'Max', 1, 'Tag', 'INPrevAxeImAdjMin', ...
    'Position', [imAdjPrevSliderX imAdjPrevSliderY imAdjPrevSliderW imAdjPrevSliderH], 'Value', 0.05);
this.GUI.handles.in.imAdjMaxPrev = uicontrol(sliderCommons{:}, 'Min', 0, 'Max', 1, 'Tag', 'INPrevAxeImAdjMax', ...
    'Position', [imAdjPrevSliderX + imAdjPrevSliderW + bPad imAdjPrevSliderY imAdjPrevSliderW imAdjPrevSliderH], ...
    'Value', 0.95);

%% - #OCIACreateWindow: Intrinsic: preview axes
axesCommons = {'Color', [0.5 0.5 0.5], NormUnits{:}, 'XTick', [], 'YTick', []};
prevAxeY = imAdjPrevSliderY + imAdjPrevSliderH + axePadY + bPad;
this.GUI.handles.in.prevAxe = axes(axesCommons{:}, 'Parent', this.GUI.handles.in.panels.prev, 'Tag', 'INPrevAxe', ...
    'Position', [prevAxeX prevAxeY prevAxeW prevAxeH]);
% the creation of the image is done later to avoid weird flickering effect due to imshow
this.GUI.handles.in.prevImg = [];

%% - #OCIACreateWindow: Intrinsic: reference axes
this.GUI.handles.in.refAxe = axes(axesCommons{:}, 'Parent', this.GUI.handles.in.panels.ref, 'Tag', 'INRefAxe', ...
    'Position', [prevAxeX prevAxeY prevAxeW prevAxeH]);

%% - #OCIACreateWindow: Intrinsic: experiment axes
axePadX = 0.01; axePadY = 0.02;
expAxeLeftW = 1 - 2 * axePadX - 2 * bPad; expAxeLeftH = 1 - 2 * axePadY - 2 * bPad;
expAxeLeftX = axePadX + bPad; expAxeLeftY = axePadY + bPad;
this.GUI.handles.in.expAxeLeft = axes(axesCommons{:}, 'Parent', this.GUI.handles.in.panels.expLeft, 'Tag', 'INExpAxeLeft', ...
    'Position', [expAxeLeftX expAxeLeftY expAxeLeftW expAxeLeftH]);
expAxeRightW = 1 - 2 * axePadX - 2 * bPad; expAxeRightH = 1 - 2 * axePadY - 2 * bPad;
expAxeRightX = axePadX + bPad; expAxeRightY = axePadY + bPad;
this.GUI.handles.in.expAxeRight = axes(axesCommons{:}, 'Parent', this.GUI.handles.in.panels.expRight, 'Tag', 'INExpAxeRight', ...
    'Position', [expAxeRightX expAxeRightY expAxeRightW expAxeRightH]);


%% - #OCIACreateWindow: Intrinsic: Parameter panel: general button
commons = {'Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Style', 'togglebutton', 'FontSize', this.GUI.pos(4) / 75};
nButs = 10; totW = (1 - (nButs + 1) * bPad);

connW = 0.1 * totW; connH = 0.07; connX = bPad; connY = 1 - connH - bPad;
this.GUI.handles.in.connect = uicontrol(commons{:}, 'String', 'Connect', 'BackgroundColor', iff(this.in.connected, 'green', 'red'), ...
    'Position', [connX connY connW connH], 'Callback', @(h, e)INConnect(this, h, e), 'Tag', 'INConnect');
prevButW = 0.1 * totW; prevButH = connH; prevButX = connX + connW + bPad; prevButY = connY;
this.GUI.handles.in.prevBut = uicontrol(commons{:}, 'String', 'Preview', 'BackgroundColor', iff(this.in.previewRunning, 'green', 'red'), ...
    'Position', [prevButX prevButY prevButW prevButH], 'Callback', @(h, e)INPreview(this, h, e), 'Tag', 'INPrev');
refButW = 0.1 * totW; refButH = connH; refButX = prevButX + prevButW + bPad; refButY = connY;
this.GUI.handles.in.refBut = uicontrol(commons{:}, 'String', 'Grab ref.', 'Tag', 'INGrabRef', ...
    'Position', [refButX refButY refButW refButH], 'Callback', @(h, e)INGrabReferenceImage(this, h, e));
runExpButW = 0.17 * totW; runExpButH = connH; runExpButX = refButX + refButW + bPad; runExpButY = connY;
this.GUI.handles.in.runExpBut = uicontrol(commons{:}, 'String', 'Run experiment', 'Tag', 'INRunExp', 'BackgroundColor', 'red', ...
    'Position', [runExpButX runExpButY runExpButW runExpButH], 'Callback', @(h, e)INRunExp(this, h, e));

%% - #OCIACreateWindow: Intrinsic: Parameter panel: experiment mode drop-down menu
expModeW = 0.13 * totW; expModeH = connH; expModeX = runExpButX + runExpButW + bPad; expModeY = connY;
this.GUI.handles.in.expMode = uicontrol('Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Style', 'popupmenu', ...
    BGWhite{:}, 'FontSize', this.GUI.pos(4) / 75, 'String', { 'standard', 'fourier' }, ...
    'Position', [expModeX expModeY expModeW expModeH], 'Callback', @(h, e)INChangeExpMode(this, h, e), ...
    'Value', iff(strcmp(this.in.expMode, 'standard'), 1, 2), 'Tag', 'INExpMode');

%% - #OCIACreateWindow: Intrinsic: zoom button
commons = {'Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Value', 0, 'Style', 'togglebutton'};
zToolW = totW * 0.05; zToolH = connH; zToolX = expModeX + expModeW + bPad; zToolY = expModeY;
zToolIcon = load(fullfile(matlabroot(), '/toolbox/matlab/icons/zoom.mat'));
this.GUI.handles.in.zTool = uicontrol(commons{:}, 'Tag', 'INZTool', 'CData', zToolIcon.zoomCData, ...
    'Position', [zToolX, zToolY, zToolW, zToolH], 'Callback', @(h, e)INActivateZoom(this, h, e), ...
    'ToolTipString', 'Zoom');

%% - #OCIACreateWindow: Intrinsic: pan button
pToolW = zToolW; pToolH = zToolH; pToolX = zToolX + zToolW + bPad; pToolY = zToolY;
pToolIcon = load(fullfile(matlabroot(), '/toolbox/matlab/icons/pan.mat'));
this.GUI.handles.in.pTool = uicontrol(commons{:}, 'CData', pToolIcon.cdata, 'Tag', 'INPTool', ...
    'Position', [pToolX, pToolY, pToolW, pToolH], 'Callback', @(h, e)INActivatePan(this, h, e), ...
    'ToolTipString', 'Pan (scroll)');

%% - #OCIACreateWindow: Intrinsic: data cursor button
cToolW = zToolW; cToolH = zToolH; cToolX = pToolX + pToolW + bPad; cToolY = zToolY;
cToolIcon = load(fullfile(matlabroot(), '/toolbox/matlab/icons/datatip.mat'));
this.GUI.handles.in.cTool = uicontrol(commons{:}, 'CData', cToolIcon.cdata, 'Tag', 'INCTool', ...
    'Position', [cToolX, cToolY, cToolW, cToolH], 'Callback', @(h, e)INActivateDataCursor(this, h, e), ...
    'ToolTipString', 'Data cursor');

%% - #OCIACreateWindow: Intrinsic: draw ROI
commons = {'Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Style', 'pushbutton', 'FontSize', 13};
drawROIW = zToolW; drawROIH = zToolH; drawROIX = cToolX + cToolW + bPad; drawROIY = zToolY;
iconPath = regexprep(which('OCIA'), '@OCIA.OCIA\.m', 'icons/menuIcons/freehandDrawTool.png');
cData = linScale(double(imread(iconPath))); % get the icon
cData(cData == 0) = NaN; % make transparency
this.GUI.handles.in.drawROI = uicontrol(commons{:}, 'CData', cData, 'Tag', 'INCTool', ...
    'Position', [drawROIX, drawROIY, drawROIW, drawROIH], 'Callback', @(h, e)INDrawROI(this, h, e), ...
    'ToolTipString', 'Draw ROI');

%% - #OCIACreateWindow: Intrinsic: save plot button
savePlotW = zToolW; savePlotH = zToolH; savePlotX = zToolX; savePlotY = zToolY - savePlotH - bPad;
savePlotIcon = load(fullfile(matlabroot(), '/toolbox/matlab/icons/savedoc.mat'));
this.GUI.handles.in.savePlot = uicontrol(commons{:}, 'CData', savePlotIcon.cdata, 'Tag', 'INSavePlot', ...
    'Position', [savePlotX, savePlotY, savePlotW, savePlotH], 'Callback', @(~, ~)INSaveImages(this, []), ...
    'ToolTipString', 'Save the currently displayed images to figures (.fig) or images (.png/.jpg/...)).');

%% - #OCIACreateWindow: Intrinsic: save output button
saveOutW = zToolW; saveOutH = zToolH; saveOutX = savePlotX + savePlotW + bPad; saveOutY = savePlotY;
saveOutIcon = linScale(double(imread(regexprep(which('OCIA'), '@OCIA.OCIA\.m', 'icons/menuIcons/saveOutput.png'))));
saveOutIcon(saveOutIcon == 0) = NaN;
this.GUI.handles.in.saveOut = uicontrol(commons{:}, 'CData', saveOutIcon, 'Tag', 'INSaveOutput', ...
    'Position', [saveOutX, saveOutY, saveOutW, saveOutH], 'Callback', @(~, ~)INSave(this, []), ...
    'ToolTipString', 'Save output results as a MAT-file');

%% - #OCIACreateWindow: Intrinsic: load output button
loadOutW = zToolW; loadOutH = zToolH; loadOutX = saveOutX + saveOutW + bPad; loadOutY = savePlotY;
loadOutIcon = linScale(double(imread(regexprep(which('OCIA'), '@OCIA.OCIA\.m', 'icons/menuIcons/loadOutput.png'))));
loadOutIcon(loadOutIcon == 0) = NaN;
this.GUI.handles.in.loadOut = uicontrol(commons{:}, 'CData', loadOutIcon, 'Tag', 'INLoadOutput', ...
    'Position', [loadOutX, loadOutY, loadOutW, loadOutH], 'Callback', @(~, ~)INLoad(this, []), ...
    'ToolTipString', 'Load output results from MAT-file');

%% - #OCIACreateWindow: Intrinsic: clear data
clearCacheW = zToolW; clearCacheH = zToolH; clearCacheX = loadOutX + loadOutW + bPad; clearCacheY = savePlotY;
iconPath = regexprep(which('OCIA'), '@OCIA.OCIA\.m', 'icons/menuIcons/reset.png');
clearCacheIcon = linScale(double(imread(iconPath)));
clearCacheIcon(clearCacheIcon == 0) = NaN;
this.GUI.handles.in.clearCache = uicontrol(commons{:}, 'CData', clearCacheIcon, 'Tag', 'INClearCache', ...
    'Position', [clearCacheX, clearCacheY, clearCacheW, clearCacheH], 'Callback', @(~, ~)INReset(this, []), ...
    'ToolTipString', 'Clear the data.');

%% - #OCIACreateWindow: Intrinsic: Parameter panel: average or single image checkbox
checkBoxCommons = { 'Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Style', 'checkbox', ...
    'FontSize', this.GUI.pos(4) / 75, BGWhite{:}, 'Value', 1 };
showAvgW = 0.14 * totW; showAvgH = connH; showAvgX = bPad; showAvgY = connY - bPad - showAvgH;
this.GUI.handles.in.showAvg = uicontrol(checkBoxCommons{:}, 'String', 'Average ?', 'Tag', 'INShowAvg', ...
    'Position', [showAvgX showAvgY showAvgW showAvgH], 'Callback', @(h, e)INUpdateGUI(this, h, e));

%% - #OCIACreateWindow: Intrinsic: Parameter panel: single image include/exclude
inclRunW = showAvgW; inclRunH = connH; inclRunX = showAvgX + showAvgW + bPad; inclRunY = showAvgY;
this.GUI.handles.in.inclRun = uicontrol(checkBoxCommons{:}, 'String', 'Include ?', 'Tag', 'INInclRun', ...
    'Position', [inclRunX inclRunY inclRunW inclRunH], 'Callback', @(h, e)INSetInclRun(this, h, e), 'Enable', 'off');

%% - #OCIACreateWindow: Intrinsic: Parameter panel: single image slider
runChoserW = expModeX + expModeW - bPad - inclRunX - inclRunW; runChoserH = connH;
runChoserX = inclRunX + inclRunW + bPad; runChoserY = showAvgY;
this.GUI.handles.in.runChooser = uicontrol('Parent', this.GUI.handles.in.panels.param, NormUnits{:}, 'Style', 'slider', ...
    'Position', [runChoserX runChoserY runChoserW runChoserH], 'Min', 0, 'Max', 10, 'Enable', 'off', ...
    'Callback', @(h, e)INUpdateGUI(this, h, e), 'Value', 1, 'SliderStep', [0.1 0.1], 'Tag', 'INRunChooser');

%% - #OCIACreateWindow: Intrinsic: Parameter panel: parameter panels
commons = {'Parent', this.GUI.handles.in.panels.param, BGWhite{:}, 'Units', ...
    'normalized', 'Visible', 'on', 'FontSize', this.GUI.pos(4) / 95};
paramPanPanW = 1 - 2 * bPad; paramPanPanH = connY - connH - 3 * bPad; paramPanPanX = bPad; paramPanPanY = bPad;
this.GUI.handles.in.paramPans.standard = uipanel(commons{:}, 'Title', 'Standard intrinsic mode', 'Tag', 'INStdParamPan', ...
    'Position', [paramPanPanX paramPanPanY paramPanPanW paramPanPanH], 'Visible', iff(strcmp(this.in.expMode, 'standard'), 'on', 'off'));
this.GUI.handles.in.paramPans.fourier = uipanel(commons{:}, 'Title', 'Fourier intrinsic mode', 'Tag', 'INFourParamPan', ...
    'Position', [paramPanPanX paramPanPanY paramPanPanW paramPanPanH], 'Visible', iff(strcmp(this.in.expMode, 'fourier'), 'on', 'off'));


end
