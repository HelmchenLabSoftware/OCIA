function OCIA_startFunction_behavior(this)
% OCIA_startFunction_behavior - [no description]
%
%       OCIA_startFunction_behavior(this)
%
% [No description]
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)

    OCIAChangeMode(this, 'Behavior');
    
end
