function this = OCIA_dataConfig_behav(this)
% OCIA_dataConfig_behav - [no description]
%
%       OCIA_dataConfig_behav(this)
%
% Adds the behavior data structures to the OCIA.
%
% 2013-2015 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)


%% behavior data type

% defines the data storage options
this.main.dataConfig = [this.main.dataConfig; cell2table({ ...
...     rowType             id                  shortLabel              label                     saveFormat    defaultOn
        'Behavior data',    'behav',            'Behav. data (raw)',    'Behavior data (raw)',    'HDF5',       false;
}, 'VariableNames', this.main.dataConfig.Properties.VariableNames)];

% define the analysis parameters for this data type
this.an.be = struct();
this.an.be.nTrialsSkip = [3, 3];
this.an.be.nMinRespTrialSkip = [4, 7];

this.an.be.binWidth = 150;
this.an.be.behavVarToPlot = { 'days', 'session', 'training phase', 'hit rate - session', ...
    'false alarm rate - session', 'performance (d'') - session' };
this.an.be.miceInfoFilePath = '';
% this.an.be.miceInfoFilePath = '1410MiceInfo.txt';
this.an.be.plotLims = [];
this.an.be.PSPer = [-1 2];
this.an.be.includeEO = true;

this.an.be.anInSampleRate = 3000;

this.an.be.selTimes = { 'imgStart', 'sound', 'lightCueOn', 'respTime', 'lightCueOff' };
this.an.be.allTimes = { 'imgStart', 'sound', 'lightCueOn', 'respTime', 'lightCueOff' };
this.an.be.selTrialTypes = { 'go', 'nogo', 'targ', 'distr', 'hit', 'CR', 'FA', 'miss' };
this.an.be.allTrialTypes = { 'go', 'nogo', 'targ', 'distr', 'hit', 'CR', 'FA', 'miss' };
this.an.be.sgFiltFrameSize = 0;
this.an.be.plotLimits = [];
this.an.be.colormap = 'jet';

this.an.be.normTrialsPrctile = [35, 98];

this.an.be.groupBehavVar = { };
this.an.be.histBinWidth = 'sqrt';

% storage for the cached data
this.an.be.dataHash = struct();

end
