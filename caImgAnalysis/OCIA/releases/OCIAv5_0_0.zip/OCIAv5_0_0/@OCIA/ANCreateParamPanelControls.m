function ANCreateParamPanelControls(this)

% abort if no configuration provided
if isempty(this.GUI.an.analysisParamConfig); return; end;

%% init the parameter pannel dimensions
% common inputs
commons = { 'Parent', this.GUI.handles.an.paramPan, 'Units', 'normalized', 'Enable', 'off' };
UICommons = struct();
UICommons.text = [ commons, { 'Background', 'white', 'Style', 'edit', 'Callback', @(h, e) ANUpdatePlot(this, h, e) } ];
UICommons.dropdown = [ commons, { 'Background', 'white', 'Style', 'popupmenu', 'Callback', @(h, e) ANUpdatePlot(this, h, e) } ];
UICommons.list = [ commons, { 'Background', 'white', 'Style', 'list', 'Min', 0, 'Max', 2, 'Callback', @(h, e) ANUpdatePlot(this, h, e) } ];
UICommons.lab = [ commons, { 'Background', 'white', 'Style', 'text' } ];

% define the max number of rows and the number of items to place
nUICtrl = size(this.GUI.an.analysisParamConfig, 1);
nMaxRows = 6; nMaxCols = 3; %#ok<NASGU>
nMinRows = 4; nMinCols = 2; pad = 0.02; inPad = 0.01;
nUICtrlRows = sum(cellfun(@(sizeCell) sizeCell(1), this.GUI.an.analysisParamConfig(:, 5)));

% calculate the number of acutal columns and rows to use
nRows = max(ceil(nUICtrlRows / nMaxCols), nMinRows);
nCols = max(ceil((nUICtrlRows / nRows)), nMinCols);
elemW = (1 - (nCols + 1) * pad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * pad) / nRows; % height depends on the number of rows
iRow = 0; iCol = 1; % init the row and column indexes

% part of the width that is allocated for the label
labelWidthRatio = 0.5;

%% create the UI elements with their labels
% go through all elements, create them and place them
for iUICtrl = 1 : nUICtrl;
    
    % get the variables of the current control element
    [categ, id, UIType, valueType, UISize, label, tooltip] = this.GUI.an.analysisParamConfig{iUICtrl, 1 : 7};
                
    % update row/column index
    iRow = iRow + UISize(1);
    % if max number of rows is reached, go to the next column update rows/columns
    if iRow > nRows;
        iRow = UISize(1);
        iCol = iCol + 1;
    end;

    % calculate X and Y base positions
    elemPosX = (iCol - 1) * (pad + elemW) + pad;
    elemPosY = 1 - iRow * (elemH + pad) + pad;
    
    % calculate positions, depending on whether the label is above or not:
    % if label is above
    if UISize(3);
        % position and size for label
        labElemX = elemPosX;
        labElemY = elemPosY + (UISize(1) - 0.5) * elemH + (UISize(1) - 1) * pad;
        labElemW = elemW;
        labElemH = elemH * 0.5;
        % position and size for GUI element
        ctrlElemX = elemPosX;
        ctrlElemW = elemW;
        ctrlElemY = elemPosY;
        ctrlElemH = (UISize(1) - 0.5) * elemH + (UISize(1) - 2) * pad ;
        
    % if label is not above
    else
        % position and size for label
        labElemX = elemPosX;
        labElemY = elemPosY + (UISize(1) * 0.5 - 0.5) * elemH;
        labElemW = elemW * (labelWidthRatio - inPad);
        labElemH = elemH;
        % position and size for GUI element
        ctrlElemX = elemPosX + elemW * (labelWidthRatio + inPad);
        ctrlElemW = elemW * (1 - labelWidthRatio - inPad);
        ctrlElemY = elemPosY;
        ctrlElemH = UISize(1) * elemH + (UISize(1) - 1) * pad;
        
    end;
    
    % create the label
    this.GUI.handles.an.paramPanElems.([id '_label']) = uicontrol(UICommons.lab{:}, 'String', label, ...
        'Position', [labElemX labElemY labElemW labElemH], 'ToolTipString', tooltip, ... 'BackgroundColor', 'red', ...
        'Tag', sprintf('ANParam%s', id), 'FontSize', this.GUI.pos(4) / (90 - 3 * nRows + 0.1 * numel(label)));
    
    % process the different UI types
    switch UIType;
        
        % text controls
        case 'text';            
            % get the value from the storage variable
            stringValue = this.an.(categ).(id);            
            % if the value is not text and its an array
            if numel(stringValue) > 1 && ~strcmp(valueType, 'text') && ~strcmp(valueType, 'cellArray');
                % display as an array between brackets:
                % add semi colon at each line end
                stringValue = [ num2str(stringValue), repmat(';',size(stringValue, 1), 1)];
                % reshape as a single line
                stringValue = reshape(stringValue', 1, numel(stringValue));
                % replace all spaces by single space
                stringValue = regexprep(stringValue, '\s+', ' ');
                % remove all starting spaces
                stringValue = regexprep(stringValue, '^\s', '');
                stringValue = regexprep(stringValue, '; ', ';');
                % remove all empty spaces and replace them by commas
                stringValue = ['[', regexprep(stringValue, '\s+', ','), ']'];
                % clean up: remove last semi colon
                stringValue = regexprep(stringValue, ';\]$', ']');
                % clean up: remove starting comas
                stringValue = regexprep(stringValue, '[\[;]$', ']');
                % clean up: add space after each colon or semi colon
                stringValue = regexprep(stringValue, '([,;])', '$1 ');
                
            % if the value is a text, keep it as a string so do nothing
            elseif numel(stringValue) > 1 && strcmp(valueType, 'text');  
                
            % if the value is a text, keep it as a cell array string so do nothing
            elseif iscell(stringValue) && strcmp(valueType, 'cellArray');  
                stringValue = ['{ ', regexprep(sprintf('%s, ', stringValue{:}), ', $', '') ' }'];
            % otherwise the value is just a number
            else
                stringValue = num2str(stringValue);
            end;
            % leave value empty
            value = [];
            
        % drop down menu elements  
        case 'dropdown';
            % if the value from the storage variable is empty
            if isempty(this.an.(categ).(id));
                value = 1; % select the first item                
            % otherwise if there is a value in the storage variable
            else
                % get the values to select
                value = find(strcmp(valueType, this.an.(categ).(id)));
            end;
            % use a string the cell-array from the configuration
            stringValue = valueType;
            
        % list elements  
        case 'list';
            
            % get the stored variable
            storedVariable = this.an.(categ).(id);
            % if the value from the storage variable is empty
            if isempty(storedVariable);
                value = []; % select nothing                
            % otherwise if there is a value in the storage variable
            else
                % make sure the stored variable is a cell
                if ~iscell(storedVariable); storedVariable = { storedVariable }; end;
                % get the values to select
                value = find(arrayfun(@(i)ismember(valueType{i}, storedVariable), 1 : numel(valueType)));
            end;
            % use a string the cell-array from the configuration
            stringValue = valueType;
            
    end; % end of GUI type switch
    
            
    % create the GUI element
    this.GUI.handles.an.paramPanElems.(id) = uicontrol(UICommons.(UIType){:}, ...
        'String', stringValue, 'Value', value, 'Tag', sprintf('ANParam%s', id), ...
        'Position', [ctrlElemX ctrlElemY ctrlElemW ctrlElemH], 'ToolTipString', tooltip, ...
        'FontSize', this.GUI.pos(4) / (95 - 3 * nRows));

end;

% refresh the GUI
drawnow();

% only show the parameter panel if there are some controls to display
set(this.GUI.handles.an.paramPan, 'Visible', iff(nUICtrl > 0, 'on', 'off'));

end