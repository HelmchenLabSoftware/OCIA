%% #OCIA:AN:ANGetCaDataRows
function selRows = ANGetCaDataRows(this, selRows)

% get the rows that do not contain calcium data
emptyRows = cellfun(@isempty, this.data.img.caTraces(cell2mat(this.an.table(selRows, 11))));
% if there are some rows with no calcium data
if any(emptyRows);
    selRows(emptyRows) = []; % remove those rows from the selected
    set(this.GUI.handles.an.rowList, 'Value', find(~emptyRows)); % update the selecter
    ANShowHideMessage(this, 1, 'Some selected runs do not have calcium data.'); % show a warning message
    pause(2);
end;

end
