%% #OCIA:AN:ANGetCachedData
function cachedData = ANGetCachedData(this, modeName, hashParamStruct)

% get the "hash" ID of the parameter structure
selectedRowsHashID = matlab.lang.makeValidName(DataHash(hashParamStruct));
% store this key as being the last one used
this.an.(modeName).dataHash.lastHashID = selectedRowsHashID;

% if the data is already in memory, just fetch it
if isfield(this.an.(modeName).dataHash, selectedRowsHashID);
    cachedData = this.an.(modeName).dataHash.(selectedRowsHashID);
    
% otherwise return an empty structure
else
    cachedData = [];
end;

end