%% #OCIA:AN:ANGetFiltCaTraces
function filtCaTraces = ANGetFiltCaTraces(this, selRows, selROIs)

    % store the "'UniformOutput' false" argument pair in a more convenient form
    UF = { 'UniformOutput', false };
        
    % get the DataWatcher table's index of all rows currently analysed
    allDWRows = cell2mat(this.an.table(:, 11));

    % get the total number of runs analysed
    nTotRuns = numel(allDWRows);
    % get which ROISet each run belongs to, using the ROISet ID stored in the DataWatcher's table
    runsROISetIndex = str2double(regexprep(this.dw.table(allDWRows, 16), '^RS(\d+) .+$', '$1'));

    % get all the unique ROISets for the data set currently analysed
    ROISets = ANGetROISetForRow(this, allDWRows);
    % if first cell is not a cell, it means we have a single ROISet so transform it to a cell-array
    if ~iscell(ROISets{1}); ROISets = { ROISets }; end;
    % extract the number of ROIs for each ROISet
    nROIsForEachROISet = cell2mat(cellfun(@(ROISet) size(ROISet, 1), ROISets, UF{:}));
    % get the total number of ROIs
    nTotROIs = sum(nROIsForEachROISet);
        
    % if the raw calcium traces matrix does not exist yet or is empty or only NaNs, create it
    if ~isfield('rawCaTraces', this.data.an) || isempty(this.data.an.rawCaTraces) ...
            || ~any(~isnan(this.data.an.rawCaTraces(:)));

        % get the number of frames for each run
        nFramesEachRun = arrayfun(@(iRun)size(this.data.img.caTraces{allDWRows(iRun)}, 2), 1 : nTotRuns, UF{:});
        % get the maximum number of frames of the currently analysed data set
        nMaxFrames = max(cell2mat(nFramesEachRun));
        
        % (re-)create the raw data matrix as a nRuns x nROIs x nFrames matrix with NaNs where there is no data
        this.data.an.rawCaTraces = nan(nTotRuns, nTotROIs, nMaxFrames);
        
        % store the ROI names
        this.data.an.ROINames = cell(nTotROIs, 1);
        for iROISet = 1 : numel(nROIsForEachROISet);
            iROIStart = sum(nROIsForEachROISet(1 : iROISet - 1)) + 1; % define the ROI indexing's start
            iROIEnd = iROIStart + nROIsForEachROISet(iROISet) - 1; % define the ROI indexing's end
            this.data.an.ROINames(iROIStart : iROIEnd) = ROISets{iROISet}(:, 1);
        end;

        % fill-in the raw data for each run and store the run names
        this.data.an.runNames = cell(nTotRuns, 1);
        for iRun = 1 : nTotRuns;
            iROISetForRun = runsROISetIndex(iRun); % get the ROISet index of this run
            iROIStart = sum(nROIsForEachROISet(1 : iROISetForRun - 1)) + 1; % define the ROI indexing's start
            iROIEnd = iROIStart + nROIsForEachROISet(iROISetForRun) - 1; % define the ROI indexing's end
            % store the raw calcium traces
            this.data.an.rawCaTraces(iRun, iROIStart : iROIEnd, 1 : nFramesEachRun{iRun}) ...
                = this.data.img.caTraces{allDWRows(iRun)};
            
            % store the run names
            this.data.an.runNames{iRun} = regexprep(regexprep(sprintf('%s:%s', ...
                this.dw.table{allDWRows(iRun), 2 : 3}), '_', ''), ':', '_');
        end;
    end;
    
    % get the selected calcium traces
    rawCaTraces = this.data.an.rawCaTraces(selRows, :, :);
    ROINames = this.data.an.ROINames;
    runNames = this.data.an.runNames(selRows);
    
    % remove empty/NaN ROIs
    emptyROIs = false(nTotROIs, 1);
    for iROI = 1 : nTotROIs;
        tracesForROI = this.data.an.rawCaTraces(selRows, iROI, :);
        emptyROIs(iROI) = ~any(~isnan(tracesForROI(:)));
    end;
    rawCaTraces(:, emptyROIs, :) = [];
    ROINames(emptyROIs) = [];

end