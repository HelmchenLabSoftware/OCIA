%% #BEGetTrialInfo
function trialInfo = BEGetTrialInfo(this, iTrial)

% default is empty
freq = ''; isTargetOrNTones = ''; resp = ''; respTime = ''; corr = ''; rew = '';

if iTrial > 0;
    freq = round(this.be.config.tone.freqs(this.be.stims(iTrial)) / 1000);
    
    % no goStim = no behavior
    if ~isempty(this.be.config.tone.goStim);
        
        % oddball discrimination
        if isfield(this.be.config.tone, 'oddProba') && this.be.config.tone.oddProba > 0;
            
            isTargetOrNTones = double(this.be.stims(iTrial) ~= this.be.odds(iTrial) && this.be.config.tone.goStim);
            
        % frequency/cloud of tone discrimination
        else
            
            isTargetOrNTones = double(ismember(this.be.stims(iTrial), this.be.config.tone.goStim));
            
        end;
    
    elseif strcmp(this.be.taskType, 'cotOdd') && numel(this.be.nTones) > 1;
        
        % fill with number of tones
        isTargetOrNTones = this.be.nTones(iTrial);
        
    end;

    if ~isempty(this.be.config.tone.goStim) && isfield(this.be, 'resps') && ~isnan(this.be.resps(iTrial));
        resp = this.be.resps(iTrial);
        if ~isnan(this.be.respDelays(iTrial));
            respTime = sprintf('%.2f', this.be.respDelays(iTrial));
        else
            respTime = '   -  ';
        end;
        corr = double((isTargetOrNTones && resp) || (~isTargetOrNTones && ~resp));
        if corr; corr = ' true '; else corr = ' false'; end;
        if ~isnan(this.be.giveRewards(iTrial)) && this.be.giveRewards(iTrial);
            rew = ' true ';
        else
            rew = ' false';
        end;
        if this.be.resps(iTrial); resp = ' true '; else resp = ' false'; end;
    end;
    if isTargetOrNTones; isTargetOrNTones = ' true '; else isTargetOrNTones = ' false'; end;
    
% no trial number
else
    
    iTrial = '';
    
end;

trialInfo = {iTrial, freq, isTargetOrNTones, resp, respTime, corr, rew};

end

