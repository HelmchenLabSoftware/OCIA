%% #OCIA:RD:RDUpdateGUI
function RDUpdateGUI(this, varargin)


RDUpdateGUITic = tic; % for performance timing purposes
o('#RDUpdateGUI()', 4, this.verb);

% get axe limits
axeLims = [get(this.GUI.handles.rd.axe, 'XLim'); get(this.GUI.handles.rd.axe, 'YLim')];

% if ROIs storing structure has 6 columns
if size(this.rd.ROIs, 2) >= 6;
    
    % make sure no cell is empty
    this.rd.ROIs(cellfun(@isempty, this.rd.ROIs(:, 6)), 6) = {false};

    % if no ROI is marked to be updated, update all of them
    if~any(cell2mat(this.rd.ROIs(:, 6)));
        this.rd.ROIs(:, 6) = num2cell(true(size(this.rd.ROIs(:, 6), 1), 1));
    end;
end;

% update the ROIs
ROIUpdateTic = tic; % for performance timing purposes
for iROI = 1 : this.rd.nROIs;

    if size(this.rd.ROIs, 2) >= 6 && ~this.rd.ROIs{iROI, 6};
        o('  #RDUpdateGUI(): skipping ROI%03d.', iROI, 4, this.verb);
        continue;
    end;
    this.rd.ROIs{iROI, 6} = false; % remove the modified tag

    this.rd.ROIs{iROI, 3} = this.rd.ROIs{iROI, 1}.getPosition(); % update the position
    ROIPos = this.rd.ROIs{iROI, 3};
    o('  #RDUpdateGUI(): ROI%03d position: [%.2f, %.2f, %.2f, %.2f]', iROI, ROIPos, 4, this.verb);

    switch class(this.rd.ROIs{iROI, 1});
        case {'impoly', 'imfreehand'};
            meanROIPos = mean(ROIPos, 1);
        otherwise;
            meanROIPos = ROIPos(1 : 2) + 0.5 * ROIPos(3 : 4);
    end

    xOffset = 3 / this.GUI.rd.zoomLevel;
    if size(this.rd.ROIs, 2) > 4 && ~isempty(this.rd.ROIs{iROI, 5}) && ishandle(this.rd.ROIs{iROI, 5});
        delete(this.rd.ROIs{iROI, 5}); % remove the text handles
    end;

    % check that this ROI is not outside of the image
    if meanROIPos(1) > axeLims(1, 1) && meanROIPos(1) < axeLims(1, 2) ...
            && meanROIPos(2) > axeLims(2, 1) && meanROIPos(2) < axeLims(2, 2);
         
        % choose the color of the ID
        col = 'red';
        if strcmp(get(this.rd.ROIs{iROI, 1}, 'Visible'), 'off') && all(this.rd.ROIs{iROI, 1}.getColor() == [1 0 0]);
            col = 'blue';
        end;
        
        % choose the visibility of the ID
        visib = 'off';
        if get(this.GUI.handles.rd.showHideROIsLab, 'Value'); visib = 'on'; end;
        
        % add the ROIID as text label and store the handle
        this.rd.ROIs{iROI, 5} = text(meanROIPos(1) - xOffset, meanROIPos(2), this.rd.ROIs{iROI, 2}, ...
            'Color', col, 'FontWeight', 'bold', 'Visible', visib, ...
            'Tag', sprintf('ROIID_%s', this.rd.ROIs{iROI, 2}), 'Parent', this.GUI.handles.rd.axe);
    end;
end;
o('#RDUpdateGUI(): updated text handles (%5.3f sec).', toc(ROIUpdateTic), 3, this.verb);

% update the mask
updateMaskTic = tic; % for performance timing purposes
RDUpdateMask(this);
o('#RDUpdateGUI(): updated mask (%5.3f sec).', toc(updateMaskTic), 3, this.verb);

% update the ROI selection list
if ~isempty(this.rd.ROIs);
%     selROIs = get(this.GUI.handles.rd.selROIsList, 'Value');
%     ROINames = get(this.GUI.handles.rd.selROIsList, 'String');
%     selROIs = find(ismember(ROINames(1 : end), arrayfun(@(x)sprintf('%03d', x), selROIs, 'UniformOutput', false)));
    set(this.GUI.handles.rd.selROIsList, 'String', this.rd.ROIs(:, 2));
else
    set(this.GUI.handles.rd.selROIsList, 'String', {}, 'Value', []);
end;

% if numel(varargin) == 0 || (numel(varargin) && varargin{1} ~= 1);
%     % clear the selection
%     set(this.GUI.handles.rd.selROISetter, 'String', '');
%     RDSelROI(this, this.GUI.handles.rd.selROISetterClear);
% end;

o('#RDUpdateGUI(): done (%5.3f sec).', toc(RDUpdateGUITic), 3, this.verb);

end
