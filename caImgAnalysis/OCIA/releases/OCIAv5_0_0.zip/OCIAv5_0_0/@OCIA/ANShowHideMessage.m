%% #OCIA:AN:ANShowHideMessage
function ANShowHideMessage(this, doShowMessage, varargin)

if doShowMessage;
    txt = 'Loading ...';
    if nargin > 2; txt = varargin{1}; end;
    % if there is a GUI
    if isGUI(this);
        % show the message and hide the axes
        set(this.GUI.handles.an.axe, 'Visible', 'off');
        set(this.GUI.handles.an.message, 'String', txt, 'Visible', 'on');
    % if there is no GUI, only set the string
    else
        set(this.GUI.handles.an.message, 'String', txt);
    end;
    showMessage(this, sprintf('Analyser: %s', txt));
else
    txt = 'Loading done.';
    if nargin > 2; txt = varargin{1}; end;
    % if there is a GUI, show the axes
    if isGUI(this);
        set(this.GUI.handles.an.message, 'String', txt, 'Visible', 'off');
        if ishandle(this.GUI.handles.an.axe); set(this.GUI.handles.an.axe, 'Visible', 'on'); end;
    % if there is no GUI, only set the string
    else
        set(this.GUI.handles.an.message, 'String', txt);
    end;
    showMessage(this, sprintf('Analyser: %s', txt));
end;

pause(0.1); % required to let the GUI update itself

end
