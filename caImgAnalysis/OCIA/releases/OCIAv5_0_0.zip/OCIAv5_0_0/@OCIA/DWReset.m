%% #OCIA:DWReset
function DWReset(this, ~, ~)
    
    % get the selected data types from the GUI
    selectedDataTypes = this.dw.dataConfig.id(get(this.GUI.handles.dw.SLROptDataList, 'Value'));
    
    % if none selected, delete all
    if isempty(selectedDataTypes);
        selectedDataTypes = 'all';
        
    % otherwise create a string list from sleection
    else
        selectedDataTypes = sprintf('%s,', selectedDataTypes{:});
    end;

    % flush requested data in requested rows
    DWFlushData(this, this.dw.selectedTableRows, true, selectedDataTypes);
    
end
