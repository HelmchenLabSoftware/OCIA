%% #OCIA:DW:DWMatchBehavTrialsToImagingData
function DWMatchBehavTrialsToImagingData(this)
% match the behavior trials and the data files

% get the list of all days
uniqueDays = get(this, 'day');
uniqueDays(cellfun(@isempty, uniqueDays)) = [];
uniqueDays = unique(uniqueDays);
    
% get the list of all spots
uniqueSpots = get(this, 'spot');
uniqueSpots(cellfun(@isempty, uniqueSpots)) = [];
uniqueSpots = unique(uniqueSpots);

% go through each day
for iDay = 1 : numel(uniqueDays);    
    dayID = uniqueDays{iDay}; % get the current day
    
    % go through spot by spot
    for iSpot = 1 : numel(uniqueSpots);
        spotID = uniqueSpots{iSpot}; % get the current spot
        
        % get the imaging rows indexes for this day and this spot
        imagingRows = DWFilterTable(this, ...
            sprintf('day = %s AND spot = %s AND rowType = Imaging data AND runType !~= \\w+', dayID, spotID));
        imagingRowIndexes = str2double(get(this, 'all', 'rowNum', imagingRows));
        
        % if no imaging data, skip
        if isempty(imagingRowIndexes) || any(isnan(imagingRowIndexes));
            continue;        
        % if only one row found, label it as session 1
        elseif numel(imagingRowIndexes) == 1;
            sessIDs = 1;            
        % if several rows, cluster them by session using time
        else
            sessIDs = clusterRowsBySession(this, imagingRowIndexes);
        end;
        
        % go through session by session
        for iSess = 1 : size(unique(sessIDs), 1);
            % get the indexes of this session
            sessRowIndexes = imagingRowIndexes(sessIDs == iSess);
            % match the behavior trials
            DWMatchBehavTrialsToImagingDataForSession(this, dayID, spotID, iSess, sessRowIndexes);
        end;
    end;
end;

end

%% - #clusterRowsBySession
function sessIDs = clusterRowsBySession(this, rowNums)

% do not process if not at least 2 rows
if numel(rowNums) < 2;
    sessIDs = repmat('1', numel(rowNums), 1);
    return;
end;
    
% separate rows into morning and afternoon sessions
nUnknRows = size(rowNums, 1);
dateNums = zeros(nUnknRows, 1);
for iUnknRow = 1 : nUnknRows;
    dateAndTime = get(this, rowNums(iUnknRow), { 'day', 'time' });
    dateNums(iUnknRow) = datenum(sprintf('%s__%s', dateAndTime{:}), 'yyyy_mm_dd__HH_MM_SS');
end;
sessIDs = clusterdata(dateNums, 'maxclust', 2);
nearbySessDiffInHours = (dn2unix(dateNums(find(sessIDs == sessIDs(end), 1, 'first'))) ...
    - dn2unix(dateNums(find(sessIDs == sessIDs(1), 1, 'last')))) / 1000 / 60 / 60;
% if sessions are too close, it means that it was a single session with a missing trial/interruption
if nearbySessDiffInHours < 3; % minimum 3 hours between sessions
    sessIDs = clusterdata(dateNums, 'maxclust', 1);
end;

end
