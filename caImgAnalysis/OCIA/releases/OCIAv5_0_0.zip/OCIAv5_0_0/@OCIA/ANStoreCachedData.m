%% #OCIA:AN:ANStoreCachedData
function ANStoreCachedData(this, modeName, hashParamStruct, cachedData)

% get the "hash" ID of the parameter structure
selectedRowsHashID = matlab.lang.makeValidName(DataHash(hashParamStruct));
% store this key as being the last one used
this.an.(modeName).dataHash.lastHashID = selectedRowsHashID;
% store the cached data
this.an.(modeName).dataHash.(selectedRowsHashID) = cachedData;

end