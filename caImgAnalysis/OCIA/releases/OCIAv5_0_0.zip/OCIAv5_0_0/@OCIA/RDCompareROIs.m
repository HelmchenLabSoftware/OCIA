%% #OCIA:RD:RDCompareROIs
function RDCompareROIs(this, ~, ~)

    % do not process if not in RDCompare mode
    if ~get(this.GUI.handles.rd.refROISet, 'Value');
        % clear the annotations
        try
            childHands = get(this.GUI.handles.rd.axe, 'Children');
            childTags = get(childHands, 'Tag');
            delete(childHands(strcmp('ROICompareLine', childTags)));
            delete(childHands(strcmp('ROICompareText', childTags)));
            delete(childHands(strcmp('ROICompareScatter', childTags)));
        catch e; %#ok<NASGU>        
        end;
        return;
    end;

    selRows = get(this.GUI.handles.rd.tableList, 'Value');
    nSelRows = numel(selRows);
    if nSelRows == 1;
        showWarning(this, 'OCIA:RD:RDCompareROIs:BadRowNumber', 'Cannot compare a single ROISet!');
        set(this.GUI.handles.rd.refROISet, 'Value', 0);
        set(this.GUI.handles.rd.refROISetASetter, 'Value', 1);
        set(this.GUI.handles.rd.refROISetBSetter, 'Value', 1);
        return;
    end;
    
    % get which ROISet should be used as reference
    refTargRowNums = cellfun(@str2double, get(this.GUI.handles.rd.refROISetASetter, 'String'))';
    iRef = refTargRowNums(get(this.GUI.handles.rd.refROISetASetter, 'Value'));
    if isempty(iRef);
        showWarning(this, 'OCIA:RD:RDCompareROIs:NoRefSelected', sprintf('Bad reference ROISet specified (%d).', iRef));
        set(this.GUI.handles.rd.refROISet, 'Value', 0);
        set(this.GUI.handles.rd.refROISetASetter, 'Value', 1);
        set(this.GUI.handles.rd.refROISetBSetter, 'Value', 1);
        return;
    end;
    
    % get reference's rowID
    iDWRowRef = this.rd.selectedTableRows(iRef);
    refRowID = regexprep(regexprep(sprintf('%s:%s', this.dw.table{iDWRowRef, 2 : 3}), '_', ''), ':', '_');
    % get the current reference's ROISet index
    iROISetRef = str2double(regexprep(this.dw.table{this.rd.selectedTableRows(iRef), 8}, 'RS', ''));
    
    % get which ROISets should be used as targets
    iTargs = refTargRowNums(get(this.GUI.handles.rd.refROISetBSetter, 'Value'));
    iTargs(iTargs == iRef) = []; % remove reference from selection
    if isempty(iTargs);
        
        % display reference image if possible and needed
        if ~isempty(this.rd.rc.refImgs) && numel(this.rd.rc.refImgs) >= iROISetRef ...
                && ~isempty(this.rd.rc.refImgs{iROISetRef}) ...
                && (isempty(this.rd.rc.displayedRef) || this.rd.rc.displayedRef ~= iROISetRef);
            
            showMessage(this, sprintf('Comparing %d ROISets, image shown: %s (%d).', ...
                nSelRows, refRowID, iRef), 'yellow');
        
            img = this.rd.rc.refImgs{iROISetRef};
            this.GUI.rd.img = img;
            set(this.GUI.handles.rd.img, 'CData', img);
            set(this.GUI.handles.rd.axe, 'XLim', [0 size(img, 1)], 'YLim', [0 size(img, 2)]);
            this.rd.rc.displayedRef = iROISetRef;
            
        else
            showWarning(this, 'OCIA:RD:RDCompareROIs:NoTargSelected', 'Bad target ROISet specified.');
        end;
        
        return;
        
    end;
    
    % set back right selection, with the eventual reference excluded
    set(this.GUI.handles.rd.refROISetBSetter, 'Value', find(ismember(refTargRowNums, iTargs)));
    
%     showMessage(this, sprintf('Comparing %d ROISets, reference: %s (%d)...', nSelRows, refRowID, iRef), 'yellow');
        
    %% load ROIs and reference images
    if isempty(this.rd.rc.ROISets) || numel(this.rd.rc.ROISets) < max(selRows) ...
            || isempty(this.rd.rc.ROISetIDs) || any(~ismember(selRows, this.rd.rc.ROISetIDs));
        
        showMessage(this, 'Loading ROISets...', 'yellow');
        
        ROISets = cell(max(selRows), 1);
        refImgs = cell(max(selRows), 1);
        ROINamesUnion = {};
        RDClearROIs(this);
        % go through each selected row
        for iRow = 1 : max(selRows);
            
            if ~ismember(iRow, selRows); continue; end;
            
            % get ROI set
            iROISet = str2double(regexprep(this.dw.table{this.rd.selectedTableRows(iRow), 8}, 'RS', ''));
            ROISets{iROISet} = this.data.img.ROISets{iROISet, 1};
            ROISets{iROISet}(strcmp(ROISets{iROISet}(:, 1), 'NPil'), :) = []; % remove NPil
            
            % get reference image and enhance it
            refImgs{iROISet} = this.data.img.ROISets{iROISet, 3}{this.an.img.chanVect(1)};
            refImgs{iROISet} = PseudoFlatfieldCorrect(refImgs{iROISet});
            minAdj = get(this.GUI.handles.rd.imAdjMinSetter, 'Value');
            maxAdj = get(this.GUI.handles.rd.imAdjMaxSetter, 'Value');
            refImgs{iROISet} = imadjust(refImgs{iROISet}, [minAdj, maxAdj]);
            refImgs{iROISet} = repmat(refImgs{iROISet}, [1 1 3]);
            
            % get the union of all names
            ROINamesUnion = [ROINamesUnion; ROISets{iROISet}(:, 1)]; %#ok<AGROW>
        end;

        % store so that there is no need to reload
        this.rd.rc.ROISetIDs = selRows;
        this.rd.rc.ROISets = ROISets;
        this.rd.rc.refImgs = refImgs;
        this.rd.rc.ROINamesUnion = ROINamesUnion;
        
    else

        % reload information
        ROISets = this.rd.rc.ROISets;
        refImgs = this.rd.rc.refImgs;
        ROINamesUnion = this.rd.rc.ROINamesUnion; %#ok<NASGU>
        
    end;
        
    % display reference image if needed
    if isempty(this.rd.rc.displayedRef) || this.rd.rc.displayedRef ~= iROISetRef;
        img = refImgs{iROISetRef};
        this.GUI.rd.img = img;
        set(this.GUI.handles.rd.img, 'CData', img);
        set(this.GUI.handles.rd.axe, 'XLim', [0 size(img, 1)], 'YLim', [0 size(img, 2)]);
        
        this.rd.rc.displayedRef = iROISetRef;
    end;
    
    % clear the annotations
    try
        childHands = get(this.GUI.handles.rd.axe, 'Children');
        childTags = get(childHands, 'Tag');
        delete(childHands(strcmp('ROICompareLine', childTags)));
        delete(childHands(strcmp('ROICompareText', childTags)));
        delete(childHands(strcmp('ROICompareScatter', childTags)));
    catch e; %#ok<NASGU>        
    end;
    
    % get the drawing axe
    axeH = this.GUI.handles.rd.axe;
    
    %% calculate ROI positions and compare ROISets
    ROIsAOnly = cell(1, max(selRows)); % only in reference
    ROIsBOnly = cell(1, max(selRows)); % only in target
    ROIsMM = cell(1, max(selRows)); % in both but with a big position difference    

    args = {'FontSize', 10, 'HorizontalAlignment', 'center', 'Parent', axeH, 'Tag', 'ROICompareText'};

    colAB = [0 1 0];
%     colABLine = [];
    colABLine = [0 1 0];
    colABMM = [1 0 0];
    colA = [1 0.2 0.5];
%     colA = [];
    colB = [1 1 0];
    
    % go through each ROISet
    for iTarg = 1 : max(selRows);
        
        % skip comparisons with not selected targets
        if ~ismember(iTarg, iTargs); continue; end;
        
        % get target's rowID
        iDWRowTarg = this.rd.selectedTableRows(iTarg);
        targRowID = regexprep(regexprep(sprintf('%s:%s', this.dw.table{iDWRowTarg, 2 : 3}), '_', ''), ':', '_');
        
        % get the ROISet number of the target row
        iROISetTarg = str2double(regexprep(this.dw.table{iDWRowTarg, 8}, 'RS', ''));

        showMessage(this, sprintf('Comparing %s (%d) to %s (%d) ...', ...
            refRowID, iRef, targRowID, iTarg), 'yellow');
        
        % get the ROISets to compare, their names and the combined set of their names
        ROISetA = ROISets{iROISetRef};
        ROISetB = ROISets{iROISetTarg};
        ROINamesA = unique(ROISetA(:, 1));
        ROINamesB = unique(ROISetB(:, 1));
        ROINamesAB = unique([ROINamesA; ROINamesB]);
        nROIsAB = size(ROINamesAB, 1);

        % calculate the position/angles diferences
        posDiffs = nan(nROIsAB, 2);
        
        % go through each ROI of the combined set
        for iROI = 1 : nROIsAB;

            iROIA = 0; iROIB = 0;
            
            % if member of ROISet A, calculate position
            if ismember(ROINamesAB{iROI}, ROINamesA)
                iROIA = find(strcmp(ROINamesAB{iROI}, ROINamesA));
                % get ROI's position in the reference ROISet
                ROIMaskA = ROISetA{strcmp(ROINamesAB{iROI}, ROINamesA), 2}';
                [ROIPosYA, ROIPosXA] = ind2sub(size(ROIMaskA), find(ROIMaskA));
                ROIPosA = [mean(ROIPosYA), mean(ROIPosXA)];
                ROISetA{iROIA, 3} = ROIPosA; % store position
            end;
            
            % if member of ROISet B, calculate position
            if ismember(ROINamesAB{iROI}, ROINamesB)
                iROIB = find(strcmp(ROINamesAB{iROI}, ROINamesB));
                % get ROI's position in the target ROISet
                ROIMaskB = ROISetB{strcmp(ROINamesAB{iROI}, ROINamesB), 2}';
                [ROIPosXB, ROIPosYB] = ind2sub(size(ROIMaskB), find(ROIMaskB));
                ROIPosB = [mean(ROIPosXB), mean(ROIPosYB)];
                ROISetB{iROIB, 3} = ROIPosB; % store position
            end;
            
            % if a ROI is member of both sets, calculate position differences and store it
            if iROIA && iROIB;
                posDiffs(iROI, :) = ROIPosB - ROIPosA;
            end;
        end;

        % calculate position threshold as the biggest of either 1.5 SD of position or 10 pixels
        meanPosDiff = nanmean(posDiffs);
        posDiffThresh = nanmax(3 * nanstd(posDiffs), 20);
        
        % get the ROIs that have a unusual angle difference
        badPosDiffsX = find(abs(posDiffs(:, 1) - meanPosDiff(:, 1)) > posDiffThresh(:, 1));
        badPosDiffsY = find(abs(posDiffs(:, 2) - meanPosDiff(:, 2)) > posDiffThresh(:, 2));
        badPosDiffs = unique([badPosDiffsX; badPosDiffsY]);
        badROINames = '';
        for iROILoop = 1 : numel(badPosDiffs);
            iROI = badPosDiffs(iROILoop);
            badROINames = sprintf('%s, %s [%.1f, %.1f]', badROINames, ROINamesAB{iROI}, ...
                posDiffs(iROI, 1), posDiffs(iROI, 2));
        end;
        badROINames = regexprep(badROINames, '^, ', '');
        
        if ~isempty(badROINames);
            showMessage(this, sprintf('Found badly positioned ROIs with target %s (%d): %s', ...
                targRowID, iTarg, badROINames));
        end;
        
        hold(axeH, 'on');
        
        for iROI = 1 : nROIsAB;

            iROIA = 0; iROIB = 0;

            if ismember(ROINamesAB{iROI}, ROINamesA)
                iROIA = find(strcmp(ROINamesAB{iROI}, ROINamesA));
                ROIPosA = ROISetA{iROIA, 3};
            end;
            if ismember(ROINamesAB{iROI}, ROINamesB)
                iROIB = find(strcmp(ROINamesAB{iROI}, ROINamesB));
                ROIPosB = ROISetB{iROIB, 3};
            end;
            
            % in both sets but with a position mismatch
            if iROIA && iROIB && ismember(iROI, badPosDiffs);
                
                ROIsMM{1, iTarg}{end + 1} = ROINamesAB{iROI};
                if ~isempty(colABMM);
                    text(ROIPosA(1), ROIPosA(2), ROINamesA{iROIA}, 'Color', colABMM, args{:});
                    line([ROIPosA(1) ROIPosB(1)], [ROIPosA(2) ROIPosB(2)], 'Color', colABMM, 'LineStyle', ':', ...
                        'Tag', 'ROICompareLine', 'Parent', axeH);
                end;
                
            % in both sets but with no position mismatch
            elseif iROIA && iROIB && ~ismember(iROI, badPosDiffs) && ~isempty(colAB);
                
                text(ROIPosA(1), ROIPosA(2), ROINamesA{iROIA}, 'Color', colAB, args{:});
                if ~isempty(colABLine);
                    line([ROIPosA(1) ROIPosB(1)], [ROIPosA(2) ROIPosB(2)], 'Color', colABLine, 'LineStyle', ':', ...
                        'Tag', 'ROICompareLine', 'Parent', axeH);
                end;
              
            % only in reference  
            elseif iROIA && ~isempty(colA);

                ROIsAOnly{1, iTarg}{end + 1} = ROINamesAB{iROI};
                posOnB = ROIPosA + meanPosDiff;
                text(ROIPosA(1), ROIPosA(2), ROINamesA{iROIA}, 'Color', colA, args{:});
                line([ROIPosA(1) posOnB(1)], [ROIPosA(2) posOnB(2)], 'Color', colA, 'LineStyle', ':', ...
                    'Tag', 'ROICompareLine', 'Parent', axeH);
%                 scatter(posOnB(1), posOnB(2), 155, colA, 'Marker', 'x', 'LineWidth', 2, ...
%                     'Tag', 'ROICompareScatter', 'Parent', axeH);
                
            % only in target
            elseif iROIB && ~isempty(colB);

                ROIsBOnly{1, iTarg}{end + 1} = ROINamesAB{iROI};
                posOnA = ROIPosB - meanPosDiff;
                text(posOnA(1), posOnA(2), ROINamesB{iROIB}, 'Color', colB, args{:});
                line([ROIPosB(1) posOnA(1)], [ROIPosB(2) posOnA(2)], 'Color', colB, 'LineStyle', ':', ...
                    'Tag', 'ROICompareLine', 'Parent', axeH);
%                 scatter(posOnA(1), posOnA(2), 155, colB, 'Marker', 'x', 'LineWidth', 2, ...
%                     'Tag', 'ROICompareScatter', 'Parent', axeH);
                
            end;
        end;
    end;
    
    showMessage(this, 'Comparing ROISets done.');
    
end
