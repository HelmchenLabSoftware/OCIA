classdef OCIA < handle
% #OCIA:MAIN:OCIA - Online Calcium Imaging Assistant
%
%       this = OCIA()
%       this = OCIA(configName)
%       this = OCIA(configName, DWFilt)
%
% Returns an OCIA object 'this', using the configuration file specified by 'configName' with the syntax
%   "OCIA_config_[configName].m". If no configuration is specified, "OCIA_config_default.m" is used. Starting filters
%   for the DataWatcher can be specified using the 'DWFilt' string or cell-array of strings.

%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       % Originally created on           08 / 10 / 2013 %
%       % Modified to v2.0 on             20 / 12 / 2013 %
%       % Modified to v3.0 on             21 / 02 / 2014 %
%       % Modified to v4.0 on             19 / 06 / 2014 %
%       % Modified to v5.0 on             15 / 09 / 2014 %
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 2013-2014 - Copyleft and programmed by Balazs Laurenczy (blaurenczy_at_gmail.com)


%% TODO list
%{

CURRENT
 - add the possibility to have a type of folder in multiple locations (e.g. parent of imgData could be spot OR day)
 - ROI mass moving/rotating GUI + implement
 - frame jitter, motion correction and motion detection should be independent of a ROISet


- General
 -- add icons to buttons for easier recognition
 -- pre-processing GUI: uipanel with options for nFrameSkip(default=0)/fShift/fJitt/moCorr/moDet
    options as checkboxes, and a "pre-process rows" button (ANPreProcRows). DWLoad('prev') should do none
    of these corrections, except frameShift and frameSkip.
    Add a display fig checkbox linked to the doPlots of the pre-processing functions.
 -- save load modularity:
  --- make the GUI dynamic for the saving options, based on the data's field and configuration
  --- adapt the saving code so that it saves the right things at the right place
  --- fix the save/load/reset options
 -- check that flushdata works properly

- DataWatcher
 -- add a "delete rows" function (hides the unwanted rows from the DataWatcher), also useful for the imagingWatcher mode
 -- intrinsic imaging: access binary file content, show vessels tif files,
    eventually overlap them with expression image using stiching algorithm
 -- behavior movie: read the video with 'video2mat.m' and eventually match frames to trials
 -- small thumbnail of the currently selected row(s) also for other data types (behavior, intrinsic, behavMovie)
  --- requires frame grouping (� la imageJ ...)
 -- only load imaging data once from the DataWatcher's table and then re-use it for analysis and ROI drawing
 -- enable the "real" analysis pipeline support : load imaging data files (.bin)(HDF5?)
 -- implement GUI items/config file for analysis parameters
NO -- add a load metadata button to avoid re-processing all folders just for the metadata
NO -- make the loaded rows' background green to show the data is loaded
NO -- store where each behavior/data file was found and dont reload it if not necessary

- ImagingWatcher
 -- create a new imaging assistant mode or extend the data-watcher to help with online analysis of the imaging
  --- could be on a different computer/matlab session for lower CPU on imaging computer and
      eventually parallel computing for faster loading/processing
 -- features:
  --- loading last recorded data
  --- "quick" ROIDrawing (semi-auto)
  --- "quick" DRR extract
  --- bleaching quantifier
  --- previous days data and metadata (laser, depth, location, surface image, etc.)

- ROIDrawer
 -- modularity in ROISet saving location
 -- bug: remove old position callback in RDRenameROI
 -- channel selection for ROI drawing, gray scale image of one channel
 -- move all ROIs with small arrow GUI pushbuttons <- ^ ->
 -- implement an semi-automatic segmentation tool based on cell centers and ring/filled cell body detection
 -- cell identity labeling tool

- Analyser
 -- implement a feature of analysing whole day/whole mice with analysRow button and watchType of only day or only animal
 -- resizing of the whole panel bug, probably when saving (or plotting?) plots
 -- enable the "real" analysis pipeline support (load imaging data files (HDF5?))
 -- check for colorbar plot saving (resizing issue)
 -- check for time-consuming sem calculation problem
 -- add plots for several mice
 -- implement a bleaching quantifier over multiple runs
 -- fix the colorbar saving problem
 -- fix the colormap problem
 -- fix the analyser plotting ROISet mismatch/non-unique problem
 -- when loading data in 'full' mode that was already loaded in 'prev', skip re-loading of 'prev' frames

- Behavior
 -- check sound amplitude (SPL) *randomization*
 -- fix licking detection or switch to lick rate
 -- implement *alternative* detection system: lick rate
 -- introduce a configuration editor or GUI items for mainConf.mat elements
 -- save threshold and rewDur for each trial
 -- perf analysis: exclude first 3-10 trials + non-responsive regions
 -- auto-connect behavior box with COM port communication

- JointTracker
 -- add coordinates display on mouse move
 -- load X frames until memory is full and then just load frames on the fly while changing frames
 -- when doing the sliding average, remove the existing frames and store them in the temp and then put it back
 -- re-process on the fly the subsequent joints when placing a joint (when placing wrist, re-find the MCP)
 -- crop function
 -- image pre-processing not everywhere but defined by ROI
 -- iJoint and iJointType from selection listbox should not be single values but must be arrays (multiple joint
    manipulation)
 -- prediction reaffinement
  --- define an "area mask" for each joint (or each group of joints), using imfreehand, to constraint their position
  --- use angles and joint distances to constraint the position of the joints
  --- use field flow technique to predict where the joint will move
  --- use correlation dip to change bounding box size (with a minimal box size setting)
 -- improve debug plot display so that one can actually see what is going on (nJoints x nProcessSteps image with labeld axes)
 -- create a progress bar to show how far we are and how is each frame annotated (manual, semi-auto validated, semi-auto not yet checked, etc.)
 -- correlation frame-to-frame or frame-wise only on the bounding boxes
 -- base frames pre-processing for better computer and/or manual annotation
  --- subtract sliding window avg image
  --- flatfield
  --- contrast enhancement
 -- base frames pre-processing might also only be applied to parts of the frame (like the sliding average only on the
    lower part of the frame)
 -- post-hoc evaluation method to get which joints are misplaced, based on:
  --- interpolation of the data points from next and previous joint coordinate ('outlier' detection)
  --- skelton distances
  --- angle-change vs frame-to-frame correlation
 -- post-hoc refinement of the match using smaller bounding box
 -- computer vision algorithms / ideas
 
%}

%% properties
properties

    % verbosity: number telling how much output should be printed out. The higher the more verbose.
    verb = 2;
    % version number
    version = '5.0.0';
    
    % paths used by the OCIA
    path = struct();
    
    % GUI related elements
    GUI = struct();
    
    % - Data storage mode
    data = struct();
    
    % - DataWatcher mode
    dw = struct();
    % - ROIDrawer mode
    rd = struct();
    % - Analyser mode
    an = struct();
    % - Behavior mode
    be = struct();
    % - JointTracker mode
    jt = struct();

end

%% methods - public
methods

%% - #OCIA - constructor
function this = OCIA(varargin)
    
    o('#%s(): constructor ...', mfilename, 4, this.verb);
    o('Launching OCIA v%s ...', this.version, 0, this.verb);
    
    %% -- #OCIA: parse inputs and load config file
    o('#%s(): parsing inputs ...', mfilename, 4, this.verb);
    % prepare the input parser object with the requested inputs
    IP = inputParser;
    addOptional(IP,         'configName',         'default',               @ischar);
    addOptional(IP,         'DWFilt',             'empty',                 @(x)ischar(x) || iscell(x));
    parse(IP, varargin{:});
    
    % get the config function's name and call it
    configName = IP.Results.configName;
    o('#%s(): using config file "%s" ...', mfilename, configName, 4, this.verb);
    [~, argsOut] = OCIAGetCallCustomFile(this, 'config', configName, 1, { this }, 1);
    % extract the outputs
    [this, inputParams] = argsOut{:};
    
    % if DataWatcher filtering was provided as input, overwrite config's parameter with input parameter
    if ~strcmp(IP.Results.DWFilt, 'empty');
        this.GUI.dw.DWFilt = IP.Results.DWFilt;
    end;
    o('#%s(): filtering elements: " %s" ...', mfilename, sprintf('%s - ', this.GUI.dw.DWFilt{:}), 4, this.verb);
        
    %% -- #OCIA: update the drop-down filters
    % define the "IDs" field for each drop-down DataWatcher filter element
    dropDownFiltersIDs = this.GUI.dw.filtElems{strcmp(this.GUI.dw.filtElems.GUIType, 'dropdown'), 'id'};
    for iFilter = 1 : numel(dropDownFiltersIDs);
        % create a list with only a dash element, which corresponds to no filtering
        this.dw.([dropDownFiltersIDs{iFilter} 'IDs']) = {'-'};
    end;
    
    %% -- #OCIA: turn warnings off
    warning('off', 'images:imshow:magnificationMustBeFitForDockedFigure');
    
    %% -- #OCIA: add java folders
    OCIAPath = regexprep(which('OCIA'), '\\', '/');
    OCIAPath = regexprep(OCIAPath, '/@OCIA/OCIA.m$', '');
    javaaddpath([OCIAPath '/java/ij.jar']);
    javaaddpath([OCIAPath '/java/TurboRegJava']);
    o('#%s(): added Java path at "%s" ...', mfilename, OCIAPath, 4, this.verb);
      
    %% -- #OCIA: create the window and show it
    o('Creating window ...', 0, this.verb);
    OCIACreateWindow(this); % create the GUI window
    pause(0.5);
    show(this); % make the GUI window visible

    %% -- #OCIA: process start function
    % set the start function to default if no specified
    if ~isfield(inputParams, 'startFunctionName') || isempty(inputParams.startFunctionName);
        inputParams.startFunctionName = 'default';
    end;
    
    % process the start function
    showMessage(this, sprintf('Initializing using start function "%s" ...', inputParams.startFunctionName), 'yellow');
    OCIAGetCallCustomFile(this, 'startFunction', inputParams.startFunctionName, 1, { this }, 1);

end


%% - #delete (destructor)
function delete(this)
    
    o('#delete()', 4, this.verb);
    
    delete(this.GUI.figH);
    
end

%% - GUI methods
%% -- #show
function show(this)
% show - Show the window
%
%       show(this)
%
% Makes the OCIA window visible. 
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    o('#show()', 4, this.verb);
    
    showTic = tic; % for performance timing purposes
    set(this.GUI.figH, 'Visible', 'on');
    pause(0.1);
    o('#show(): done (%.4f sec)', toc(showTic), 4, this.verb);
        
end;

%% -- #hide
function hide(this)
% hide - Hides the window
%
%       hide(this)
%
% Makes the OCIA window invisible. 

    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    o('#hide()', 4, this.verb);
    
    set(this.GUI.figH, 'Visible', 'off');
    
end;

%% -- #isGUI
function isGUIBool = isGUI(this)
% isGUI - GUI-mode check
%
%       isGUIBool = isGUI(this)
%
% Returns the logical 'isGUIBool' telling whether the current instance of the OCIA ('this') is running in a 
%   windowed mode or not.

    % if not in no-GUI mode and either in deployed mode or not in a matlab worker (parallel computing)
    isGUIBool = ~this.GUI.noGUI && (isdeployed || isempty(javachk('desktop')));
        
end;

%% -- #showMessage
function showMessage(this, messageTxt, bgColor)
% showMessage - Display a message
%
%       showMessage(this, messageTxt, bgColor)
%
% Displays the message 'messageTxt' (char) in the log bar and in the command window. If the variable 'bgColor' is
%   specified, the background of the log bar is set to the color specified either as a color string ("red", "blue",
%   etc.) or as an array of 3 values between 0.0 and 1.0 (RGB). Otherwise the default color (green) is used.

    % print out the message in the command window
    o(messageTxt, 1, this.verb);
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    % if variable color not specified or neither a string nor a 3-elements RGB array
    if ~exist('bgColor', 'var') || (~ischar(bgColor) && numel(bgColor) > 3);
        % use the default green color
        bgColor = 'green';
    end;
    
    % display the message and set the background
    set(this.GUI.handles.logBar, 'String', messageTxt, 'Background', bgColor);
    
end;

%% -- #showWarning
function showWarning(this, warnID, warningText, bgColor)
% showMessage - Display a warning
%
%       showWarning(this, warnID, warningText, bgColor)
%
% Displays the warning 'warningText' (char) with the ID 'warningID' (char) in the log bar and in the command window.
%   If the variable 'bgColor' is specified, the background of the log bar is set to the color specified either as a
%   color string ("red", "blue", etc.) or as an array of 3 values between 0.0 and 1.0 (RGB). Otherwise the default
%   color (yellow) is used.
    
    
    % if variable color not specified or neither a string nor a 3-elements RGB array
    if ~exist('bgColor', 'var') || (~ischar(bgColor) && numel(bgColor) > 3);
        % use the default green color
        bgColor = 'yellow';
    end;
    
    % show the warning but without the stack trace
    warning off backtrace;
    warning(warnID, [strrep(warningText, '\', '\\') ' (' warnID ')']);
    warning on backtrace;
    
    % do nothing if there is no GUI or if warning is disabled
    warnState = warning('query', warnID);
    if ~isGUI(this) || strcmp(warnState.state, 'off'); return; end;
    
    % split the warning text at end-of-line characters
    warningTextSplit = regexp(warningText, '\n', 'split');
    % only display the first line of the warning text and set the background
    set(this.GUI.handles.logBar, 'String', warningTextSplit{1}, 'Background', bgColor);    
    
end;

%% -- #getJTable
function jTable = getJTable(this, hTable)
% getJTable - Get a Java table
%
%       jTable = getJTable(this, hTable)
%
% Returns the Java object 'jTable' associated with the uitable specified by 'hTable' either as a string ('DWTable', etc.)
%   or as a uitable handle.

    jTable = []; % return empty in case there is a problem
    tableName = '';
    
    % if handle is actually a string, get the appropriate uitable handle first
    if ischar(hTable);
        
        % store the table's name
        tableName = hTable;
        
        % check if the table was not already stored in memory
        if isfield(this.GUI, 'jTables') && isfield(this.GUI.jTables, tableName);
            jTable = this.GUI.jTables.(tableName);
            return;
        end;
        
        % get the appropriate handle for the table
        switch tableName;
            case 'DWTable';
                hTable = this.GUI.handles.dw.table;
            case 'BEConfTable';
                hTable = this.GUI.handles.be.confTable;
            otherwise;
                showWarning(this, 'OCIA:getJTable:UnknownTable', sprintf('Cannot find JTable for "%s".', hTable));
                return;
        end;
    end;
    
    % sometimes the Java-object fetching fails on first attempt, so try a second time
    try
        % get the actual java table underlying the requested uitable
        jTable = findjobj(hTable); jTable = jTable.getComponents();
        jTable = jTable(1); jTable = jTable.getComponents();
        jTable = jTable(1);
        
    % try a second time
    catch e; %#ok<NASGU>
        pause(0.5);
        % get the actual java table underlying the requested uitable
        jTable = findjobj(hTable); jTable = jTable.getComponents();
        jTable = jTable(1); jTable = jTable.getComponents();
        jTable = jTable(1);
    end;
    
    % if the table was acced by a name, store the jtable
    if ~isempty(tableName);
        this.GUI.jTables.(tableName) = jTable;
    end;
end;


%% -- #getData
function data = getData(this, varargin)
% getData - Get data or load status from the DataWatcher's table
%
%       data = getData(this, rows, dataType)
%       data = getData(this, rows, dataType, subFieldName)
%
% Returns the requested data type from the DataWatcher's table data. "rows" should be a double or an array of double and
%   "columns" a string or a cell-array of string, "dataType" a string. "subFieldName" should be a string that specifies
%   which sub-field ('data', 'loadStatus', 'procState') should be returned.

% by default or in case of error, return nothing
data = [];

% all columns for specified row(s)
if numel(varargin) == 2 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && ischar(varargin{2});
    rows = varargin{1};
    dataType = varargin{2};
    subFieldName = [];
    
% specified rows and specified column(s)
elseif numel(varargin) == 3 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && ischar(varargin{2}) && ischar(varargin{3});
    rows = varargin{1};
    dataType = varargin{2};
    subFieldName = varargin{3};
    
% otherwise: bad input arguments
else
    rows = [];
    dataType = [];
    subFieldName = [];
end;

% if all rows are required to be selected using the 'all' command
if ischar(rows) && strcmp(rows, 'all');
    rows = 1 : size(tableToUse, 1);
end;

% if the parameters where not all provided or could not be figured out, abort with warning
if isempty(rows) || isempty(dataType);
    showWarning(this, 'OCIA:getData:BadInputArguments', 'Bad input arguments for function getData, please read the help.');   
    return;
end;

% get the data structure
dataStruct = getR(this, rows, 'data');

% if no data structure found, return nothing
if isempty(dataStruct);
    return;
end;

% allocate the data as a cell array
data = cell(size(dataStruct));
% go through each fetched sub-structure
for iStruct = 1 : numel(dataStruct); 
    % if the dataType exists
    if isfield(dataStruct{iStruct}, dataType);
        % if no sub-field name provided, return the data structures themselves
        if isempty(subFieldName);
            data{iStruct} = dataStruct{iStruct}.(dataType);
        % if the sub-field name is required and exists, return it
        elseif isfield(dataStruct{iStruct}.(dataType), subFieldName);
            data{iStruct} = dataStruct{iStruct}.(dataType).(subFieldName);
        end;
    end;    
end;

% do not return a single empty cell, return an empty array instead
if iscell(data) && numel(data) == 1;
    data = data{1};
end;

end


%% -- #setData
function data = setData(this, varargin)
% getData - Get data or load status from the DataWatcher's table
%
%       setData(this, rows, dataType, data)
%       setData(this, rows, dataType, subFieldName, data)
%
% Stores the specified data in the DataWatcher's table specified data type. "rows" should be a double or an array of double and
%   "columns" a string or a cell-array of string, "dataType" a string. "subFieldName" should be a string that specifies
%   which sub-field ('data', 'loadStatus', 'procState') should be returned. "data" is the data to store, can be a cell
%   array.

% all columns for specified row(s)
if numel(varargin) == 3 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && ischar(varargin{2});
    rows = varargin{1};
    dataType = varargin{2};
    subFieldName = [];
    data = varargin{3};
    
% specified rows and specified column(s)
elseif numel(varargin) == 4 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && ischar(varargin{2}) && ischar(varargin{3});
    rows = varargin{1};
    dataType = varargin{2};
    subFieldName = varargin{3};
    data = varargin{4};
    
% otherwise: bad input arguments
else
    rows = [];
    dataType = [];
    subFieldName = [];
    data = [];
end;

% if all rows are required to be selected using the 'all' command
if ischar(rows) && strcmp(rows, 'all');
    rows = 1 : size(tableToUse, 1);
end;

% if the parameters where not all provided or could not be figured out, abort with warning
if isempty(rows) || isempty(dataType);
    showWarning(this, 'OCIA:setData:BadInputArguments', 'Bad input arguments for function setData, please read the help.');   
    return;
end;

% make sure the data's format is a cell-array
if ~iscell(data) || numel(rows) == 1;
    data = { data };
end;

% if the number of rows is too big, abort with warning
if numel(rows) ~= numel(data);
    showWarning(this, 'OCIA:setData:NumberOfRowsMismatch', ...
        sprintf('Number of rows specified (%02d) is not equal to the size of the input data (%02d).', ...
            numel(rows), numel(data)));   
    return;
end;

% go through each row
for iRow = 1 : numel(rows); 
    % get the data for this row
    dataStruct = get(this, rows(iRow), 'data');
    % if the dataType exists
    if isfield(dataStruct, dataType);
        % if no sub-field name provided, store the whole data data type
        if isempty(subFieldName);
            dataStruct.(dataType) = data{iRow};
        % otherwise just set the field
        else
            dataStruct.(dataType).(subFieldName) = data{iRow};
        end;
    end; 
    % set the data for this row
    set(this, rows(iRow), 'data', dataStruct);   
end;

end


%% -- #get
function values = get(this, varargin)
% get - Get values from table
%
%       values = get(this, rows)
%       values = get(this, columns)
%       values = get(this, rows, columns)
%       values = get(this, rows, columns, tableToUse)
%       values = get(this, rows, columns, tableToUse, tableIDs)
%
% Returns the requested rows/columns from the DataWatcher's table. "rows" should be a double or an array of double and
%   "columns" a string or a cell-array of string. Optionnally, an alternative table "tableToUse" can be provided with
%   its own columns names "tableIDs".

% get the raw values
values = getR(this, varargin{:});

% do some post-process tasks if there are some cells
if ~isempty(values);
    
    % filter for the delete tag
    charCells = cellfun(@ischar, values);
    values(charCells) = regexprep(values(charCells), ['^' this.GUI.dw.deleteTag], '');
    values(charCells) = regexprep(values(charCells), '^<html>(<[^>]+>)?(<[^>]+>)?([^<]+)(<[^>]+>)*', '$3');

    % do not return a single cell, return the value it contains instead
    if iscell(values) && numel(values) == 1;
        values = values{1};
    end;

end;

end

%% -- #getR
function values = getR(this, varargin)
% getR - Get raw values from table (no post-processing)
%
%       values = getR(this, rows)
%       values = getR(this, columns)
%       values = getR(this, rows, columns)
%       values = getR(this, rows, columns, tableToUse)
%       values = getR(this, rows, columns, tableToUse, tableIDs)
%
% Returns the requested rows/columns from the DataWatcher's table without any further modification (delete tag removal).
%   "rows" should be a double or an array of double and "columns" a string or a cell-array of string. Optionnally, 
%   an alternative table "tableToUse" can be provided with its own columns names "tableIDs".

% get the default table and its IDs
tableToUse = this.dw.table;
tIDs = this.dw.tableIDs;

% by default or in case of error, return nothing
values = [];

% all columns for specified row(s)
if numel(varargin) == 1 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all')));
    rows = varargin{1};
    columns = tIDs;
    
% all rows for specified column(s)
elseif numel(varargin) == 1 && (ischar(varargin{1}) || iscell(varargin{1}));
    rows = 'all';
    columns = varargin{1};
    
% specified rows and specified column(s)
elseif numel(varargin) == 2 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2}));
    rows = varargin{1};
    columns = varargin{2};
    
% specified rows and specified column(s) with a custom table
elseif numel(varargin) == 3 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2})) ...
        && iscell(varargin{3});
    rows = varargin{1};
    columns = varargin{2};
    tableToUse = varargin{3};
    
% specified rows and specified column(s) with a custom table and table IDs
elseif numel(varargin) == 4 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2})) ...
        && iscell(varargin{3}) && iscell(varargin{4});
    rows = varargin{1};
    columns = varargin{2};
    tableToUse = varargin{3};
    tIDs = varargin{4};
    
% otherwise: bad input arguments
else
    rows = [];
    columns = [];  
end;

% if all rows are required to be selected using the 'all' command
if ischar(rows) && strcmp(rows, 'all');
    rows = 1 : size(tableToUse, 1);
end;

% make sure the column name(s)'format is a cell-array
if ischar(columns) && ~isempty(columns);
    columns = { columns };
end;

% if no rows selected, abort
if isempty(rows);
    return;
end;

% if the parameters where not all provided or could not be figured out, abort with warning
if isempty(columns) || isempty(tableToUse) || isempty(tIDs);
    showWarning(this, 'OCIA:getR:BadInputArguments', 'Bad input arguments for function get, please read the help.');   
    return;
end;

% if the number of rows is too big, abort with warning
if numel(rows) > size(tableToUse, 1);
    showWarning(this, 'OCIA:getR:NumberOfRowsExceeded', ...
        sprintf('Number of rows specified (%02d) exceeds table''s dimensions (%02d).', numel(rows), size(tableToUse, 1)));   
    return;
end;

% if all is good, then fetch the values:
% get the indexes of the columns that are in the IDs, in the same order as requested
[~, b] = ismember(columns(ismember(columns, tIDs)), tIDs);
% fetch the values
values = tableToUse(rows, b);

% post-process the column names
for iCol = 1 : numel(columns);
    switch columns{iCol};
        case 'rowID';
            rowID = DWGetRowID(this, rows);
            if ~iscell(rowID); rowID = { rowID }; end;
            values(:, iCol) = rowID;
        case 'rowTypeID';
            rowTypeID = DWGetRowTypeID(this, rows);
            if ~iscell(rowTypeID); rowTypeID = { rowTypeID }; end;
            values(:, iCol) = rowTypeID;
        otherwise;
            % do nothing
    end;
end;

end

%% -- #set
function varargout = set(this, varargin)
% set - set values in table
%
%      set(this, rows, values)
%      set(this, columns, values)
%      set(this, rows, columns, values)
%      tableToUse = set(this, rows, columns, values, tableToUse)
%      tableToUse = set(this, rows, columns, values, tableToUse, tableIDs)
%
% Stores the specified values in the rows/columns from the DataWatcher's table. "rows" should be a double or an 
%   array of double and "columns" a string or a cell-array of string. Optionnally, an alternative table "tableToUse" 
%   can be provided with its own columns names "tableIDs", in which case the new table is returned.

% by default, no output
varargout = {};

% get the default table and its IDs
tableToUse = this.dw.table;
tIDs = this.dw.tableIDs;
% set the flag specifying if the table used was from input, by default "false"
tableFromInput = false;

% all columns for specified row(s)
if numel(varargin) == 2 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all')));
    rows = varargin{1};
    columns = tIDs;
    values = varargin{2};
    
% all rows for specified column(s)
elseif numel(varargin) == 2 && (ischar(varargin{1}) || iscell(varargin{1}));
    rows = 'all';
    columns = varargin{1};
    values = varargin{2};
    
% specified rows and specified column(s)
elseif numel(varargin) == 3 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2}));
    rows = varargin{1};
    columns = varargin{2};
    values = varargin{3};
    
% specified rows and specified column(s) with a custom table
elseif numel(varargin) == 4 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2})) ...
        && iscell(varargin{4});
    rows = varargin{1};
    columns = varargin{2};
    values = varargin{3};
    tableToUse = varargin{4};
    % set the flag specifying that the table used was from input
    tableFromInput = true;
    
% specified rows and specified column(s) with a custom table and table IDs
elseif numel(varargin) == 5 && (isnumeric(varargin{1}) || (ischar(varargin{1}) && strcmp(varargin{1}, 'all'))) ...
        && (ischar(varargin{2}) || iscell(varargin{2})) ...
        && iscell(varargin{4}) && iscell(varargin{5});
    rows = varargin{1};
    columns = varargin{2};
    values = varargin{3};
    tableToUse = varargin{4};
    tIDs = varargin{5};
    % set the flag specifying that the table used was from input
    tableFromInput = true;
    
% otherwise: bad input arguments
else
    columns = []; 
end;

% if all rows are required to be selected using the 'all' command
if ischar(rows) && strcmp(rows, 'all');
    rows = 1 : size(tableToUse, 1);
end;

% make sure the column name(s)'format is a cell-array
if ischar(columns) && ~isempty(columns);
    columns = { columns };
end;

% if the parameters where not all provided or could not be figured out, abort with warning
if isempty(rows) || isempty(columns) || isempty(tableToUse) || isempty(tIDs);
    showWarning(this, 'OCIA:set:BadInputArguments', 'Bad input arguments for function set, please read the help.');   
    return;
end;

% if the number of rows is too big, abort with warning
if numel(rows) > size(tableToUse, 1);
    showWarning(this, 'OCIA:set:NumberOfRowsExceeded', ...
        sprintf('Number of rows specified (%02d) exceeds table''s dimensions (%02d).', numel(rows), size(tableToUse, 1)));   
    return;
end;

% make sure the values' format is a cell-array
if ~iscell(values);
    values = { values };
end;

% if the size of the values does not match exactly the size of what needs to be replaced, try to extend the values
tableToReplace = tableToUse(rows, ismember(tIDs, columns));
if ~all(size(values) == size(tableToReplace));
    
    % if inputs are just transposed, transposed them back
    if all(size(values') == size(tableToReplace));
        values = values';
    
    % if the values are a vector and can be expanded on one dimension to fit the right size
    elseif size(values, 1) == 1 && size(values, 2) == size(tableToReplace, 2);
        values = repmat(values, size(tableToReplace, 1), 1);
    % if the values are a vector and can be expanded on one dimension to fit the right size
    elseif size(values, 1) == 1 && size(values, 2) == size(tableToReplace, 1);
        values = repmat(values', 1, size(tableToReplace, 2));
    % if the values are a vector and can be expanded on one dimension to fit the right size
    elseif size(values, 2) == 1 && size(values, 1) == size(tableToReplace, 1);
        values = repmat(values, 1, size(tableToReplace, 1));
    % if the values are a vector and can be expanded on one dimension to fit the right size
    elseif size(values, 2) == 1 && size(values, 1) == size(tableToReplace, 2);
        values = repmat(values', size(tableToReplace, 1), 1);
    % if the values are a vector and can be expanded on one dimension to fit the right size
    elseif size(values, 2) == 1 && size(values, 1) == 1;
        values = repmat(values', size(tableToReplace, 1), size(tableToReplace, 2));
    % if nothing can be done, abort
    else
        showWarning(this, 'OCIA:set:BadSizeInputValues', ...
            sprintf('Input values have bad size: provided size: %d x %d, required size: %d x %d.', ...
                size(values), size(tableToReplace))); 
        return;
    end;
end;

% set the values
tableToUse(rows, ismember(tIDs, columns)) = values;

% if the table comes from input arguments, return it
if tableFromInput;
    varargout = { tableToUse };
% otherwise, update the data watcher table
else
    this.dw.table = tableToUse;
end;

end

%{
%% - #event handlers
%% -- #keyPressed
function keyPressed(this, ~, e)

%     currObj = get(this.GUI.figH, 'CurrentObject');
%     currObjTag = get(currObj, 'Tag');
    
    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    isChangeMode = 0;
    if ismember('shift', e.Modifier);
        switch e.Key;
            case {'1', '2', '3', '4'};
                OCIAChangeMode(this, this.GUI.modes{str2double(e.Key), 1});
                isChangeMode = 1;
        end;
    end;
    
    if ~isChangeMode;
        switch currentMode
            case 'ROIDrawer';
                switch e.Key;
                    case {'uparrow', 'downarrow', 'leftarrow', 'rightarrow'};
%                         if isempty(currObj) || strcmp(currObjTag, 'ROIDrawerPanel');
                        if ~ismember('control', e.Modifier) && ~ismember('alt', e.Modifier);
                            RDMoveROIs(this, strrep(e.Key, 'arrow', ''), this.rd.moveROIsStep);
                        elseif ismember('control', e.Modifier) && strcmp(e.Key, 'leftarrow');
                            RDRotateROIs(this, - this.rd.rotateROIsStep);
                        elseif ismember('control', e.Modifier) && strcmp(e.Key, 'rightarrow');
                            RDRotateROIs(this, this.rd.rotateROIsStep);
                        elseif ismember('alt', e.Modifier) && strcmp(e.Key, 'downarrow');
                            currROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                            if isempty(currROI); currROI = 1; end;
                            if currROI(1) < numel(get(this.GUI.handles.rd.selROIsList, 'String'));
                                set(this.GUI.handles.rd.selROIsList, 'Value', currROI(1) + 1);
                            end;
                            RDSelROI(this);
                        elseif ismember('alt', e.Modifier) && strcmp(e.Key, 'uparrow');
                            currROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                            if isempty(currROI);
                                currROI = numel(get(this.GUI.handles.rd.selROIsList, 'String'));
                            end;
                            if currROI(1) > 1;
                                set(this.GUI.handles.rd.selROIsList, 'Value', currROI(1) - 1);
                            end;
                            RDSelROI(this);
                        end;
%                         end;
                    case 'z';
                        RDActivateZoom(this, ~get(this.GUI.handles.rd.zTool, 'Value'));
                    case 'c';
                        % invert target and reference
                        if ismember('control', e.Modifier);
                            selRef = get(this.GUI.handles.rd.refROISetASetter, 'Value');
                            selTarg = get(this.GUI.handles.rd.refROISetBSetter, 'Value');
                            set(this.GUI.handles.rd.refROISetASetter, 'Value', selTarg(1));
                            set(this.GUI.handles.rd.refROISetBSetter, 'Value', selRef(1));
                            RDCompareROIs(this, 'IDs');
                        elseif ismember('alt', e.Modifier);
                            compareState = get(this.GUI.handles.rd.refROISet, 'Value');
                            set(this.GUI.handles.rd.refROISet, 'Value', ~compareState);
                            RDCompareROIs(this, 'IDs');
                        else
                            RDCompareROIs(this, 'IDs');
                        end;
                    case 'l';
                           set(this.GUI.handles.rd.selROIsList, 'Value', ...
                               numel(get(this.GUI.handles.rd.selROIsList, 'String')));
                            RDSelROI(this);
                    case 'r';
                        if ismember('shift', e.Modifier);
                            spotIndex = get(GUIDWFiltH.spotID, 'Value');
                            selRef = get(this.GUI.handles.rd.refROISetASetter, 'Value');
                            selTarg = get(this.GUI.handles.rd.refROISetBSetter, 'Value');
                            DWProcessWatchFolder(this);
                            DWExtractNotebookInfo(this);
                            set(GUIDWFiltH.spotID, 'Value', spotIndex);
                            DWFilterSelectTable(this, 'new');
                            RDDrawROIsForRows(this);
                            set(this.GUI.handles.rd.tableList, 'Value', 1 : size(this.rd.selectedTableRows{iRDRow, 1));
                            RDChangeRow(this, this.GUI.handles.rd.tableList);
                            set(this.GUI.handles.rd.refROISetASetter, 'Value', selRef);
                            set(this.GUI.handles.rd.refROISetBSetter, 'Value', selTarg);
                            set(this.GUI.handles.rd.refROISet, 'Value', 1);
                            RDCompareROIs(this);
                            RDLoadROIs(this);
                        else
                            RDRenameROI(this);
                        end;
                    case 'space';
                        
                    case 'delete';
                        iSelROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                        RDDeleteROI(this);
                        if ~isempty(iSelROI);
                            set(this.GUI.handles.rd.selROIsList, 'Value', iSelROI(1));
                            RDSelROI(this);
                        end;
                    case 'i';
                        if ismember('control', e.Modifier);
                            RDShowHideROIs(this, 'ROIs');
                        else
                            RDShowHideROIs(this, 'IDs');
                        end;
                    case 's';
                        if ismember('control', e.Modifier);
                            RDSaveROIs(this);
                        end;
                    case 'a';
                        if ismember('control', e.Modifier);
                            set(this.GUI.handles.rd.selROIsList, 'Value', ...
                                1 : numel(get(this.GUI.handles.rd.selROIsList, 'String')));
                            RDSelROI(this);
                        else
                            set(this.GUI.handles.rd.imAdj, 'Value', ~get(this.GUI.handles.rd.imAdj, 'Value'));
                            RDUpdateImage(this, this.GUI.handles.rd.imAdj);
                        end;
                    case 'p';
                        set(this.GUI.handles.rd.pseudFF, 'Value', ~get(this.GUI.handles.rd.pseudFF, 'Value'));
                        RDUpdateImage(this, this.GUI.handles.rd.pseudFF);
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
            case 'Analyser';
                switch e.Key;
                    case {'leftarrow', 'rightarrow'};
                        ANSelPlot(this, strrep(e.Key, 'arrow', ''));
                    case {'uparrow', 'downarrow'};
                        ANSelRuns(this, strrep(e.Key, 'arrow', ''));
                    case 'a';
                        ANSelRuns(this, 'all');
                    case 'z';
                        ANActivateZoom(this, ~get(this.GUI.handles.an.zTool, 'Value'));
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
            case 'JointTracker';
                switch e.Key;
                    case 'c';
                        JTSwapCursor(this);
                    case 'a';
                        if ismember('shift', e.Modifier);
                            set(this.GUI.handles.jt.frameSetter, 'Value', 1);
                        else
                            set(this.GUI.handles.jt.frameSetter, 'Value', max(this.GUI.jt.iFrame - 1, 1));
                        end;
                    case 'd';
                        if ismember('shift', e.Modifier);
                            if get(this.GUI.handles.jt.autoTrack, 'Value');
                                JTProcess(this, 'all');
                            else
                                set(this.GUI.handles.jt.frameSetter, 'Value', this.jt.nFrames);
                            end;
                        else
                            set(this.GUI.handles.jt.frameSetter, 'Value', min(this.GUI.jt.iFrame + 1, this.jt.nFrames));
                        end;
                    case {'w', 's'};
                        addValue = 1; if strcmp(e.Key, 's'); addValue = -1; end;
                        newValue = min(max(this.GUI.jt.iJointType + addValue, 1), this.jt.nJointTypes);
                        if newValue ~= get(this.GUI.handles.jt.jointTypeSelSetter, 'Value');
                            set(this.GUI.handles.jt.jointTypeSelSetter, 'Value', newValue);
                            JTChangeJointOrJointType(this, this.GUI.handles.jt.jointTypeSelSetter);
                        end;
                    case 'f';
                        set(this.GUI.handles.jt.autoTrack, 'Value', ~get(this.GUI.handles.jt.autoTrack, 'Value'));
                        JTProcess(this, 'autoTrackChanged');
                    case {'m', 'v'};
                        set(this.GUI.handles.jt.manuTrack, 'Value', ~get(this.GUI.handles.jt.manuTrack, 'Value'));
                        JTManualTrackStart(this);
                    case 'space';
                        set(this.GUI.handles.jt.viewOpts.preProc, 'Value', ...
                            ~get(this.GUI.handles.jt.viewOpts.preProc, 'Value'));
                        JTUpdateGUI(this, this.GUI.handles.jt.viewOpts.preProc);
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
        end;
    end;

end;

%% -- #mouseDown
function mouseDown(this, ~, ~)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
        case 'JointTracker';
            
            % make sure the click is within the axe image and not during a ROI drawing
            pos = get(this.GUI.handles.jt.axe, 'CurrentPoint');
            pos = pos(1, 1 : 2);
            XLim = get(this.GUI.handles.jt.axe, 'XLim');
            YLim = get(this.GUI.handles.jt.axe, 'YLim');
            if this.GUI.jt.selectingROI || any(pos < 0) || pos(1) > XLim(2) || pos(2) > YLim(2);
                return;
            end;
            
            if isempty(this.GUI.jt.placeJointIndex) && isempty(this.GUI.jt.moveJointIndex);
                selectionType = get(this.GUI.figH, 'SelectionType');
                JTJointClickStart(this, strcmp(selectionType, 'extend'));
            end;
    end;

end;

%% -- #mouseUp
function mouseUp(this, h, e)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
        
        case 'ROIDrawer';
            
            RDUpdateGUI(this, h, e);
            
        case 'JointTracker';
            
            % make sure the click is within the axe image and not during a ROI drawing
            pos = get(this.GUI.handles.jt.axe, 'CurrentPoint');
            pos = pos(1, 1 : 2);
            XLim = get(this.GUI.handles.jt.axe, 'XLim');
            YLim = get(this.GUI.handles.jt.axe, 'YLim');
            if this.GUI.jt.selectingROI || any(pos < 0) || pos(1) > XLim(2) || pos(2) > YLim(2);
                return;
            end;
            
            % process the click event
            JTImClick(this, h, e);
            
            % reset the joint tracking/moving settings
            this.GUI.jt.placeJointIndex = [];
            this.GUI.jt.moveJointIndex = [];
            this.GUI.jt.startFrame = [];
            this.GUI.jt.endFrame = [];
            this.GUI.jt.startTime = [];

            % remove manual tracking
            set(this.GUI.handles.jt.manuTrack, 'Value', 0);
    end;

end;

%% -- #mouseMoved
function mouseMoved(this, ~, ~)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
    end;

end;

%}

end  % end methods


end
