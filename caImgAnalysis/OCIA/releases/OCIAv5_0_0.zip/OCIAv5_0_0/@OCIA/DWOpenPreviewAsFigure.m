%% #OCIA:DW:DWOpenPreviewAsFigure
function DWOpenPreviewAsFigure(this, varargin)
    
    % if nothing is selected, abort
    if isempty(this.dw.selectedTableRows); 
        showWarning(this, 'OCIA:DWOpenPreviewAsFigure:NoRowsSelected', 'No rows selected! Aborting.');
        return;
    end;
    
    % get the selected row and it's rowID
    rowID = DWGetRowID(this, this.dw.selectedTableRows(1));
    
    % create the figure
    prevFigH = figure('Name', sprintf('%s - preview', rowID), 'NumberTitle', 'off', 'Position', ...
        [1 1 repmat(max(get(0, 'ScreenSize')) * 0.5, 1, 2)]);
    imagesc(get(this.GUI.handles.dw.prevIm, 'CData'));
    set(gca, 'XTick', [], 'YTick', []);
    tightfig();
    movegui(prevFigH, 'center');
    
end
