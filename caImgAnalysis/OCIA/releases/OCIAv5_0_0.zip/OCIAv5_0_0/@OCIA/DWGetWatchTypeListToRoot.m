%% #OCIA:DWGetRowID
function watchTypeListToRoot = DWGetWatchTypeListToRoot(this, startWatchType)
    
% get the watch type's parent
currWatchType = char(this.dw.watchTypes{startWatchType, 'parent'});
watchTypeListToRoot = { currWatchType };
while ~isempty(currWatchType);
    currWatchType = this.dw.watchTypes{currWatchType, 'parent'};
    if ~isempty(currWatchType{1});
        currWatchType = char(currWatchType);
        watchTypeListToRoot{end + 1} = currWatchType; %#ok<AGROW>
    else
        break;
    end;
end;

end
