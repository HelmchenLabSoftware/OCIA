function ANUpdateVariablesFromParamPanel(this)

% update the parameter panel depending on the plot using the analysisParamConfig
nUICtrl = size(this.GUI.an.analysisParamConfig, 1);

% go through all elements and update their associated parameters
for iUICtrl = 1 : nUICtrl;
    
    % extract the elements of the parameter config
    [categ, id, UIType, valueType] = this.GUI.an.analysisParamConfig{iUICtrl, 1 : 5};
    
    % if no field corresponds to the id, skip this element
    if ~isfield(this.GUI.handles.an.paramPanElems, id); continue; end;
    
    % process the different UI types
    switch UIType;
        
        % text input elements
        case 'text';
            
            % get the text
            txt = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            
            % process the different value types
            switch valueType;
                
                case 'numeric'; % single number
                    dblValue = str2double(txt); % get the value as double
                    % unless the value is a NaN, store it in the right variable
                    if ~isnan(dblValue); this.an.(categ).(id) = dblValue; end;
                    
                case 'text'; % string
                    % unless the value is a empty, store it in the right variable
                    if ~isempty(txt); this.an.(categ).(id) = txt; end;
                    
                case 'array'; % array of numbers
                    % remove anything that is not a number, a comma, a colon, a dot, a minus, a space or square brackets
                    val = regexprep(txt, '[^\[\]\d ,:;\.-]', '');
                    % single dash means leave empty
                    if strcmp(val, '-');
                        this.an.(categ).(id) = '';
                        continue;
                    end;
                    % if the text is not empty, evaluate the text to get the actual array, 
                    %   using try-catch to catch the eval errors
                    if ~isempty(val); try val = eval(val); catch e; val = []; end; end; %#ok<NASGU>
                    % if the array is not empty and does not contains NaNs, store its value
                    if ~isempty(val) && ~any(isnan(val(:))); this.an.(categ).(id) = val; end;
                    
                case 'cellArray'; % cell array of strings
                    % remove anything that is not a number, a comma, a colon, a dot, a minus, a space or square brackets
                    val = regexp(regexprep(txt, '^\{ (.+)\ }$', '$1'), ', ', 'split');
                    % make sure val is a cell
                    if ~iscell(val); val = { val }; end;
                    % single dash means leave empty
                    if numel(val) == 1 && strcmp(val{1}, '-');
                        this.an.(categ).(id) = { };
                        continue;
                    end;
                    % if the array is a cell array of strings, store it
                    if ~isempty(val) && iscell(val) && all(cellfun(@ischar, val)); this.an.(categ).(id) = val; end;
                    
            end; % end of valueType switch
            
        % drop down elements
        case 'dropdown';
            % get the possible values
            values = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            % store the selected value
            this.an.(categ).(id) = values{get(this.GUI.handles.an.paramPanElems.(id), 'Value')};
            
        % list elements
        case 'list';
            % get the possible values
            values = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            % store the selected value
            this.an.(categ).(id) = values(get(this.GUI.handles.an.paramPanElems.(id), 'Value'));
            
    end; % end of UIType switch
    
end; % end of control element loop

end