%% #OCIA:DW:DWOpenDataAsFigure
function DWOpenDataAsFigure(this, varargin)
    
    % if nothing is selected, abort
    if isempty(this.dw.selectedTableRows); 
        showWarning(this, 'OCIA:DWOpenDataAsFigure:NoRowsSelected', 'No rows selected! Aborting.');
        return;
    end;
    
    % get the selected row and it's rowID
    iDWRow = this.dw.selectedTableRows(1);
    rowID = DWGetRowID(this, iDWRow);
    rowTypeID = DWGetRowTypeID(this, iDWRow);
    
    % create the user data structure
    userDataStruct = struct('RGBIm', [], 'iFrame', 1, 'channels', [1 1 1], 'imHandle', [], 'textHandle', [], ...
        'isGrayScale', 0, 'isAverage', 0, 'isFilter', 0);
    
    % create the figure
    prevFigH = figure('Name', sprintf('%s - data preview', rowID), 'NumberTitle', 'off', 'Position', ...
        [1 1 repmat(max(get(0, 'ScreenSize')) * 0.5, 1, 2)], ...
        'KeyPressFcn', @(h, e)DWChangeFrameForDataPreview(this, h, e));
    
    % show a black image
    userDataStruct.imHandle = imagesc(zeros([this.an.img.defaultImDim, 3]));
    % add the text display
    userDataStruct.textHandle = text(3, 3, 'Loading ...', 'Color', 'yellow');
    % remove axes
    set(gca, 'XTick', [], 'YTick', []);
    % make the figure borders tight and center the figure
    tightfig();
    movegui(prevFigH, 'center');
    pause(0.1);
    
    % call the custom function without warnings
    warning('off', 'OCIA:getPreviewFunctionNotFound');
    [~, RGBIm] = OCIAGetCallCustomFile(this, 'getPreview', rowTypeID, true, { this, iDWRow, 'full' }, false);
    warning('on', 'OCIA:getPreviewFunctionNotFound');

    % if no images obtained from the preview function, use a black square
    if isempty(RGBIm); RGBIm = zeros([this.an.img.defaultImDim, 1, 3]); end;
    
    % display the actual data
    userDataStruct.imHandle = imagesc(squeeze(RGBIm(:, :, 1, :)));    
    % add the text display
    userDataStruct.textHandle = text(2, 5, sprintf(['frame: %d/%d, channel: [%d, %d, %d], average: off, ', ...
        'grayscale: off, filter: off. Type "h" for shortcuts.'], userDataStruct.iFrame, size(RGBIm, 3), ...
        userDataStruct.channels), 'Color', 'yellow');
    % save the images in the figure's user data
    userDataStruct.RGBIm = RGBIm;
    set(prevFigH, 'UserData', userDataStruct);
    
end
