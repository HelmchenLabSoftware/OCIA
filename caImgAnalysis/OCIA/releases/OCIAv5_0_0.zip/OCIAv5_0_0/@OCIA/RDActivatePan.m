%% #OCIA:RD:RDActivatePan
function RDActivatePan(this, h, ~)
    
o('#RDActivatePan()', 4, this.verb);
if this.GUI.handles.rd.pTool ~= h; % if change was requested by a input value
    panState = h;
    set(this.GUI.handles.rd.pTool, 'Value', panState);
else % if change was requested by the callback
    panState = get(this.GUI.handles.rd.pTool, 'Value');
end;

if panState;
    RDActivateZoom(this, 0); % make sure zoom is no longer active
    hPan = pan(this.GUI.figH);
    hCMP = uicontextmenu('Parent', this.GUI.figH);
    uimenu('Parent', hCMP, 'Label', 'Stop pan', 'Callback', @(~, ~)RDActivatePan(this, 0));
    set(hPan, 'UIContextMenu', hCMP);
    set(hPan, 'Enable', 'on');
    showMessage(this, 'Pan tool on (ROIDrawer)');
else
    pan(this.GUI.figH, 'off');
    % delete the context menu object
    delete(get(pan(this.GUI.figH), 'UIContextMenu'));
    showMessage(this, 'Pan tool off (ROIDrawer)', 'yellow');
end;

end
