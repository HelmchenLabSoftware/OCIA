%% #BEUpdateGUI
function BEUpdateGUI(this, ~, ~)

try % capture display errors

lims = this.GUI.be.monPlotLimits;
    
if isfield(this.be, 'hw') && isfield(this.be.hw, 'connected') && this.be.hw.connected;
    axeH = this.GUI.handles.be.monAxes;
    delete(get(axeH, 'Children')); % delete previous data
    if isfield(this.be, 'anInData');
    
        if this.be.isRunning && this.be.iTrial;
            iTrial = this.be.iTrial;
            x = this.be.times.respMin(iTrial); y = lims(1);
            w = this.be.times.respMax(iTrial) - x; h = lims(2) - y;
            if w > 0;
                rectangle('Parent', this.GUI.handles.be.monAxes, 'Position', [x y w h], ...
                    'FaceColor', [1 0.7 0.7], 'EdgeColor', 'red');
                text(x + 0.5 * w, y + 0.95 * h, 'respWindow', 'HorizontalAlignment', 'center', ...
                    'Parent', axeH, 'FontSize', 6);
            else
                x = this.be.times.sound(iTrial); y = lims(1);
                w = this.be.times.soundDur(iTrial); h = lims(2) - y;
                if w > 0;
                    rectangle('Parent', this.GUI.handles.be.monAxes, 'Position', [x y w h], ...
                        'FaceColor', [0.7 1 0.7], 'EdgeColor', 'green');
                    text(x + 0.5 * w, y + 0.97 * h, 'sound', 'HorizontalAlignment', 'center', ...
                        'Parent', axeH, 'FontSize', 6);
                end;
            end;
        end;

        hold(axeH, 'on');
        nAnIn = numel(this.be.hw.analogIns);
        nSamples = 0;
        for iAnIn = 1 : nAnIn;
            anInName = this.be.hw.analogIns{iAnIn};
            if isfield(this.be.anInData, anInName);
                anInData = this.be.anInData.(anInName);
                
                % get the number of samples and check if there are any samples to plot
                nSamples = size(anInData, 1);
                if nSamples;
                    
                    % filter data if required
                    filtSize = this.GUI.be.anInFilt(iAnIn);
                    if filtSize;
                        if mod(filtSize, 2) == 0; filtSize = filtSize + 1; end;
                        anInData = sgolayfilt(this.be.anInData.(anInName), 1, filtSize);
                    end;
                    
                    % calculate the absolute value of the data
                    if this.GUI.be.anInDoAbs(iAnIn);
                        anInData = abs(anInData);
                    end;
                    
                    % plot the data
                    t = (0 : (nSamples - 1)) / this.be.hw.anInSampRate;
                    plot(axeH, t, anInData * this.GUI.be.anInMagnifs(iAnIn), this.GUI.be.anInColors{iAnIn});
                    
                end;
            end;
        end;
        
        if isfield(this.be.params, 'piezoThresh');
            iPiezo = find(strcmp(this.be.hw.analogIns, 'piezo'));
            if ~isempty(iPiezo);
                thresh = repmat(this.be.params.piezoThresh, 1, 2) * this.GUI.be.anInMagnifs(iPiezo);
                plot(axeH, [0 this.be.hw.maxRecDur], thresh, [this.GUI.be.anInColors{iPiezo}, ':']);
            end;
        end;
        
        legends = this.be.hw.analogIns;
        if nSamples && ~isempty(legends) && ~isempty(get(axeH, 'Children')) ...
                && any(~strcmp('text', get(get(axeH, 'Children'), 'Type')));
            legend(axeH, legends);
        end;

        if this.be.isRunning && this.be.iTrial;
            iTrial = this.be.iTrial;
            timesToShow = struct('imag', 'b--', 'startDelay', 'c:', 'respTime', 'r:', 'endImagObs', 'b--', ...
                'end', 'b:', 'spoutIn', 'k--', 'spoutOut', 'k--', 'endPunish', 'c--'); % 'sound', 'c:', 'soundDur__plus__sound', 'c--', 'respMin', 'r:', 
            tNames = fieldnames(timesToShow);
            for iTime = 1 : numel(tNames);
                tName = tNames{iTime};
                col = timesToShow.(tName);
                if regexp(tName, '__plus__');
                    nameParts = regexp(tName, '__plus__', 'split');
                    tName = nameParts{1};
                    t = 0;
                    for iPart = 1 : numel(nameParts);
                        if isfield(this.be.times, nameParts{iPart});
                            t = t + this.be.times.(nameParts{iPart})(iTrial);
                        end;
                    end;
                    if t == 0;
                        t = NaN;
                    end;
                else
                    if isfield(this.be.times, tName);
                        t = this.be.times.(tName)(iTrial);
                    else
                        t = NaN;
                    end;
                end;
                o('%s: %.3f', tName, t, 4, this.verb);
                if isnan(t) || ~t; continue; end;
                plot(axeH, repmat(t, 2, 1), lims, col);
                text(t, lims(2) * (1.05 + 0.075 * mod(iTime - 1, 3)), tName, 'Parent', axeH, 'FontSize', 6, ...
                    'HorizontalAlignment', 'center');
            end;
        end;
    end;

    xlim(axeH, [0 this.be.hw.maxRecDur]);
    ylim(axeH, lims);

end;

if this.be.isRunning;
    stateData(:, 1) = BEGetTrialInfo(this, this.be.iTrial - 1);
    stateData(:, 2) = BEGetTrialInfo(this, this.be.iTrial);
    if this.be.iTrial < this.be.config.training.nTrials;
        stateData(:, 3) = BEGetTrialInfo(this, this.be.iTrial + 1);
    else
        stateData(:, 3) = BEGetTrialInfo(this, 0);
    end;
else
    if isfield(this.be, 'configLoaded') && this.be.configLoaded && this.be.iTrial == 0;
        stateData(:, 3) = BEGetTrialInfo(this, 1);
    else
        stateData(:, 3) = BEGetTrialInfo(this, 0);
    end;
end;
set(this.GUI.handles.be.expTable, 'Data', stateData);

catch err;
    errStack = getStackText(err);
    showWarning(this, 'OCIA:BEUpdateGUI', sprintf('Problem in the behavior GUI update function: "%s".', err.message));
    o(errStack, 0, 0);
end
