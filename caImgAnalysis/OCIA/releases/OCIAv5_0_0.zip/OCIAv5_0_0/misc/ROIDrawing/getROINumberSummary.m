%% count
% ROISetIDs = [1 2 3 4 5 7];
% ROISetIDs = [4 5 7 9 11 13];
% thisRef = this;

ROISetIDs = str2double(regexprep(thisRef.dw.table(thisRef.dw.selectedTableRows, 8), 'RS', ''));
dayIDs = regexprep(thisRef.dw.table(thisRef.dw.selectedTableRows, 2), '_', '');
if numel(unique(dayIDs)) ~= numel(dayIDs);
    for iDay = 1 : numel(dayIDs) - 1;
        if strcmp(dayIDs{iDay}, dayIDs{iDay + 1});
            dayIDs{iDay} = sprintf('%s_am', dayIDs{iDay});
            dayIDs{iDay + 1} = sprintf('%s_pm', dayIDs{iDay + 1});
        end;
    end;
end;
ROINames = cell(numel(ROISetIDs), 1);
ROINamesIntersec = {};
ROINamesUnion = {};
nROISets = numel(ROISetIDs);
for iROISet = 1 : nROISets;
    ROINames{iROISet} = thisRef.data.img.ROISets{ROISetIDs(iROISet), 1}(:, 1);
    if isempty(ROINamesIntersec); ROINamesIntersec = ROINames{iROISet}; end;
    ROINamesIntersec = intersect(ROINamesIntersec, ROINames{iROISet});
    ROINamesUnion = [ROINamesUnion; ROINames{iROISet}]; %#ok<AGROW>
    fprintf('day %s (%d): %d\n', dayIDs{iROISet}, iROISet, numel(ROINames{iROISet}));
end;
ROINamesUniqueUnion = unique(ROINamesUnion);
nUniqueROIs = numel(ROINamesUniqueUnion);
fprintf('intersect: %d, union: %d, uniqueUnion: %d\n', numel(ROINamesIntersec), numel(ROINamesUnion), nUniqueROIs);

% intersect matrix
intersects = nan(nROISets, nROISets);
for iRef = 1 : nROISets;
    for iTarg = 1 : nROISets;
        intersects(iRef, iTarg) = numel(intersect(ROINames{iRef}, ROINames{iTarg}));
    end;
end;

%% plot
figure('Name', 'Summary', 'NumberTitle', 'off', 'Position', [700 45 1200 1050]);
subplot(2, 2, 1);
counts = zeros(nROISets, 1);
for i = 1 : nROISets;
    counts(i) = sum(cellfun(@(x)sum(strcmpi(x, ROINamesUnion)), ROINamesUniqueUnion) == i);
end;
bar(counts);
xlabel('Times seen'); ylabel('nROIs');
title('Number of times ROIs are present in dataset');
subplot(2, 2, 3);
imagesc(intersects, [0 nUniqueROIs]);
set(gca, 'XTick', 1 : nROISets, 'XTickLabel', 1 : nROISets, 'YTick', 1 : nROISets, 'YTickLabel', dayIDs);
for iRef = 1 : nROISets;
    for iTarg = 1 : nROISets;
        text(iRef, iTarg, num2str(intersects(iRef, iTarg)), 'HorizontalAlignment', 'center', 'FontSize', 8);
    end;
end;
colorbar();
subplot(2, 2, [2 4]);
title('ROI Presence');
hold on;
xRange = 1 : nROISets;
yRange = cellfun(@str2double, ROINamesUniqueUnion);
yRange(end) = yRange(end - 1) + 1;
for iROI = 1 : nUniqueROIs;
    presence = double(arrayfun(@(i)ismember(ROINamesUniqueUnion{iROI}, ROINames{i}), 1 : nROISets));
    yROI = yRange(iROI);
    plot(xRange, yROI, 'LineStyle', 'none', 'Marker', 'o', ...
        'MarkerFaceColor', 'none', 'MarkerEdgeColor', 'black', 'MarkerSize', 5);
    presence(~presence) = NaN;
    presence(~isnan(presence)) = 0;
    col = [0 0 0];
    nNans = sum(isnan(presence));
    if ~nNans; col = [1 0 0]; end;
    if nNans == 1; col = [0.5 0 0]; end;
    plot(xRange, presence + yROI, 'LineStyle', 'none', 'Marker', 'o', ...
        'MarkerFaceColor', col, 'MarkerEdgeColor', col, 'MarkerSize', 5);
    % mark ROIs where only one day is missing
    if nNans == 1;
        presence(~isnan(presence)) = 0;
        presence(isnan(presence)) = 1;
        presence(~presence) = NaN;
        presence(~isnan(presence)) = 0;
        plot(xRange, presence + yROI, 'LineStyle', 'none', 'Marker', 'x', ...
            'MarkerFaceColor', col, 'MarkerEdgeColor', col, 'MarkerSize', 15);
    end;
end;
xlabel('Days');
ylabel('ROIs');
ROISetps = 3;
yTicks = [1 (1 + ROISetps : ROISetps : nUniqueROIs - ROISetps) nUniqueROIs];
set(gca, 'YTick', 1 + yTicks, 'YTickLabel', ROINamesUniqueUnion(yTicks));
set(gca, 'XTick', 1 : nROISets, 'XTickLabel', dayIDs);
rotateXLabels(gca, 25);
ylim([-2.1 nUniqueROIs + 2.9]);
xlim([-0.1 nROISets + 1.1]);