function figHand = plotPeriStimAverage(axeH, PSCaTraces, t, stimIDs, saveName)

%% init
% get the size of the data set
[nStimTypes, nStims, ~, nPSFrames] = size(PSCaTraces);

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
end;

% color each trace by a specific color
if nStimTypes == 1;
    colors = [0 0 0];
    colorsLight = colors;
    colorsLight(colorsLight == 0) = 0.5;
    lineStyles = {'-'};
elseif nStimTypes == 2;
    colors = [0 0 0; 1 0 0];
    colorsLight = colors;
    colorsLight(colorsLight == 0) = 0.5;
    lineStyles = {'-', '-'};
elseif nStimTypes == 3;
    colors = [0.7 0.7 0.7; 0 0 0; 1 0 0;];
    colorsLight = colors;
    colorsLight(colorsLight == 0.7) = 0.85;
    colorsLight(colorsLight == 0) = 0.5;
    lineStyles = {'-.', '-', '-'};
else
    colors = jet(nStimTypes);
    colorsLight = colors;
    colorsLight(colorsLight == 0) = 0.5;
    lineStyles = [];
end;


%% average the traces
% average each ROI
PSCaTraceMeansTemp = reshape(nanmean(PSCaTraces, 3), [nStimTypes, nStims, nPSFrames]);
PSCaTraceErrorsTemp = reshape(nanmean(PSCaTraces, 3), [nStimTypes, nStims, nPSFrames]);
% average each stimulus
PSCaTraceMeans = reshape(nanmean(PSCaTraceMeansTemp, 2), [nStimTypes, nPSFrames]);
PSCaTraceErrors = nan(size(PSCaTraceMeans));
for iStimType = 1 : nStimTypes;
    PSCaTraceErrors(iStimType, :, 1, :) = nansem(squeeze(PSCaTraceErrorsTemp(iStimType, :, 1, :)));
end;
PSCaTraceErrors = reshape(PSCaTraceErrors, [nStimTypes, nPSFrames]);

%% plot
plotHands = cell(nStimTypes, 1);
legHandles = zeros(1, nStimTypes);
opengl software;
for iStim = 1 : nStimTypes;
    plotHands{iStim} = shadedErrorBar(t, PSCaTraceMeans(iStim, :), PSCaTraceErrors(iStim, :), [], 1, figHand, axeH);
    hold(axeH, 'on');
    set(plotHands{iStim}.mainLine, 'Color', colors(iStim, :), 'LineWidth', 2);
    if ~isempty(lineStyles); set(plotHands{iStim}.mainLine, 'LineStyle', lineStyles{iStim}); end;
    set(plotHands{iStim}.patch, 'FaceColor', colorsLight(iStim, :));
    set(plotHands{iStim}.edge, 'Color', colors(iStim, :));
    legHandles(iStim) = plotHands{iStim}.mainLine;
end;

set(axeH, 'LineWidth', 1.5, 'Box', 'off'); % defeat OpenGL border bug

yLimits = get(axeH, 'YLim');
yLimits(1) = min(yLimits(1), 0);
hStimLine = plot(axeH, [0 0], yLimits, 'Color', 'red', 'LineWidth', 2, 'LineStyle', '--');

% add the legends
% legend(axeH, stimIDs, 'Location', 'EastOutside');
hLeg = legend(axeH, [legHandles, hStimLine], [stimIDs, 'stim. onset'], 'Location', 'NorthWest', 'Orientation', 'Horizontal');
set(hLeg, 'Box', 'off'); % defeat OpenGL border bug

% axis labels and title
set(axeH, 'FontSize', 15, 'YLim', yLimits, 'XLim', t([1 end]));
ylabel(axeH, 'dFF/dRR [%]', 'FontSize', 15);
xlabel(axeH, 'Time [s]', 'FontSize', 15);
title(axeH, saveName, 'Interpreter', 'none', 'FontSize', 15);
hold(axeH, 'off');

%  makePrettyFigure(figHand);

end

