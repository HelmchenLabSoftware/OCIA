function figHand = plotPeriStimAverageHeatMap(axeH, PSCaTraces, t, stimIDs, saveName, ROINames, plotLimits, colorMapName)

%% init
% get the size of the data set
[nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces);

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
    axeParent = get(axeH, 'Parent');
end;

%% average the traces
% average each stimulus
PSCaTraceMeans = reshape(nanmean(PSCaTraces, 2), [nStimTypes, nROIs, nPSFrames]);

%% plot
% get the position of the initial axe
baseAxePosition = get(axeH, 'Position');
% hide the original axe
set(axeH, 'YTick', [], 'XTick', [], 'XColor', 'white', 'YColor', 'white');
% create a holder for the handles of the sub-axes
imAxeHandles = nan(nStimTypes, 1);
% create one sub-plot for each stimulus type
for iStimType = 1 : nStimTypes;
    % calculate the new position
    axePosition = baseAxePosition;
    axePosition(3) = (baseAxePosition(3) / (nStimTypes + 0.05)) * 0.98;
    axePosition(1) = baseAxePosition(1) + (iStimType - 1) * axePosition(3) * 1.02;
    % create the new axe
    imAxeHandles(iStimType) = axes('Parent', axeParent, 'Color', 'blue', 'Position', axePosition, 'Visible', 'off');
    % plot the matrix as heat map
    imagesc(t, 1 : nROIs, squeeze(PSCaTraceMeans(iStimType, :, :)), 'Parent', imAxeHandles(iStimType));
    % if there are plot limits, apply them
    if ~isempty(plotLimits);
        set(imAxeHandles(iStimType), 'CLim', plotLimits);
    end;
    % change the colormap
    colormap(imAxeHandles(iStimType), colorMapName); close(gcf);
    % remove ticks
    set(imAxeHandles(iStimType), 'YTick', []);
    % plot the stimulus line
    hold(imAxeHandles(iStimType), 'on');
    plot(imAxeHandles(iStimType), [0 0], [0 nROIs + 1], 'LineWidth', 1.5, 'LineStyle', '--', 'Color', 'red');
    % plot the stimulus ID
    text(0, -nROIs / 80, stimIDs{iStimType}, 'Color', 'red', 'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center', 'Parent', imAxeHandles(iStimType), 'FontSize', 12);
    hold(imAxeHandles(iStimType), 'off');
end;

% add the color bar on the last axe
hColBar = colorbar('peer', imAxeHandles(end));
set(get(hColBar, 'YLabel'), 'String', 'DFF/DRR [%]');
% compensate the width
colBarPos = get(hColBar, 'Position');
set(imAxeHandles(end), 'Position', get(imAxeHandles(end), 'Position') + [0 0 colBarPos(3) * 2 0]);
set(hColBar, 'Color', 'red');
% create the ROI label axe
textAxeH = axes('Parent', axeParent, 'Color', 'blue', 'Position', get(imAxeHandles(1), 'Position'), 'Visible', 'off', ...
    'XLim', get(imAxeHandles(1), 'XLim'), 'YLim', get(imAxeHandles(1), 'YLim'));
% add ROI labels
ROINamesFlipped = flipud(ROINames);
for iROI = 1 : nROIs;
    text(t(1) - (t(2) - t(1)), iROI, ROINamesFlipped{iROI}, 'Parent', textAxeH, 'HorizontalAlignment', 'right', ...
        'Interpreter', 'none', 'FontSize', 15 - (0.166 * nROIs));
end;
% link all these axes
linkaxes([imAxeHandles; textAxeH]', 'y');
% put the label axe at the bottom
restackAxes(textAxeH, 'bottom');

%{


sumEvoked = sum(ROIStats((baseFrames + 1) : end, 1 : end - 1, 1));
[~, sortIndex] = sort(-sumEvoked);
ROIStats = ROIStats(:, [sortIndex nROIs], :);

% reshape again to have all the frames for each stims in one row per ROI
ROIStatsPermuted = permute(ROIStats, [1 3 2]);
ROIStatsAligned = reshape(ROIStatsPermuted, nFrames * nStims, nROIs);
% ROIStatsMeanEvoked = reshape(ROIStatsMeanEvoked3DPermuted, nEvokedFrames * nStims, nROIs)';

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
end;

ROIStatsMean = nanmean(ROIStatsAligned, 2);
ROIStatsAligned = horzcat(ROIStatsAligned, ROIStatsMean);
stimLine = zeros(1, size(ROIStatsAligned, 1)) + max(ROIStatsAligned(:));
for iStim = 1 : nStims;
    stimStart = baseFrames + (iStim - 1) * nFrames;
    stimEnd = stimStart + round(stimDur * frameRate);
    stimLine(stimStart : stimEnd) = min(ROIStatsAligned(:));
end;
ROIStatsAligned = horzcat(stimLine', ROIStatsAligned);
% ROIStatsForROILabels = [ROISet(:, 1); 'mean'];

% colormap hot;
if isempty(plotLimits);
    imagesc(ROIStatsAligned', 'Parent', axeH);
else
%     imagesc(ROIStatsAligned', plotLimits, 'Parent', axeH);
    imagesc((0 : size(ROIStatsAligned, 1)) / frameRate, 1 : (nROIs + 1), ROIStatsAligned', 'Parent', axeH);
end;
% imagesc(ROIStatsForROIMean);
hColBar = colorbar('peer', axeH);
set(get(hColBar,'YLabel'), 'String', 'DFF/DRR [%]');

yLimits = [0.5 nROIs + 1.5];
set(axeH, 'ylim', yLimits);

set(axeH, 'YTick', []);
set(axeH, 'XTick', []);

% add line to separate stimuli
hold(axeH, 'on');
% iStimHandles = zeros(nStims, 1);
for iStim = 1 : nStims;
    plot(axeH, repmat((iStim * nFrames) / frameRate, 1, 2), yLimits, 'LineWidth', 4.5, 'Color', 'white');
%     iStimHandles(iStim) = plot(axeH, repmat((baseFrames + (iStim - 1) * nFrames) / frameRate, 1, 2), yLimits, ...
%         'LineWidth', 1.5, 'Color', 'blue', 'LineStyle', '--');
    text((baseFrames + (iStim - 1) * nFrames + 5) / frameRate, 1.05, stimIDs{iStim}, 'Color', 'white', ...
        'HorizontalAlignment', 'left', 'Parent', axeH, 'FontSize', 8);
end;
text(-0.02, 1.05, 'stim', 'Color', 'black', ...
        'HorizontalAlignment', 'right', 'Parent', axeH, 'FontSize', 8);
text(-0.02, nROIs + 0.05, 'NPil', 'Color', 'black', ...
        'HorizontalAlignment', 'right', 'Parent', axeH, 'FontSize', 8);
text(-0.02, nROIs + 1.05, 'mean', 'Color', 'black', ...
        'HorizontalAlignment', 'right', 'Parent', axeH, 'FontSize', 8);
% % add line to separate neuropil from the others
% if ~isROIMode;
%     plot(axeH, xLimits, [nROIs - 0.5 nROIs - 0.5], 'LineWidth', 2, 'Color', 'white');
% end;
% % add line to separate mean from the others
% plot(axeH, xLimits, [nROIs + 0.5 nROIs + 0.5], 'LineWidth', 2, 'Color', 'white');


% display all ticks
%{
frameStep = 5;
ticks = 0 : frameStep : (nFrames * nStims) - 1;
time = zeros(1, numel(ticks));
currentTime = -baseFrames / frameRate;
for iTick = 1 : numel(time);
     time(iTick) = currentTime;
     currentTime = currentTime + frameStep / frameRate;
     if currentTime > nEvokedFrames / frameRate;
         currentTime = 0;
     end;
 end;
%}

% only display first stim and then only the zeros
% frameStep = 5;
% ticks = [(1 : frameStep : nFrames + 1), (2 : nStims - 1) * nFrames - nEvokedFrames] - 0.5;
% time = [((0 : frameStep : nFrames + 1) - baseFrames) / frameRate, zeros(1, nStims - 2)];

%{
%% TODO: only mark 0 and 0.5 - hard coded shit that needs to change. we need to
% make ticks based on stimulus duration...
%
ticks = 1 : nStims * nFrames;
time = zeros(1, numel(ticks));
zeroCounter = nFrames - baseFrames;
for i = 1 : nStims * nFrames;
    zeroCounter = zeroCounter + 1;
    if zeroCounter == nFrames;
        ticks(i) = 0;
        time(i) = 4;
        time(i + baseFrames) = 6.5;
        zeroCounter = 0;
    end;
end;
ticks = find(time);
time = time(ticks) - 4;
% %}

set(axeH, 'XTick', ticks);
set(axeH, 'XTickLabel', time);
set(axeH, 'YTick', 1 : nROIs + 1);
set(axeH, 'YTickLabel', ROIStatsForROILabels);
% stimAxe = axes('Position', get(timeAxe, 'Position'), 'YAxisLocation', 'right', 'XAxisLocation', 'top');
% set(stimAxe, 'XLim', get(timeAxe, 'XLim'), 'YLim', get(timeAxe, 'YLim'));
% set(stimAxe, 'YTick', [], 'YTickLabel', []);
% set(stimAxe, 'XTick', ((0.5 : 1 : nStims + 0.5) * nFrames), 'XTickLabel', stimIDs);

%}

titleHandle = title(axeH, sprintf('%s, N = %d', saveName, N), 'Interpreter', 'none');
% hLeg = legend(iStimHandles, 'Orientation', 'horzontal', 'Location', 'SouthOutside', stimIDs);

% make the time axe the current axe
set(figHand, 'CurrentAxes', axeH)
hold(axeH, 'all');

% create and adjust the axes of the labels (ROI labels and stim)
labH = xlabel(axeH, 'Time [s]');
if isROIMode;
    ylabel(axeH, 'Stimulus');
else
    ylabel(axeH, 'ROIs');
end;

% makePrettyFigure(figHand);
set(axeH, 'FontSize', 8);
% set(stimAxe, 'FontSize', 8);
set(titleHandle, 'FontSize', 10);
set(labH, 'FontSize', 12);

% restack axes so that the trace axes is on top
restackAxes(axeH, 'top');

%}


end
