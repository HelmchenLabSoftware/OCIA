%% #OCIA:OCIA_startFunction_analysisPipeline
function OCIA_startFunction_analysisPipeline(this)

    % go to DataWatcher mode
    OCIAChangeMode(this, 'DataWatcher');

    if ischar(this.GUI.dw.DWWatchTypes);
        DWWatchTypesStr = this.GUI.dw.DWWatchTypes;
    elseif iscell(this.GUI.dw.DWWatchTypes);
        DWWatchTypesStr = ['|', sprintf('%s|', this.GUI.dw.DWWatchTypes{:})];
    else
        DWWatchTypesStr = '?';
    end;

    showMessage(this, sprintf(['Processing options: start function: %s, noGUI: %d, DWFilt: %s, ', ...
        'DWWatchTypes: %s, DWSkiptMeta: %d, preProcOptions: %s, rawOrLocal: %s.'], ...
        regexprep(mfilename(), 'OCIA_startFunction_', ''), this.GUI.noGUI, ...
        ['|', sprintf('%s|', this.GUI.dw.DWFilt{:})], DWWatchTypesStr, ...
        this.GUI.dw.DWSkiptMeta, ['|', sprintf('%s|', this.an.an.preProcOptions{:})], this.GUI.dw.DWRawOrLocal));

    % process the selected folder and extract the notebook informations
    DWProcessWatchFolder(this);

    if size(this.dw.table, 1) == 0;
        showWarning(this, 'OCIA:OCIAStartFunction:analysisPipeline:TableEmpty', 'Table is empty. Aborting');
        return;
    end;

    % if there are any filters for row type or run type, select them
    GUIDWFiltH = this.GUI.handles.dw.filt;
    if ~isempty(get(GUIDWFiltH.rowtype, 'String')) || ~isempty(get(GUIDWFiltH.runtype, 'String'));
        DWFilterSelectTable(this, 'new');
    end;

    ANAnalyseRows(this);
            
end
