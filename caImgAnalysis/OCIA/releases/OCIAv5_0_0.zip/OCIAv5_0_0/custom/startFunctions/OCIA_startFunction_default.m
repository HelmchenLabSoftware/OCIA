%% #OCIA:OCIA_startFunction_default
function OCIA_startFunction_default(this)

    OCIAChangeMode(this, 'DataWatcher');
    showMessage(this, sprintf('Welcome to the OCIA v%s !', this.version));
            
end
