%% #OCIA:DW:OCIA_getPreview_imgData
function RGBIm = OCIA_getPreview_imgData(this, iDWRow, previewType)

loadTic = tic; % for performance timing purposes
o('#%s: iDWRow: %d.', mfilename, iDWRow, 3, this.verb);

% default is empty
RGBIm = [];

% load the data in partial mode (only first couple frames)
DWLoadRow(this, iDWRow, 'partial');

% get the processed images
imgData = get(this, iDWRow, 'data');
preProcData = imgData.procImg.data;

% if some data was loaded
if ~isempty(preProcData);
    % compensate absent pre-processed data with raw data
    for iChan = 1 : numel(preProcData);
        if isempty(preProcData{iChan});
            preProcData{iChan} = imgData.rawImg.data{iChan};
        end;
    end;
    
    % get the color vector
    colVect = 1 : numel(preProcData);
    try colVect = this.an.img.colVect; catch err; end; %#ok<NASGU>
    % little "hack" so that if the comments say that the image was with a red/green filter cube, alter the color vector
    if regexp(get(this, iDWRow, 'comments'), 'red/green'); colVect = [1 2 0]; end;
    
    % create the RGB image, averaged or not depending on the preview type
    RGBIm = cell2RGB(preProcData, colVect, strcmp(previewType, 'preview'));
end;
            
o('#%s: iDWRow: %d done (%3.1f sec)', mfilename, iDWRow, toc(loadTic), 3, this.verb);

end
