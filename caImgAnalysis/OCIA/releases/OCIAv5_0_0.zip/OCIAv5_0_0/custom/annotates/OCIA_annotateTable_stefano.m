%% #OCIA:OCIA_annotateTable_stefano
function OCIA_annotateTable_stefano(this)

DWMatchROISetsToDataStefano(this);
DWExtractSpotIdentity(this);
DWDisplayTable(this);

% extract the spot's depth:
% get the spot folder pattern
spotPattern = char(this.dw.watchTypes{strcmp(this.dw.watchTypes.id, 'spot'), 6});
for iRow = 1 : size(this.dw.table, 1);
    if ~isempty(this.dw.table{iRow, 7}) && strcmp(DWGetRowType(this, iRow), 'imgData');
        spotLabel = regexp(this.dw.table{iRow, 7}, spotPattern, 'names');
        if ~isempty(spotLabel);
            depth = str2double(spotLabel.depth);
            if depth < 500;
                this.dw.table{iRow, 8} = '500-';
            elseif depth < 600;
                this.dw.table{iRow, 8} = '500+';
            elseif depth < 700;
                this.dw.table{iRow, 8} = '600+';
            elseif depth < 800;
                this.dw.table{iRow, 8} = '700+';
            elseif depth < 900;
                this.dw.table{iRow, 8} = '800+';
            elseif depth < 1000;
                this.dw.table{iRow, 8} = '900+';
            else
                this.dw.table{iRow, 8} = '1000+';
            end;
        end;
    end;
end;

end
