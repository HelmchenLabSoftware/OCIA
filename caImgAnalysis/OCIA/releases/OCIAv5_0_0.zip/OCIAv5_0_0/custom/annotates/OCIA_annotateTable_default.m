%% #OCIA:OCIA_annotateTable_default
function OCIA_annotateTable_default(this)

% extract the notebook's informations
DWExtractNotebookInfo(this);
DWDisplayTable(this); % display the table
        
% check if the processing should be aborted
if DWCheckProcessAbort(this, [], []); return; end;

% if there is behavior data to process
if ismember('behav', this.dw.dataModes) && size(DWFilterTable(this, 'rowType = Behavior data'), 1) > 0;            
    % match the behavior trial numbers to the imaging data
    DWMatchBehavTrialsToImagingData(this);    
end;

% check if the processing should be aborted
if DWCheckProcessAbort(this, [], []); return; end;
    
% match the ROISets to the data
DWMatchROISetsToData(this);
DWDisplayTable(this); % display the table

end
