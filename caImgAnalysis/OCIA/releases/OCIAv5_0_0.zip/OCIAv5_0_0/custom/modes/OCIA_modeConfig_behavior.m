function [this, inputParams] = OCIA_modeConfig_behavior(this)
% adds the behavior mode to the OCIA

inputParams = [];

%% -- properties: path: Behavior
docPath = 'C:/Users/laurenczy/Documents';
% path of the behavior configuration mat-file
this.path.behavConf = sprintf('%s/LabVIEW Data/mainConf.mat', docPath);
% path where the behavior data should be saved
this.path.behavSave = sprintf('%s/LabVIEW Data/%s/', docPath, datestr(date, 'yyyy_mm_dd'));

%% -- properties: GUI: Behavior
this.GUI.be = struct();
% update rate of the GUI elements in second
this.GUI.be.updateRate = 1;
% update rate of the trial while-loop when in paused mode (avoids full-speed looping)
this.GUI.be.trialLoopUpdateRate = 0.3;
% handle for the GUI updating timer object
this.GUI.be.updateTimer = [];
% currently selected behavior configuration row
this.GUI.be.selConfigRow = [];
% names of the behavior auto-reward modes
this.GUI.be.autoRewModes = { 'EarlyOn', 'On', 'Auto', 'Off' };
% names of the behavior configiguration table's columns
this.GUI.be.confTableColNames = { 'AnimalID', 'TaskType', 'Phase' };
% widths of the behavior animal config table's columns
this.GUI.be.confTableColW = { 0.4 0.4 0.2 };
% names of the behavior experiment table's columns
this.GUI.be.expTableColNames = { 'Prev.', 'Curr.', 'Next' };
% widths of the behavior experiment table's columns
this.GUI.be.expTableColW = { 0.22 0.21 0.21 0.21 };
% names of the behavior experiment table's rows
this.GUI.be.expTableRowNames = { 'iTrial', 'Freq', 'Target', 'Response', 'Resp. Time', 'Correct', 'Reward' };
% analog input's magnification factor on the behavior monitoring plot
this.GUI.be.anInMagnifs = [3 20 30 70];
% analog input's filtering options on the behavior monitoring plot
this.GUI.be.anInFilt = [0 11 0 3];
% analog input's absolute-apply options on the behavior monitoring plot
this.GUI.be.anInDoAbs = [0 0 0 1];
% y plot limits for the behavior mode's monitoring plot
this.GUI.be.monPlotLimits = [-3.1, 3.1];
% analog input's display color on the behavior monitoring plot
this.GUI.be.anInColors = { 'b', 'g', 'c', 'r' };

%% - properties: Behavior
this.be = struct();
% enables to run the behavior software for testing with no actual device connected to the computer
this.be.debugMode = 0;
% version number
this.be.version = '2.2';
% room ID where the behavior is being done (allows different hardware configuration for each room)
this.be.room = '';
% timing storage
this.be.times = struct();
% defines whether the behavior experiment is running or not
this.be.isRunning = false;
% defines whether the behavior experiment is paused or not
this.be.isPaused = false;
% defines whether the behavior experiment has to be reset or not
this.be.isToReset = false;
% defines whether the behavior configuration is loaded or not
this.be.configLoaded = false;
% current index of trial, incremented every new trial
this.be.iTrial = 0;
% currently used/loaded behavior configuration
this.be.config = [];
% "main" or "parent" configuration structure containing all configurations -(content of mainConf.mat)
this.be.configs = [];
%% -- properties: Behavior: Hardware
this.be.hw = struct();
% hardware configure structure, loaded in a room-dependent manner
this.be.hw.conf = [];
% defines whether the hardware is connected or not
this.be.hw.connected = false;
% analog input channels, loaded using the hardware configure structure
this.be.hw.analogIns = { 'yscan', 'motion', 'micr', 'piezo' };
% digital output channels, loaded using the hardware configure structure
this.be.hw.digitalOuts = { 'valve', 'airPuff' };
% analog output channels, loaded using the hardware configure structure
this.be.hw.analogOuts = { 'imagTTL' };
% number of samples to record from the analog input channels
this.be.hw.sampToRec = 200;
% maximum record duration before the recorded data is flushed, only when behavior experiment is not running
this.be.hw.maxRecDur = 25;
% analog input channels' fixed sampling rate
this.be.hw.anInSampRate = 3000;
% analog output channels' fixed sampling rate
this.be.hw.anOutSampRate = 3000;
%% -- properties: Behavior: Params
% threshold for the piezo-sensor "activation" detection (e.g. licking event)
this.be.params.piezoThresh = 0.007;
% valve opening time in seconds ("reward duration")
this.be.params.rewDur = 0.02;
% valve opening time in seconds ("punishment duration")
this.be.params.punishDur = 0.5;
% current mode of rewarding
this.be.params.autoRewardMode = 'Auto';
% time between the imaging end and the trial end in seconds
this.be.params.imgEndStopTime = 3;
   


end
