function [this, inputParams] = OCIA_config_analysis_H6403b(this)

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

%% - input parameters
% inputParams.startFunctionName = 'behaviorSummary';
inputParams.startFunctionName = 'dataWatcher';

this.GUI.noGUI = false;
% this.GUI.dw.DWFilt = { 'mou_bl_140515_01', '2014_06_03', 'spot01', 'imgData', 'B' };
% this.GUI.dw.DWFilt = { 'mou_bl_140730_01', '2014_08_13', 'spot01', 'imgData', 'B' };
% this.GUI.dw.DWFilt = { 'mou_bl_140730_01', '2014_08_13', '-', 'imgData', 'B' };
this.GUI.dw.DWFilt = { 'mou_bl_141001_01', '2014_10_16', 'spot01' };
% this.GUI.dw.DWFilt = { 'mou_bl_141001_01', '-', '-', 'Behavior data' };
% this.GUI.dw.DWWatchTypes = { 'animal', 'day' };
% this.GUI.dw.DWWatchTypes = { 'animal', 'day', 'behav' };
this.GUI.dw.DWWatchTypes = 'all';
this.GUI.dw.DWSkiptMeta = false;
this.GUI.dw.DWRawOrLocal = 'local';

this.an.an.preProcOptions = { 'skipFrame', 'fShift', 'fJitt', 'moCorr', 'moDet' };

%% - properties: GUI
% initial position of the main window
% this.GUI.pos = [1950, 175, 1220, 805];
% this.GUI.pos = [100, 175, 1220, 805];
this.GUI.pos = [1920, 1, 1280, 1000];

%% - properties: general
% verbosity, number telling how much debugging output should be printed out. The higher the more verbose.
this.verb = 2;

%% -- properties: general: paths to relevant locations (raw data, ect.)
% path of the raw data (usually stored on the server)
this.path.rawData = 'Z:/RawData/Balazs_Laurenczy/2014/2014_chronic/1410_chronic/';
% path of the local data
this.path.localData = 'F:/RawData/1410_chronic/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'E:/Analysis/1410_chronic/';

end
