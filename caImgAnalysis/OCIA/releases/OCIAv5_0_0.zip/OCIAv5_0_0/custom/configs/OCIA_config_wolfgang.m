function [this, inputParams] = OCIA_config_wolfgang(this)

this.GUI.modes = { 'DataWatcher', 'dw'; 'JointTracker', 'jt' };

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

this.data = struct();

inputParams.startFunctionName = 'jointtracker';
this.dw.preProcessFunctionName = 'jointtracker';

% path of the raw data (usually stored on the server)
this.path.rawData = 'W:/RawData/';
% path of the local data
this.path.localData = 'F:/RawData/Wolfgang/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'E:/Analysis/Wolfgang/';

% initial position of the main window
this.GUI.pos = [1950, 175, 1220, 805];

% mini-hack: check computerID and eventually change things
[~, rawComputerID] = system('hostname');
if strcmp(genvarname(rawComputerID), 'OoPC');
    this.path.localData = 'D:/Users/BaL/PhD/RawData/Wolfgang/';
    this.path.OCIASave = 'D:/Users/BaL/PhD/Analysis/Wolfgang/';
    this.GUI.pos = [330, 185, 1220, 805];
elseif strcmp(genvarname(rawComputerID), 'Oo0x2Elocal');
    this.path.localData = '/Users/BaL/Documents/RawData/Wolfgang/';
    this.path.OCIASave = '/Users/BaL/Documents/Analysis/Wolfgang/';
    this.GUI.pos = [330, 185, 1220, 705];
end;

this.GUI.dw.DWFilt = { '2013_09_10', '00_28_21' };
% this.GUI.dw.DWFilt = { '2013_09_10', '00_10_52' };
this.GUI.dw.DWWatchTypes = 'all';
this.GUI.dw.DWSkiptMeta = false;
this.GUI.dw.DWRawOrLocal = 'local';

%% -- properties: DataWatcher: WatchTypes
% defines the aspect of the filtering panel: cell array with nFilt lines and 
%   5 columns: { filter name, GUI type, GUI width and DataWatcher table's column column where to apply the filter, supports range }
this.GUI.dw.filtElems = { 
    'day',      'dropdown',     1,    2,  false;
    'time',     'textfield',    1,    3,  false;
    'movies',   'textfield',    1,    1,  false;
};
% specifies which further processing step buttons are available as a cell array with 4 columns: { ID, label, tag, 
%   tooltip }
this.GUI.dw.processButtons = { ...
    'trackMovies',  'Track movie(s)',       'DWTrackMovies',    'Track movies of selected rows';
};

%% -- properties: DataWatcher : watch types
% file/folder types that can be processed and will appear in the DataWatcher's table with their regexp pattern, stored as a 
%   cell-array with 6 columns: { ID, display name, parent folder, visible in GUI, tooltip text, regular expression pattern }
this.dw.watchTypes = cell2table({
    'day',          'Day',          [],         true,   'Day folder',               '^\d{4}_\d{2}_\d{2}$';
    'trackmovie',   'TrackMovie',   'day',      true,   'TrackMovie file',          '^Trial_(?<date>\d{8})(?<time>\d{6})';
}, 'VariableNames', { 'id', 'label', 'parent', 'visible', 'tooltip', 'pattern' });

%% -- properties: DataWatcher : watch type file patterns
% file patterns for files inside "watchType" folders (these are kind of "sub-watchTypes")
this.dw.watchTypeFilePatterns = struct();

%% -- properties: DataWatcher : data configuration
% defines which data "modules" should be appended to the software
this.dw.dataModes = { };
% defines the data saving options for each "type" of saving as a cell-array with 3 columns: { ID, label, tooltip text }
this.dw.dataConfig = { ...
    'GUI',      'GUI',              'Save / load the GUI (table, checkboxes'' values, etc.)';
    'raw',      'Raw data',         'Save / load the raw data';
    'preProc',  'Pre-proc. data',   'Save / load the pre-processed data';
};

% apply data configuration
configHandle = str2func('OCIA_modeConfig_data');
this = configHandle(this);

%% - properties: DataWatcher : filter IDs
% define the "IDs" field for each drop-down DataWatcher filter element
dropDownListFilterNames = this.GUI.dw.filtElems(strcmp(this.GUI.dw.filtElems(:, 2), 'dropdown'), 1);
for iName = 1 : numel(dropDownListFilterNames);
    filtName = dropDownListFilterNames{iName}; % get the filter name
    % create a list with only a dash element, which corresponds to no filtering
    this.dw.([filtName 'IDs']) = {'-'};
end;

%% - properties: JointTracker
% joints as a cell-array with one row per joint and 8 columns: 
%   { 1: name, 2: is virtual [0/1], 3: window size [pixels], 4: distance to previous and next joint [pixels], 
%       5: flexibility in the distances to the next/previous joint [1 - 3], 6: find joint method, 
%       7: and pre-processing settings, 8: joint size }
% The different methods to find the peaks are : { xcorr_ref, xcorr_gauss, xcorr_comb }
this.jt.jointConfig = {
    
    'scapula',  0,  [16, 24;   20, 30;   40 60],    [NaN, 78],  1,      'xcorr_comb',   'smallMoveJoint',       [11 11];
    'shoulder', 0,  [19, 20;   24, 25;   48, 50],   [78, 79],   1,      'xcorr_comb',   'smallMoveJoint',       [11 11];
    'elbow',    1,  [],                             [79, 60],   0,      '',             '',                     [0 0];
    'wrist',    0,  [50, 40;   90, 70;   150, 140], [60, 24],   1,      'xcorr_comb',   'bigMoveWristJoint',    [9 7];
    'MCP',      0,  [50, 34;   80, 60;   130, 120], [24, 29],   1.2,    'xcorr_comb',   'bigMoveJoint',         [7 5];
    'finger',   0,  [50, 34;   80, 60;   130, 120], [29, NaN],  1.3,    'xcorr_comb',   'bigMoveJoint',         [7 7];
    
};
this.jt.nJoints = size(this.jt.jointConfig, 1);
% order in which joints should be processed
this.jt.jointProcessOrder = [2 1 4 5 6 3];


end
