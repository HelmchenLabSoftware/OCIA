function [this, inputParams] = OCIA_config_OoPC(this)

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

%% - input parameters
inputParams.startFunctionName = 'dataWatcherLoadAnalyse';
% inputParams.startFunctionName = 'processAndSavePipeline';

this.GUI.noGUI = false;
% this.GUI.dw.DWFilt = { 'mou_bl_140515_01', '2014_06_03', 'spot01', 'imgData', 'B' };
% this.GUI.dw.DWFilt = { 'mou_bl_141001_02', '-', '-', 'Behavior data', '' };
this.GUI.dw.DWFilt = { 'mou_bl_141001_01', '2014_10_16', 'spot01', 'Imaging data', 'runType = Trial' };
% this.GUI.dw.DWFilt = { 'mou_bl_141001_02', '2014_10_16', 'spot01', '', '' };
this.GUI.dw.DWWatchTypes = 'all';
% this.GUI.dw.DWWatchTypes = { 'animal', 'day', 'behav' };
this.GUI.dw.DWSkiptMeta = false;
this.GUI.dw.DWRawOrLocal = 'local';

%% - properties: GUI
% initial position of the main window
this.GUI.pos = [690, 190, 1220, 805]; 

%% - properties: general
% verbosity, number telling how much debugging output should be printed out. The higher the more verbose.
this.verb = 2;

%% -- properties: general: paths to relevant locations (raw data, ect.)
% path of the raw data (usually stored on the server)
this.path.rawData = 'D:/Users/BaL/PhD/RawData/1410_chronic/';
% path of the local data
this.path.localData = 'D:/Users/BaL/PhD/RawData/1410_chronic/';
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'D:/Users/BaL/PhD/Analysis/1410_chronic/';

end
