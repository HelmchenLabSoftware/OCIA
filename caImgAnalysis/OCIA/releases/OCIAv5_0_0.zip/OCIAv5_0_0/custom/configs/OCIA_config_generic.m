function [this, inputParams] = OCIA_config_generic(this)

inputParams = [];

% %% - properties: DataWatcher
% % define structures
% this.dw = struct();
% this.GUI.dw = struct();
% % display settings for each column of the DataWatcher's table
% this.GUI.dw.tableDisplay = cell2table({ ...
% ...     id              label               order   width   visible     description
%         'rowNum',       'Row',              01,     0.025,  true,       'Row number'; ...
%         'animal',       'Animal',           02,     0.090,  true,       'Animal ID'; ...
%         'spot',         'Spot',             03,     0.035,  true,       'Spot ID'; ...
%         'day',          'Day',              04,     0.058,  true,       'Day'; ...
%         'time',         'Time',             05,     0.052,  true,       'Time'; ...
%         'nFiles',       'N. files',         06,     0.040,  true,       'Number of files in the folder'; ...
%         'dim',          'Dimension',        07,     0.080,  true,       'Dimension of the data'; ...
%         'rowType',      'Row type',         08,     0.075,  true,       'Row type or data type (imaging, behavior, ROISet, etc.)'; ...
%         'runType',      'Run type',         09,     0.050,  true,       'Run type (which stimulus was used, etc.)'; ...
%         'runNum',       'Run number',       10,     0.030,  true,       'Run number (or trial number)'; ...
%         'ROISet',       'ROISet',           11,     0.085,  true,       'ROISet''s ID'; ...
%         'data',         'Data',             12,     0.150,  true,       'Data associated with this row'; ...
%         'imType',       'Image type',       13,     0.035,  true,       'Image type (movie, frame, stack, etc.)'; ...
%         'laserInt',     'Laser intensity',  14,     0.035,  true,       'Laser intensity in percent'; ...
%         'zoom',         'Zoom factor',      15,     0.035,  true,       'Zoom factor'; ...
%         'frameRate',    'Frame rate',       16,     0.035,  true,       'Imaging frame rate'; ...
%         'zStep',        'Z-step',           17,     0.035,  true,       'Z-step for the stacks'; ...
%         'comments',     'Comments',         18,     0.150,  true,       'Comments'; ...
%         'path',         'Path',             19,     0.320,  true,       'Full path to the folder/file/data'; ...
% ...        
%     }, 'VariableNames', { 'id', 'label', 'order', 'width', 'visible', 'description' });
% this.GUI.dw.tableDisplay.Properties.RowNames = this.GUI.dw.tableDisplay.id; % make the ID be the row names
% % Matlab "table"-object holding the current data set (from the watch folder's content), displayed in a big table
% this.dw.table = cell2table(cell(100, size(this.GUI.dw.tableDisplay, 1)), 'VariableNames', this.GUI.dw.tableDisplay.id);
% % currently selected (highlighted) database row. Empty if none selected
% this.dw.selectedTableRows = [];
% % pattern to use to built the DataWatcher table rows' IDs
% this.dw.rowIDPattern = '%s_%s';
% % columns from the DataWatcher table to use to built the DataWatcher table rows' IDs using the specified pattern,
% %   including the replace patterns for each column.
% this.dw.rowIDColumns = cell2table({ ...
% ...     id              replaceSourcePattern    replaceTargetPattern
%         'day',          '_',                    '';
%         'time',         '_',                    '';
% }, 'VariableNames', { 'id', 'replaceSourcePattern', 'replaceTargetPattern'} );
% % path to the folder to 'watch' for data
% this.dw.watchFolder = '';
% % defines whether the watch folder should be automatically processed upon changing its path
% this.dw.autoProcessWatchFolder = false;
% % defines whether a warning of data flushing upon watch folder change should be displayed or not
% this.dw.ignoreDataFlushWarning = true;
% % HDF5 saving compression level. If empty or 0, no compression at all, otherwise specify values 
% %   between 1 (best speed) and 9 (best compression)
% this.dw.HDF5GZipLevel = [];
% % data "types" that are to be flushed between runs once they are saved to avoid memory overflow
% this.dw.savedDataToFlushBetweenRuns = { };
% % specifies whether to overwrite the file where the data will be saved
% this.dw.overwriteSaveFile = false;
% % specifies whether to overwrite already saved data (within an existing file) when saving it to HDF5
% this.dw.overwriteHDF5Data = true;
% % specifies which data should be saved in a HDF5 file
% this.dw.dataAsHDF5 = { 'raw', 'preProc', 'caTraces', 'ROISets', 'stim', 'behav' };
% % specifies which data should be saved in a .mat file
% this.dw.dataAsMat = { };
% % defines the maximum number of frames to load for the preview loading type
% this.dw.previewNMaxFrameToLoad = 100;
% % tells which parts of the raw path should be used for the saving
% this.dw.savePathParts = [1, 3, 2];
% % name of the function that do post-processing after the notebook file parsing
% this.dw.annotateTableFunctionName = 'default';
% % name of the function that parses the notebook file
% this.dw.notebookParsingFunctionName = 'default';
% % name of the function that do pre-processing of the selected rows
% this.dw.preProcessFunctionName = 'default';
% 
% %% -- properties: GUI: DataWatcher
% % string that is displayed for the cells of the DataWatcher's table that are empty
% this.GUI.dw.tableEmptyCellDisplayContent = '-';
% % defines whether to show a summary line for folders that were not processed
% this.GUI.dw.showEmptyFolderSummary = true;
% % defines whether to show a small thumbnail of the currently selected row
% this.GUI.dw.showThumbnailPreview = true;
% % defines whether to show or not a GUI
% this.GUI.noGUI = false;
% % defines which filter settings should be active at start
% this.GUI.dw.DWFilt = { };
% % defines which watch types should be activated at start
% this.GUI.dw.DWWatchTypes = { };
% % defines whether to skip meta-data processing
% this.GUI.dw.DWSkiptMeta = true;
% % defines whether to use the raw or local watch folder
% this.GUI.dw.DWRawOrLocal = 'local';
% % list of buttons that are available to further process the data, as a table array with 4 columns: { ID, label, tag, 
% %   tooltip }
% this.GUI.dw.processButtons = cell2table({ ...
% ...     id              label               	tag                 tooltip
%         'drawROIs',     'Draw ROIs',            'DWDrawROIs',       'Draw Regions Of Interest for selected rows';
%         'preProcRows',  'Pre-process row(s)',   'DWPreProcRows',    'Pre-process selected rows';
%         'analyseRows',  'Analyse row(s)',       'DWAnalyseRows',    'Analyse selected rows';
% }, 'VariableNames', { 'id', 'label', 'tag', 'tooltip' });
% this.GUI.dw.processButtons.Properties.RowNames = this.GUI.dw.processButtons.id; % make the ID be the row names
% 
% %% -- properties: DataWatcher : watch types
% % file/folder types that can be processed and will appear in the DataWatcher's table with their regexp pattern, stored
% %   as a table with 6 columns: { ID, label, parent watch type's ID, visible in GUI, tooltip text, 
% %   regular expression pattern }
% this.dw.watchTypes = cell2table({
% ...     id              label               parent    	visible     tooltip                     pattern
%         'animal',       'Animal',           [],         true,       'Animal folder',            '^(?<animal>mou_[db]l_\d{6}_\d{2})$';
%         'day',          'Day',              'animal',   true,       'Day folder',               '^(?<day>\d{4}_\d{2}_\d{2})$';
%         'spot',         'Spot',             'day',      true,       'Spot folder',              '^(?<spot>spot\d{2})$';
%         'img',          'Imaging data',     'spot',     true,       'Imaging data folder',      '^(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h$';
%         'notebook',     'Notebook',         'day',      true,       'Notebook file',            '^notebook__(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}h_\d{2}m)\.txt$';
%         'behav',        'Behavior data',    'day',      true,       'Behavior data folder',     '^behav$';
%         'roiset',       'ROISet',           'day',      true,       'ROISet folder',            '^ROISets$';
%         'intrinsic',    'Intrinsic',        'day',      true,       'Intrinsic folder',         '^intr(Fourier)?_?(?<day>\d{4}_\d{2}_\d{2})?$';
% }, 'VariableNames', { 'id', 'label', 'parent', 'visible', 'tooltip', 'pattern' });
% this.dw.watchTypes.Properties.RowNames = this.dw.watchTypes.id; % make the ID be the row names
% % create a variable in the table for file patterns for files inside "watchType" folders (these are 
% %   kind of "sub-watchTypes") and fill-in the sub-file patterns for each required watch type:
% this.dw.watchTypes.subFilePatterns = cell(size(this.dw.watchTypes, 1), 1);
% % imaging data
% this.dw.watchTypes{'img', 'subFilePatterns'} = { cell2table({ ...
% ...     id                  label                   createNewRow    pattern
%         'imgMeta',          'Imaging meta-data',    false,          '^(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h\.xml$';
%         'imgDataBin',       'Imaging data',         false,          '^(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h__channel_?(?<iChan>\d+)\.bin$';
%         'imgDataTif',       'Imaging data',         false,          '^(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h__channel_?(?<iChan>\d+)\.tif$';
% }, 'VariableNames', { 'id', 'label', 'createNewRow', 'pattern' }) };
% % behavior data
% this.dw.watchTypes{'behav', 'subFilePatterns'} = { cell2table({ ...
% ...     id                  label                   createNewRow    pattern
%         'behavData',        'Behavior data',        true,           '^Behavior_(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})\.mat$';
%         'behavMovie',       'Behavior movie',       true,           '^(?<day>\d{4}-\d{2}-\d{2}) (?<time>\d{2}-\d{2}-\d{2}\.\d{3})\.wmv$';
% }, 'VariableNames', { 'id', 'label', 'createNewRow', 'pattern' }) };
% % ROISet
% this.dw.watchTypes{'roiset', 'subFilePatterns'} = { cell2table({ ...
% ...     id                  label                   createNewRow    pattern
%         'ROISetMatFile',    'ROISet',               true,           '^ROISet_(?<day>\d{4}_\d{2}_\d{2})__(?<time>\d{2}_\d{2}_\d{2})h\.mat$';
% }, 'VariableNames', { 'id', 'label', 'createNewRow', 'pattern' }) };
% % intrinsic imaging data
% this.dw.watchTypes{'intrinsic', 'subFilePatterns'} = { cell2table({ ...
% ...     id                  label                           createNewRow    pattern
%         'intrBinary',       'Intrinsic data (standard)',    true,           '^intr(?<runNum>\d+)_(?<comments>[\w\d_]+)$';
%         'intrFourier',      'Intrinsic data (fourier)',     true,           '^intr(?<runNum>\d+)_?(?<comments>[\w\d_]+)?\.mat$';
%         'intrScreen',       'Intrinsic screenshot',         true,           '^intr(?<runNum>\d+)_(?<comments>[\w\d_]+)\.png$';
%         'intrVessel',       'Intrinsic reference',          true,           '^vessels(?<runNum>\d+)?\.tif$';
% }, 'VariableNames', { 'id', 'label', 'createNewRow', 'pattern' }) };
% 
% %% -- properties: DataWatcher : data configuration
% % defines which data "modules" should be appended to the software
% this.dw.dataModes = { 'img'; 'behav'; };
% % defines the maximum number of runs to store (can be extended)
% this.dw.dataNMaxRuns = 300;
% % defines the data saving options for each "saving type" as a table with 3 columns: { ID, label, tooltip text }
% this.dw.dataConfig = cell2table({ ...
% ...     id          label               tooltip
%         'GUI',      'GUI',              'Save / load the GUI (table, checkboxes'' values, etc.)';
%         'raw',      'Raw data',         'Save / load the raw data';
%         'preProc',  'Pre-proc. data',   'Save / load the pre-processed data';
%         'caTraces', 'Calcium traces',   'Save / load the extracted calcium traces';
%         'exclMask', 'Exclusion masks',  'Save / load the exclusion masks (from motion detection)';
%         'stim',     'Stimulus'          'Save / load the stimulus vectors for the calcium traces';
%         'ROISets',  'ROISets',          'Save / load the ROISets';
%         'behav',    'Behavior data',    'Save / load the behavior data';
% }, 'VariableNames', { 'id', 'label', 'tooltip'});
% this.dw.dataConfig.Properties.RowNames = this.dw.dataConfig.id; % make the ID be the row names
% 
% % defines the data saving general options as a table with 3 columns: { ID, label, tooltip text }
% this.dw.dataSaveOptionsConfig = cell2table({ ...
% ...     id                  label                           tooltip
%         'loadBefSave',      'Fully load before save',       'Fully load the data from the raw files before saving to HDF5 (save-mode only)';
%         'preProcBefSave',   'Pre-process before save',      'Pre-process the data before saving it to HDF5 (save-mode only)';
%         'SLRSelOnly',       'Use selection only',           'Save / load / reset only the selected rows';
% }, 'VariableNames', { 'id', 'label', 'tooltip'});
% this.dw.dataSaveOptionsConfig.Properties.RowNames = this.dw.dataSaveOptionsConfig.id; % make the ID be the row names
% 
% %% -- properties: DataWatcher: filter elements and IDs
% % defines the aspect of the filtering panel as a table with one row per filter and 5 columns: 
% %   { ID, GUI element's type, GUI width and DataWatcher's table column where to apply the filter, supports range }
% this.GUI.dw.filtElems = cell2table({ ...
% ...     id          GUIType         width   DWTableID   rangeSupport
%         'animal',   'dropdown',     1,      'animal',   false;
%         'day',      'dropdown',     1,      'day',      false;
%         'spot',     'dropdown',     1,      'spot',     false;
%         'rowtype',  'textfield',    1,      'rowType',  false;
%         'runtype',  'textfield',    0.5,    'runType',  false;
%         'runindex', 'textfield',    0.5,    'runNum',   true;
%         'status',   'textfield',    1,      'status',   false;
% }, 'VariableNames', { 'id', 'GUIType', 'width', 'DWTableID', 'rangeSupport' });
% this.GUI.dw.filtElems.Properties.RowNames = this.GUI.dw.filtElems.id; % make the ID be the row names

end
