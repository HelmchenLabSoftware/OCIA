function [this, inputParams] = OCIA_config_ROIDrawer_H6403b(this)

% get the default configuration
configHandle = str2func('OCIA_config_default');
[this, inputParams] = configHandle(this);

% define some path
currentDir = regexprep(pwd(), '\\', '/');

%% - input parameters
inputParams.startFunctionName = 'drawer';

this.GUI.noGUI = false;
this.GUI.dw.DWFilt = { 'mou_bl_140109_01', '2014_02_19', 'spot01', 'ROISet', 'RS' };
this.GUI.dw.DWWatchTypes = 'all';
this.GUI.dw.DWSkiptMeta = false;
this.an.an.preProcOptions = { 'skipFrame', 'fShift', 'fJitt', 'moCorr' };
this.GUI.dw.DWRawOrLocal = 'local';

%% - properties: GUI
% initial position of the main window
this.GUI.pos = [345, 285, 1220, 805]; % default

%% - properties: general
% verbosity, number telling how much debugging output should be printed out. The higher the more verbose.
this.verb = 2;
%% -- properties: general: paths to relevant locations (raw data, ect.)
% path of the raw data (usually stored on the server)
this.path.rawData = 'W:/Scratch-02 no Backup/RawDataBalazs/2014_chronic/1402_chronic/';
% path of the local data
this.path.localData = 'F:/RawData/'; % HIFOWSH640x2D03b
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = 'E:/Analysis/'; % HIFOWSH640x2D03b
% path of the behavior configuration mat-file
this.path.behavConf = sprintf('%s/mainConf.mat', currentDir); % default
% path where the behavior data should be saved
this.path.behavSave = sprintf('%s/%s/', currentDir, datestr(date, 'yyyy_mm_dd')); % default

%% - properties: GUI: ROIDrawer
% default size of the first empty left and right images
this.GUI.rd.defaultImDim = 200;
% the different tools for the ROIDRawer
this.GUI.rd.drawTools = { 'ellipse', 'freehand' };

%% - properties: ROIDrawer
% number of pixels/units to move ROIs when adjusting the position of all ROIs at the same time
this.rd.moveROIsStep = 1;

end
