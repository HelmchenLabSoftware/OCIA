%% #OCIA:AN:OCIA_analysis_caTraces_heatMap
function OCIA_analysis_caTraces_heatMap(this, iDWRows)

%% plotting parameter UI controls       
this.GUI.an.analysisParamConfig = { ...
    'img', 'sgFiltFrameSize',   'text',     'numeric',      [1 1 0],    'Savitzky-Golay filter',    'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'img', 'stimIDs',           'text',     'cellArray',    [1 1 0],    'Stimulus IDs',             '';
    'img', 'plotLimits',        'text',     'array',        [1 1 0],    'Plot limits',              '';
    'img', 'colormap',          'dropdown', { 'gray', 'hot', 'whitetoblack' }', [1 1 0], 'Colormap', '';
    'img', 'selROINames',       'list',     { },            [4 1 1],    'Selected ROIs',            '';
};

%% get the imaging data
ANShowHideMessage(this, 1, 'Loading data ...');
loadDataTic = tic; % for performance timing purposes
% get the calcium traces
[~, ~, ROINames, concatCaTraces, concatStims, ~, ~, allROINames] = OCIA_analysis_getCaTracesMatrix(this, iDWRows, this.an.img.selROINames);
% set the ROINames in the param. config to be displayed
this.GUI.an.analysisParamConfig{end, 4} = allROINames;
% get the size of the dataset
[nROIs, nConcatFrames] = size(concatCaTraces);
showMessage(this, sprintf('Loading data done (%3.1f sec).', toc(loadDataTic)));

%% prepare data
% get the filtering parameter
SGFiltSize = this.an.img.sgFiltFrameSize;
% apply filtering if required
if SGFiltSize > 1;
    concatCaTracesSGFilt = nan(size(concatCaTraces));
    for iROI = 1 : nROIs;
        concatCaTracesSGFilt(iROI, :) = sgolayfilt(concatCaTraces(iROI, :), 1, SGFiltSize);
    end;
% use the raw traces otherwise
else
    concatCaTracesSGFilt = concatCaTraces;
end;

% create a time vector
t = (1 : nConcatFrames) / this.an.img.defaultFrameRate;

%% plot
plotCaTracesHeatMap(this.GUI.handles.an.axe, 0, '', [], concatCaTracesSGFilt, concatStims, ...
    this.an.img.stimIDs, ROINames, t, [], this.an.img.plotLimits, this.an.img.colormap);

% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');

end
