%% #OCIA:AN:OCIA_analysis_PSAvg_basic
function OCIA_analysis_PSAvg_basic(this, iDWRows)

%% plotting parameter UI controls       
this.GUI.an.analysisParamConfig = { ...
    'img', 'sgFiltFrameSize',   'text',     'numeric',      [1 1 0],    'Savitzky-Golay filter',    'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'img', 'stimIDs',           'text',     'cellArray',    [1 1 0],    'Stimulus IDs',             '';
    'img', 'PSPer',             'text',     'array',        [1 1 0],    'Peri-stim. period',        '';
    'img', 'selROINames',       'list',     { },            [4 1 1],    'Selected ROIs',            '';
};

%% get the imaging data
ANShowHideMessage(this, 1, 'Loading data ...');
loadDataTic = tic; % for performance timing purposes
% get the per-stimulus calcium traces
[PSCaTraces, ~, ~, allROINames] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows, this.an.img.selROINames);
% set the ROINames in the param. config to be displayed
this.GUI.an.analysisParamConfig{end, 4} = allROINames;
% get the size of the dataset
[nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces);

showMessage(this, sprintf('Loading data done (%3.1f sec).', toc(loadDataTic)));

% check data consistency
if nStimTypes + nStims + nROIs == 3;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot average a single ROI on a single Trial.');
    return;
end;

%% prepare data

% create a time vector
t = ((1 : nPSFrames) / this.an.img.defaultFrameRate) - this.an.img.PSPer(1);

%% plot
plotPeriStimAverage(this.GUI.handles.an.axe, PSCaTraces, t, this.an.img.stimIDs, '');
        
% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');


%{

% get the axe handle where all the plotting elements should be displayed
anAxe = this.GUI.handles.an.axe;
% get a default configuration for the analysis function
config = getAnalyseROIStatsDefaultConfig();
% fill the configuration with the local parameters: axe handle, stim IDs, save name and frame rate
config.axeH = anAxe;
config.stimIDs = this.an.an.stimIDs;
config.saveName = 'AnalyserUpdatePlot';
config.frameRate = this.an.img.defaultFrameRate;
config.stimDur = this.an.an.stimDur;

% set the filtering and down-sampling options
if this.an.an.sgFiltFrameSize > 1;
    config.sgfilter.poly = 1;
    config.sgfilter.win = this.an.an.sgFiltFrameSize;
else
    config.sgfilter.poly = 0;
    config.sgfilter.win = 0;
end;
if this.an.an.downSampFactor > 1;
    config.downSampleFactor = this.an.an.downSampFactor;
else
    config.downSampleFactor = 0;
end;

% set the plotting limits and the colormap
config.plotLimits = this.an.an.plotLimits;
config.colormap = this.an.an.colormap;

% get the ROISet of the first row
ROISet = ANGetROISetForRow(this, DWRows(1));

% convert ROI names to 3-digits format
nROIs = size(ROISet, 1);
for iROI = 1 : nROIs;
    if strcmp(ROISet{iROI, 1}, 'NPil'); continue; end;
    ROISet{iROI, 1} = sprintf('%03d', str2double(ROISet{iROI, 1}));
end;

% if no ROIs found, abort.
if ~nROIs;
    ANShowHideMessage(this, 1, 'No ROISet found.');
    return;
end;

% get the concatenated traces of the selected rows
caTraces = this.data.img.caTraces(DWRows)';

% exclMask = this.data.img.exclMask(DWRows)';
nRuns = size(caTraces, 2); % get the number of runs (which corresponds to the number of selected rows) 
% transform the data into a cell array of nROI x nRuns, with each cell containing the dFF/dRR trace
caTracesDataCell = cell(nROIs, nRuns);
for iROI = 1 : nROIs; % go through each ROI
    for iRun = 1 : nRuns; % go through each run
        caTracesDataCell{iROI, iRun} = caTraces{iRun}(iROI, :); % copy to the cell array
%         caTracesDataCell{iROI, iRun}(~isnan(exclMask{iRun}(iROI, :))) = NaN; % apply mask
    end;
end;

% set the stimulus vector in the configuration
config.stim = this.data.img.stim(DWRows)';

% set up the run names as the trials' names
config.runFileIDs = arrayfun(@(iRow) sprintf('%s_%s', this.dw.table{iRow, 8 : 9}), DWRows, 'UniformOutput', false);

% if no ROI list exists yet, fill the list
if isempty(get(this.GUI.handles.an.ROIList, 'String'));
    set(this.GUI.handles.an.ROIList, 'String', ROISet(:, 1), 'Value', 1 : nROIs);
% otherwise, restrict the ROIs for the analysis to the selected ones
else
    ROISelRange = get(this.GUI.handles.an.ROIList, 'Value'); % get the selected range
    ROISelRange(ROISelRange > nROIs) = [];
    ROISet = ROISet(ROISelRange, :); % restrict the ROISet
    nROIs = size(ROISet, 1); %#ok<NASGU>, update the number of ROIs
    caTracesDataCell = caTracesDataCell(ROISelRange, :); % restrict the traces to the selected data
end;

% load the ROISet and the traces in the configuration
config.ROIStatsData = caTracesDataCell;
config.ROISet = ROISet;

% configuration for all the plots        
this.GUI.an.analysisParamConfig = { ...
    'sgfilter', 'an', 'sgFiltFrameSize', 'text',  'numeric', 'Savitzky-Golay filter', ...
        'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'downsamp', 'an', 'downSampFactor',  'text',  'numeric', 'Down-sampling factor', ...
        'Temporal down-sampling factor, value must be bigger than 0.';
    'ignoreStim', 'an', 'ignoreStim',     'text',   'array',  'Ignored stimulus', ...
        'Stimulus to ignore.';
};


doPlot = true;

%{

% set the configuration's plotting parameter depending on the requested plots
selPlotTypes = this.an.analysisTypes{selPlots};
doPlot = true;
switch selPlotTypes;

    % Calcium traces as lines
    case 'ROICaTraces';

%}
        if nRuns == 1;  config.doSaveROICaTracesPlot = 1; % single run option
        else            config.doSaveROICaTracesAllRunsPlot = 1; % multiple runs option
        end;
        for iRun = 1 : nRuns;
            stimIndexes = find(config.stim{iRun} > 0);
            stimIndexesToRemove = find(ismember(config.stim{iRun}(stimIndexes), this.an.an.ignoreStim));
            config.stim{iRun}(stimIndexes(stimIndexesToRemove)) = 0; %#ok<FNDSB>
        end;
        config.stimIDs(this.an.an.ignoreStim) = [];
        
%{
    % Calcium traces as heat map
    case 'ROICaTracesHeatMap';
        if nRuns == 1;  config.doSaveROICaTracesHeatMapPlot = 1; % single run option
        else            config.doSaveROICaTracesHeatMapAllRunsPlot = 1; % multiple runs option
        end;
        for iRun = 1 : nRuns;
            stimIndexes = find(config.stim{iRun} > 0);
            stimIndexesToRemove = find(ismember(config.stim{iRun}(stimIndexes), this.an.an.ignoreStim));
            config.stim{iRun}(stimIndexes(stimIndexesToRemove)) = 0; %#ok<FNDSB>
        end;
        config.stimIDs(this.an.an.ignoreStim) = [];
          
        this.GUI.an.analysisParamConfig = vertcat(this.GUI.an.analysisParamConfig, { ...
            'plotlims',  'an', 'plotLimits',     'text',  'array',   'Plot limits', ...
                'Plot limits applied on some of the plots. Leave empty for auto-limits.';
            'colormap',  'an', 'colormap',       'text',  'text',   'Colormap', ...
                'Colormap for the heat maps: autumn/bone/colorcube/cool/copper/flag/gray/hot/hsv/jet/lines/pink/prism/spring/summer/white/winter.';
        });

    % Calcium traces averaged for all trials 
    case { 'PSAverage', 'PSAverageHeatMap' };
              
        this.GUI.an.analysisParamConfig = vertcat(this.GUI.an.analysisParamConfig, { ...
            'psframes',  'an', 'PSPer',          'text',  'array',   'Peri-stimulus period', ...
                'Peri-stimulus time in seconds, values must be an array of 2 numerics.';
        });
        
        config.doPSAnalysis = 1;
        if strcmp(selPlotTypes, 'PSAverage');
            config.doSavePSAvgPlot = 1;
        elseif strcmp(selPlotTypes, 'PSAverageHeatMap');
            config.doSavePSPlotAllStimHeatMap = 1;
            this.GUI.an.analysisParamConfig = vertcat(this.GUI.an.analysisParamConfig, { ...
                'plotlims',  'an', 'plotLimits',     'text',  'array',   'Plot limits', ...
                    'Plot limits applied on some of the plots. Leave empty for auto-limits.';
                'colormap',  'an', 'colormap',       'text',  'text',   'Colormap', ...
                    'Colormap for the heat maps: autumn/bone/colorcube/cool/copper/flag/gray/hot/hsv/jet/lines/pink/prism/spring/summer/white/winter.';
            });
        end;
        
        config.PSFrames = struct('base', floor(this.an.an.PSPer(1) * config.frameRate), ...
            'evoked', floor(this.an.an.PSPer(2) * config.frameRate));
        config.plotLimits = [2 20];
        colormap(this.GUI.figH, 'hot'); close all;
        for iRun = 1 : nRuns;
            stimIndexes = find(config.stim{iRun} > 0);
            if numel(stimIndexes) > 1 && ~isempty(this.an.an.ignoreStim) && this.an.an.ignoreStim == -1;
                stimIndexesToRemove = 2 : numel(stimIndexes);
            else
                stimIndexesToRemove = find(ismember(config.stim{iRun}(stimIndexes), this.an.an.ignoreStim));
            end;
            config.stim{iRun}(stimIndexes(stimIndexesToRemove)) = 0; %#ok<FNDSB>
        end;
        if this.an.an.ignoreStim ~= -1
            config.stimIDs(this.an.an.ignoreStim) = [];
        end;

    % Calcium traces averaged for all trials in oddball paradigm, comparing deviants with standards
    case { 'PSAverageOdd', 'PSAverageOddHeatMap' };
        
        this.GUI.an.analysisParamConfig = vertcat(this.GUI.an.analysisParamConfig, { ...
            'psframes',  'an', 'PSPer',          'text',  'array',   'Peri-stimulus period', ...
                'Peri-stimulus time in seconds, values must be an array of 2 numerics.';
        });
    
        config.doPSAnalysis = 1;
        if      strcmp(selPlotTypes, 'PSAverageOdd');
            config.doSavePSAvgPlot = 1;
        elseif  strcmp(selPlotTypes, 'PSAverageOddHeatMap');
            config.doSavePSPlotAllStimHeatMap = 1;
            this.GUI.an.analysisParamConfig = vertcat(this.GUI.an.analysisParamConfig, { ...
                'plotlims',  'an', 'plotLimits',     'text',  'array',   'Plot limits', ...
                    'Plot limits applied on some of the plots. Leave empty for auto-limits.';
                'colormap',  'an', 'colormap',       'text',  'text',   'Colormap', ...
                    'Colormap for the heat maps: autumn/bone/colorcube/cool/copper/flag/gray/hot/hsv/jet/lines/pink/prism/spring/summer/white/winter.';
            });
        end;
        config.stimIDs = { 'first', 'pre-odd', 'odd' };
        config.PSFrames = struct('base', floor(this.an.an.PSPer(1) * config.frameRate), ...
            'evoked', floor(this.an.an.PSPer(2) * config.frameRate));
        config.plotLimits = [2 20];
        
        % get which stimuli to plot
        freqsToKeep = setdiff([1, 2], this.an.an.ignoreStim);
        if numel(freqsToKeep) == 1 && freqsToKeep == 1;
            config.saveName = 'CloudOfTonesOddball - Low';
        elseif numel(freqsToKeep) == 1 && freqsToKeep == 2;
            config.saveName = 'CloudOfTonesOddball - High';
        elseif numel(freqsToKeep) == 2 && all(freqsToKeep == [1 2]);
            config.saveName = 'CloudOfTonesOddball - Both';
        else
            ANShowHideMessage(this, 1, 'No stimulus to plot. Change the ignored stimuli setting.');
            doPlot = false;
        end;
        
        for iRun = 1 : nRuns;
            stimIndexes = find(config.stim{iRun});
            
            if numel(stimIndexes) < 3;
                doPlot = false;
                continue;
            end;
            
            firstStim = config.stim{iRun}(stimIndexes(1));
            preOddStim = config.stim{iRun}(stimIndexes(end - 1));
            oddStim = config.stim{iRun}(stimIndexes(end));
            
            config.stim{iRun}(stimIndexes(1 : end)) = 0;
            
            if ismember(firstStim, freqsToKeep);
                config.stim{iRun}(stimIndexes(1)) = 1;
            end;
            if ismember(preOddStim, freqsToKeep);
                config.stim{iRun}(stimIndexes(end - 1)) = 2;
            end;
            if ismember(oddStim, freqsToKeep);
                config.stim{iRun}(stimIndexes(end)) = 3;
            end;
        end;
        
        colormap(this.GUI.figH, 'hot'); close all;
        
    otherwise;
        doPlot = false;

end;
        
        %}


if doPlot;
    %% compute plot
    listBoxTopRun = get(this.GUI.handles.an.rowList, 'ListboxTop');
    listBoxTopROIs = get(this.GUI.handles.an.ROIList, 'ListboxTop');

    % % DEBUG
    % ANShowHideMessage(this, 0, 'Showing plot area even before it is draw ! [DEBUG].');

    % do the calculation/processing and the plotting
    caTracesOut = analyseROIStatsSingleDay(config);
    
    % store the output
    this.an.caTracesOut = caTracesOut;
    
    %{

    % check if everything went right
    if ismember(selPlotTypes, {'PSAverage', 'PSAverageOdd'}) && isempty(caTracesOut.PS.unfilt.raw);
        ANShowHideMessage(this, 1, 'Problem during plotting.');
        return;
    end;
    
    %}

    % hide the message and show plot
    ANShowHideMessage(this, 0, 'Update analyser plot done.');

    set(this.GUI.handles.an.rowList, 'ListboxTop', listBoxTopRun);
    set(this.GUI.handles.an.ROIList, 'ListboxTop', listBoxTopROIs);
    
else
    ANShowHideMessage(this, 1, 'Plot not available. Sorry about that.');
end;

%}
    
end
