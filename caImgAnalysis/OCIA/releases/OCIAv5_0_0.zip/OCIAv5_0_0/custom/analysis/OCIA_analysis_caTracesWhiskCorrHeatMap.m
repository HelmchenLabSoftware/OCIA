%% #OCIA:AN:OCIA_analysis_caTracesWhiskCorrHeatMap
function OCIA_analysis_caTracesWhiskCorrHeatMap(this, DWRows)

% remove rows where there is not caTraces data and set the run selecter accordingly
emptyRows = cellfun(@isempty, this.data.img.caTraces(DWRows));
if any(emptyRows)
    DWRows(emptyRows) = [];
    set(this.GUI.handles.an.rowList, 'Value', find(~emptyRows));
    ANShowHideMessage(this, 1, 'Some runs do not have imaging data.');
    pause(1);
end;

if isempty(DWRows);
    ANShowHideMessage(this, 1, 'Problem during plotting.');
    return;
end;

if ~isfield(this.data, 'whisk');
    ANShowHideMessage(this, 1, 'This plot is not available for this dataset.');
    return;
end;


this.GUI.an.analysisParamConfig = { ...
    'sgfilter', 'an', 'sgFiltFrameSize', 'text',  'numeric', 'Savitzky-Golay filter', ...
        'Frame size of the Savitzky-Golay filter, value must be an odd number.';
    'downsamp', 'an', 'downSampFactor',  'text',  'numeric', 'Down-sampling factor', ...
        'Temporal down-sampling factor, value must be bigger than 0.';
    'plotlims',  'an', 'plotLimits',     'text',  'array',   'Plot limits', ...
        'Plot limits applied on some of the plots. Leave empty for auto-limits.';
    'colormap',  'an', 'colormap',       'text',  'text',   'Colormap', ...
        'Colormap for the heat maps: autumn/bone/colorcube/cool/copper/flag/gray/hot/hsv/jet/lines/pink/prism/spring/summer/white/winter.';
};

% get the axe handle where all the plotting elements should be displayed
axeH = this.GUI.handles.an.axe;

% get the ROISet of the first row
ROISet = ANGetROISetForRow(this, DWRows(1));

% convert to 3-digits format
nROIs = size(ROISet, 1);
for iROI = 1 : nROIs;
    if strcmp(ROISet{iROI, 1}, 'NPil'); continue; end;
    ROISet{iROI, 1} = sprintf('%03d', str2double(ROISet{iROI, 1}));
end;

% if no ROI list exists yet, fill the list
if isempty(get(this.GUI.handles.an.ROIList, 'String'));
    set(this.GUI.handles.an.ROIList, 'String', ROISet(:, 1), 'Value', 1 : nROIs);
% otherwise, restrict the ROIs for the analysis to the selected ones
else
    ROISelRange = get(this.GUI.handles.an.ROIList, 'Value'); % get the selected range
    ROISet = ROISet(ROISelRange, :); % restrict the ROISet
    nROIs = size(ROISet, 1); % update the number of ROIs
end;

% get the number of runs
nRuns = numel(DWRows);

% get the calcium traces
caTracesCell = this.data.img.caTraces(DWRows);
nImgFrames = size(caTracesCell{1}, 2);
% restrisct the data to the selected ROIs
caTracesCell = cellfun(@(caTrace) caTrace(ROISelRange, :), caTracesCell, 'UniformOutput', false);
% reshape in a matrix of nROIs x nRuns x nFrames
caTraces = reshape(cell2mat(caTracesCell), nROIs, nRuns, nImgFrames);

% get the imaging frame rate and number of frames
imgFrameRate = this.an.img.defaultFrameRate;
nImgFrames = size(caTraces, 3);
% get the sampling rate of the whisker data
whiskSampRate = this.data.whisk(DWRows(1)).frameRate;

% get the whisker data and truncate it
whiskAngles = arrayfun(@(iRow)this.data.whisk(iRow).angle, DWRows, 'UniformOutput', false);
% calculate the real number of points it should contain
nRealPointsWhiskData = round((nImgFrames / imgFrameRate) * whiskSampRate);
% only take the last points
whiskAngles = arrayfun(@(iRow)whiskAngles{iRow}(end - nRealPointsWhiskData + 1 : end), 1 : numel(whiskAngles), ...
    'UniformOutput', false);
% calculate the new number of frames for the whisker data
nWhiskFrames = size(whiskAngles{1}, 2);

% pre-allocate a matrix to store all correlations
corrMatrix = zeros(nRuns, nROIs);

% loop through each run and calculate the enveloppe
whiskAngleEnvs = cell(whiskAngles);
for iRun = 1 : nRuns;
    % calculate the envelope
    whiskAngle = whiskAngles{iRun};
    winSize = round(nWhiskFrames * 0.005);
    whiskAngleEnvs{iRun} = zeros(1, nWhiskFrames);
    for iFrame = 1 : nWhiskFrames;
        r = iFrame - winSize : iFrame + winSize;
        r(r < 1 | r > nWhiskFrames) = [];
        whiskAngleEnvs{iRun}(iFrame) = max(whiskAngle(r));
    end;
end;

% loop through each run and each ROI and calculate the correlation
for iRun = 1 : nRuns;
    for iROI = 1 : nROIs;
        % up-sample the calcium trace for this run and this ROI
        caTraceUS = interp1DS(imgFrameRate, whiskSampRate, squeeze(caTraces(iROI, iRun, :)));
        caTraceUS(end + 1 : nWhiskFrames) = 0;
        % filter the trace if required
        if this.an.an.sgFiltFrameSize > 1 && mod(this.an.an.sgFiltFrameSize, 2) ~= 0;
            caTraceUS = sgolayfilt(caTraceUS, 1, this.an.an.sgFiltFrameSize);
        end;
        % calculate the correlation between the whisker angle and the calcium data
        corrValue = corr([caTraceUS; whiskAngleEnvs{iRun}]', 'rows', 'pairwise');
        % store the correlation coefficient
        corrMatrix(iRun, iROI) = corrValue(1, 2);
    end;
end;

%{
% calculate the mean correlations for all runs and for all ROIs
corrMatrix(end + 1, :) = nanmean(corrMatrix, 1);
corrMatrix(:, end + 1) = nanmean(corrMatrix, 2);
corrMatrix(end, end) = nanmean(reshape(corrMatrix(1 : nRuns, 1 : nROIs), 1, nRuns * nROIs));
%}

% calculate the correlation on all traces concatenated
corrMatrix(end + 1, :) = zeros(1, size(corrMatrix, 2)); % allocate for the new correlation row
allWhiskAngleEnvs = cell2mat(whiskAngleEnvs);
for iROI = 1 : nROIs;
    % up-sample the calcium trace for this run and this ROI
    caTraceUSAllRuns = interp1DS(imgFrameRate, whiskSampRate, reshape(squeeze(caTraces(iROI, 1 : nRuns, :))', ...
        nRuns * nImgFrames, 1)');
    caTraceUSAllRuns(end + 1 : numel(allWhiskAngleEnvs)) = 0;
    % filter the trace if required
    if this.an.an.sgFiltFrameSize > 1 && mod(this.an.an.sgFiltFrameSize, 2) ~= 0;
        caTraceUSAllRuns = sgolayfilt(caTraceUSAllRuns, 1, this.an.an.sgFiltFrameSize);
    end;
    % calculate the correlation between the whisker angle and the calcium data
    corrValue = corr([caTraceUSAllRuns; allWhiskAngleEnvs]', 'rows', 'pairwise');
    % store the correlation coefficient
    corrMatrix(end, iROI) = corrValue(1, 2);
end;

imagesc(1 : size(corrMatrix, 2), 1 : size(corrMatrix, 1), corrMatrix, 'Parent', axeH);
axis(axeH, 'image');
if ~isempty(this.an.an.plotLimits); set(axeH, 'CLim', this.an.an.plotLimits); end;
hColBar = colorbar('peer', axeH);
set(get(hColBar, 'YLabel'), 'String', 'Correlation');
colormap(axeH, this.an.an.colormap); close(gcf);

% add all runs label
YTicks = get(axeH, 'YTick');
YTickLabels = num2cell(get(axeH, 'YTickLabel'));
YTickLabels = arrayfun(@(i)cell2mat(YTickLabels(i, :)), 1 : size(YTickLabels, 1), 'UniformOutput', false);
if ~any(YTicks == size(corrMatrix, 1));
    YTicks(end + 1) = size(corrMatrix, 1);
    YTickLabels{end + 1} = 'all runs';
else
    YTickLabels{YTicks == size(corrMatrix, 1)} = 'all runs';
end;
set(axeH, 'YTick', YTicks, 'YTickLabel', YTickLabels);

% add neuropil label
if strcmp(ROISet{end, 1}, 'NPil');
    XTicks = get(axeH, 'XTick');
    XTickLabels = num2cell(get(axeH, 'XTickLabel'));
    XTickLabels = arrayfun(@(i)cell2mat(XTickLabels(i, :)), 1 : size(XTickLabels, 1), 'UniformOutput', false);
    if XTicks(end) ~= size(corrMatrix, 2);
        XTicks(end + 1) = size(corrMatrix, 2);
        XTickLabels{end + 1} = 'NPil';
    else
        XTickLabels{end} = 'NPil';
    end;
    set(axeH, 'XTick', XTicks, 'XTickLabel', XTickLabels);
end;

% adjust the axes and show title
xlabel(axeH, 'ROIs');
ylabel(axeH, 'Runs');
title(axeH, sprintf('Correlation between each run and ROI with the whisker angle (%d run(s), %d ROI(s))', nRuns, nROIs));

% show plot and display message
ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
end
