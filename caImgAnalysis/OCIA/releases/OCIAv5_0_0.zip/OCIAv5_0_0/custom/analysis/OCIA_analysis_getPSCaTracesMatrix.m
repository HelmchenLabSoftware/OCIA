function [PSCaTraces, ROINames, allPSCaTraces, allROINames] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows, selROINames)

totalTic = tic; % for performance timing purposes

% get the list of all rows
allIDWRows = this.an.selectedTableRows;

% get the calcium traces
[~, ~, ~, ~, ~, allCaTraces, allStims, allROINames] = OCIA_analysis_getCaTracesMatrix(this, iDWRows, selROINames);

% get the selected calcium traces, stimulus vectors and ROIs
caTraces = allCaTraces(ismember(allIDWRows, iDWRows), :, :);
stims = allStims(ismember(allIDWRows, iDWRows), :);

% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'PSPer', this.an.img.PSPer, 'sgFiltFrameSize', this.an.img.sgFiltFrameSize, ...
    'dataType', 'PSCaTraces');
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the per-stimulus calcium traces matrix is not in cache yet, create it
if isempty(cachedData);

    % apply filtering if required
    if this.an.img.sgFiltFrameSize > 1;
        % get the size of the dataset
        [nTrials, nROIs, ~] = size(caTraces);
        caTracesSGFilt = nan(size(caTraces));
        for iTrial = 1 : nTrials;
            for iROI = 1 : nROIs;
                caTracesSGFilt(iTrial, iROI, :) = sgolayfilt(caTraces(iTrial, iROI, :), 1, this.an.img.sgFiltFrameSize);
            end;
        end;
        caTraces = caTracesSGFilt;
    end;
    
    % extract the peri-stimulus calcium traces
    allPSCaTraces = extractPSTrace(caTraces, stims, round(this.an.img.PSPer * this.an.img.defaultFrameRate));

    % store the variables
    cachedData = struct('allPSCaTraces', allPSCaTraces);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);

% if data was in memory, fetch it
else
    % fetch the data
    allPSCaTraces = cachedData.allPSCaTraces;

end;

% get the indexes of the selected ROIs
selROIs = find(ismember(allROINames, selROINames));
% if none selected, select all of them
if isempty(selROIs);
    selROIs = 1 : numel(allROINames);
end;

% exclude the ROIs that have no data
emptyROIs = false(numel(selROIs), 1);
for iSelROI = 1 : numel(emptyROIs);
    PSTracesForROI = allPSCaTraces(:, :, selROIs(iSelROI), :);
    emptyROIs(iSelROI) = ~any(~isnan(PSTracesForROI(:)));
end;
selROIs(emptyROIs) = [];

% get the selected calcium traces, stimulus vectors and ROIs
PSCaTraces = allPSCaTraces(:, :, selROIs, :);
ROINames = allROINames(selROIs);

o('#%s done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);

end