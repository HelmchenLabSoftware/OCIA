function [caTraces, stims, ROINames, concatCaTraces, concatStims, allCaTraces, allStims, allStimTypeNames, allROINames] ...
    = OCIA_analysis_getCaTracesMatrix(this, iDWRows)

totalTic = tic; % for performance timing purposes

% store the "'UniformOutput' false" argument pair in a more convenient form
UF = { 'UniformOutput', false };

% get the list of all rows
allIDWRows = this.an.selectedTableRows;


%% fetch or extract data
% get the data in memory
hashStruct = struct('allIDWRows', allIDWRows, 'dataType', 'caTraces');
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the raw calcium traces matrix is not in cache yet, create it
if isempty(cachedData);
    % get the total number of rows analysed
    nTotRows = numel(allIDWRows);
    % get which ROISet each run belongs to, using the ROISet ID stored in the DataWatcher's table
    rowsROISetIDs = get(this, allIDWRows, 'ROISet');
    if ~iscell(rowsROISetIDs); rowsROISetIDs = { rowsROISetIDs }; end;

    % get all the unique ROISets for the data set currently analysed
    [ROISets, ~, iDWROISetRows] = ANGetROISetForRow(this, allIDWRows);
    % get the ROISet IDs
    ROISetRowIDs = DWGetRowID(this, iDWROISetRows);
    if ~iscell(ROISetRowIDs); ROISetRowIDs = { ROISetRowIDs }; end;
    % if first cell is not a cell, it means we have a single ROISet so transform it to a cell-array
    if ~iscell(ROISets{1}); ROISets = { ROISets }; end;
    % extract the number of ROIs for each ROISet
    nROIsForEachROISet = cell2mat(cellfun(@(ROISet) size(ROISet, 1), ROISets, UF{:}));
    % get the total number of ROIs
    nTotROIs = sum(nROIsForEachROISet);

    % get the calcium data of all rows as a cell array of matrices
    allCaTracesCell = getData(this, allIDWRows, 'caTraces', 'data');
    if ~iscell(allCaTracesCell); allCaTracesCell = { allCaTracesCell }; end;
    % get the number of frames for each row
    nFramesEachrow = arrayfun(@(iRow) size(allCaTracesCell{iRow}, 2), 1 : nTotRows, UF{:});
    % get the maximum number of frames of the currently analysed data set
    nMaxFrames = max(cell2mat(nFramesEachrow));
    % get the stimulus vectors and their bit description for the current selection
    allStimsCell = getData(this, allIDWRows, 'stim', 'data');
    allStimsTypesCell = getData(this, allIDWRows, 'stim', 'stimTypes');
    if ~iscell(allStimsCell); allStimsCell = { allStimsCell }; end;
    if ~iscell(allStimsTypesCell); allStimsTypesCell = { allStimsTypesCell }; end;

    % (re-)create the raw calcium traces matrix as a nrows x nROIs x nFrames matrix with NaNs where there is no data
    allCaTraces = nan(nTotRows, nTotROIs, nMaxFrames);
    allStims = nan(nTotRows, nMaxFrames);

    % store the ROI names
    allROINames = cell(nTotROIs, 1);
    for iROISet = 1 : numel(nROIsForEachROISet);
        iROIStart = sum(nROIsForEachROISet(1 : iROISet - 1)) + 1; % define the ROI indexing's start
        iROIEnd = iROIStart + nROIsForEachROISet(iROISet) - 1; % define the ROI indexing's end
        allROINames(iROIStart : iROIEnd) = cellfun(@(ROIName)sprintf('RS%02d_%s', iROISet, ROIName), ROISets{iROISet}(:, 1), UF{:});
    end;

    % fill-in the raw calcium traces for each row
    for iRow = 1 : nTotRows;
        iROISetForRow = find(strcmp(rowsROISetIDs{iRow}, ROISetRowIDs)); % get the ROISet index of this row
        iROIStart = sum(nROIsForEachROISet(1 : iROISetForRow - 1)) + 1; % define the ROI indexing's start
        iROIEnd = iROIStart + nROIsForEachROISet(iROISetForRow) - 1; % define the ROI indexing's end
        % store the raw calcium traces
        allCaTraces(iRow, iROIStart : iROIEnd, 1 : nFramesEachrow{iRow}) = allCaTracesCell{iRow};
        % store the stimulus vector and the bit description
        allStims(iRow, 1 : nFramesEachrow{iRow}) = allStimsCell{iRow};
    end;


    % store the variables
    cachedData = struct('allCaTraces', allCaTraces, 'allStims', allStims, 'allStimsBitDescr', { allStimsTypesCell }, ...
        'allROINames', { allROINames });
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);

% if data was in memory, fetch it
else
    % fetch the data
    allCaTraces = cachedData.allCaTraces;
    allStims = cachedData.allStims;
    allStimsTypesCell = cachedData.allStimsBitDescr;
    allROINames = cachedData.allROINames;

end;

%% prepare data
% get all stimulus types
[nTotRows, nTotFrames] = size(allStims); %#ok<NASGU>
allStimTypeNames = {};
for iRow = 1 : nTotRows;
    allStimTypeNames = unique([allStimTypeNames regexp(allStimsTypesCell{iRow}, ',', 'split')], 'stable');
end;

% get the selected calcium traces, stimulus vectors
caTraces = allCaTraces(ismember(allIDWRows, iDWRows), :, :);
stims = allStims(ismember(allIDWRows, iDWRows), :);
[nRows, nROIs, nFrames] = size(caTraces); %#ok<ASGLU,NASGU>

%% get the list of selected stimulus types
stimTypeNames = this.an.img.selStimTypeNames;
% get the indexes of the selected stimulus types
selStimTypes = find(ismember(allStimTypeNames, stimTypeNames));
% if none selected, select the first one
if isempty(selStimTypes);
    selStimTypes = 1;
    stimTypeNames = allStimTypeNames(selStimTypes);
end;

% adapt the stimulus vector
for iRow = 1 : nRows;
    
    % get the stimulus vector indices for this row
    stimIndices = find(stims(iRow, :) > 0);
    % get the stimulus vector indices for this row
    stimValues = stims(iRow, stimIndices);
    % reset the stimulus vector
    stims(iRow, stimIndices) = 0;
    
    % get the stimulus types for this row
    stimTypesForRow = regexp(allStimsTypesCell{iRow}, ',', 'split');
    % if this row has no stimulus type matching with the selected ones, skip
    if ~any(ismember(stimTypeNames, stimTypesForRow)); continue; end;
    
    % go through all the selected stimulus types
    stimIndex = 0;
    for iSelStimType = 1 : numel(selStimTypes);
        % get the current selected stimulus type's index
        selStimType = selStimTypes(iSelStimType);
        % check which index of the row's stimTypes the current selected stim type is
        [~, stimTypeIndexInRowStimTypes] = ismember(stimTypeNames(iSelStimType), stimTypesForRow);
        % if it is in the row (index not 0)
        if stimTypeIndexInRowStimTypes ~= 0; 
        CONTINUE HERE
        end;
        % update the stimulus index
        stimIndex = stimIndex + 2;
    end;
    
end;

%% get the list of selected ROIs
ROINames = this.an.img.selROINames;
% get the indexes of the selected ROIs
selROIs = find(ismember(allROINames, ROINames));
% if none selected, select all of them
if isempty(selROIs);
    selROIs = 1 : numel(allROINames);
end;

% exclude the ROIs that have no data
emptyROIs = false(numel(selROIs), 1);
for iSelROI = 1 : numel(emptyROIs);
    caTracesForROI = caTraces(:, selROIs(iSelROI), :);
    emptyROIs(iSelROI) = ~any(~isnan(caTracesForROI(:)));
end;
selROIs(emptyROIs) = [];

% get the selected calcium traces and ROIs
caTraces = caTraces(:, selROIs, :);
ROINames = allROINames(selROIs);
% set back the ROINames and stim types in the selection
this.an.img.selROINames = ROINames;
this.an.img.selStimTypeNames = stimTypeNames;

%% concatenate the data by putting together all runs:
[nRows, nROIs, nFrames] = size(caTraces);
nConcatFrames = nFrames * nRows; % total number of frames in the concatenated data
% concatenate all the calcium traces and the stimulus vectors in a single vector
concatCaTraces = nan(nROIs, nConcatFrames);
concatStims = nan(1, nConcatFrames);
for iRow = 1 : nRows;
    for iROI = 1 : nROIs;
        concatCaTraces(iROI, (iRow - 1) * nFrames + 1 : iRow * nFrames) = caTraces(iRow, iROI, :);
    end;
    concatStims(1, (iRow - 1) * nFrames + 1 : iRow * nFrames) = stims(iRow, :);
end;

o('#%s done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);

end