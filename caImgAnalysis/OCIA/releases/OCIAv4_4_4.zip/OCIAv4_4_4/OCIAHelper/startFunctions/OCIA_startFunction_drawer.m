%% #OCIA:OCIA_startFunction_drawer
function OCIA_startFunction_drawer(this)

   % go to data watcher mode
    OCIAChangeMode(this, 'DataWatcher');

    % process the selected folder and extract the notebook informations
    DWProcessWatchFolder(this);
    pause(0.1);
    DWExtractNotebookInfo(this);

    % if there is no filters for row type, set it to 'imgData'
    GUIDWFiltH = this.GUI.handles.dw.filt;
    if isempty(get(GUIDWFiltH.rowtype, 'String'));
        set(GUIDWFiltH.rowtype, 'String', 'imgData');
    end;

    % if there is no filters for run type, set it to 'B' (any imaging data with a behavior data associated)
    if isempty(get(GUIDWFiltH.runtype, 'String'));
        set(GUIDWFiltH.runtype, 'String', 'B');
    end;

    % select the rows
    DWFilterRunTable(this, 'new');           

    % draw ROIs for rows
    RDDrawROIsForRows(this);
            
end
