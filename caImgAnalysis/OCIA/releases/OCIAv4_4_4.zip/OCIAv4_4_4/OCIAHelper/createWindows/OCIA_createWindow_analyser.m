%% #OCIA:GUI:OCIA_createWindow_analyser
function OCIA_createWindow_analyser(this, pad)

BGWhite = {'Background', 'white'}; %#ok<*CCAT>
NormUnits = {'Units', 'normalized'};

%% - #OCIACreateWindow: Analyser: plot axes
axePadL = 0.065; axePadR = 0.065; axePadT = 0.25; axePadB = 0.065;
axeW = 1 - axePadL - axePadR - 2 * pad; axeH = 1 - axePadT - axePadB - 1.5 * pad;
axeY = pad + axePadB; axeX = pad + axePadL;
commons = {'Parent', this.GUI.handles.panels.AnalyserPanel, NormUnits{:}};
this.GUI.handles.an.axe = axes(commons{:}, 'Tag', 'ANAxe', 'Color', 'white', 'Position', ...
    [axeX axeY axeW axeH]);

%% - #OCIACreateWindow: Analyser: loading text
commons = [commons, BGWhite{:}];
this.GUI.handles.an.message = uicontrol(commons{:}, 'Tag', 'ANMessage', 'Style', 'text', ...
    'String', 'Loading ...', 'Visible', 'off', 'FontSize', this.GUI.pos(4) / 45, ...
    'Position', [axeX axeY axeW axeH]);

%% - #OCIACreateWindow: Analyser: runTable, plotList and ROI selection list
commons = [commons, 'Style', 'list', 'Max', 2, 'Min', 0];
fListH = axePadT * 0.8 - 1.5 * pad; fListY = 1 - fListH - pad;
runTableW = 0.30 - 1.5 * pad; plotListW = 0.15 - 1.5 * pad; 
runTableX = pad; plotListX = runTableX + runTableW + pad;
anSelROIListW = runTableW * 0.2; anSelROIListX = plotListX + plotListW + pad;
this.GUI.handles.an.runTable = uicontrol(commons{:}, 'Tag', 'ANRunTable', 'Max', 2, 'Min', 0, ...
    'Position', [runTableX, fListY, runTableW, fListH], 'Callback', @(h, e)ANUpdatePlot(this, h, e));
this.GUI.handles.an.plotList = uicontrol(commons{:}, 'Tag', 'ANPlotList', ...
    'Position', [plotListX, fListY, plotListW, fListH], 'Callback', @(h, e)ANUpdatePlot(this, h, e));
this.GUI.handles.an.selROIList = uicontrol(commons{:}, 'Tag', 'ANSelROIList', 'String', {}, 'Callback', ...
    @(h, e)ANUpdatePlot(this, h, e), 'Position', [anSelROIListX, fListY, anSelROIListW, fListH]);

%% - #OCIACreateWindow: Analyser: zoom button
commons = {'Parent', this.GUI.handles.panels.AnalyserPanel, NormUnits{:}, 'Value', 0, 'Style', 'togglebutton'};
zToolW = 0.1; zToolH = 0.025;
zToolX = anSelROIListX + anSelROIListW + pad; zToolY = 1 - zToolH - pad;
this.GUI.handles.an.zTool = uicontrol(commons{:}, 'String', 'Zoom', 'Tag', 'ANZTool', ...
    'Position', [zToolX, zToolY, zToolW, zToolH], 'Callback', @(h, e)ANActivateZoom(this, h, e));

%% - #OCIACreateWindow: Analyser: pan button
pToolW =zToolW; pToolH = zToolH; pToolX = zToolX; pToolY = zToolY - pToolH - pad;
this.GUI.handles.an.pTool = uicontrol(commons{:}, 'String', 'Pan', 'Tag', 'ANPTool', ...
    'Position', [pToolX, pToolY, pToolW, pToolH], 'Callback', @(h, e)ANActivatePan(this, h, e));

%% - #OCIACreateWindow: Analyser: save plot button
commons = {'Parent', this.GUI.handles.panels.AnalyserPanel, NormUnits{:}, 'Style', 'pushbutton'};
saveAnPlotW = zToolW; saveAnPlotH = zToolH;
saveAnPlotX = zToolX; saveAnPlotY = pToolY - saveAnPlotH - pad;
this.GUI.handles.an.savePlot = uicontrol(commons{:}, 'String', 'Save plot', 'Tag', 'ANSavePlot', ...
    'Position', [saveAnPlotX, saveAnPlotY, saveAnPlotW, saveAnPlotH], 'Callback', ...
    @(~, ~)ANSavePlot(this, []));

%% - #OCIACreateWindow: Analyser: save plot button
saveAnOutW = zToolW; saveAnOutH = zToolH;
saveAnOutX = zToolX; saveAnOutY = saveAnPlotY - saveAnOutH - pad;
this.GUI.handles.an.savePlot = uicontrol(commons{:}, 'String', 'Save output', 'Tag', 'ANSaveOutput', ...
    'Position', [saveAnOutX, saveAnOutY, saveAnOutW, saveAnOutH], 'Callback', ...
    @(~, ~)ANSaveOutput(this, []));

%% - #OCIACreateWindow: Analyser: all runs
selAllRunsW = zToolW; selAllRunsH = zToolH;
selAllRunsX = zToolX; selAllRunsY = saveAnOutY - selAllRunsH - pad;
this.GUI.handles.an.selAllRuns = uicontrol(commons{:}, 'String', 'Select all runs', 'Tag', 'ANSelAllRuns', ...
    'Position', [selAllRunsX, selAllRunsY, selAllRunsW, selAllRunsH], 'Callback', ...
    @(~, ~)ANSelRuns(this, 'all'));

%% - #OCIACreateWindow: Analyser: select all ROIs
selAllROIsW = zToolW; selAllROIsH = zToolH;
selAllROIsX = zToolX; selAllROIsY = selAllRunsY - selAllROIsH - pad;
this.GUI.handles.an.selAllROIs = uicontrol(commons{:}, 'String', 'Select all ROIs', 'Tag', 'ANSelAllROIs', ...
    'Position', [selAllROIsX, selAllROIsY, selAllROIsW, selAllROIsH], 'Callback', ...
    @(~, ~)ANSelROIs(this, 'all'));

%% - #OCIACreateWindow: Analyser: parameter panel
paramPansX = zToolX + zToolW + pad; paramPansY = fListY;
paramPansW = 1 - paramPansX - 2 * pad; paramPansH = 1 - paramPansY - 2 * pad;
this.GUI.handles.an.paramPan = uipanel('Parent', this.GUI.handles.panels.AnalyserPanel, NormUnits{:}, BGWhite{:}, ...
    'Title', 'Plot parameters', 'Tag', 'ANParamPan', 'Position', [paramPansX paramPansY paramPansW paramPansH]);

end
