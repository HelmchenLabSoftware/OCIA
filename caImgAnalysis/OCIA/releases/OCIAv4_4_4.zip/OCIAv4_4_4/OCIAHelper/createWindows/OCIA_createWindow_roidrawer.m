%% #OCIA:GUI:OCIA_createWindow_roidrawer
function OCIA_createWindow_roidrawer(this, pad)

BGWhite = {'Background', 'white'}; %#ok<*CCAT>
NormUnits = {'Units', 'normalized'};

%% - #OCIACreateWindow: ROIDrawer
%% -- #OCIACreateWindow: ROIDrawer: image axe
alignOffsetX = -0.013; alignOffsetY = 0.0025;
RDFrameSetterH = 0.02;
RDImAxeY = pad + alignOffsetY + RDFrameSetterH + pad; RDImAxeX = pad + alignOffsetX;
RDImAxeH = 1 - RDFrameSetterH - 3 * pad; RDImAxeHPix = this.GUI.pos(4) * RDImAxeH;
RDImAxeW = RDImAxeHPix / this.GUI.pos(3); 
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, 'Color', 'white', NormUnits{:}};
this.GUI.handles.rd.axe = axes(commons{:}, 'Tag', 'RDAxe', 'Position', [RDImAxeX RDImAxeY RDImAxeW RDImAxeH]);
%% -- #OCIACreateWindow: ROIDrawer: image handle (imshow)
% the creation of the image is done later to avoid weird flickering effect due to imshow
this.GUI.handles.rd.img = [];

%% -- #OCIACreateWindow: ROIDrawer: frame browsing slider's label
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}};
RDFrameLabelW = 0.055; RDFrameLabelX = pad; RDFrameLabelY = pad;
this.GUI.handles.rd.frameLabel = uicontrol(commons{:}, 'Style', 'text', 'String', 'Frame 000', ...
    'Tag', 'RDFrameLabel', BGWhite{:}, 'Position', [RDFrameLabelX, RDFrameLabelY, RDFrameLabelW, RDFrameSetterH], ...
     'FontSize', this.GUI.pos(4) / 100, 'HorizontalAlignment', 'left');

%% -- #OCIACreateWindow: ROIDrawer: frame browsing slider
alignOffsetX = 0.022;
RDFrameSetterW = RDImAxeW - RDFrameLabelW - 2 * pad - alignOffsetX;
RDFrameSetterX = RDFrameLabelX + RDFrameLabelW + pad; RDFrameSetterY = pad;
this.GUI.handles.rd.frameSetter = uicontrol(commons{:}, 'Style', 'slider', 'Min', 0, 'Max', 1, 'Value', 0, ...
    'SliderStep', [0 1], 'Callback', @(h, e)RDChangeFrame(this, h, e), 'TooltipString', 'Change frame', 'Tag', ...
    'RDFrameSetter', 'Enable', 'off', 'Position', [RDFrameSetterX, RDFrameSetterY, RDFrameSetterW, RDFrameSetterH]);

%% - #OCIACreateWindow: ROIDrawer: ROI tool button group
alignOffsetX = -0.008; alignOffsetY = 0.01;
toolSelH = 0.05; toolSelY = 1 - pad - toolSelH + alignOffsetY; toolSelX = RDImAxeX + RDImAxeW + alignOffsetX;
toolSelW = 1 - toolSelX - pad;
this.GUI.handles.rd.drawToolSelGroup = uibuttongroup(commons{:}, 'Title', 'Draw tools', 'Tag', 'RDDrawToolGroup', ...
    BGWhite{:}, 'Position', [toolSelX toolSelY toolSelW toolSelH]);

%% - #OCIACreateWindow: ROIDrawer: ROI tool radio buttons
commons = {'Parent', this.GUI.handles.rd.drawToolSelGroup, 'Style', 'radiobutton', BGWhite{:}, NormUnits{:}};
nDrawTools = numel(this.GUI.rd.drawTools);
radioW = (1 - (nDrawTools + 1) * pad) / nDrawTools; radioH =  1 - 2 * pad;
for iTool = fliplr(1 : nDrawTools);
    toolName = this.GUI.rd.drawTools{iTool};
    % create the label for the radio buttons
    toolLabel = toolName;
    if strcmp(toolLabel, 'semiauto'); toolLabel = 'Semi-auto.';
    else toolLabel(1) = upper(toolLabel(1)); end;
    % create the tool
    this.GUI.handles.rd.drawTool.(toolName) = uicontrol(commons{:}, 'String', toolLabel, ...
        'Tag', ['RDDrawTool' toolName], 'Position', [pad + (iTool - 1) * (radioW + pad), pad, radioW, radioH]);
end;
% set the change function and set the first tool to be selected 
set(this.GUI.handles.rd.drawToolSelGroup, 'SelectedObject', this.GUI.handles.rd.drawTool.(this.GUI.rd.drawTools{1}));

%% - #OCIACreateWindow: ROIDrawer: saveROI
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, 'Style', 'pushbutton'};
saveROIW = (toolSelW - 2 * pad) / 3; saveROIH = toolSelH; saveROIX = toolSelX; saveROIY = toolSelY - pad - saveROIH;
this.GUI.handles.rd.saveROIs = uicontrol(commons{:}, 'String', 'Save ROIs', 'Tag', 'RDSaveROIs', ...
    'Position', [saveROIX, saveROIY, saveROIW, saveROIH], 'Callback', @(h, e)RDSaveROIs(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: LoadROI
loadROIW = saveROIW; loadROIH = saveROIH; loadROIX = saveROIX + saveROIW + pad; loadROIY = saveROIY ;
this.GUI.handles.rd.loadROIs = uicontrol(commons{:}, 'String', 'Load ROIs', 'Tag', 'RDWLoadROIs',  ...
    'Position', [loadROIX, loadROIY, loadROIW, loadROIH], 'Callback', @(h, e)RDLoadROIs(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: clearROIs
clearROIsW = saveROIW; clearROIsH = saveROIH; clearROIsX = loadROIX + loadROIW + pad; clearROIsY = saveROIY;
this.GUI.handles.rd.clearROIs = uicontrol(commons{:}, 'String', 'Clear ROIs', 'Tag', 'RDClearROIs',  ...
    'Position', [clearROIsX, clearROIsY, clearROIsW, clearROIsH], 'Callback', @(h, e)RDClearROIs(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: deleteROI
delROIW = saveROIW; delROIH = saveROIH; delROIX = saveROIX; delROIY = saveROIY - saveROIH - pad;
this.GUI.handles.rd.deleteROI = uicontrol(commons{:}, 'String', 'Delete ROI', 'Tag', 'RDDeleteROI', ...
    'Position', [delROIX, delROIY, delROIW, delROIH], 'Callback', @(h, e)RDDeleteROI(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: renameROI
renameROIW = saveROIW; renameROIH = saveROIH; renameROIX = delROIX + delROIW + pad; renameROIY = delROIY;
this.GUI.handles.rd.renameROI = uicontrol(commons{:}, 'String', 'Rename ROI', 'Tag', 'RDRenameROI', ...
    'Position', [renameROIX, renameROIY, renameROIW, renameROIH], 'Callback', @(h, e)RDRenameROI(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: Rename ROI edit field's label
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, BGWhite{:}};
alignOffsetY = -0.015;
ROINameLabW = (saveROIW - pad) * 2 / 3; ROINameLabH = saveROIH; ROINameLabX = renameROIX + renameROIW + pad;
ROINameLabY = delROIY + alignOffsetY;
this.GUI.handles.rd.ROINameLabel = uicontrol(commons{:}, 'String', 'ROI new name: ', 'Tag', 'RDROINameLabel', ...
    'Style', 'text', 'HorizontalAlignment', 'center', 'Position', [ROINameLabX, ROINameLabY, ROINameLabW, ROINameLabH]);

%% - #OCIACreateWindow: ROIDrawer: Rename ROI edit field
commons = [commons, {'Style', 'edit'}];
ROINameW = (saveROIW - pad) / 3; ROINameH = saveROIH; ROINameX = ROINameLabX + ROINameLabW + pad; ROINameY = delROIY;
this.GUI.handles.rd.ROIName = uicontrol(commons{:}, 'String', '', 'Tag', 'RDROIName', ...
    'Position', [ROINameX, ROINameY, ROINameW, ROINameH], 'TooltipString', 'Enter here the ROI''s new name');

%% - #OCIACreateWindow: ROIDrawer: renumbering on delete checkbox
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, BGWhite{:}, 'Style', 'checkbox', 'Value', 0};
renumW = ((1 - toolSelX - pad) - 5 * pad) / 4; renumH = saveROIH * 0.6;
renumX = delROIX; renumY = delROIY - renumH - pad;
this.GUI.handles.rd.renum = uicontrol(commons{:}, 'String', 'Renum. on delete', 'Tag', 'RDRenumDel', ...
    'Position', [renumX, renumY, renumW, renumH], 'ToolTipString', ...
    'When an ROI is deleted, renumber the other ROIs according to their order in the list.');

%% - #OCIACreateWindow: ROIDrawer: load type
DRLoadTypeW = renumW; DRLoadTypeH = saveROIH * 0.6;
DRLoadTypeX = renumX + renumW + pad; DRLoadTypeY = renumY;
this.GUI.handles.rd.loadAllFrames = uicontrol(commons{:}, 'String', 'Load all frames', 'Tag', 'RDWLoadAllFrames', ...
    'Position', [DRLoadTypeX, DRLoadTypeY, DRLoadTypeW, DRLoadTypeH], ...
    'Callback', @(h, e)RDChangeRow(this, this.GUI.handles.rd.rowListNames));

%% - #OCIACreateWindow: ROIDrawer: auto-imadj
autoImAdjW = renumW; autoImAdjH = saveROIH * 0.6;
autoImAdjX = DRLoadTypeX + DRLoadTypeW + pad; autoImAdjY = renumY;
this.GUI.handles.rd.autoImAdj = uicontrol(commons{:}, 'String', 'Image adjust auto', 'Tag', 'RDImAdjAuto', ...
    'Position', [autoImAdjX, autoImAdjY, autoImAdjW, autoImAdjH]);

%% - #OCIACreateWindow: ROIDrawer: show average
showAvgW = renumW; showAvgH = saveROIH * 0.6;
showAvgX = autoImAdjX + autoImAdjW + pad; showAvgY = renumY;
this.GUI.handles.rd.showAvg = uicontrol(commons{:}, 'String', 'Show average', 'Tag', 'RDShowAvg', ...
    'Value', 1, 'Position', [showAvgX, showAvgY, showAvgW, showAvgH], ...
    'Callback', @(h, e)RDChangeRow(this, this.GUI.handles.rd.rowListNames));

%% - #OCIACreateWindow: ROIDrawer: show/hide ROIs
showHideROIsW = renumW; showHideROIsH = saveROIH * 0.6;
showHideROIsX = renumX; showHideROIsY = renumY - showHideROIsH - pad;
this.GUI.handles.rd.showHideROIs = uicontrol(commons{:}, 'String', 'Show ROIs', 'Tag', 'RDShowHideROIs', ...
    'Position', [showHideROIsX, showHideROIsY, showHideROIsW, showHideROIsH], 'Value', 1, ...
    'Callback', @(h, e)RDShowHideROIs(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: show/hide ROIs labels
showHideROIsLabW = renumW; showHideROIsLabH = saveROIH * 0.6;
showHideROIsLabX = showHideROIsX + showHideROIsW + pad; showHideROIsLabY = renumY - showHideROIsLabH - pad;
this.GUI.handles.rd.showHideROIsLab = uicontrol(commons{:}, 'String', 'Show ROI IDs', 'Tag', 'RDShowHideROIIDs', ...
    'Position', [showHideROIsLabX, showHideROIsLabY, showHideROIsLabW, showHideROIsLabH], 'Value', 1, ...
    'Callback', @(h, e)RDShowHideROIs(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: filter frames
filtFramesW = renumW; filtFramesH = saveROIH * 0.6;
filtFramesX = showHideROIsLabX + showHideROIsLabW + pad; filtFramesY = showHideROIsY;
this.GUI.handles.rd.filtFrames = uicontrol(commons{:}, 'String', 'Filter frames', 'Tag', 'RDShowHideROIs', ...
    'Position', [filtFramesX, filtFramesY, filtFramesW, filtFramesH], ...
    'Callback', @(h, e)RDChangeRow(this, this.GUI.handles.rd.rowListNames));

%% - #OCIACreateWindow: ROIDrawer: Zoom tool
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, 'Value', 0, 'Style', 'togglebutton'};
RDZToolW = ROINameW; RDZToolH = saveROIH; RDZToolX = saveROIX; RDZToolY = showHideROIsY - RDZToolH - pad;
this.GUI.handles.rd.zTool = uicontrol(commons{:}, 'String', 'Zoom', 'TooltipString', 'Activate zoom', ...
    'Tag', 'RDZTool', 'Position', [RDZToolX, RDZToolY, RDZToolW, RDZToolH], ...
    'Callback', @(h, e)RDActivateZoom(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: Pan tool
RDPToolW = ROINameW; RDPToolH = saveROIH; RDPToolX = RDZToolX + RDZToolW + pad; RDPToolY = RDZToolY;
this.GUI.handles.rd.pTool = uicontrol(commons{:}, 'String', 'Pan', 'TooltipString', 'Activate pan', ...
    'Tag', 'RDPTool', 'Position', [RDPToolX, RDPToolY, RDPToolW, RDPToolH], ...
    'Callback', @(h, e)RDActivatePan(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: ROI select button
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, 'Style', 'pushbutton'};
selROIW = (saveROIW - 1.5 * pad) * 2 / 3; selROIH = saveROIH; selROIX = RDPToolX + RDPToolW + pad; selROIY = RDZToolY;
this.GUI.handles.rd.selROI = uicontrol(commons{:}, 'String', 'Select ROIs', 'Tag', 'RDSelROI', ...
    'Position', [selROIX, selROIY, selROIW, selROIH], 'Callback', @(h, e)RDSelROI(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: ROI select edit field
selROISettW = (saveROIW - 1.5 * pad) * 2 / 3; selROISettH = saveROIH;
selROISettX = selROIX + selROIW + pad; selROISettY = RDZToolY;
this.GUI.handles.rd.selROISetter = uicontrol(commons{:}, 'String', '', 'Tag', 'RDSelROISett', 'Style', 'edit', ...
    'Position', [selROISettX, selROISettY, selROISettW, selROISettH], BGWhite{:}, ...
    'TooltipString', '"Formula" to evaluate for ROI selection', 'Callback', @(h, e)RDSelROI(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: ROI select edit field clear
alignOffset = 1.1;
selROISettClearW = selROISettW * 0.15; selROISettClearWPix = this.GUI.pos(3) * selROISettClearW;
selROISettClearH = selROISettClearWPix / this.GUI.pos(4);
selROISettClearX = selROISettX + selROISettW - selROISettClearW * alignOffset;
selROISettClearY = selROISettY + selROISettH - selROISettClearH * alignOffset;
this.GUI.handles.rd.selROISetterClear = uicontrol(commons{:}, 'Tag', 'RDSelROISettClear', 'String', 'X', ...
    'Position', [selROISettClearX, selROISettClearY, selROISettClearW, selROISettClearH], ...
    'Foreground', 'red', 'TooltipString', 'Clear selection', 'FontSize', this.GUI.pos(4) / 110, ...
    'Callback', @(h, e)RDSelROI(this, h, e));

%% - #OCIACreateWindow: ROIDrawer: frame avereage select field
selFrameRangeW = (saveROIW - 1.5 * pad) * 2 / 3; selFrameRangeH = saveROIH;
selFrameRangeX = selROISettX + selROISettW + pad; selFrameRangeY = RDZToolY;
this.GUI.handles.rd.selFrameRange = uicontrol(commons{:}, 'String', '', 'Tag', 'RDSelFrameRange', 'Style', 'edit', ...
    'Position', [selFrameRangeX, selFrameRangeY, selFrameRangeW, selFrameRangeH], BGWhite{:}, ...
    'TooltipString', 'Range on which the averaging should be done', ...
    'Callback', @(h, e)RDChangeRow(this, h));

% %% - #OCIACreateWindow: ROIDrawer: createRef
% ROIRGBW = saveROIW; ROIRGBH = saveROIH; ROIRGBX = delROIX; ROIRGBY = clearROIsY;
% this.GUI.handles.rd.ROIRGB = uicontrol(commons{:}, 'String', 'Create reference', 'Tag', 'RDCreateRef', ...
%     'Position', [ROIRGBX, ROIRGBY, ROIRGBW, ROIRGBH], 'Callback', @(h, e)RDCreateRef(this, h, e), ...
%     'ToolTipString', 'Create a reference image from the average of all the selected runs');
% 
% %% - #OCIACreateWindow: ROIDrawer: createROIRGB
% ROIRGBW = saveROIW; ROIRGBH = saveROIH; ROIRGBX = delROIX; ROIRGBY = clearROIsY;
% this.GUI.handles.rd.ROIRGB = uicontrol(commons{:}, 'String', 'Create ROIRGB', ...
% 'Position', [ROIRGBX, ROIRGBY, ROIRGBW, ROIRGBH], 'Callback', @(h, e)createROIRGB(this, h, e), 'Style', 'pushbutton');

%% - #OCIACreateWindow: ROIDrawer: apply mask
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, 'Value', 0, 'Style', 'togglebutton', ...
    'Callback', @(h, e)RDUpdateImage(this, h, e)};
RDMaskW = saveROIW; RDMaskH = saveROIH; RDMaskX = saveROIX; RDMaskY = RDZToolY - RDMaskH - pad;
this.GUI.handles.rd.mask = uicontrol(commons{:}, 'String', 'Apply mask', 'Tag', 'RDMask', ...
    'Position', [RDMaskX, RDMaskY, RDMaskW, RDMaskH], 'TooltipString', 'Applies a black mask to see ROIs');

%% - #OCIACreateWindow: ROIDrawer: image adjust
imAdjW = saveROIW; imAdjH = saveROIH; imAdjX = saveROIX; imAdjY = RDMaskY - imAdjH - pad;
this.GUI.handles.rd.imAdj = uicontrol(commons{:}, 'String', 'Adjust image', 'Tag', 'RDImAdj', ...
    'Position', [imAdjX, imAdjY, imAdjW, imAdjH], 'TooltipString', 'Adjusts the image''s intensity');

%% - #OCIACreateWindow: ROIDrawer: pseudo-flat field
pseudFFW = saveROIW; pseudFFH = saveROIH; pseudFFX = saveROIX; pseudFFY = imAdjY - pseudFFH - pad;
this.GUI.handles.rd.pseudFF = uicontrol(commons{:}, 'String', 'Pseudo flat-field', 'Tag', 'RDPseudFF', ...
    'Position', [pseudFFX, pseudFFY, pseudFFW, pseudFFH], 'TooltipString', 'Apply a pseudo flat-field correction');

%% - #OCIACreateWindow: ROIDrawer: compare ROI sets
RDRefROISetW = saveROIW; RDRefROISetH = saveROIH; RDRefROISetX = saveROIX; RDRefROISetY = pseudFFY - RDRefROISetH - pad;
this.GUI.handles.rd.refROISet = uicontrol(commons{:}, 'String', 'Compare ROI sets', 'Tag', 'RDRefROISet', ...
    'Position', [RDRefROISetX, RDRefROISetY, RDRefROISetW, RDRefROISetH], 'TooltipString', 'Compare ROI sets');

%% - #OCIACreateWindow: ROIDrawer: mask opacity
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, 'Style', 'slider', 'Max', 1, 'Min', 0, ...
    'Callback', @(h, e)RDUpdateImage(this, h, e)};
RDMaskSettW = toolSelW - RDMaskW - pad; RDMaskSettH = RDMaskH;
RDMaskSettX = RDMaskX + RDMaskW + pad; RDMaskSettY = RDMaskY;
this.GUI.handles.rd.maskSetter = uicontrol(commons{:}, 'Value', 0.15, 'TooltipString', 'Mask opacity', 'Max', 0.8, ...
    'Tag', 'RDMaskSett', 'Position', [RDMaskSettX, RDMaskSettY, RDMaskSettW, RDMaskSettH]);

%% - #OCIACreateWindow: ROIDrawer: image adjust min and max value
imAdjSettW = (RDMaskSettW - pad) / 2; imAdjSettH = imAdjH; imAdjSettY = imAdjY;
imAdjMinSettX = RDMaskX + RDMaskW + pad; imAdjMaxSettX = imAdjMinSettX + imAdjSettW + pad;
this.GUI.handles.rd.imAdjMinSetter = uicontrol(commons{:}, 'TooltipString', 'Minimum intensity', 'Max', 0.5, ...
    'Tag', 'RDImAdjMinSett', 'Position', [imAdjMinSettX, imAdjSettY, imAdjSettW, imAdjSettH], 'Value', 0.15);
this.GUI.handles.rd.imAdjMaxSetter = uicontrol(commons{:}, 'TooltipString', 'Maximum intensity', 'Min', 0.5, ...
    'Tag', 'RDImAdjMaxSett', 'Position', [imAdjMaxSettX, imAdjSettY, imAdjSettW, imAdjSettH], 'Value', 0.65);

%% - #OCIACreateWindow: ROIDrawer: pseudo flat field image dimension
pseudFFSettW = toolSelW - pseudFFW - pad; pseudFFSettH = pseudFFH;
pseudFFSettX = pseudFFX + pseudFFW + pad; pseudFFSettY = pseudFFY;
this.GUI.handles.rd.pseudFFSetter = uicontrol(commons{:}, 'Value', 4, 'TooltipString', 'Flat field dimension', ...
    'Tag', 'RDPseudFFSett', 'Position', [pseudFFSettX, pseudFFSettY, pseudFFSettW, pseudFFSettH], 'Max', 32, 'Min', 1);

%% - #OCIACreateWindow: ROIDrawer: compare ROI sets
RDRefROISetSettW = (RDMaskSettW - pad) / 2; RDRefROISetSettH = RDRefROISetH; RDRefROISetSettY = RDRefROISetY;
RDRefROISetSettAX = RDRefROISetX + RDRefROISetW + pad; RDRefROISetSettBX = RDRefROISetSettAX + RDRefROISetW + pad;
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, BGWhite{:}, 'Style', 'listbox', ...
    'Value', 1, 'String', {'1', '2'}, 'FontSize', this.GUI.pos(4) / 65, 'Callback', @(h, e)RDUpdateImage(this, h, e)};
this.GUI.handles.rd.refROISetASetter = uicontrol(commons{:}, 'Tag', 'RDRefROISetASett', ...
    'TooltipString', 'Reference', 'Position', [RDRefROISetSettAX, RDRefROISetSettY, RDRefROISetSettW, RDRefROISetSettH]);
this.GUI.handles.rd.refROISetBSetter = uicontrol(commons{:}, 'Min', 0, 'Max', 2, 'Tag', 'RDRefROISetBSett', ...
    'TooltipString', 'Targets', 'Position', [RDRefROISetSettBX, RDRefROISetSettY, RDRefROISetSettW, RDRefROISetSettH]);

%% - #OCIACreateWindow: ROIDrawer: Row list display, row list selection and ROI list selection labels
fListNamesW = (toolSelW - 2 * pad) * 0.78; fListRowsW = (toolSelW - 2 * pad) * 0.11;
fListROIsW = (toolSelW - 2 * pad) * 0.11;
fListLabelH = 0.02; fListLabelY = RDRefROISetSettY - fListLabelH - pad;
fListY = pad; fListH = fListLabelY - 2 * pad;
fListNamesX = saveROIX; fListRowsX = fListNamesX + fListNamesW + pad; fListROIsX = fListRowsX + fListRowsW + pad;
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, BGWhite{:}, 'Style', 'text', ...
    'FontSize', this.GUI.pos(4) / 80, 'HorizontalAlignment', 'center'};
this.GUI.handles.rd.rowListNamesLabel = uicontrol(commons{:}, 'Tag', 'RDSRowsLabel', 'String', 'Row display ', ...
    'Position', [fListNamesX, fListLabelY, fListNamesW, fListLabelH]);
this.GUI.handles.rd.runSelLabel = uicontrol(commons{:}, 'Tag', 'RDSelRowsLabel', 'String', 'Run(s)  ', ...
    'Position', [fListRowsX, fListLabelY, fListRowsW, fListLabelH]);
this.GUI.handles.rd.selROIsListLabel = uicontrol(commons{:}, 'Tag', 'RDSelROIsListLabel', ...
    'String', 'ROIs  ', 'Position', [fListROIsX, fListLabelY, fListROIsW, fListLabelH]);

%% - #OCIACreateWindow: ROIDrawer: Row list display, row list selection and ROI list selection
commons = {'Parent', this.GUI.handles.panels.ROIDrawerPanel, NormUnits{:}, BGWhite{:}, 'String', {}, ...
    'Style', 'list', 'Max', 2, 'Min', 0};
this.GUI.handles.rd.rowListNames = uicontrol(commons{:}, 'Position', [fListNamesX, fListY, fListNamesW, fListH], ...
    'Tag', 'RDSRows', 'Callback', @(h, e)RDChangeRow(this, h, e), 'TooltipString', 'Selection for rows to display');
this.GUI.handles.rd.runSel = uicontrol(commons{:}, 'Position', [fListRowsX, fListY, fListRowsW, fListH], ...
    'Tag', 'RDSelRows', 'TooltipString', 'Selection for runs/rows where the current ROISet applies');
this.GUI.handles.rd.selROIsList = uicontrol(commons{:}, 'Position', [fListROIsX, fListY, fListROIsW, fListH], ...
    'Tag', 'RDSelROIsList', 'Callback', @(h, e)RDSelROI(this, h, e), 'TooltipString', 'ROI selection');

end
