%% #OCIA:OCIA_notebookPostProcess_default
function OCIA_notebookPostProcess_default(this)

if ismember('an', fields(this)) && isfield(this.an, 'behav') && ~isempty(this.an.behav);
    DWMatchBehavTrialsToDataFiles(this);
    DWDisplayRunTable(this);
    DWMatchROISetsToData(this);
    DWMatchBehavDataToSpot(this);
else
    DWMatchROISetsToDataNoBehav(this);
    DWExtractSpotIdentity(this);
end;

end
