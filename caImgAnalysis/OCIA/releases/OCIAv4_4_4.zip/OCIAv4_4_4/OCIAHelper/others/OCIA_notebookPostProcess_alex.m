%% #OCIA:OCIA_notebookPostProcess_alex
function OCIA_notebookPostProcess_alex(this)

runTypes = unique(this.dw.runTable(~cellfun(@isempty, this.dw.runTable(:, 8)), 8));

this.dw.stimtypeIDs = ['-'; runTypes];
set(this.GUI.handles.dw.filt.stimtypeID, 'String', this.dw.stimtypeIDs);

DWMatchROISetsToData(this);
    
end
