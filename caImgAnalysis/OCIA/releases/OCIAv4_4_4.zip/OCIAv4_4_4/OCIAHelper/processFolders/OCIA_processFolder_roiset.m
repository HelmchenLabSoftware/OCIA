%% #OCIA:DW:OCIA_processFolder_roiset
function runTable = OCIA_processFolder_roiset(this, folderPath, ~, folderName, ~, ~, ~)

ROISetProcessTic = tic;
o('#OCIA_processFolder_roiset(): in ''%s'', ROISetFolderName: %s.', folderPath, folderName, 3, this.verb);

runTable = cell(20, size(this.dw.runTable, 2)); % create an information row
iRow = 1;
ROISetFolderPath = [folderPath '/'];

% check what's in the watchfolder and exclude irrelephant files
dirParseTic = tic;
files = dir(ROISetFolderPath); % check out the content of the folder
files(arrayfun(@(x)x.isdir, files)) = []; % only keep files
% exclude everything that is not a vessel or a binary intrinsic file
files(arrayfun(@(x) isempty(regexp(x.name, this.dw.watchTypeFilePatterns.roisetfile, 'once')), files)) = [];

nFiles = numel(files); % count the number of remaining files
o('#OCIA_processFolder_roiset(): found %d file(s) (%3.1f sec).', nFiles, toc(dirParseTic), 5, this.verb);

% loop trough all existing files
for iFolder = 1 : nFiles;
    fileName = files(iFolder).name;
    o('  #OCIA_processFolder_roiset(): found file ''%s''.', fileName, 5, this.verb);

    % ROISet mat-file
    if regexp(fileName, this.dw.watchTypeFilePatterns.roisetfile, 'once');

        % extract the information using regexp and store them in the runTable
        ROISetFileHits = regexp(fileName, this.dw.watchTypeFilePatterns.roisetfile, 'names');
        runTable{iRow, 1} = ' / ROISet';
        runTable{iRow, 2} = ROISetFileHits.date;
        runTable{iRow, 3} = ROISetFileHits.time;
        runTable{iRow, 4} = '01';

        ROISetMatStruct = load([folderPath '/' fileName]);
        nROIs = size(ROISetMatStruct.ROIs, 1);
        ROISet = cell(nROIs, 2);
        ROISet(:, 1) = ROISetMatStruct.ROIs(:, 2);
        ROISet(:, 2) = arrayfun(@(x) ROISetMatStruct.ROIMask == x, 1 : nROIs, 'UniformOutput', false);
        [ROISet, nROIs] = addNPilROIToROISet(ROISet, this.an.an.nPilMaskBord);
        this.data.img.ROISets{end + 1, 1} = ROISet;
        nRuns = size(ROISetMatStruct.runsValidity, 1);
        this.data.img.ROISets{end, 2} = ROISetMatStruct.runsValidity;
        if isfield(ROISetMatStruct, 'refImage');
            this.data.img.ROISets{end, 3} = ROISetMatStruct.refImage;
        else
            showWarning(this, 'OCIA:OCIA_processFolder_roiset:NoRefImage', ...
                sprintf('No reference image found in ''%s''!', fileName));
        end;

        runTable{iRow, 5} = sprintf('%03d ROIs, %02d runs', nROIs, nRuns);
        runTable{iRow, 8} = sprintf('RS%02d', size(this.data.img.ROISets, 1));
        runTable{iRow, 16} = sprintf('%03d', nROIs);
        
    else % if no file pattern matched, show warning

        showWarning(this, 'OCIA:OCIA_processFolder_roiset:UnknownFileFound', ...
            sprintf('Unknown file type found: ''%s''! Skipping it.', fileName));
        continue;
    end;

    iRow = iRow + 1; % increment the counter
end;

% clean up runTables: delete empty cells
o('  #OCIA_processFolder_roiset(): folder(s) processing done, cleaning up runTables ...', 5, this.verb);
runTable(cellfun(@isempty, (runTable(:, 1))), :) = [];

o('  #OCIA_processFolder_roiset: %s done (%3.1f sec).', folderName, toc(ROISetProcessTic), 4, this.verb);

end
