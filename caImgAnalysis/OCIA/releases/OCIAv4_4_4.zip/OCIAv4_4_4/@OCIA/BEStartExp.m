%% #BEStartExp
function BEStartExp(this, ~, ~)

if this.be.isRunning;
    showWarning(this, 'OCIA:Behavior:CannotStartAlreadyRunning', ...
        'Cannot start because experiment is already running.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;

% if experiment was previously aborted, re-initialize it
if this.be.isToReset;
    showMessage(this, 'Re-initializing experiment ...', 'yellow');
    BEInitExp(this);
end;

if ~this.be.configLoaded;
    showWarning(this, 'OCIA:Behavior:InitExp:configNotLoaded', ...
        'Cannot initialize experiment because config is not loaded.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;
if isempty(this.be.animalID);
    showWarning(this, 'OCIA:Behavior:InitExp:NoMouseId', ...
        'Cannot initialize experiment because there is no animalID.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;
if ~this.be.hw.connected;
    showWarning(this, 'OCIA:Behavior:InitExp:HardwareDisconnected', ...
        'Cannot initialize experiment because hardware is disconnected.');
    set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
    set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
    return;
end;

this.be.iTrial = 1;
this.be.isRunning = true;

set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
set(this.GUI.handles.be.startExp, 'BackgroundColor', 'green', 'Value', 1);


%           showMessage(this, 'D-D-D-D-DANGEROUS !! FAIL SAFE OUTPUT SAVING DISABLED !!', 'red');
%           showMessage(this, 'D-D-D-D-DANGEROUS !! FAIL SAFE OUTPUT SAVING DISABLED !!', 'red');
%           showMessage(this, 'D-D-D-D-DANGEROUS !! FAIL SAFE OUTPUT SAVING DISABLED !!', 'red');
%           pause(1);

try
    BERunExp(this);
catch err;
    BESaveOutput(this);
    errStack = getStackText(err);
    showWarning(this, 'OCIA:BEStartExp', sprintf('Problem during the experiment: "%s".', err.message));
    o(errStack, 0, 0);
    throw(err);
end;

end

