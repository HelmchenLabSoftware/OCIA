%% #OCIA:AN:ANUpdatePlot
function ANUpdatePlot(this, ~, ~)

% disable all GUI elements of the analyser panel
childElems = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
inputElems = strcmp('uicontrol', get(childElems, 'Type'));
set(childElems(inputElems), 'Enable', 'off');
% disable all GUI elements of the analyser panel's parameter panel
childElems = get(this.GUI.handles.an.paramPan, 'Children');
inputElems = strcmp('uicontrol', get(childElems, 'Type'));
set(childElems(inputElems), 'Enable', 'off');
set(this.GUI.handles.an.message, 'Enable', 'on'); % do not disable the message display element

%% - #OCIA:AN:ANUpdatePlot: init
% update the parameters from the plots
nUICtrl = size(this.GUI.an.plotParamConfig, 1);
% go through all elements and update their associated parameters
for iUICtrl = 1 : nUICtrl;
    id = this.GUI.an.plotParamConfig{iUICtrl, 1};
    categ = this.GUI.an.plotParamConfig{iUICtrl, 2};
    name = this.GUI.an.plotParamConfig{iUICtrl, 3};
    UIType = this.GUI.an.plotParamConfig{iUICtrl, 4};
    valueType = this.GUI.an.plotParamConfig{iUICtrl, 5};
    if ~isfield(this.GUI.handles.an.paramPanElems, id); continue; end;
    switch UIType;
        case 'text';
            txt = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            switch valueType
                case 'numeric';
                    dblValue = str2double(txt);
                    if ~isnan(dblValue); this.an.(categ).(name) = dblValue; end;
                case 'text';
                    if ~isempty(txt); this.an.(categ).(name) = txt; end;
                case 'array';
                    res = NaN;
                    txt = regexprep(txt, '[^\[\]\d ,:\.-]', '');
                    if isempty(txt); res = [];
                    else try res = eval(txt); catch e; end; %#ok<NASGU>
                    end;
                    if isempty(res) || ~any(isnan(res)); this.an.(categ).(name) = res; end;
            end;
    end;
end;

% clear the plot and show a message
ANClearPlot(this);
ANShowHideMessage(this, 1, 'Plotting ...');

% get the selected rows and plot
selRows = get(this.GUI.handles.an.runTable, 'Value');
selPlots = get(this.GUI.handles.an.plotList, 'Value');

% get the selected rows
DWRows = cell2mat(this.an.runTable(selRows, 11));

% only process first selected plot
selPlots = selPlots(1);
set(this.GUI.handles.an.plotList, 'Value', selPlots);

o('#OCIA:AN:ANUpdatePlot(): updating plot, plotType(s):%s, row(s):%s ...', ...
    sprintf(' %s', this.an.plotTypes{selPlots}), sprintf(' %d', selRows), 3, this.verb);


%% plotting parameter UI controls
% configuration for all the plots        
this.GUI.an.plotParamConfig = { };

try
    
    % only process first selected plot
    switch this.an.plotTypes{selPlots};

        %% - #OCIA:AN:ANUpdatePlot: d' plot for the behavior data
        case 'DPrime';

            ANPlotDPrime(this, selRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace-based plots
        case {'ROICaTraces', 'ROICaTracesHeatMap', 'PSAverage', 'PSAverageHeatMap', ...
                'PSAverageOdd', 'PSAverageOddHeatMap'};

            ANPlotCaTraces(this, DWRows, selPlots);

        %% - #OCIA:AN:ANUpdatePlot: raw traces with ratio and DFF/DRR calculation
        case 'RawTraces';

            ANPlotRawTraces(this, DWRows, selRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and behavior combining plot
        case 'CaTraceBehavior';

            ANPlotCaTracesBehav(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhisk';

            ANPlotCaTracesWhisk(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhiskCorrHeatMap';

            ANPlotCaTracesWhiskCorrHeatMap(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: Calcium trace and whisker angle
        case 'CaTracesWhiskCorrDistr';

            ANPlotCaTracesWhiskCorrDistr(this, DWRows);

        %% - #OCIA:AN:ANUpdatePlot: unknown plot
        otherwise

            ANShowHideMessage(this, 1, 'Plot not available. Sorry about that.');
    end;
    
catch err;
    % show message and error
    ANShowHideMessage(this, 1, 'An error occured during the plotting. Sorry about that.');
    showWarning(this, 'OCIA:ANUpdatePlot:PlotError', ...
        sprintf('%s (%s)\n%s', err.message, err.identifier, getStackText(err)), 'red');    
end;

% common input parameters for the UI controls
commons = { 'Parent', this.GUI.handles.an.paramPan, 'Units', 'normalized', 'Enable', 'off' };
commonsTxt = [ commons, { 'Background', 'white', 'Style', 'edit', 'Callback', @(h, e) ANUpdatePlot(this, h, e) } ];
commonsLab = [ commons, { 'Background', 'white', 'Style', 'text' } ];
% define the max number of rows and the number of items to place
nMaxRows = 6; nMaxCols = 2; nUICtrl = size(this.GUI.an.plotParamConfig, 1); %#ok<NASGU>
nMinRows = 4; nMinCols = 1; pad = 0.02; inPad = 0.01;
% calculate the number of acutal columns and rows
% nCols = ceil(nUICtrl / nMaxRows); nRows = min(nMaxRows, nUICtrl);
nRows = max(ceil(nUICtrl / nMaxCols), nMinRows); nCols = max(min(nMaxCols, nUICtrl), nMinCols);
elemW = (1 - (nCols + 1) * pad) / nCols; % width depends on the number of columns
elemH = (1 - (nRows + 1) * pad) / nRows; % height depends on the number of rows
iRow = 1; iCol = 1; % init the row and column indexes
% go through all elements, create them and place them
for iUICtrl = 1 : nUICtrl;
    id = this.GUI.an.plotParamConfig{iUICtrl, 1};
    categ = this.GUI.an.plotParamConfig{iUICtrl, 2};
    name = this.GUI.an.plotParamConfig{iUICtrl, 3};
    UIType = this.GUI.an.plotParamConfig{iUICtrl, 4};
    valueType = this.GUI.an.plotParamConfig{iUICtrl, 5};
    label = this.GUI.an.plotParamConfig{iUICtrl, 6};
    tooltip = this.GUI.an.plotParamConfig{iUICtrl, 7};
    
    if iRow > nRows; iRow = 1; iCol = iCol + 1; end;
%     if iCol > nCols; iCol = 1; iRow = iRow + 1; end;
    elemPosX = (iCol - 1) * (pad + elemW) + pad; % calculate X position
    elemPosY = 1 - iRow * (elemH + pad) + pad; % calculate Y position
    % create the GUI element
    switch UIType;
        case 'text';
            this.GUI.handles.an.paramPanElems.([id '_label']) = uicontrol(commonsLab{:}, 'String', label, ...
                'Position', [elemPosX elemPosY + elemH * 0.25 elemW * (0.7 - inPad) elemH * 0.5], ...
                'ToolTipString', tooltip, 'Tag', sprintf('ANParam%s', id));
            val = this.an.(categ).(name);
            if numel(val) > 1;
                if ~strcmp(valueType, 'text');
                    val = ['[', regexprep(num2str(val), '\s+', ','), ']'];
                end;
            else
                val = num2str(val);
            end;
            this.GUI.handles.an.paramPanElems.(id) = uicontrol(commonsTxt{:}, ...
                'String', val, 'Tag', sprintf('ANParam%s', id), ...
                'Position', [elemPosX + elemW * (0.7 + inPad) elemPosY elemW * (0.3 - inPad) elemH], ...
                'ToolTipString', tooltip);
    end;
    iRow = iRow + 1;
%     iCol = iCol + 1;
end;
drawnow(); % display the GUI

if nUICtrl;
    set(this.GUI.handles.an.paramPan, 'Visible', 'on');
else
    set(this.GUI.handles.an.paramPan, 'Visible', 'off');
end;

% disable all GUI elements of the analyser panel
childElems = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
inputElems = strcmp('uicontrol', get(childElems, 'Type'));
set(childElems(inputElems), 'Enable', 'on');
% disable all GUI elements of the analyser panel's parameter panel
childElems = get(this.GUI.handles.an.paramPan, 'Children');
inputElems = strcmp('uicontrol', get(childElems, 'Type'));
set(childElems(inputElems), 'Enable', 'on');
    
uicontrol(this.GUI.handles.an.selROIList);

end
