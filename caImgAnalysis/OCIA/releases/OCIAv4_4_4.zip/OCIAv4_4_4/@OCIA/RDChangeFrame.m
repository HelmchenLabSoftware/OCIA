%% #OCIA:RD:RDChangeFrame
function RDChangeFrame(this, h, ~)

    % if change was requested by a number
    if h ~= this.GUI.handles.rd.frameSetter && h ~= -1;
        selFrame = h;
    % if change was requested by the callback
    else
        selFrame = round(get(this.GUI.handles.rd.frameSetter, 'Value'));
    end;
    
    % get the first selected row (in case there is more than one selected)
    iRow = get(this.GUI.handles.rd.rowListNames, 'Value');
    iRow = iRow(1);
        
    % if an average is requested
    if get(this.GUI.handles.rd.showAvg, 'Value');
        
        this.GUI.rd.img = this.rd.runTable{iRow, 3};
        
        % change the frame label
        set(this.GUI.handles.rd.frameLabel, 'String', 'Average');
    % if a frame is requested
    else
        % get the images
        RGBIm = this.rd.runTable{iRow, 4};
        % show the selected frame
        this.GUI.rd.img = squeeze(RGBIm(:, :, selFrame, :));
        % change the frame label
        set(this.GUI.handles.rd.frameLabel, 'String', sprintf('Frame %03d', selFrame));
    end;
    
    % restrict the image between 0 and 1
    img = this.GUI.rd.img; img(img < 0) = 0; img(img > 1) = 1;
    % if only one channel is actually used, use grayscale images
    if ndims(img) == 3;
        chanEmptiness = arrayfun(@(iChan)nansum(nansum(img(:, :, iChan))), 1 : 3) > 0;
        if sum(chanEmptiness) == 1;
            img(:, :, ~chanEmptiness) = repmat(img(:, :, chanEmptiness), [1, 1, 2]);
        end;
    else
        img = repmat(img, [1 1 3]);
    end;
    set(this.GUI.handles.rd.img, 'CData', img);
    set(this.GUI.handles.rd.axe, 'XLim', [-size(img, 2) * 0.05 size(img, 2) * 1.05], ...
        'YLim', [-size(img, 1) * 0.05 size(img, 1) * 1.05]);
        
    % remove the applied image corrections
    this.GUI.rd.applImCorr = {};
    
    % if call from the callback, update image
    if h == this.GUI.handles.rd.frameSetter;
%         RDUpdateImage(this, h);
    end;
    
end
