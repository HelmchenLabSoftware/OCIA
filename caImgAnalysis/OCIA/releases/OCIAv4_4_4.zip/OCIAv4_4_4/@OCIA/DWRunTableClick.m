%% #OCIA:DW:DWRunTableClick
function DWRunTableClick(this, ~, ~)

    o('#DWRunTableClick()', 4, this.verb);
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;

    % update the list of selected rows
    jTable = getJTable(this, 'DWRunTable');
    if ~isempty(this.dw.runTable);
        clickedRows = jTable.getSelectedRows() + 1;
        this.dw.selRunTableRows = clickedRows;
    else
        this.dw.selRunTableRows = [];
    end;

    % remove selected rows that are out of the range ot the runTable
    this.dw.selRunTableRows(this.dw.selRunTableRows > size(this.dw.runTable, 1)) = [];
    % highlight the selected rows
    DWSelRunTableRows(this, this.dw.selRunTableRows);

    o('#DWRunTableClick(): clickedRows: %s, selected rows: %s ...', num2str(clickedRows'), ...
        num2str(this.dw.selRunTableRows'), 4, this.verb);
end
