%% #OCIA:RD:RDChangeRow
function RDChangeRow(this, h, ~)

    % if change was requested by a number
    if h ~= this.GUI.handles.rd.rowListNames && h ~= this.GUI.handles.rd.selFrameRange;
        selRows = h;
    % if change was requested by a callback
    else
        selRows = get(this.GUI.handles.rd.rowListNames, 'Value');
    end;
    
    % get the first or first two input row(s)
    nSelRows = numel(selRows);
%     selRows = selRows(1 : min(2, nSelRows));
%     selRows = selRows(1 : min(3, nSelRows));
    nValues = size(get(this.GUI.handles.rd.rowListNames, 'String'), 1);
    selRows(selRows > nValues) = nValues; % set boundaries for iRow so that it does not exceed the range
    selRows(selRows < 1) = 1; % set boundaries for iRow so that it does not exceed the range
    selRows = unique(selRows); % make sure there are no duplicated values
    set(this.GUI.handles.rd.rowListNames, 'Value', selRows);
    
    
    % set the right number of steps for the image overlay setter
    if nSelRows > 1;
        set(this.GUI.handles.rd.refROISetASetter, 'Value', 1, 'String', num2cell(selRows));
        set(this.GUI.handles.rd.refROISetBSetter, 'Value', 1, 'String', num2cell(selRows));
    else
        set(this.GUI.handles.rd.refROISetASetter, 'Value', 1, 'String', num2cell(1));
        set(this.GUI.handles.rd.refROISetBSetter, 'Value', 1, 'String', num2cell(1));
    end;
    
    % clear the annotations
    try
        childHands = get(this.GUI.handles.rd.axe, 'Children');
        childTags = get(childHands, 'Tag');
        delete(childHands(strcmp('ROICompareLine', childTags)));
        delete(childHands(strcmp('ROICompareText', childTags)));
        delete(childHands(strcmp('ROICompareScatter', childTags)));
    catch e; %#ok<NASGU>
    end;
    
    % disable the setter
    set(this.GUI.handles.rd.frameSetter, 'Enable', 'off');
    
    o('#RDChangeRow(): h: %d, selRows: %s.', h, num2str(selRows), 3, this.verb);
    
    % determine whether to load all the frames or just the first "couple" as preview
    if get(this.GUI.handles.rd.loadAllFrames, 'Value');
        loadType = 'full';
    else
        loadType = 'prev';
    end;
    
    % if the data for this image was not loaded yet
    for iSelRow = 1 : numel(selRows);
        
        iRow = selRows(iSelRow);
        iDWRow = this.dw.selRunTableRows(iRow); % get the data watcher's row number
        DWLoadRow(this, iDWRow, loadType);
        
        % get the data of the row
        data = this.data.preProc{iDWRow};
        imgDim = size(data{this.an.img.preProcChan});
        if numel(imgDim) < 3; imgDim(3) = 1; end; % make sure dimension is described as number of frames        
        
        % create the average if not available or if number of frames has changed
        if isempty(this.rd.runTable{iRow, 3}) || imgDim(3) ~= size(this.rd.runTable{iRow, 4}, 3) ...
                || h == this.GUI.handles.rd.selFrameRange;
            
    
            % get the frame range for the averaging
            frameRangeStr = regexprep(get(this.GUI.handles.rd.selFrameRange, 'String'), '-', ':');
            if ~isempty(frameRangeStr);
                dataForAverage = data;
                frameRange = eval(frameRangeStr);
                for iChan = 1 : numel(dataForAverage);
                    frameRangeChan = frameRange;
                    frameRangeChan(frameRangeChan < 1 | frameRangeChan > size(dataForAverage{iChan}, 3)) = [];
                    dataForAverage{iChan} = dataForAverage{iChan}(:, :, frameRangeChan);
                end;
            else
                dataForAverage = data;
            end;
            
            % create the averaged RGB image with the data
            RGBImAvg = cell2RGB(dataForAverage, this.an.img.colVect, true);
            % store the image
            this.rd.runTable{iRow, 3} = RGBImAvg;
        end;
        
        % only create/update the images if frames should be showed (not average) and if number of frames has changed
        %   or if filtering was enabled/disabled
        if ~get(this.GUI.handles.rd.showAvg, 'Value') && (imgDim(3) ~= size(this.rd.runTable{iRow, 4}, 3) ...
                || (ishandle(h) && this.GUI.handles.rd.filtFrames));
                        
            % if required, apply a filter
            if get(this.GUI.handles.rd.filtFrames, 'Value');
                showMessage(this, 'Filtering frames ...', 'yellow');
                
                % filter each channel ony by one
                parfor iChan = 1 : size(data, 1);
                    dataChan = data{iChan};
                    dataChanFilt = zeros(imgDim);
                    f = fspecial('gaussian', 2, 1.5);
                    for iFrame = 1 : imgDim(3);
                        dataChanFilt(:, :, iFrame) = imfilter(dataChan(:, :, iFrame), f, 'replicate');
%                         dataChanFilt(:, :, iFrame) = medfilt2(dataChan(:, :, iFrame), [3 3], 'symmetric');
                    end;
                    data{iChan} = dataChanFilt; % copy back the filtered data
                end;
                
                showMessage(this, 'Filtering frames done.');
            end;
            
        
            showMessage(this, 'Preparing frames ...', 'yellow');
            % calculate the RGB image for each (eventually filtered) frame
            RGBIm = cell2RGB(data, this.an.img.colVect, false);
            showMessage(this, 'Preparing frames done.');

            % store the frames
            this.rd.runTable{iRow, 4} = RGBIm;
            
        end;
        
        % if an average image is requested, disable frame setter
        if get(this.GUI.handles.rd.showAvg, 'Value');
            set(this.GUI.handles.rd.frameSetter, 'Enable', 'off', 'Value', 0, 'Min', 0, 'Max', 1, ...
                'SliderStep', [0 1]);
        % otherwise, set the appropriate values for the frame setter
        else
            set(this.GUI.handles.rd.frameSetter, 'Enable', 'on', 'Value', 1, 'Min', 1, 'Max', imgDim(3), ...
                'SliderStep', [1 / imgDim(3) 3 / imgDim(3)]);
        end;
        
    end;

    % set the right frame
    RDChangeFrame(this, -1);
        
    % set back image correction filters to 0
    set(this.GUI.handles.rd.mask, 'Value', 0);
    set(this.GUI.handles.rd.imAdj, 'Value', 0);
    set(this.GUI.handles.rd.pseudFF, 'Value', 0);
    set(this.GUI.handles.rd.refROISet, 'Value', 0);
    % remove the applied image corrections
    this.GUI.rd.applImCorr = {};
    
end
