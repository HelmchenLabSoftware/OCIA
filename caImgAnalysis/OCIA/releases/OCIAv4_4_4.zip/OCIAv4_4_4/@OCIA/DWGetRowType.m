%% #OCIA:DW:DWGetRowType
function rowType = DWGetRowType(this, iDWRow)

% get the row's name/path
rowName = this.dw.runTable{iDWRow, 1};
% extract the row's type from the last "word" of the row's name
rowType = cell2mat(regexp(rowName, '\w+$', 'match'));

end