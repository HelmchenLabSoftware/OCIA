
%% basic stuff
TDTSampFreq = 97656.25;
standardSampFreq = 44100;

COTUniqueFreqs_4To21kHz_25freqs = 4000 * (2 .^ (((1 : 25) - 1) * (0.1))); % used for chronic_1402
COTUniqueFreqs_4To32kHz_25freqs = 4000 * (2 .^ (((1 : 25) - 1) * (2 ^ -3))); % use for chronic_1406 & 1407
COTUniqueFreqs_5To40kHz_25freqs = 5000 * (2 .^ (((1 : 24) - 1) * (2 ^ -3))); % alternative

%% stim matrices
o('Generating stim matrices ...', 0, 0);

% 50 trials, 1 as start
stimTypes = [1 2]; stimSize = 50; blockSize = 10; maxConsec = 3; nSeqs = 10; seqStart = 1; plotMatrix = 0;
try
    stimMatrix_50stim_10block_3max_10seq_1start = configs.behavior.cotDiscr.CA1.tone.stimMatrix; % 1 as start
    stimMatrix_50stim_10block_3max_10seq_2start = configs.behavior.cotDiscr.CA2.tone.stimMatrix; % 2 as start
catch e;
end; 
if ~exist('stimMatrix_50stim_10block_3max_10seq_1start', 'var');
    stimMatrix_50stim_10block_3max_10seq_1start = genStimMatrix(stimTypes, stimSize, blockSize, maxConsec, nSeqs, ...
        seqStart, plotMatrix);
end;
% 50 trials, 2 as start
if ~exist('stimMatrix_50stim_10block_3max_10seq_2start', 'var');
    stimMatrix_50stim_10block_3max_10seq_2start = stimMatrix_50stim_10block_3max_10seq_1start;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 1) = 3;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 2) = 1;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 3) = 2;
end;
o('Generating stim/nTones matrices 1 / 3 done.', 0, 0);

% 30 trials, 1 as start
stimSize = 30; plotMatrix = 0;
try stimMatrix_30stim_10block_3max_10seq_1start = configs.behavior.cotDiscr.AA.tone.stimMatrix;
catch e; end;
if ~exist('stimMatrix_30stim_10block_3max_10seq_1start', 'var');
    stimMatrix_30stim_10block_3max_10seq_1start = genStimMatrix(stimTypes, stimSize, blockSize, maxConsec, nSeqs, ...
        seqStart, plotMatrix);
end;    
o('Generating stim/nTones matrices 2 / 3 done.', 0, 0);

stimTypes = 6 : 11; stimSize = 50; seqStart = []; plotMatrix = 0;
try nTones_50stim_10block_3max_10seq = configs.behavior.cotOdd.A.tone.nTonesMatrix;
catch e; end;
if ~exist('nTones_50stim_10block_3max_10seq', 'var');
    nTones_50stim_10block_3max_10seq = genStimMatrix(6 : 10, stimSize, blockSize, maxConsec, nSeqs, seqStart, ...
        plotMatrix);
end;
o('Generating stim/nTones matrices 3 / 3 done.', 0, 0);

%% - configs: animals
configs.animals = { ...
    '140730_01',    'cotDiscr',     'BE';   ...
    '140730_02',    'cotDiscr',     'BE';   ...
    'testing',      'cotDiscr',     'AA';   ...
    'testing',      'cotDiscr',     'AB';   ...
    'testing',      'cotDiscr',     'AC';   ...
    'testing',      'cotDiscr',     'BA';   ...
    'testing',      'cotDiscr',     'BB';   ...
    'testing',      'cotDiscr',     'BC';   ...
    'testing',      'cotDiscr',     'BD';   ...
    'testing',      'cotDiscr',     'BE';   ...
    'testing',      'cotDiscr',     'BF';   ...
    'testing',      'cotDiscr',     'CA1';   ...
    'testing',      'cotDiscr',     'CA2';   ...
    'testing',      'cotDiscr',     'CB1';   ...
    'testing',      'cotDiscr',     'CB2';   ...
};

%% - configs: behavior: cloud of tones discrimination base config (QW)
% - configs: behavior: cloud of tones discrimination : tone
s.tone.samplingFreq = TDTSampFreq;
s.tone.toneDur = 0.03;
s.tone.toneISI = 0.01;
s.tone.stimDur = 0.5; % half second sound
s.tone.uniqueFreqs = COTUniqueFreqs_4To32kHz_25freqs;
s.tone.cloudDispersion = 2; % narrow cloud
s.tone.freqIndexes = [1 + s.tone.cloudDispersion numel(s.tone.uniqueFreqs) - s.tone.cloudDispersion];
s.tone.freqs = s.tone.uniqueFreqs(s.tone.freqIndexes);
s.tone.goStim = []; % no go stim
s.tone.stimProba = [];
s.tone.nTones = 1;
s.tone.ISI = 0;
s.tone.stimProba = [];
s.tone.stimMatrix = stimMatrix_30stim_10block_3max_10seq_1start;
s.training.nTrials = 30;
s.training.startDelay = 3;
s.training.startDelayRand = 1;
s.training.minRespTime = 0;
s.training.maxRespTime = 0;
s.training.rewCollTime = 0;
s.training.rewDur = 0;
s.training.timeoutPunish = 0;
s.training.endDelay = 10;
sBase = s;
configs.behavior.cotDiscr.QW = s;

% - configs: behavior: cloud of tones discrimination A (learn to lick)
s.tone.goStim = [1 2]; % both clouds are target
s.tone.stimMatrix = stimMatrix_30stim_10block_3max_10seq_1start;
s.training.nTrials = 30;
s.training.minRespTime = 0.1;
respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
s.training.rewCollTime = 2;
s.training.rewDur = 0.02;
s.training.timeoutPunish = 0;
s.training.endDelay = 3;
configs.behavior.cotDiscr.AA = s;
% longer delay version
s.training.endDelay = 5;
configs.behavior.cotDiscr.AB = s;
% 50 trials version
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
s.training.nTrials = 50;
configs.behavior.cotDiscr.AC = s;

% - configs: behavior: cloud of tones discrimination B (learn to lick the right way with delay)
s.tone.goStim = [1 2]; % both clouds are target
s.training.minRespTime = 0.3;
s.training.endDelay = 5;
respTime = 3; s.training.maxRespTime = s.training.minRespTime + respTime;
s.training.rewDur = 0.02;
s.training.timeoutPunish = 0;
configs.behavior.cotDiscr.BA = s;
% longer wait time version
s.training.minRespTime = 0.5;
respTime = 2.5; s.training.maxRespTime = s.training.minRespTime + respTime;
configs.behavior.cotDiscr.BB = s;
% even longer wait time version
s.training.minRespTime = 0.8;
respTime = 2.5; s.training.maxRespTime = s.training.minRespTime + respTime;
configs.behavior.cotDiscr.BC = s;
% even longer wait time version
s.training.minRespTime = 1;
respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
configs.behavior.cotDiscr.BD = s;
% more response delay
s.training.minRespTime = 1;
respTime = 4; s.training.maxRespTime = s.training.minRespTime + respTime;
configs.behavior.cotDiscr.BE = s;
% less response time
s.training.minRespTime = 1;
respTime = 3; s.training.maxRespTime = s.training.minRespTime + respTime;
configs.behavior.cotDiscr.BF = s;

% - configs: behavior: cloud of tones discrimination C (full version)
s.tone.goStim = 1; % low cloud is the target
s.training.endDelay = 8;
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
s.training.rewDur = 0.02;
s.training.timeoutPunish = 3;
configs.behavior.cotDiscr.CA1 = s;
s.training.timeoutPunish = 5;
configs.behavior.cotDiscr.CB1 = s;
% high cloud version
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_2start;
s.tone.goStim = 2; % high cloud is the target
s.training.timeoutPunish = 3;
configs.behavior.cotDiscr.CA2 = s;
s.training.timeoutPunish = 5;
configs.behavior.cotDiscr.CB2 = s;

%% - configs: behavior: cloud of tones oddball
s = sBase;
s.tone.goStim = [];
s.tone.nTonesMatrix = nTones_50stim_10block_3max_10seq;
s.tone.nTones = unique(s.tone.nTonesMatrix);
s.tone.ISI = 0.6;
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
s.training.nTrials = 50;
configs.behavior.cotOdd.A = s;

%% - configs: hardware
configs.hardware.H30.adaptorID = 'ni';
configs.hardware.H30.piezo.deviceName = 'BehaviorBox';
configs.hardware.H30.piezo.channel = 'ai0';
configs.hardware.H30.piezo.range = [-1 1];
configs.hardware.H30.piezo.inputType = 'SingleEnded';
configs.hardware.H30.micr.deviceName = 'BehaviorBox';
configs.hardware.H30.micr.channel = 'ai1';
configs.hardware.H30.micr.range = [-10 10];
configs.hardware.H30.micr.inputType = 'SingleEnded';
configs.hardware.H30.valve.deviceName = 'BehaviorBox';
configs.hardware.H30.valve.portLine = 'Port0/Line0';
configs.hardware.H30.valve.defaultState = 1;
configs.hardware.H30.airPuff.deviceName = 'BehaviorBox';
configs.hardware.H30.airPuff.portLine = 'Port0/Line1';
configs.hardware.H30.airPuff.defaultState = 1;
configs.hardware.H30.yscan.channel = 'ai2';
configs.hardware.H30.yscan.deviceName = 'BehaviorBox';
configs.hardware.H30.yscan.range = [-10 10];
configs.hardware.H30.yscan.inputType = 'SingleEnded';
configs.hardware.H30.imagTTL.deviceName = 'ExtraChannels';
configs.hardware.H30.imagTTL.range = [-10 10];
configs.hardware.H30.imagTTL.channel = 'ao0';
configs.hardware.H30.motion.deviceName = 'ExtraChannels';
configs.hardware.H30.motion.channel = 'ai0';
configs.hardware.H30.motion.range = [-10 10];
configs.hardware.H30.motion.inputType = 'SingleEnded';


%%
%{
configs.behavior.basic.A.tone.samplingFreq = TDTSampFreq;
configs.behavior.basic.A.tone.freqs = 12000;
configs.behavior.basic.A.tone.stimProba = 1;
configs.behavior.basic.A.tone.goStim = 1;
configs.behavior.basic.A.tone.stimDur = 0.2;
configs.behavior.basic.A.tone.nTones = 1;
configs.behavior.basic.A.tone.ISI = 0.1;
configs.behavior.basic.A.tone.oddProba = 0;

configs.behavior.basic.A.training.respTime = 1;
configs.behavior.basic.A.training.trialDur = 2;
configs.behavior.basic.A.training.startDelay = 1.5;
configs.behavior.basic.A.training.rewDur = 0.02;
configs.behavior.basic.A.training.rewDelay = 0;
configs.behavior.basic.A.training.timeoutPunish = 6;
configs.behavior.basic.A.training.minRespTime = 0.5;
configs.behavior.basic.A.training.rewCollTime = 2;
configs.behavior.basic.A.training.nTrials = 10;
configs.behavior.basic.A.training.startDelayRand = 2;

configs.behavior.basic.B.tone.samplingFreq = 44100;
configs.behavior.basic.B.tone.freqs = 12000;
configs.behavior.basic.B.tone.stimProba = 1;
configs.behavior.basic.B.tone.goStim = 1;
configs.behavior.basic.B.tone.stimDur = 0.2;
configs.behavior.basic.B.tone.nTones = 1;
configs.behavior.basic.B.tone.ISI = 0.1;
configs.behavior.basic.B.tone.oddProba = 0;
configs.behavior.basic.B.training.respTime = 1;
configs.behavior.basic.B.training.trialDur = 2;
configs.behavior.basic.B.training.startDelay = 1.5;
configs.behavior.basic.B.training.rewDur = 0.02;
configs.behavior.basic.B.training.rewDelay = 0;
configs.behavior.basic.B.training.timeoutPunish = 5;
configs.behavior.basic.B.training.minRespTime = 0;
configs.behavior.basic.B.training.rewCollTime = 1.5;
configs.behavior.basic.B.training.InTriLickTimerDur = 1.5;
configs.behavior.basic.B.training.nTrials = 100;
configs.behavior.basic.B.training.startDelayRand = 1;
configs.behavior.freqDiscr.C.tone.samplingFreq = 44100;
configs.behavior.freqDiscr.C.tone.freqs = [7000 12000];
configs.behavior.freqDiscr.C.tone.stimProba = [0.5 0.5];
configs.behavior.freqDiscr.C.tone.goStim = 2;
configs.behavior.freqDiscr.C.tone.stimDur = 0.1;
configs.behavior.freqDiscr.C.tone.nTones = 1;
configs.behavior.freqDiscr.C.tone.ISI = 0.1;
configs.behavior.freqDiscr.C.tone.oddProba = 0;
configs.behavior.freqDiscr.C.training.respTime = 1;
configs.behavior.freqDiscr.C.training.trialDur = 2;
configs.behavior.freqDiscr.C.training.startDelay = 1.5;
configs.behavior.freqDiscr.C.training.rewDur = 0.03;
configs.behavior.freqDiscr.C.training.rewDelay = 0;
configs.behavior.freqDiscr.C.training.timeoutPunish = 5;
configs.behavior.freqDiscr.C.training.minRespTime = 0;
configs.behavior.freqDiscr.C.training.rewCollTime = 1.5;
configs.behavior.freqDiscr.C.training.InTriLickTimerDur = 1.5;
configs.behavior.freqDiscr.C.training.nTrials = 100;
configs.behavior.freqDiscr.C.training.startDelayRand = 1;
configs.behavior.freqDiscr.D.tone.samplingFreq = 44100;
configs.behavior.freqDiscr.D.tone.freqs = [4000 8000 12000 16000 20000];
configs.behavior.freqDiscr.D.tone.stimProba = [0.1 0.1 0.6 0.1 0.1];
configs.behavior.freqDiscr.D.tone.goStim = 3;
configs.behavior.freqDiscr.D.tone.stimDur = 0.1;
configs.behavior.freqDiscr.D.tone.nTones = 1;
configs.behavior.freqDiscr.D.tone.ISI = 0;
configs.behavior.freqDiscr.D.tone.oddProba = 0;
configs.behavior.freqDiscr.D.training.respTime = 1;
configs.behavior.freqDiscr.D.training.trialDur = 2;
configs.behavior.freqDiscr.D.training.startDelay = 1.5;
configs.behavior.freqDiscr.D.training.rewDur = 0.04;
configs.behavior.freqDiscr.D.training.rewDelay = 0;
configs.behavior.freqDiscr.D.training.timeoutPunish = 5;
configs.behavior.freqDiscr.D.training.minRespTime = 0;
configs.behavior.freqDiscr.D.training.rewCollTime = 1.5;
configs.behavior.freqDiscr.D.training.InTriLickTimerDur = 1.5;
configs.behavior.freqDiscr.D.training.nTrials = 100;
configs.behavior.freqDiscr.D.training.startDelayRand = 1;
configs.behavior.freqDiscr.E.training.respTime = 1;
configs.behavior.freqDiscr.E.training.trialDur = 2;
configs.behavior.freqDiscr.E.training.startDelay = 1.5;
configs.behavior.freqDiscr.E.training.rewDur = 0.04;
configs.behavior.freqDiscr.E.training.rewDelay = 0;
configs.behavior.freqDiscr.E.training.timeoutPunish = 5;
configs.behavior.freqDiscr.E.training.minRespTime = 0;
configs.behavior.freqDiscr.E.training.rewCollTime = 1.5;
configs.behavior.freqDiscr.E.training.InTriLickTimerDur = 1.5;
configs.behavior.freqDiscr.E.training.nTrials = 100;
configs.behavior.freqDiscr.E.training.startDelayRand = 1;
configs.behavior.freqDiscr.E.tone.samplingFreq = 44100;
configs.behavior.freqDiscr.E.tone.freqs = [4000 8000 12000 16000 20000];
configs.behavior.freqDiscr.E.tone.stimProba = [0.15 0.15 0.4 0.15 0.15];
configs.behavior.freqDiscr.E.tone.goStim = 3;
configs.behavior.freqDiscr.E.tone.stimDur = 0.1;
configs.behavior.freqDiscr.E.tone.nTones = 1;
configs.behavior.freqDiscr.E.tone.ISI = 0;
configs.behavior.freqDiscr.E.tone.oddProba = 0;
configs.behavior.freqDiscr.F.training.respTime = 1;
configs.behavior.freqDiscr.F.training.trialDur = 2;
configs.behavior.freqDiscr.F.training.startDelay = 1.5;
configs.behavior.freqDiscr.F.training.rewDur = 0.04;
configs.behavior.freqDiscr.F.training.rewDelay = 0;
configs.behavior.freqDiscr.F.training.timeoutPunish = 5;
configs.behavior.freqDiscr.F.training.minRespTime = 0;
configs.behavior.freqDiscr.F.training.rewCollTime = 1.5;
configs.behavior.freqDiscr.F.training.InTriLickTimerDur = 1.5;
configs.behavior.freqDiscr.F.training.nTrials = 100;
configs.behavior.freqDiscr.F.training.startDelayRand = 1;
configs.behavior.freqDiscr.F.tone.samplingFreq = 44100;
configs.behavior.freqDiscr.F.tone.freqs = [4000 8000 12000 16000 20000];
configs.behavior.freqDiscr.F.tone.stimProba = [0.175 0.175 0.3 0.175 0.175];
configs.behavior.freqDiscr.F.tone.goStim = 3;
configs.behavior.freqDiscr.F.tone.stimDur = 0.1;
configs.behavior.freqDiscr.F.tone.nTones = 1;
configs.behavior.freqDiscr.F.tone.ISI = 0;
configs.behavior.freqDiscr.F.tone.oddProba = 0;
configs.behavior.oddDiscr.B.tone.samplingFreq = 44100;
configs.behavior.oddDiscr.B.tone.freqs = 12000;
configs.behavior.oddDiscr.B.tone.stimProba = 1;
configs.behavior.oddDiscr.B.tone.nTrials = 30;
configs.behavior.oddDiscr.B.tone.goStim = 1;
configs.behavior.oddDiscr.B.tone.stimDur = 0.2;
configs.behavior.oddDiscr.B.tone.nTones = 2;
configs.behavior.oddDiscr.B.tone.ISI = 0.1;
configs.behavior.oddDiscr.B.tone.oddProba = 0;
configs.behavior.oddDiscr.B.training.respTime = 1;
configs.behavior.oddDiscr.B.training.trialDur = 2;
configs.behavior.oddDiscr.B.training.startDelay = 0.5;
configs.behavior.oddDiscr.B.training.rewDur = 0.02;
configs.behavior.oddDiscr.B.training.rewDelay = 0;
configs.behavior.oddDiscr.B.training.timeoutPunish = 5;
configs.behavior.oddDiscr.B.training.minRespTime = 0.2;
configs.behavior.oddDiscr.B.training.rewCollTime = 1.5;
configs.behavior.oddDiscr.B.training.InTriLickTimerDur = 4;
configs.behavior.oddDiscr.C.training.respTime = 1;
configs.behavior.oddDiscr.C.training.trialDur = 2;
configs.behavior.oddDiscr.C.training.startDelay = 0.5;
configs.behavior.oddDiscr.C.training.rewDur = 0.02;
configs.behavior.oddDiscr.C.training.rewDelay = 0;
configs.behavior.oddDiscr.C.training.timeoutPunish = 5;
configs.behavior.oddDiscr.C.training.minRespTime = 0.2;
configs.behavior.oddDiscr.C.training.rewCollTime = 1.5;
configs.behavior.oddDiscr.C.training.InTriLickTimerDur = 4;
configs.behavior.oddDiscr.C.tone.samplingFreq = 44100;
configs.behavior.oddDiscr.C.tone.freqs = 12000;
configs.behavior.oddDiscr.C.tone.stimProba = 1;
configs.behavior.oddDiscr.C.tone.nTrials = 100;
configs.behavior.oddDiscr.C.tone.goStim = 1;
configs.behavior.oddDiscr.C.tone.stimDur = 0.2;
configs.behavior.oddDiscr.C.tone.nTones = 4;
configs.behavior.oddDiscr.C.tone.ISI = 0.1;
configs.behavior.oddDiscr.C.tone.oddProba = 0;
configs.behavior.oddDiscr.D.tone.samplingFreq = 44100;
configs.behavior.oddDiscr.D.tone.freqs = [7000 12000];
configs.behavior.oddDiscr.D.tone.stimProba = [0.5 0.5];
configs.behavior.oddDiscr.D.tone.nTrials = 100;
configs.behavior.oddDiscr.D.tone.goStim = 1;
configs.behavior.oddDiscr.D.tone.stimDur = 0.2;
configs.behavior.oddDiscr.D.tone.nTones = 4;
configs.behavior.oddDiscr.D.tone.ISI = 0.1;
configs.behavior.oddDiscr.D.tone.oddProba = 0.3;
configs.behavior.oddDiscr.D.training.respTime = 1;
configs.behavior.oddDiscr.D.training.trialDur = 2;
configs.behavior.oddDiscr.D.training.startDelay = 0.5;
configs.behavior.oddDiscr.D.training.rewDur = 0.02;
configs.behavior.oddDiscr.D.training.rewDelay = 0;
configs.behavior.oddDiscr.D.training.timeoutPunish = 5;
configs.behavior.oddDiscr.D.training.minRespTime = 0.2;
configs.behavior.oddDiscr.D.training.rewCollTime = 1.5;
configs.behavior.oddDiscr.D.training.InTriLickTimerDur = 4;
configs.behavior.cotDiscr.C1.tone.samplingFreq = 44100;
configs.behavior.cotDiscr.C1.tone.freqs = [4594.79341998814 18379.1736799526];
configs.behavior.cotDiscr.C1.tone.stimProba = [0.5 0.5];
configs.behavior.cotDiscr.C1.tone.goStim = 1;
configs.behavior.cotDiscr.C1.tone.toneDur = 0.03;
configs.behavior.cotDiscr.C1.tone.toneISI = 0.01;
configs.behavior.cotDiscr.C1.tone.stimDur = 0.21;
configs.behavior.cotDiscr.C1.tone.cloudDispersion = 2;
configs.behavior.cotDiscr.C1.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
configs.behavior.cotDiscr.C1.tone.nTones = 1;
configs.behavior.cotDiscr.C1.tone.ISI = 0;
configs.behavior.cotDiscr.C1.tone.freqIndexes = [3 23];
configs.behavior.cotDiscr.C1.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2      
      2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 2 2      
      1 1 1 2 2 1 1 1 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2      
      2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 2 2 1 1 2 2 2 1 1 1 1 1 1 2 1 1 2 2      
      2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 1 1 2 1 2 2 1 2 2 2 2 2 2 1 2 2 1 2 2 2 1];
configs.behavior.cotDiscr.C1.training.maxRespTime = 1;
configs.behavior.cotDiscr.C1.training.startDelay = 1.5;
configs.behavior.cotDiscr.C1.training.timeoutPunish = 5;
configs.behavior.cotDiscr.C1.training.minRespTime = 0;
configs.behavior.cotDiscr.C1.training.rewCollTime = 1.5;
configs.behavior.cotDiscr.C1.training.nTrials = 100;
configs.behavior.cotDiscr.C1.training.startDelayRand = 1;
configs.behavior.cotDiscr.C1.training.endDelay = 4;
configs.behavior.cotDiscr.C1.training.rewDur = 0.02;
configs.behavior.cotDiscr.A.tone.samplingFreq = 44100;
configs.behavior.cotDiscr.A.tone.freqs = [4594.79341998814 18379.1736799526];
configs.behavior.cotDiscr.A.tone.stimProba = [0.5 0.5];
configs.behavior.cotDiscr.A.tone.goStim = [1 2];
configs.behavior.cotDiscr.A.tone.toneDur = 0.03;
configs.behavior.cotDiscr.A.tone.toneISI = 0.01;
configs.behavior.cotDiscr.A.tone.stimDur = 0.21;
configs.behavior.cotDiscr.A.tone.cloudDispersion = 2;
configs.behavior.cotDiscr.A.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
configs.behavior.cotDiscr.A.tone.nTones = 1;
configs.behavior.cotDiscr.A.tone.ISI = 0;
configs.behavior.cotDiscr.A.tone.freqIndexes = [3 23];
configs.behavior.cotDiscr.A.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2       
     2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 2 2       
     1 1 1 2 2 1 1 1 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2       
     2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 2 2 1 1 2 2 2 1 1 1 1 1 1 2 1 1 2 2       
     2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 1 1 2 1 2 2 1 2 2 2 2 2 2 1 2 2 1 2 2 2 1];
configs.behavior.cotDiscr.A.training.maxRespTime = 1.5;
configs.behavior.cotDiscr.A.training.startDelay = 2;
configs.behavior.cotDiscr.A.training.rewDur = 0.02;
configs.behavior.cotDiscr.A.training.timeoutPunish = 0;
configs.behavior.cotDiscr.A.training.minRespTime = 0;
configs.behavior.cotDiscr.A.training.rewCollTime = 1.5;
configs.behavior.cotDiscr.A.training.nTrials = 50;
configs.behavior.cotDiscr.A.training.startDelayRand = 1;
configs.behavior.cotDiscr.A.training.endDelay = 4.5;
configs.behavior.cotDiscr.C2.tone.samplingFreq = 44100;
configs.behavior.cotDiscr.C2.tone.freqs = [4594.79341998814 18379.1736799526];
configs.behavior.cotDiscr.C2.tone.stimProba = [0.5 0.5];
configs.behavior.cotDiscr.C2.tone.goStim = 2;
configs.behavior.cotDiscr.C2.tone.toneDur = 0.03;
configs.behavior.cotDiscr.C2.tone.toneISI = 0.01;
configs.behavior.cotDiscr.C2.tone.stimDur = 0.21;
configs.behavior.cotDiscr.C2.tone.cloudDispersion = 2;
configs.behavior.cotDiscr.C2.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
configs.behavior.cotDiscr.C2.tone.nTones = 1;
configs.behavior.cotDiscr.C2.tone.ISI = 0;
configs.behavior.cotDiscr.C2.tone.freqIndexes = [3 23];
configs.behavior.cotDiscr.C2.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2      
      2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 2 2      
      1 1 1 2 2 1 1 1 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2      
      2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 2 2 1 1 2 2 2 1 1 1 1 1 1 2 1 1 2 2      
      2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 1 1 2 1 2 2 1 2 2 2 2 2 2 1 2 2 1 2 2 2 1];
configs.behavior.cotDiscr.C2.training.maxRespTime = 1;
configs.behavior.cotDiscr.C2.training.startDelay = 1.5;
configs.behavior.cotDiscr.C2.training.rewDur = 0.02;
configs.behavior.cotDiscr.C2.training.timeoutPunish = 5;
configs.behavior.cotDiscr.C2.training.minRespTime = 0;
configs.behavior.cotDiscr.C2.training.rewCollTime = 1.5;
configs.behavior.cotDiscr.C2.training.nTrials = 100;
configs.behavior.cotDiscr.C2.training.startDelayRand = 1;
configs.behavior.cotDiscr.C2.training.endDelay = 4;
configs.behavior.cotDiscr.QW.tone.samplingFreq = 44100;
configs.behavior.cotDiscr.QW.tone.freqs = [4594.79341998814 18379.1736799526];
configs.behavior.cotDiscr.QW.tone.stimProba = [0.5 0.5];
configs.behavior.cotDiscr.QW.tone.goStim = [1 2];
configs.behavior.cotDiscr.QW.tone.toneDur = 0.03;
configs.behavior.cotDiscr.QW.tone.toneISI = 0.01;
configs.behavior.cotDiscr.QW.tone.stimDur = 0.21;
configs.behavior.cotDiscr.QW.tone.cloudDispersion = 2;
configs.behavior.cotDiscr.QW.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
configs.behavior.cotDiscr.QW.tone.nTones = 1;
configs.behavior.cotDiscr.QW.tone.ISI = 0;
configs.behavior.cotDiscr.QW.tone.freqIndexes = [3 23];
configs.behavior.cotDiscr.QW.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2      
      2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 2 2      
      1 1 1 2 2 1 1 1 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2      
      2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 2 2 1 1 2 2 2 1 1 1 1 1 1 2 1 1 2 2      
      2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 1 1 2 1 2 2 1 2 2 2 2 2 2 1 2 2 1 2 2 2 1];
configs.behavior.cotDiscr.QW.training.maxRespTime = 0;
configs.behavior.cotDiscr.QW.training.startDelay = 2;
configs.behavior.cotDiscr.QW.training.rewDur = 0;
configs.behavior.cotDiscr.QW.training.timeoutPunish = 0;
configs.behavior.cotDiscr.QW.training.minRespTime = 0;
configs.behavior.cotDiscr.QW.training.rewCollTime = 0;
configs.behavior.cotDiscr.QW.training.nTrials = 50;
configs.behavior.cotDiscr.QW.training.startDelayRand = 1;
configs.behavior.cotDiscr.QW.training.endDelay = 6;
configs.behavior.cotDiscr.B1.tone.samplingFreq = 44100;
configs.behavior.cotDiscr.B1.tone.freqs = [4594.79341998814 18379.1736799526];
configs.behavior.cotDiscr.B1.tone.stimProba = [0.5 0.5];
configs.behavior.cotDiscr.B1.tone.goStim = 1;
configs.behavior.cotDiscr.B1.tone.toneDur = 0.03;
configs.behavior.cotDiscr.B1.tone.toneISI = 0.01;
configs.behavior.cotDiscr.B1.tone.stimDur = 0.21;
configs.behavior.cotDiscr.B1.tone.cloudDispersion = 2;
configs.behavior.cotDiscr.B1.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
configs.behavior.cotDiscr.B1.tone.nTones = 1;
configs.behavior.cotDiscr.B1.tone.ISI = 0;
configs.behavior.cotDiscr.B1.tone.freqIndexes = [3 23];
configs.behavior.cotDiscr.B1.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2      
      2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 2 1 2 1 2 2 1 2 2 1 1      
      1 1 1 2 1 1 2 2 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 1 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2      
      2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 2 1 1 2 1 2 1 2 1 1 2 2      
      2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 1 1 2 1 1 2 1 2 2 1 2 1 2 2 1 2 2 1 1 2 2 1 2 2 1 2 2 2 1];
configs.behavior.cotDiscr.B1.training.maxRespTime = 1;
configs.behavior.cotDiscr.B1.training.startDelay = 1.5;
configs.behavior.cotDiscr.B1.training.timeoutPunish = 5;
configs.behavior.cotDiscr.B1.training.minRespTime = 0;
configs.behavior.cotDiscr.B1.training.rewCollTime = 1.5;
configs.behavior.cotDiscr.B1.training.nTrials = 50;
configs.behavior.cotDiscr.B1.training.startDelayRand = 1;
configs.behavior.cotDiscr.B1.training.endDelay = 4;
configs.behavior.cotDiscr.B1.training.rewDur = 0.02;
s.tone.samplingFreq = 44100;
s.tone.freqs = [4594.79341998814 18379.1736799526];
s.tone.stimProba = [0.5 0.5];
s.tone.goStim = 2;
s.tone.toneDur = 0.03;
s.tone.toneISI = 0.01;
s.tone.stimDur = 0.21;
s.tone.cloudDispersion = 2;
s.tone.uniqueFreqs = [4000 4287.09385014517 4594.79341998814 4924.57765337967 5278.03164309158 5656.85424949238 6062.86626604159 6498.01917084989 6964.40450636899 7464.26393229446 8000 8574.18770029035 9189.58683997628 9849.15530675933 10556.0632861832 11313.7084989848 12125.7325320832 12996.0383416998 13928.809012738 14928.5278645889 16000 17148.3754005807 18379.1736799526 19698.3106135187 21112.1265723663];
s.tone.nTones = 1;
s.tone.ISI = 0;
s.tone.freqIndexes = [3 23];
s.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2      
      2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 2 2      
      1 1 1 2 2 1 1 1 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2      
      2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 2 2 1 1 2 2 2 1 1 1 1 1 1 2 1 1 2 2      
      2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 1 1 2 1 2 2 1 2 2 2 2 2 2 1 2 2 1 2 2 2 1];
s.training.maxRespTime = 1;
s.training.startDelay = 1.5;
s.training.rewDur = 0.02;
s.training.timeoutPunish = 5;
s.training.minRespTime = 0;
s.training.rewCollTime = 1.5;
s.training.nTrials = 50;
s.training.startDelayRand = 1;
s.training.endDelay = 4;
s.tone.samplingFreq = 97656.25;
s.tone.freqs = [5946.03557501361 10905.0773266526];
s.tone.stimProba = [0.5 0.5];
s.tone.goStim = [];
s.tone.toneDur = 0.03;
s.tone.toneISI = 0.01;
s.tone.stimDur = 0.2;
s.tone.cloudDispersion = 2;
s.tone.uniqueFreqs = [5000 5452.53866332629 5946.03557501361 6484.19777325505 7071.06781186548 7711.05412703971 8408.96415253715 9170.04043204671 10000 10905.0773266526 11892.0711500272 12968.3955465101 14142.135623731 15422.1082540794 16817.9283050743 18340.0808640934 20000 21810.1546533052 23784.1423000544 25936.7910930202 28284.2712474619 30844.2165081588 33635.8566101486 36680.1617281868 40000];
s.tone.nTones = [5 6 7 8 9 10];
s.tone.ISI = 0.6;
s.tone.freqIndexes = [3 10];
s.tone.stimMatrix = [1 2 2 2 1 1 2 2 2 1 1 2 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 1 1 1 2 2 1 1 2 2 1 2 2 1 1 1 2 2 1 1 1 2 2 2 
   2 2 2 1 1 2 1 2 1 1 1 2 2 2 1 1 1 2 2 1 1 1 2 1 2 1 2 1 2 1 2 2 2 1 1 2 2 1 1 2 1 2 1 2 2 1 2 2 1 1 
   1 1 1 2 1 1 2 2 1 2 1 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 1 1 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 2 1 2 1 1 2 2 
   2 2 1 1 1 2 2 2 1 2 2 2 1 2 2 1 1 1 1 2 2 1 2 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 2 1 1 2 1 2 1 2 1 1 2 2 
   2 1 2 1 1 1 2 1 1 2 2 1 2 2 1 1 1 2 1 1 2 1 1 2 1 1 2 1 2 2 1 2 1 2 2 1 2 2 1 1 2 2 1 2 2 1 2 2 2 1];
s.tone.oddProba = 0.1;
s.tone.nTonesMatrix = [6 8 8 9 8 9 10 5 6 9 9 5 7 7 7 6 8 10 7 10 6 5 5 7 6 6 7 6 6 7 5 6 5 8 9 10 10 7 9 8 8 8 8 10 9 9 5 10 5 10 
     5 8 9 10 8 10 6 9 6 8 7 10 7 7 5 7 7 9 8 5 10 7 7 9 9 7 10 6 9 10 6 6 10 6 5 8 8 8 5 9 5 6 8 8 6 5 5 6 9 10 
     10 6 9 5 7 7 8 9 9 8 5 8 6 10 8 5 7 6 8 7 10 7 6 5 9 6 5 10 8 6 9 5 5 7 7 10 10 8 5 10 8 6 9 9 9 7 6 10 8 6 
     9 10 6 7 10 8 6 7 5 8 8 8 5 9 5 6 6 8 9 5 8 9 8 10 7 10 10 7 5 9 7 9 7 5 7 9 10 5 10 8 6 5 6 6 6 10 9 6 7 8 
     7 5 7 5 8 10 7 9 6 9 5 8 6 9 10 6 5 5 6 6 8 7 7 10 6 10 8 6 9 6 8 5 9 5 8 9 8 10 8 7 7 9 7 10 6 5 10 10 9 8];
s.training.maxRespTime = 0;
s.training.startDelay = 3;
s.training.rewDur = 0;
s.training.timeoutPunish = 0;
s.training.minRespTime = 0;
s.training.rewCollTime = 0;
s.training.nTrials = 50;
s.training.startDelayRand = 1;
s.training.endDelay = 6;

%%

configs.behavior = struct();
configs.hardware = struct();

configs.behavior.cotOdd = struct('A', configs.behavior.cotDiscr.A);
s = s;
s.tone.samplingFreq = 97656.25;
s.tone.uniqueFreqs = 5000 * (2 .^ (((1 : 25) - 1) * (2 ^ -3)));
s.tone.cloudDispersion = 2;
% s.tone.cloudDispersion = 4;
% s.tone.freqIndexes = [1 + s.tone.cloudDispersion numel(s.tone.uniqueFreqs) - s.tone.cloudDispersion];
s.tone.freqIndexes = [3 10];
s.tone.freqs = s.tone.uniqueFreqs(s.tone.freqIndexes);
s.tone.stimProba = [0.5 0.5];
s.tone.oddProba = 0.1;
s.tone.goStim = [];
s.tone.toneDur = 0.03;
s.tone.toneISI = 0.01;
s.tone.stimDur = 0.2;
s.tone.ISI = 0.8 - s.tone.stimDur;
s.tone.stimMatrix = [ ...
    1,2,2,2,1,1,2,2,2,1,1,2,1,1,1,2,1,2,2,1,2,2,2,1,1,1,2,1,1,1,2,2,1,1,2,2,1,2,2,1,1,1,2,2,1,1,1,2,2,2;...
    2,2,2,1,1,2,1,2,1,1,1,2,2,2,1,1,1,2,2,1,1,1,2,1,2,1,2,1,2,1,2,2,2,1,1,2,2,1,1,2,1,2,1,2,2,1,2,2,1,1;...
    1,1,1,2,1,1,2,2,1,2,1,2,1,1,1,2,1,2,2,1,2,1,1,2,1,2,1,1,2,2,1,2,1,1,2,2,2,1,1,2,1,2,2,2,1,2,1,1,2,2;...
    2,2,1,1,1,2,2,2,1,2,2,2,1,2,2,1,1,1,1,2,2,1,2,2,1,1,2,1,1,2,2,1,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,2,2;...
    2,1,2,1,1,1,2,1,1,2,2,1,2,2,1,1,1,2,1,1,2,1,1,2,1,1,2,1,2,2,1,2,1,2,2,1,2,2,1,1,2,2,1,2,2,1,2,2,2,1;...
    ];
s.tone.nTones = 5 : 10;
nTrials = 50;
n = round(nTrials ./ numel(s.tone.nTones));
nRows = 5;
nTonesMatrix = [repmat(s.tone.nTones, nRows, n), repmat([6 8], 5, 1)];
for iRow = 1 : nRows;
    nTonesMatrix(iRow, :) = nTonesMatrix(iRow, randperm(nTrials));
end;
s.tone.nTonesMatrix = nTonesMatrix;

s.training.maxRespTime = 0;
s.training.startDelay = 3;
s.training.rewDur = 0;
s.training.timeoutPunish = 0;
s.training.minRespTime = 0;
s.training.rewCollTime = 0;
s.training.nTrials = nTrials;
s.training.startDelayRand = 1;
s.training.endDelay = 10;
s = s;

%}
