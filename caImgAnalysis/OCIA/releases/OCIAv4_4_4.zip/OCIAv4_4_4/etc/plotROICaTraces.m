function fig = plotROICaTraces(axeH, iRun, saveName, caTraces, caTracesFilt, stim, ROISet, t, tFilt)

% created by B. Laurenczy - 2013 (adapted from H. Luetcke)

dbgLevel = 0;
% init the size of the data set
nROIs = size(ROISet, 1);
nFrames = size(caTraces, 2);
isFilt = ~isempty(caTracesFilt);
o('    #plotROICaTraces: run %d ''%s'', %d ROI(s), %d frame(s) ...', ...
    iRun, saveName, nROIs, nFrames, 2, dbgLevel);

% init the title and the figure
if iRun;
    titleStr = sprintf('%s_run%02d', saveName, iRun);
else
    titleStr = saveName;
end;
if isempty(axeH);
    fig = figure('Name', titleStr, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', fig);
else
    fig = getParentFigure(axeH);
end;

% extract the stimuli times
stimTimes = t(stim > 0);
% extract the stimulus 'IDs' by converting the stim index into a string (the index of the stimuli)
stimIDIndexes = stim(stim > 0);
stimIDs = cell(1, numel(stimIDIndexes));
for n = 1 : numel(stimIDIndexes);
    stimIDs{n} = num2str(stimIDIndexes(n));
end

o('    #plot..races: run %d, variables initialized.', iRun, 2, dbgLevel);

currOffSet = 0; % offset between each ROI
% overallOffset = 0;
normCaTraces = zeros(size(caTraces));
if isFilt; normFiltCaTraces = zeros(size(caTracesFilt)); end;
% go through each ROI to extract the ROI's ID and to normalize the data
iROI = 1;
for iROILoop = 1 : nROIs;
    ROICaTrace = caTraces(iROILoop, :);
    if isFilt; ROICaTraceFilt = caTracesFilt(iROILoop, :); end;
    % if the ROI trace is not empty/null
    if nansum(ROICaTrace);
        % normalize by removing the minimum value and add the maximum so far
        if isFilt; meanDiff = nanmean(ROICaTrace) - nanmean(ROICaTraceFilt); end;
%         if isFilt; lowestMin = min([ROICaTrace ROICaTraceFilt]);
%         else       lowestMin = min(ROICaTrace);
%         end;
%         if isFilt; lowestMin = prctile([ROICaTrace ROICaTraceFilt], 1);
%         else       lowestMin = prctile(ROICaTrace, 1);
%         end;
%         if currOffSet == 0;
%            overallOffset = lowestMin;
%         end;
%         normCaTraces(iROI, :) = ROICaTrace - lowestMin + currOffSet;
%         if isFilt; normFiltCaTraces(iROI, :) = ROICaTraceFilt + meanDiff - lowestMin + currOffSet; end;
        normCaTraces(iROI, :) = ROICaTrace + currOffSet;
        if isFilt; normFiltCaTraces(iROI, :) = ROICaTraceFilt + meanDiff + currOffSet; end;
        currOffSet = nanmax(normCaTraces(iROI, :));
        iROI = iROI + 1;
    else
        nROIs = nROIs - 1;
        normCaTraces(iROI, :) = [];
        if isFilt; normFiltCaTraces(iROI, :) = []; end;
        o('      #plot..races: run %d, ROI [iROILoop:%d-iROI:%d] is null (no value above 0).', ...
            iRun, iROILoop, iROI, 0, dbgLevel);
    end;
end;
o('    #plot..races: run %d, caTraces normalized.', iRun, 2, dbgLevel);

% if currOffSet > 10000; roundTo = 1000;
% elseif currOffSet > 5000; roundTo = 500;
% elseif currOffSet > 2000; roundTo = 200;
% elseif currOffSet > 1000; roundTo = 100;
% elseif currOffSet > 500; roundTo = 50;
% elseif currOffSet > 200; roundTo = 20;
% elseif currOffSet > 100; roundTo = 10;
% elseif currOffSet > 50; roundTo = 5;
% elseif currOffSet > 10; roundTo = 1;
% else roundTo = 1;
% end;

% DRRTicks = roundn(overallOffset, max(round(log(roundTo)) - 1, 0)) : roundTo : currOffSet;
% DRRTicks = 0 : roundTo : currOffSet;

% adjust the axes of the calcium traces
% yLimits = [overallOffset currOffSet];
yLimits = [min(normCaTraces(:)) currOffSet];
xLimits = [min(t) - 0.2  max(t) + 0.2];
% set(axeH, 'ylim', yLimits, 'xlim', xLimits, 'YTick', DRRTicks, 'YTickLabel', DRRTicks);
set(axeH, 'ylim', yLimits, 'xlim', xLimits);
xlabel(axeH, 'Time [s]');
% create and adjust the axes of the labels (ROI labels and stim)
ylabel(axeH, sprintf('%s', 'dFF/dRR [%]'));
labelAxe = axes('Position', get(axeH, 'Position'), 'Parent', get(axeH, 'Parent'), ...
    'YAxisLocation', 'right', 'XAxisLocation', 'top', 'Tag', 'ROICaTracesPlotLabelAxe');
ROIIDs = arrayfun(@(iROI)sprintf('%s (%4.2f)', ROISet{iROI, 1}, nanstd(normCaTraces(iROI, :))), ...
    1 : nROIs, 'UniformOutput', false)';

nROIs = size(ROIIDs, 1);
if nROIs > 300; roundTo = 20;
elseif nROIs > 150; roundTo = 10;
elseif nROIs > 80; roundTo = 5;
elseif nROIs > 40; roundTo = 2;
else roundTo = 1;
end;

ROITicks = 0 : roundTo : nROIs;
ROITicks(1) = 1;
ROITicks(end) = numel(ROIIDs);
ROITicks = unique(ROITicks);
ROIIDLabels = ROIIDs(ROITicks);
set(labelAxe, 'YLim', yLimits, 'YTick', nanmean(normCaTraces(ROITicks, :), 2), 'YTickLabel', ROIIDLabels);
set(labelAxe, 'XTick', stimTimes, 'XTickLabel', stimIDs);
title(axeH, titleStr, 'Interpreter', 'none');
o('    #plot..races: run %d, axes initialized.', iRun, 2, dbgLevel);

% make the trace axe the current axe
set(fig, 'CurrentAxes', axeH);
hold(axeH, 'all');
if ~isempty(stim);
    % colors for the simuli
    % stimColors = jet(numel(unique(stimIDIndexes)));
    stimColors = lines(max(stimIDIndexes));
    % plot the stimuli in the appropriate colors
    for n = 1 : numel(stim);
        if stim(n) > 0;
            plot(axeH, [t(n) t(n)], yLimits, 'LineStyle', '--', 'Color', stimColors(stim(n), :));
        end;
    end
    o('    #plot..races: run %d, stims plotted.', iRun, 2, dbgLevel);
end;

% plotting loop
o('    #plot..races: run %d, plotting calcium traces ...', iRun, 3, dbgLevel);
% colors for the ROIs
ROIColors = lines(nROIs);
plotHandles = zeros(nROIs, 1); % for legend handling
for iROI = 1 : nROIs;
    o('      #plot..races: run %d - ROI %d, plotting calcium trace ...', iRun, iROI, 4, dbgLevel);
    if isFilt;
        % plot the 'raw' calcium trace in gray
        plotHandles(iROI) = plot(axeH, t, normCaTraces(iROI, :), 'LineWidth', 1, 'Color', [.8 .8 .8]);
        % plot the filtered calcium trace in color
        plotHandles(iROI) = plot(axeH, tFilt, normFiltCaTraces(iROI, :), 'LineWidth', 1.5, 'Color', ROIColors(iROI, :));
    else
        % plot the 'raw' calcium trace in color
        plotHandles(iROI) = plot(axeH, t, normCaTraces(iROI, :), 'LineWidth', 1.5, 'Color', ROIColors(iROI, :));
    end;
    % stop for some reason before displaying the last ROI (the neuropil?)
    if iROI == nROIs; break; end;
    o('      #plot..races: run %d - ROI %d, plotting calcium trace done.', iRun, iROI, 3, dbgLevel);
end;
o('    #plot..races: run %d, plotting calcium traces done.', iRun, 2, dbgLevel);

linkaxes([labelAxe, axeH], 'xy'); % link the axes so the traces and stim indications are aligned
set(axeH, 'ylim', yLimits, 'xlim', xLimits);
o('    #plot..races: run %d, axes linked.', iRun, 2, dbgLevel);

o('    #plot..races: run %d ''%s'', %d ROI(s), %d frame(s) done.', ...
    iRun, saveName, nROIs, nFrames, 1, dbgLevel);
hold(axeH, 'off');

% make the axe handle the top-most element
restackAxes(axeH, 'top');

end
