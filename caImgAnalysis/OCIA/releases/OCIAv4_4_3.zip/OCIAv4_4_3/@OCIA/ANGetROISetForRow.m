%% #OCIA:AN:ANGetROISetForRow
function [ROISet, runsValidity, iDWROISetRow, iDWRefRow, refImage] = ANGetROISetForRow(this, iDWRow)

ROISet = []; % default is empty
runsValidity = []; % default is empty
iDWROISetRow = []; % default is empty
iDWRefRow = []; % default is empty
refImage = []; % default is empty

% try to match the ROISet for the requested row
ROISetHits = regexp(char(this.dw.runTable{iDWRow, 16}), '^RS(?<iROISet>\d+)', 'names');
% if no ROISet information, try to find ROISet as the ROISet row itself
if isempty(ROISetHits);
    ROISetHits = regexp(char(this.dw.runTable{iDWRow, 8}), '^RS(?<iROISet>\d+)', 'names');
end;

% if no ROISet information, return empty and show warning
if isempty(ROISetHits);
    showWarning(this, 'OCIA:ANCalcDRRForRow:NoROISet', sprintf('No ROISet for %s__%s (%d)! Skipping.', ...
        this.dw.runTable{iDWRow, 2 : 3}, iDWRow));
    return;
else
    iROISet = str2double(ROISetHits.iROISet);
end;

if iROISet > size(this.data.img.ROISets, 1);
    showWarning(this, 'OCIA:ANGetROISetForRow:ROISetNotInMemory', ...
        sprintf('ROISet for %s__%s (%d) is not in memory anymore.', this.dw.runTable{iDWRow, 2 : 3}, iDWRow));
    return;
end;

% get the row index of this ROISet
iDWROISetRow = DWFindRunTableRows(this, 'ROISet', '', '', sprintf('RS%02d', iROISet), '', '', '');
% get the rows which have of this ROISet as ROISet
dataRowsForRef = DWFindRunTableRows(this, '[dD]ata', this.dw.runTable{iDWROISetRow, 2}, '', '', '', '', ...
    sprintf('RS%02d', iROISet));
% get the row index of the reference run of this ROISet (data row that has the same time)
iDWRefRow = dataRowsForRef(strcmp(this.dw.runTable(dataRowsForRef, 3), this.dw.runTable{iDWROISetRow, 3}));


% get the ROISet
ROISet = this.data.img.ROISets{iROISet, 1};
% get the runs validity
runsValidity = this.data.img.ROISets{iROISet, 2};
% get the reference image
refImage = this.data.img.ROISets{iROISet, 3};

% if mask is empty, show warning
if ~any(size(ROISet{1, 2}));
    
    ROISet = [];
    runsValidity = [];
    iDWROISetRow = [];
    iDWRefRow = [];
    refImage = [];
    
    showWarning(this, 'OCIA:ANGetROISetForRow:ROISetHasNoMask', ...
        sprintf('ROISet found for %s (%d) has no mask (empty dimensions)! Skipping.', ...
        this.dw.runTable{iDWRow, 2 : 3}, iDWRow));
        
end;
    
end
