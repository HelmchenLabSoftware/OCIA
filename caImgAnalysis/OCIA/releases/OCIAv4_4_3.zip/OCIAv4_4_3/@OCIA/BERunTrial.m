%% #BERunTrial
function RP = BERunTrial(this)

RP = []; %#ok<NASGU>

% init some variables
nTrials = this.be.config.training.nTrials;
iTrial = this.be.iTrial;
interTrialLickCount = 0;
resp = 0;
this.be.punishTimeOuts(iTrial) = 0;

showMessage(this, sprintf('%s | Trial %03d/%03d - start ... ', datestr(now(), this.be.logDateFormat), ...
    iTrial, this.be.config.training.nTrials), 'yellow');

% load sound into TDT
TDTLoadTic = tic;
soundToPlay = this.be.toneArray{iTrial};
% attenuation = randi(4, 1) - 1; % randomized 0 - 3 dB SPL attenuation
attenuation = 0;
RP = playTDTSound(soundToPlay, attenuation, this.GUI.figH);
o('#BERunTrial: TDT loaded, attenuation: %d dB SPL (%.4f)', attenuation, toc(TDTLoadTic), 2, this.verb);

% calculate a random delay for starting the sounds
randomStartDelay = this.be.config.training.startDelay ...
    + (rand - 0.5) * 2 * this.be.config.training.startDelayRand;
randomStartDelay = randomStartDelay + 1; % add delay for the imagTTL delay

% reset the stored data so the plot starts at the T0 of the trial (trial start time)
for iChan = 1 : size(this.be.hw.analogIns, 2);
    anInName = this.be.hw.analogIns{iChan};
    this.be.anInData.(anInName) = [];
end;

if this.be.hw.anIn.IsRunning;
    this.be.hw.anIn.stop();
end;
this.be.hw.anIn.startBackground();
this.be.times.start(iTrial) = nowUNIXSec;
o('Times:start: %.4f', this.be.times.start(iTrial), 3, this.verb);

 % /!\ NOTE: all times are in seconds (with decimals though) since trial start ("trialStartTimes", UNIX time)

%% ---- BERunTrial - trial start initial (random) delay
this.be.times.startDelay(iTrial) = randomStartDelay;
o('Times:startDelay: %.4f', this.be.times.startDelay(iTrial), 3, this.verb);
BEImagingTTL(this, 1); % launch imaging before the random start delay
this.be.times.imag(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
o('Times:imag: %.4f', this.be.times.imag(iTrial), 3, this.verb);

% start waiting loop
while (nowUNIXSec - this.be.times.start(iTrial)) < this.be.times.startDelay(iTrial);
    if ~this.be.isRunning; return; end; % check if experiment is paused/stopped
    pause(0.1); % avoid full-speed looping
%     o('Start delay waiting loop ... %.4f', nowUNIXSec - this.be.times.start(iTrial), 3, this.verb);
end;
this.be.nInTriLick(iTrial) = interTrialLickCount;

if ~this.be.isRunning; return; end; % check if experiment is paused/stopped

% %% ---- BERunTrial - play sound (NO TDT)
% soundToPlay = this.be.toneArray{iTrial};
% player = audioplayer(soundToPlay, this.be.config.tone.samplingFreq);
% player.playblocking;

%% ---- BERunTrial - play sound (TDT)
% play sound using TDT
RP.SoftTrg(1);
this.be.times.sound(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
o('Times:sound: %.4f', this.be.times.sound(iTrial), 3, this.verb);


%% ---- BERunTrial - wait for response
abortTrial = 0;
this.be.times.respWaitStart(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
this.be.times.respMin(iTrial) = this.be.times.respWaitStart(iTrial) + this.be.config.training.minRespTime;
this.be.times.respMax(iTrial) = this.be.times.respWaitStart(iTrial) + this.be.config.training.maxRespTime;
o('Times:respWaitStart: %.4f', this.be.times.respWaitStart(iTrial), 3, this.verb);
o('Times:respMin: %.4f', this.be.times.respMin(iTrial), 3, this.verb);
o('Times:respMax: %.4f', this.be.times.respMax(iTrial), 3, this.verb);

% display message
if ~isempty(this.be.config.tone.goStim);
    showMessage(this, sprintf('%s | Trial %03d/%03d - waiting for response ... ', ...
        datestr(now(), this.be.logDateFormat), iTrial, this.be.config.training.nTrials), 'yellow');
    this.be.times.soundDur(iTrial) = 0; % do not wait for the sound to finish
else
    % calculate sound duration in seconds using number of samples and sampling frequency of the TDT
    soundDur = numel(soundToPlay) / this.be.config.tone.samplingFreq;
    showMessage(this, sprintf('%s | Trial %03d/%03d - playing sound (%.2f sec duration) ... ', ...
        datestr(now(), this.be.logDateFormat), iTrial, this.be.config.training.nTrials, soundDur), 'yellow');
    this.be.times.soundDur(iTrial) = soundDur; % wait for the sound to finish
    o('"Times" sound + soundDur: %.4f', this.be.times.sound(iTrial) + soundDur, 3, this.verb);
end;

displayedEarly = false;
this.be.autoRewardGiven(iTrial) = 0;
this.be.autoRewardModes{iTrial} = this.be.params.autoRewardMode;
while (nowUNIXSec - this.be.times.start(iTrial)) < (this.be.times.respMax(iTrial) + this.be.times.soundDur(iTrial));
    if ~this.be.isRunning; return; end; % check if experiment is paused/stopped

%     o('Reward waiting loop ... %.4f', nowUNIXSec - this.be.times.start(iTrial), 3, this.verb);
    
    % in 'EarlyOn' mode, reward happens anyways at half of the response time
    respDurationTime = (this.be.times.respMax(iTrial) - this.be.times.respMin(iTrial));
    halfRespDurTime = this.be.times.respMin(iTrial) + 0.5 * respDurationTime;
    if strcmp(this.be.autoRewardModes{iTrial}, 'EarlyOn') && ~this.be.autoRewardGiven(iTrial) ...
            && (nowUNIXSec - this.be.times.start(iTrial)) > halfRespDurTime;
        BEGiveReward(this);
        this.be.autoRewardGiven(iTrial) = 1;
    end;

    if isfield(this.be.anInData, 'piezo')
        nSamples = size(this.be.anInData.piezo, 1);
    else
        nSamples = 0;
    end;
    startEarlyRespIndex = round(this.be.times.respWaitStart(iTrial) * this.be.hw.anInSampRate);
    endEarlyRespIndex = min(round(this.be.times.respMin(iTrial) * this.be.hw.anInSampRate), nSamples);
    startRespIndex = round(this.be.times.respMin(iTrial) * this.be.hw.anInSampRate);
    endRespIndex = min(round(this.be.times.respMax(iTrial) * this.be.hw.anInSampRate), nSamples);

    % skip the check for this loop if we do not have any samples yet
    if startEarlyRespIndex > nSamples;
        pause(0.01); % needed to allow time for data collection
        continue;
    end;
    
    piezoData = this.be.anInData.piezo;
    piezoListIndex = strcmp(this.be.hw.analogIns, 'piezo');
    if this.GUI.be.anInDoAbs(piezoListIndex); piezoData = abs(piezoData); end;
    filtPiezo = sgolayfilt(piezoData, 1, this.GUI.be.anInFilt(piezoListIndex));
    isEarlyResp = any(filtPiezo(startEarlyRespIndex : endEarlyRespIndex) > this.be.params.piezoThresh);
    isResp = any(filtPiezo(startRespIndex : endRespIndex) > this.be.params.piezoThresh);
   
    % if there was an early response and punishment is on
    if isEarlyResp && this.be.params.punishDur > 0.01;
        
        this.be.times.respTime(iTrial) = nowUNIXSec - this.be.times.start(iTrial);  
        o('Times:resp: %.4f', this.be.times.respTime(iTrial), 3, this.verb);  
        this.be.respDelays(iTrial) = this.be.times.respTime(iTrial) - this.be.times.respMin(iTrial);
        showMessage(this, sprintf('%s | Trial %03d/%03d - EARLY! (%.4f sec)', ...
            datestr(now(), this.be.logDateFormat), iTrial, nTrials, this.be.respDelays(iTrial)), 'yellow');

        % give punish
        BEGiveAirPuff(this);
        
        this.be.times.respTime(iTrial) = nowUNIXSec - this.be.times.start(iTrial);  
        o('Times:resp: early: %.4f', this.be.times.respTime(iTrial), 3, this.verb);  
        this.be.respDelays(iTrial) = this.be.times.respTime(iTrial) - this.be.times.respMin(iTrial);
        o('Times:respDelays: early: %.4f', this.be.respDelays(iTrial), 3, this.verb);
        resp = 1;
        this.be.punishTimeOuts(iTrial) = 1;
        this.be.respTypes(iTrial) = 5;
        abortTrial = 1;
        break;
        
    % early but not punish
    elseif isEarlyResp;
        
        % only display message if it was not already displayed
        if ~displayedEarly;
            displayedEarly = true;
            this.be.times.respTime(iTrial) = nowUNIXSec - this.be.times.start(iTrial);  
            o('Times:resp: %.4f', this.be.times.respTime(iTrial), 3, this.verb);  
            this.be.respDelays(iTrial) = this.be.times.respTime(iTrial) - this.be.times.respMin(iTrial);
            showMessage(this, sprintf('%s | Trial %03d/%03d - EARLY! (noPunish) (%.4f sec)', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials, this.be.respDelays(iTrial)), 'yellow');
        end;
        resp = 1;
        this.be.punishTimeOuts(iTrial) = 1;
        this.be.respTypes(iTrial) = 5;        
    end;
        
    % if there was a response within the requested time frame
    if isResp;

        this.be.times.respTime(iTrial) = nowUNIXSec - this.be.times.start(iTrial);  
        o('Times:resp: %.4f', this.be.times.respTime(iTrial), 3, this.verb);  
        this.be.respDelays(iTrial) = this.be.times.respTime(iTrial) - this.be.times.respMin(iTrial);
        o('Times:respDelays: %.4f', this.be.respDelays(iTrial), 3, this.verb);
        
        % if the auto-reward of early-on has not been given yet 
        if ~this.be.autoRewardGiven(iTrial);
            resp = 1;
            showMessage(this, sprintf('%s | Trial %03d/%03d - LICK! (%.4f sec)', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials, ...
                this.be.respDelays(iTrial)), 'yellow');  
        else
            showMessage(this, sprintf('%s | Trial %03d/%03d - POST-REW-LICK! (%.4f sec)', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials, ...
                this.be.respDelays(iTrial)), 'yellow');            
        end;
    
        break; % break out of response wait while loop
    end;
    
    pause(0.01); % needed to allow time for data collection
    
end; % end of response waiting time loop

this.be.resps(iTrial) = resp;

% if the trial should be aborted, do not execute the following
if ~abortTrial;

    if ~this.be.isRunning; return; end; % check if experiment is paused/stopped

    % if goStim is empty, it means no behavior
    if ~isempty(this.be.config.tone.goStim);
        %% ---- BERunTrial - analyse response
        isOddTrial = this.be.stims(iTrial) ~= this.be.odds(iTrial);
        % oddball discrimination
        if isfield(this.be.config.tone, 'oddProba') && this.be.config.tone.oddProba > 0;
            isTargetStim = isOddTrial && this.be.config.tone.goStim;
        % frequency discrimination/COT discrimination
        else
            isTargetStim = ismember(this.be.stims(iTrial), this.be.config.tone.goStim);
        end;

        
        % only create a response type if it is not already set to "early"
        if this.be.respTypes(iTrial) == 5;
            this.be.punishTimeOuts(iTrial) = 1;
            this.be.giveRewards(iTrial) = 0;
            
        % response and it was a target: hit (correct response) (respType = 1)
        elseif resp && isTargetStim;
            showMessage(this, sprintf('%s | Trial %03d/%03d - HIT! (%.4f sec)', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials, ...
                this.be.respDelays(iTrial)), 'green');
            this.be.respTypes(iTrial) = 1;
            this.be.giveRewards(iTrial) = 1;

        % NO response and it was NOT a target: correct rejection (respType = 2)
         elseif ~resp && ~isTargetStim;
            showMessage(this, sprintf('%s | Trial %03d/%03d - CORRECT REJECT!', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials), 'green');
            this.be.respTypes(iTrial) = 2;
            this.be.giveRewards(iTrial) = 0;
        % response and it was NOT a target: false alarm (respType = 3)
        elseif resp && ~isTargetStim;
            showMessage(this, sprintf('%s | Trial %03d/%03d - FALSE ALARM! (%.4f sec)', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials, ...
                this.be.respDelays(iTrial)), 'red');
            this.be.respTypes(iTrial) = 3;
            this.be.punishTimeOuts(iTrial) = 1;
            this.be.giveRewards(iTrial) = 0;
        % NO response and it was a target: miss (respType = 4)
        elseif ~resp && isTargetStim;
            showMessage(this, sprintf('%s | Trial %03d/%03d - MISS!', ...
                datestr(now(), this.be.logDateFormat), iTrial, nTrials), 'red');
            this.be.respTypes(iTrial) = 4;
            this.be.punishTimeOuts(iTrial) = 1;
            this.be.giveRewards(iTrial) = 0;
        end

        switch this.be.autoRewardModes{iTrial};
            case {'EarlyOn', 'On'}; this.be.giveRewards(iTrial) = 1;
            case 'Off';             this.be.giveRewards(iTrial) = 0;
            case 'Auto';            % do nothing, rewarding depends on mouse's response
            otherwise;
                showWarning(this, 'OCIA:RunTrial:UnknownAutoRewardMode', ...
                    sprintf('Unknown auto-reward mode: %s. Using default "auto" (reward: %d).', ...
                    this.be.autoRewardModes{iTrial}, this.be.giveReards(iTrial)));
        end;

        o('RespAnalysis: respType: %d, punish: %d, reward: %d', this.be.respTypes(iTrial), ...
            this.be.punishTimeOuts(iTrial), this.be.giveRewards(iTrial), 3, this.verb);

        %% ---- BERunTrial - reward collection
        this.be.times.rewCollEnd(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
        o('Times:rewCollEnd: %.4f', this.be.times.rewCollEnd(iTrial), 3, this.verb);
        % only give reward if deserved and if not already given by auto-reward
        if this.be.giveRewards(iTrial) && ~this.be.autoRewardGiven(iTrial);
            this.be.times.rewCollEnd(iTrial) = this.be.times.rewCollEnd(iTrial) ...
                + this.be.config.training.rewCollTime;
            this.be.times.rewStart(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
            this.be.times.rewStop(iTrial) = nowUNIXSec - this.be.times.start(iTrial) ...
                + this.be.params.rewDur;
            o('Times:rewCollEnd(2): %.4f', this.be.times.rewCollEnd(iTrial), 3, this.verb);
            o('Times:rewStart: %.4f', this.be.times.rewStart(iTrial), 3, this.verb);
            o('Times:rewStop: %.4f', this.be.times.rewStop(iTrial), 3, this.verb);
            BEGiveReward(this);
        end;
        while (nowUNIXSec - this.be.times.start(iTrial)) < this.be.times.rewCollEnd(iTrial);
            pause(0.2); % avoid full-speed looping
        end;
        
    end; % end check goStim empty

end; % end of abort trial check

%% ---- BERunTrial - final trial end wait (punishment)
punishDelay = 0;
if this.be.punishTimeOuts(iTrial);
    punishDelay = this.be.config.training.timeoutPunish;
end;
this.be.times.endPunish(iTrial) = nowUNIXSec - this.be.times.start(iTrial) ...
    + this.be.config.training.endDelay + punishDelay;
o('Times:endPunish: %.4f', this.be.times.endPunish(iTrial), 3, this.verb);

this.be.times.endImagExp(iTrial) = this.be.times.endPunish(iTrial) - punishDelay - this.be.params.imgEndStopTime;
o('Times:endImagExp: %.4f', this.be.times.endImagExp(iTrial), 3, this.verb);
        
imagStop = 0;
while (nowUNIXSec - this.be.times.start(iTrial)) < this.be.times.endPunish(iTrial);
    % imaging goes on for 1 more second after the end of the reward collection time
    if ((nowUNIXSec - this.be.times.start(iTrial)) > this.be.times.endImagExp(iTrial)) && ~imagStop;
        BEImagingTTL(this, 0); % stop imaging
        imagStop = 1;
        this.be.times.endImagObs(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
        o('Times:endImagObs: %.4f', this.be.times.endImagObs(iTrial), 3, this.verb);
    end;
    pause(0.01); % avoid full-speed looping
%     o('End delay waiting loop ... %.4f', nowUNIXSec - this.be.times.start(iTrial), 3, this.verb);
end;

if isempty(this.be.config.tone.goStim);
    showMessage(this, sprintf('%s | Trial %03d/%03d - done. ', ...
        datestr(now(), this.be.logDateFormat), iTrial, this.be.config.training.nTrials), 'green');
end;

end

