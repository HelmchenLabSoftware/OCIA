%% #OCIA:AN:ANClearPlot
function ANClearPlot(this)

anAxe = this.GUI.handles.an.axe;
anPanelChild = get(this.GUI.handles.panels.AnalyserPanel, 'Children');
% remove everything that doesn't belong to the Analyser panel
anPanelChild(~cellfun(@isempty, regexp(get(anPanelChild, 'Tag'), '^AN'))) = [];
anPanelChild(anPanelChild == anAxe) = [];
delete(anPanelChild); % delete unwanted objects
if ishandle(anAxe);
    delete(get(anAxe, 'Children')); % delete previous data of the analyser axes
    delete(anAxe);
end;

% re-create the axes
pad = 0.005; anAxePadL = 0.065; anAxePadR = 0.065; anAxePadT = 0.25; anAxePadB = 0.065;
anAxeW = 1 - anAxePadL - anAxePadR - 2 * pad; anAxeH = 1 - anAxePadT - anAxePadB - 1.5 * pad;
anAxeY = pad + anAxePadB; anAxeX = pad + anAxePadL;
this.GUI.handles.an.axe = axes('Parent', this.GUI.handles.panels.AnalyserPanel, 'Units', 'normalized', ...
    'Tag', 'ANAxe', 'Color', 'white', 'Position', [anAxeX anAxeY anAxeW anAxeH]);

% clear the parameters area
delete(get(this.GUI.handles.an.paramPan, 'Children'));
this.GUI.handles.an.paramPanElems = struct();

end   