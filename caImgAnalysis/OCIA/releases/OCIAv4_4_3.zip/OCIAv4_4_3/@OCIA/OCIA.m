classdef OCIA < handle
%% OCIA - Online Calcium Imaging Assistant
% OCIA  Online Calcium Imaging Assistant
%
% Usage:
%           this = OCIA()
%           this = OCIA(varargin)
%
% PARAMETERS (not required):
% configName        string determining which configuration file should be used using the syntax
% DWFilt            string or cell-array of strings determining which filters should be loaded at start
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Originally created on           08 / 10 / 2013 %
% % Modified to v2.0 on             20 / 12 / 2013 %
% % Modified to v3.0 on             21 / 02 / 2014 %
% % Modified to v4.0 on             19 / 06 / 2014 %
% % Written by B. Laurenczy (blaurenczy@gmail.com) %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% TODO list
%{

- General
 -- add icons to buttons for easier recognition
 -- pre-processing GUI: uipanel with options for nFrameSkip(default=0)/fShift/fJitt/moCorr/moDet
    options as checkboxes, and a "pre-process rows" button (ANPreProcRows). DWLoad('prev') should do none
    of these corrections, except frameShift and frameSkip.
    Add a display fig checkbox linked to the doPlots of the pre-processing functions.
 -- save load modularity:
  --- make the GUI dynamic for the saving options, based on the data's field and configuration
  --- adapt the saving code so that it saves the right things at the right place
  --- fix the save/load/reset options
 -- check that flushdata works properly

- DataWatcher
 -- add a "delete rows" function (hides the unwanted rows from the data watcher), also useful for the imagingWatcher mode
 -- intrinsic imaging: access binary file content, show vessels tif files,
    eventually overlap them with expression image using stiching algorithm
 -- behavior movie: read the video with 'video2mat.m' and eventually match frames to trials
 -- small thumbnail of the currently selected row(s) also for other data types (behavior, intrinsic, behavMovie)
  --- requires frame grouping (� la imageJ ...)
 -- only load imaging data once from the runTable and then re-use it for analysis and ROI drawing
 -- enable the "real" analysis pipeline support : load imaging data files (.bin)(HDF5?)
 -- implement GUI items/config file for analysis parameters
NO -- add a load metadata button to avoid re-processing all folders just for the metadata
NO -- make the loaded rows' background green to show the data is loaded
NO -- store where each behavior/data file was found and dont reload it if not necessary

- ImagingWatcher
 -- create a new imaging assistant mode or extend the data-watcher to help with online analysis of the imaging
  --- could be on a different computer/matlab session for lower CPU on imaging computer and
      eventually parallel computing for faster loading/processing
 -- features:
  --- loading last recorded data
  --- "quick" ROIDrawing (semi-auto)
  --- "quick" DRR extract
  --- bleaching quantifier
  --- previous days data and metadata (laser, depth, location, surface image, etc.)

- ROIDrawer
 -- bug: remove old position callback in RDRenameROI
 -- channel selection for ROI drawing, gray scale image of one channel
 -- move all ROIs with small arrow GUI pushbuttons <- ^ ->
 -- implement an semi-automatic segmentation tool based on cell centers and ring/filled cell body detection
 -- cell identity labeling tool

- Analyser
 -- implement a feature of analysing whole day/whole mice with analysRow button and watchType of only day or only animal
 -- resizing of the whole panel bug, probably when saving (or plotting?) plots
 -- enable the "real" analysis pipeline support (load imaging data files (HDF5?))
 -- check for colorbar plot saving (resizing issue)
 -- check for time-consuming sem calculation problem
 -- add plots for several mice
 -- implement a bleaching quantifier over multiple runs
 -- fix the colorbar saving problem
 -- fix the colormap problem
 -- fix the analyser plotting ROISet mismatch/non-unique problem
 -- when loading data in 'full' mode that was already loaded in 'prev', skip re-loading of 'prev' frames

- Behavior
 -- check sound amplitude (SPL) *randomization*
 -- fix licking detection or switch to lick rate
 -- implement *alternative* detection system: lick rate
 -- introduce a configuration editor or GUI items for mainConf.mat elements
 -- save threshold and rewDur for each trial
 -- perf analysis: exclude first 3-10 trials + non-responsive regions
 -- auto-connect behavior box with COM port communication

- JointTracker
 -- load X frames until memory is full and then just load frames on the fly while changing frames
 -- when doing the sliding average, remove the existing frames and store them in the temp and then put it back
 -- re-process on the fly the subsequent joints when placing a joint (when placing wrist, re-find the MCP)
 -- crop function
 -- image pre-processing not everywhere but defined by ROI
 -- iJoint and iJointType from selection listbox should not be single values but must be arrays (multiple joint
    manipulation)
 -- prediction reaffinement
  --- define an "area mask" for each joint (or each group of joints), using imfreehand, to constraint their position
  --- use angles and joint distances to constraint the position of the joints
  --- use field flow technique to predict where the joint will move
  --- use correlation dip to change bounding box size (with a minimal box size setting)
 -- improve debug plot display so that one can actually see what is going on (nJoints x nProcessSteps image with labeld axes)
 -- create a progress bar to show how far we are and how is each frame annotated (manual, semi-auto validated, semi-auto not yet checked, etc.)
 -- correlation frame-to-frame or frame-wise only on the bounding boxes
 -- base frames pre-processing for better computer and/or manual annotation
  --- subtract sliding window avg image
  --- flatfield
  --- contrast enhancement
 -- base frames pre-processing might also only be applied to parts of the frame (like the sliding average only on the
    lower part of the frame)
 -- post-hoc evaluation method to get which joints are misplaced, based on:
  --- interpolation of the data points from next and previous joint coordinate ('outlier' detection)
  --- skelton distances
  --- angle-change vs frame-to-frame correlation
 -- post-hoc refinement of the match using smaller bounding box
 -- computer vision algorithms / ideas
 
%}

%% properties
properties

    % verbosity, number telling how much output should be printed out. The higher the more verbose.
    verb = 2;
    % version number
    version = '4.4.3';
    
    % - Path
    path = struct();    
    % - GUI
    GUI = struct();    
    % - Data
    data = struct();
    % - DataWatcher
    dw = struct();
    % - ROIDrawer
    rd = struct();
    % - Analyser
    an = struct();
    % - Behavior
    be = struct();
    % - JointTracker
    jt = struct();

end

%% methods - public
methods

%% - #OCIA - constructor
function this = OCIA(varargin)
    
    o('#OCIA()', 4, this.verb);
    o('Launching OCIA v%s ...', this.version, 0, this.verb);
    
    %% -- #OCIA: parse inputs and load config file
    % prepare the input parser object with the requested inputs
    IP = inputParser;
    addOptional(IP,         'configName',         'default',               @ischar);
    addOptional(IP,         'DWFilt',             'empty',                 @(x)ischar(x) || iscell(x));
    parse(IP, varargin{:});
    
    % get the config function's name and check if it exists
    configName = IP.Results.configName;
    funcName = sprintf('OCIA_config_%s', configName);
    if ~exist(funcName, 'file');
        showWarning(this, 'OCIA:ConfigNotFound', sprintf('Config file "%s" not found, using default.', funcName));
        configName = 'default';
        funcName = sprintf('OCIA_config_%s', configName);
    end;
    
    o('Initializing ... (configuration: "%s")', configName, 0, this.verb);   
    % get the handle and call the function
    configHandle = str2func(funcName);
    [this, inputParams] = configHandle(this);
    
    % overwrite config parameter with input parameter
    if ~strcmp(IP.Results.DWFilt, 'empty');
        this.GUI.dw.DWFilt = IP.Results.DWFilt;
    end;
    
    %% -- #OCIA: add java folders
    OCIAPath = regexprep(which('OCIA'), '\\', '/');
    OCIAPath = regexprep(OCIAPath, '/@OCIA/OCIA.m$', '');
    javaaddpath([OCIAPath '/java/ij.jar']);
    javaaddpath([OCIAPath '/java/TurboRegJava']);
      
    %% -- #OCIA: create the window and show it
    createWindowTic = tic;
    OCIACreateWindow(this); % create the GUI window
    o('  #OCIA(): window created (%.4f sec).', toc(createWindowTic), 3, this.verb);
    show(this); % make the GUI window visible

    %% -- #OCIA: process start function
    % set the start function to default if no specified
    if ~isfield(inputParams, 'startFunctionName') || isempty(inputParams.startFunctionName);
        inputParams.startFunctionName = 'default';
    end;
    
    % process the start function
    showMessage(this, sprintf('Initializing ... (start function: "%s")', inputParams.startFunctionName), 'yellow');    
    % get the start function's name and check if it exists
    funcName = sprintf('OCIA_startFunction_%s', inputParams.startFunctionName);
    if ~exist(funcName, 'file');
        showWarning(this, 'OCIA:StartFunctionNotFound', ...
            sprintf('Start function "%s" not found, using default.', funcName));
        funcName = 'OCIA_startFunction_default';
    end;
    % call the appropriate start function with an error catching block
    try
        OCIAStartFun = str2func(funcName);
        OCIAStartFun(this);
    catch err;        
        showWarning(this, 'OCIA:StartFunctionError', ...
            sprintf('Start function "%s" run into an error: %s (%s)\n%s.', ...
            funcName, err.message, err.identifier, getStackText(err)));          
    end;

end


%% - #delete (destructor)
function delete(this)
    
    o('#delete()', 4, this.verb);
    
    delete(this.GUI.figH);     
    
end

%% - GUI methods
%% -- #show
function show(this)
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    o('#show()', 4, this.verb);
    
    showTic = tic;
    set(this.GUI.figH, 'Visible', 'on'); 
    pause(0.1);
    o('#show(): done (%.4f sec)', toc(showTic), 4, this.verb);
        
end;

%% -- #hide
function hide(this)
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    o('#hide()', 4, this.verb);
    
    set(this.GUI.figH, 'Visible', 'off');    
    
end;

%% -- #isGUI
function isGUIBool = isGUI(this)
    
    % if not in no-GUI mode and either in deployed mode or not in a matlab worker (parallel computing)
    isGUIBool = ~this.GUI.noGUI && (isdeployed || isempty(javachk('desktop')));
        
end;

%% -- #showMessage
function showMessage(this, message, color)
    
    o(message, 1, this.verb);
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    if ~exist('color', 'var'); color = 'green'; end;
    set(this.GUI.handles.logBar, 'String', message, 'Background', color);
%     pause(0.03); % required to let the GUI update itself
    
end;

%% -- #showWarning
function showWarning(this, warnID, warningText, color)
    
    warning(warnID, strrep(warningText, '\', '\\'));
    
    % do nothing if there is no GUI
    if ~isGUI(this); return; end;
    
    
    if ~exist('color', 'var'); color = 'yellow'; end;
    warningTextSplit = regexp(warningText, '\n', 'split');
    set(this.GUI.handles.logBar, 'String', warningTextSplit{1}, 'Background', color);
    pause(0.1); % required to let the GUI update itself
    
    
end;

%% -- #showError
function showError(this, errorID, errorText)
    
    % if not in noGUI mode and not in a matlab worker (parallel computing)
    if isGUI(this);
        set(this.GUI.handles.logBar, 'String', errorText, 'Background', 'red');
    end;
    
    error(errorID, strrep(errorText, '\', '\\'));
    
end;

%% -- #getJTable
function jTable = getJTable(this, hTable)
    
    jTable = []; % return empty in case there is a problem
    
    % if handle is actually a string, get the appropriate uitable handle first
    if ischar(hTable);
        switch hTable;
            case 'DWRunTable'; hTable = this.GUI.handles.dw.runTable;
            case 'BEConfTable'; hTable = this.GUI.handles.be.confTable;
            otherwise;
                this.showWarning('OCIA:getJTable:UnknownTable', sprintf('Cannot find JTable for "%s".', hTable));
                return;
        end;
    end;
    
    % sometimes the J-object fetching fails on first attempt, so try a second time
    try
        % get the actual java table underlying the requested uitable
        jTable = findjobj(hTable); jTable = jTable.getComponents();
        jTable = jTable(1); jTable = jTable.getComponents();
        jTable = jTable(1);
        
    % try a second time
    catch e; %#ok<NASGU>
        pause(0.5);
        % get the actual java table underlying the requested uitable
        jTable = findjobj(hTable); jTable = jTable.getComponents();
        jTable = jTable(1); jTable = jTable.getComponents();
        jTable = jTable(1);
    end;
    
end;

%% - #event handlers
%% -- #keyPressed
function keyPressed(this, ~, e)

%     currObj = get(this.GUI.figH, 'CurrentObject');
%     currObjTag = get(currObj, 'Tag');
    
    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    isChangeMode = 0;
    if ismember('shift', e.Modifier);
        switch e.Key;
            case {'1', '2', '3', '4'};
                OCIAChangeMode(this, this.GUI.modes{str2double(e.Key), 1});
                isChangeMode = 1;
        end;
    end;
    
    if ~isChangeMode;
        switch currentMode
            case 'ROIDrawer';
                switch e.Key;
                    case {'uparrow', 'downarrow', 'leftarrow', 'rightarrow'};
%                         if isempty(currObj) || strcmp(currObjTag, 'ROIDrawerPanel');
                        if ~ismember('control', e.Modifier) && ~ismember('alt', e.Modifier);
                            RDMoveROIs(this, strrep(e.Key, 'arrow', ''), this.rd.moveROIsStep);
                        elseif ismember('control', e.Modifier) && strcmp(e.Key, 'leftarrow');
                            RDRotateROIs(this, - this.rd.rotateROIsStep);
                        elseif ismember('control', e.Modifier) && strcmp(e.Key, 'rightarrow');
                            RDRotateROIs(this, this.rd.rotateROIsStep);
                        elseif ismember('alt', e.Modifier) && strcmp(e.Key, 'downarrow');
                            currROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                            if isempty(currROI); currROI = 1; end;
                            if currROI(1) < numel(get(this.GUI.handles.rd.selROIsList, 'String'));
                                set(this.GUI.handles.rd.selROIsList, 'Value', currROI(1) + 1);
                            end;
                            RDSelROI(this);
                        elseif ismember('alt', e.Modifier) && strcmp(e.Key, 'uparrow');
                            currROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                            if isempty(currROI);
                                currROI = numel(get(this.GUI.handles.rd.selROIsList, 'String'));
                            end;
                            if currROI(1) > 1;
                                set(this.GUI.handles.rd.selROIsList, 'Value', currROI(1) - 1);
                            end;
                            RDSelROI(this);
                        end;
%                         end;
                    case 'z';
                        RDActivateZoom(this, ~get(this.GUI.handles.rd.zTool, 'Value'));
                    case 'c';
                        % invert target and reference
                        if ismember('control', e.Modifier);
                            selRef = get(this.GUI.handles.rd.refROISetASetter, 'Value');
                            selTarg = get(this.GUI.handles.rd.refROISetBSetter, 'Value');
                            set(this.GUI.handles.rd.refROISetASetter, 'Value', selTarg(1));
                            set(this.GUI.handles.rd.refROISetBSetter, 'Value', selRef(1));
                            RDCompareROIs(this, 'IDs');
                        elseif ismember('alt', e.Modifier);
                            compareState = get(this.GUI.handles.rd.refROISet, 'Value');
                            set(this.GUI.handles.rd.refROISet, 'Value', ~compareState);
                            RDCompareROIs(this, 'IDs');
                        else
                            RDCompareROIs(this, 'IDs');
                        end;
                    case 'l';
                           set(this.GUI.handles.rd.selROIsList, 'Value', ...
                               numel(get(this.GUI.handles.rd.selROIsList, 'String')));
                            RDSelROI(this);
                    case 'r';
                        if ismember('shift', e.Modifier);                            
                            spotIndex = get(GUIDWFiltH.spotID, 'Value');
                            selRef = get(this.GUI.handles.rd.refROISetASetter, 'Value');
                            selTarg = get(this.GUI.handles.rd.refROISetBSetter, 'Value');
                            DWProcessWatchFolder(this);
                            DWExtractNotebookInfo(this);
                            set(GUIDWFiltH.spotID, 'Value', spotIndex);
                            DWFilterRunTable(this, 'new');
                            RDDrawROIsForRows(this);
                            set(this.GUI.handles.rd.rowListNames, 'Value', 1 : size(this.rd.runTable, 1));
                            RDChangeRow(this, this.GUI.handles.rd.rowListNames);
                            set(this.GUI.handles.rd.refROISetASetter, 'Value', selRef);
                            set(this.GUI.handles.rd.refROISetBSetter, 'Value', selTarg);
                            set(this.GUI.handles.rd.refROISet, 'Value', 1);
                            RDCompareROIs(this);
                            RDLoadROIs(this);
                        else
                            RDRenameROI(this);
                        end;
                    case 'space';
                        
                    case 'delete';
                        iSelROI = get(this.GUI.handles.rd.selROIsList, 'Value');
                        RDDeleteROI(this);
                        if ~isempty(iSelROI);
                            set(this.GUI.handles.rd.selROIsList, 'Value', iSelROI(1));
                            RDSelROI(this);
                        end;
                    case 'i';
                        if ismember('control', e.Modifier);
                            RDShowHideROIs(this, 'ROIs');
                        else
                            RDShowHideROIs(this, 'IDs');
                        end;
                    case 's';
                        if ismember('control', e.Modifier);
                            RDSaveROIs(this);
                        end;
                    case 'a';
                        if ismember('control', e.Modifier);
                            set(this.GUI.handles.rd.selROIsList, 'Value', ...
                                1 : numel(get(this.GUI.handles.rd.selROIsList, 'String')));
                            RDSelROI(this);
                        else
                            set(this.GUI.handles.rd.imAdj, 'Value', ~get(this.GUI.handles.rd.imAdj, 'Value'));
                            RDUpdateImage(this, this.GUI.handles.rd.imAdj);
                        end;
                    case 'p';
                        set(this.GUI.handles.rd.pseudFF, 'Value', ~get(this.GUI.handles.rd.pseudFF, 'Value'));
                        RDUpdateImage(this, this.GUI.handles.rd.pseudFF);
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
            case 'Analyser';
                switch e.Key;
                    case {'leftarrow', 'rightarrow'};
                        ANSelPlot(this, strrep(e.Key, 'arrow', ''));
                    case {'uparrow', 'downarrow'};
                        ANSelRuns(this, strrep(e.Key, 'arrow', ''));
                    case 'a';
                        ANSelRuns(this, 'all');
                    case 'z';
                        ANActivateZoom(this, ~get(this.GUI.handles.an.zTool, 'Value'));
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
            case 'JointTracker';
                switch e.Key;
                    case 'c';
                        JTSwapCursor(this);
                    case 'a';
                        if ismember('shift', e.Modifier);
                            set(this.GUI.handles.jt.frameSetter, 'Value', 1);
                        else
                            set(this.GUI.handles.jt.frameSetter, 'Value', max(this.GUI.jt.iFrame - 1, 1));
                        end;
                    case 'd';
                        if ismember('shift', e.Modifier);
                            if get(this.GUI.handles.jt.autoTrack, 'Value');
                                JTProcess(this, 'all');
                            else
                                set(this.GUI.handles.jt.frameSetter, 'Value', this.jt.nFrames);
                            end;
                        else
                            set(this.GUI.handles.jt.frameSetter, 'Value', min(this.GUI.jt.iFrame + 1, this.jt.nFrames));
                        end;
                    case {'w', 's'};
                        addValue = 1; if strcmp(e.Key, 's'); addValue = -1; end;
                        newValue = min(max(this.GUI.jt.iJointType + addValue, 1), this.jt.nJointTypes);
                        if newValue ~= get(this.GUI.handles.jt.jointTypeSelSetter, 'Value');
                            set(this.GUI.handles.jt.jointTypeSelSetter, 'Value', newValue);
                            JTChangeJointOrJointType(this, this.GUI.handles.jt.jointTypeSelSetter);
                        end;
                    case 'f';
                        set(this.GUI.handles.jt.autoTrack, 'Value', ~get(this.GUI.handles.jt.autoTrack, 'Value'));
                        JTProcess(this, 'autoTrackChanged');
                    case {'m', 'v'};
                        set(this.GUI.handles.jt.manuTrack, 'Value', ~get(this.GUI.handles.jt.manuTrack, 'Value'));
                        JTManualTrackStart(this);
                    case 'space';
                        set(this.GUI.handles.jt.viewOpts.preProc, 'Value', ...
                            ~get(this.GUI.handles.jt.viewOpts.preProc, 'Value'));
                        JTUpdateGUI(this, this.GUI.handles.jt.viewOpts.preProc);
                    otherwise;
%                         showWarning(this, 'OCIA:keyPressed:UnknownKey', sprintf('Unknown key (%s) pressed.', e.Key));
                end;
        end;
    end;

end;

%% -- #mouseDown
function mouseDown(this, ~, ~)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
        case 'JointTracker';
            
            % make sure the click is within the axe image and not during a ROI drawing
            pos = get(this.GUI.handles.jt.axe, 'CurrentPoint');
            pos = pos(1, 1 : 2);
            XLim = get(this.GUI.handles.jt.axe, 'XLim');
            YLim = get(this.GUI.handles.jt.axe, 'YLim');
            if this.GUI.jt.selectingROI || any(pos < 0) || pos(1) > XLim(2) || pos(2) > YLim(2);
                return;
            end;
            
            if isempty(this.GUI.jt.placeJointIndex) && isempty(this.GUI.jt.moveJointIndex);
                selectionType = get(this.GUI.figH, 'SelectionType');
                JTJointClickStart(this, strcmp(selectionType, 'extend'));
            end;
    end;

end;

%% -- #mouseUp
function mouseUp(this, h, e)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
        
        case 'ROIDrawer';
            
            RDUpdateGUI(this, h, e);
            
        case 'JointTracker';
            
            % make sure the click is within the axe image and not during a ROI drawing
            pos = get(this.GUI.handles.jt.axe, 'CurrentPoint');
            pos = pos(1, 1 : 2);
            XLim = get(this.GUI.handles.jt.axe, 'XLim');
            YLim = get(this.GUI.handles.jt.axe, 'YLim');
            if this.GUI.jt.selectingROI || any(pos < 0) || pos(1) > XLim(2) || pos(2) > YLim(2);
                return;
            end;
            
            % process the click event
            JTImClick(this, h, e);
            
            % reset the joint tracking/moving settings
            this.GUI.jt.placeJointIndex = [];
            this.GUI.jt.moveJointIndex = [];
            this.GUI.jt.startFrame = [];
            this.GUI.jt.endFrame = [];
            this.GUI.jt.startTime = [];

            % remove manual tracking
            set(this.GUI.handles.jt.manuTrack, 'Value', 0);
    end;

end;

%% -- #mouseMoved
function mouseMoved(this, ~, ~)

    currentMode = this.GUI.modes{get(this.GUI.handles.changeMode, 'Value'), 1};
    
    switch currentMode;
    end;

end;

end  % end methods


end
