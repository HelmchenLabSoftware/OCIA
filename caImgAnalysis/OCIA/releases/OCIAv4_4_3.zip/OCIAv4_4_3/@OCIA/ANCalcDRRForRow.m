%% #OCIA:AN:ANCalcDRRForRow
function chanStats = ANCalcDRRForRow(this, iDWRow, varargin)

% get whether to do plots or not
if nargin > 2;  doPlots = varargin{1};
else            doPlots = 0;
end;
% get the progress fraction
if nargin > 3;  prog = varargin{2};
else            prog = '';
end;

% get the runID
runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});

calcDRRTic = tic;
o('#ANCalcDRRForRow(): %s (%d%s) ...', runID, iDWRow, prog, 4, this.verb);

% calculate dFF/dRR if not already calculated
if isempty(this.data.img.caTraces{iDWRow});

    % display message
    showMessage(this, sprintf('Extracting trace for %s (%d%s) ...', runID, iDWRow, prog), 'yellow');
    
    % get the ROISet for this row
    ROISet = ANGetROISetForRow(this, iDWRow);
    nROIs = size(ROISet, 1); % number of ROIs
    
    % if no ROIs, abort
    if ~nROIs; return; end;

    % get the raw images for this row
    firstChan = this.an.img.chanVect(1);
    imgData = this.data.preProc{iDWRow};
    imgDim = size(imgData{firstChan});

    % initialize the data set
    this.data.img.caTraces{iDWRow} = nan(nROIs, size(imgData{firstChan}, 3));

    % background substract images for each channel using the first percentile
    for iChan = 1 : this.an.img.nChans; % go through all channels
        
        if isempty(imgData{iChan}) || imgDim(1) == 0; continue; end;
        
        % calculate cutoff on the first 10% frames
        nFrames = fix(imgDim(3) * 0.1);
        bgPrctileCutOff = prctile(reshape(imgData{iChan}(:, :, 1 : nFrames), 1, prod(imgDim(1 : 2)) * nFrames), ...
            this.an.img.bgPrctile);
        imgData{iChan} = imgData{iChan} - bgPrctileCutOff; % remove cutoff
        imgData{iChan}(imgData{iChan} < 0) = 0; % flatten so that there are no negative values
        
    end;

    YFPData = imgData{this.an.img.chanVect(1)};
    
    % use CFP if there is a second channel
    if numel(this.an.img.chanVect) > 1;
        CFPData = imgData{this.an.img.chanVect(2)};
    else
        CFPData = [];
    end;
    
    downSampFactor = this.an.an.channelDownSampFactor;
    if ~downSampFactor; downSampFactor = 1; end;
    caTraces = nan(nROIs, floor(size(YFPData, 3) / downSampFactor));
    chanStats = nan(nROIs, floor(size(YFPData, 3) / downSampFactor), numel(this.an.img.chanVect));
    defaultFrameRate = this.an.img.defaultFrameRate;
    
    % process each ROI
    for iROI = 1 : nROIs;
        
        % extract the channels
        YFP = nanmean(GetRoiTimeseries(YFPData, ROISet{iROI, 2}), 1)';
        if ~isempty(CFPData);
            CFP = nanmean(GetRoiTimeseries(CFPData, ROISet{iROI, 2}), 1)';
        else
            CFP = [];
        end;
        
        % apply filter on traces if required
        if this.an.an.channelSFGiltFrameSize > 1;
            YFP = sgolayfilt(YFP, 1, this.an.an.channelSFGiltFrameSize);
            if ~isempty(CFP);
                CFP = sgolayfilt(CFP, 1, this.an.an.channelSFGiltFrameSize);
            end;
        end;
        
        % apply downsampling on traces if required
        if downSampFactor > 1;
            YFP = interp1DS(defaultFrameRate, defaultFrameRate / downSampFactor, YFP);
            YFP = YFP(1 : size(caTraces, 2));
            if ~isempty(CFP);
                CFP = interp1DS(defaultFrameRate, defaultFrameRate / downSampFactor, CFP);
                CFP = CFP(1 : size(caTraces, 2));
            end;
        end;
        
        chanStats(iROI, :, 1) = YFP;
        if ~isempty(CFP);
            chanStats(iROI, :, 2) = CFP;
        end;
        
        % extract the dFF/dRR from the channels
        caTraces(iROI, :) = extractDFFDRR(YFP, CFP, this.an.img.f0method, this.an.img.f0params, ...
            this.an.img.polyfitCorrect, this.an.img.polyfitFraction, defaultFrameRate, ...
            sprintf('%s_%02d_ROI%s', runID, iDWRow, ROISet{iROI, 1}), [], doPlots);
        
    end;
    
    % store the data
    this.data.img.caTraces{iDWRow} = caTraces;

    % display message
    showMessage(this, sprintf('Extracting trace for %s (%d%s) done (%3.1f sec).', ...
        runID, iDWRow, prog, toc(calcDRRTic)));
    
end;

end
