%% - #DWMatchROISetsToData
function DWMatchROISetsToData(this)

    nROISets = size(this.data.img.ROISets, 1);
    ROISetRows = DWFindRunTableRows(this, 'ROISet', '', '', '', '', '', '');
    for iROISet = 1 : nROISets;
        ROISet = this.data.img.ROISets{iROISet, 1};
        runValidity = this.data.img.ROISets{iROISet, 2};
        nMatchROIs = size(ROISet, 1);
        spotID = '';
        for iRunTableRow = 1 : size(this.dw.runTable, 1);
            ROISearchRunID = sprintf('%s__%s', this.dw.runTable{iRunTableRow, 2}, this.dw.runTable{iRunTableRow, 3});

            % compare the runs validity but only for the data rows
            if any(strcmp(runValidity, ROISearchRunID)) ...
                    && ~isempty(regexp(this.dw.runTable{iRunTableRow, 1}, '(imgD|d)ata', 'once'));
                this.dw.runTable{iRunTableRow, 16} = sprintf('RS%02d / %03d', iROISet, nMatchROIs);
                if isempty(spotID);
                    spotID = this.dw.runTable{iRunTableRow, 7};
                    if iROISet > numel(ROISetRows);
                        showWarning(this, 'OCIA:DWExtractNotebookInfo:DWMatchROISetsToData:ROISetSizeDimError', ...
                            sprintf('Index of ROISet (%d) exceeds size of the ROISetRows (%d).', ...
                                iROISet, numel(ROISetRows)));
                    else
                        this.dw.runTable{ROISetRows(iROISet), 7} = spotID;
                    end;
                end;
            end;
        end;

    end;

end
