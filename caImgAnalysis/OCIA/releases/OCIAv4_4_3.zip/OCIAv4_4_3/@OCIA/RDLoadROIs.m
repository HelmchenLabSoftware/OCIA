%% #OCIA:RD:RDLoadROIs
function RDLoadROIs(this, ~, ~)

o('#RDLoadROIs()', 4, this.verb);
showMessage(this, 'Loading ROIs ...', 'yellow');

% if not in RDCompareROIs mode
if ~get(this.GUI.handles.rd.refROISet, 'Value');
    iRDRow = get(this.GUI.handles.rd.rowListNames, 'Value');
    if isempty(iRDRow);
        warning('OCIA:RD:RDLoadROIs:NoRowSelected', 'No rows are selected!');
        return;
    end;
    iRDRow = iRDRow(1); % only use the first row
else
    iRDRows = get(this.GUI.handles.rd.rowListNames, 'Value');
    iRDRow = iRDRows(get(this.GUI.handles.rd.refROISetASetter, 'Value'));
end;
o('#RDLoadROIs(): iListRow: %d', iRDRow, 4, this.verb);

dataFolderPath = this.rd.runTable{iRDRow, 2};

% check whether selected row is a ROISet row
isROISetRow = ~isempty(regexp(dataFolderPath, 'ROISets/ROISet_', 'once'));

% if selected row is a ROISet row, load directly its path
if isROISetRow;
    ROISetFilePath = dataFolderPath;
% if selected row is not a ROISet row, get the associated ROISet path
else
    dataFolderName = cell2mat(regexp(dataFolderPath, '[\w\.]+/$', 'match'));
    o('#RDLoadROIs(): dataFolderName: %s', dataFolderName, 4, this.verb);
    
    spotIndex = strcmp(this.dw.watchTypes(:, 1), 'spot');
        spotFolderPath = strrep(dataFolderPath, dataFolderName, '');
    if any(spotIndex);
        spotFolderName = cell2mat(regexp(spotFolderPath, '(\w+)/$', 'match'));
        o('#RDLoadROIs(): spotFolderName: %s', spotFolderName, 4, this.verb);
    else
        spotFolderName = dataFolderName;
    end;
    
    dataFolderName = regexprep(dataFolderName, '\.exp\d+/$', '/');
    dataFolderName = regexprep(dataFolderName, '_X.*/$', '/');
    
    if ~isempty(spotFolderName); % if data is in a spot folder, remove that spot folder name
        dayFolderPath = strrep(spotFolderPath, spotFolderName, '');
    else % otherwise just consider the spot folder is actually a day folder
        dayFolderPath = spotFolderPath;
    end;
    ROISetFolderPath = sprintf('%sROISets/', dayFolderPath);
    o('#RDLoadROIs(): ROISetFolderPath: %s', ROISetFolderPath, 4, this.verb);
    ROISetFilePath = sprintf('%sROISet_%s.mat', ROISetFolderPath, regexprep(dataFolderName, '/$', ''));
    o('#RDLoadROIs(): ROISetFilePath: %s', ROISetFilePath, 4, this.verb);

    %% HACK : this is a big hack to load ROISets from previous days
    otherROIParts = regexp(get(this.GUI.handles.rd.ROIName, 'String'), ',', 'split');
    if ~isempty(otherROIParts{1});
        otherDayOffset = str2double(otherROIParts{1});
        if regexp(otherROIParts{2}, '^\d{6}$');
            otherROIParts{2} = sprintf('%s_%s_%s', otherROIParts{2}(1:2), otherROIParts{2}(3:4), otherROIParts{2}(5:6));
        end;
        currentDay = this.dw.dayIDs{get(this.GUI.handles.dw.filt.dayID, 'Value')};
        otherDay = this.dw.dayIDs{get(this.GUI.handles.dw.filt.dayID, 'Value') + otherDayOffset};
        ROISetFilePath = sprintf('%sROISets/ROISet_%s__%sh.mat', regexprep(dayFolderPath, currentDay, otherDay), ...
            otherDay, otherROIParts{2});
    end;
end;

% if the file cannot be found, abort with a warning
if ~exist(ROISetFilePath, 'file');
    this.showWarning('RDLoadROIs:ROISetFileNotFound', ...
        sprintf('Could not find ROISet file at ''%s''. Aborting.', ROISetFilePath));
    return;
end;

% clear the eventually present previous ROIs
o('#RDLoadROIs(): Clearing previous ROIs, nROIs: %d', this.rd.nROIs, 4, this.verb);
showMessage(this, 'Loading ROIs: clearing previous ROIs ...', 'yellow');
RDClearROIs(this);
pause(0.1);

% load the ROISet containig mat-file
o('#RDLoadROIs(): loading ROIs ...', 3, this.verb);
showMessage(this, 'Loading ROIs: loading file ...', 'yellow');
ROISetMatStruct = load(ROISetFilePath);

% load back the runsValidity (runs where the loaded ROISet is valid)
runsValidity = ROISetMatStruct.runsValidity;
if ~isempty(runsValidity); % if it is not empty, select the runs
    
    if isROISetRow;
        nRuns = numel(runsValidity);
        set(this.GUI.handles.rd.runSel, 'String', num2cell(1 : nRuns), 'Value', 1 : nRuns, 'ListBoxTop', 1);
    else
        % get the runIDs from the datawatcher's run table
        selDWRuns = this.dw.selRunTableRows;
        runIDs = arrayfun(@(iDWRow) sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3}), ...
            selDWRuns, 'UniformOutput', false);
        % set back the selection of the loaded runsValidity
        toSelectRowIndexes = find(cellfun(@(x)ismember(x, runsValidity), runIDs));
        if numel(toSelectRowIndexes) ~= numel(runsValidity);
            showWarning(this, 'RDLoadROIs:SizeMismatch', 'Run validity: some runs not found.');
        end;
        set(this.GUI.handles.rd.runSel, 'Value', toSelectRowIndexes);
    end;
end;

% load back the variables
this.rd.ROIMask = ROISetMatStruct.ROIMask;
this.rd.ROIs = ROISetMatStruct.ROIs;
this.rd.nROIs = size(this.rd.ROIs, 1);
% this.GUI.rd.img = ROISetMatStruct.refImage;

% recreate the imroi objects
o('#RDLoadROIs(): recreating imroi objects ...', 3, this.verb);
showMessage(this, 'Loading ROIs: creating ROIs ...', 'yellow');
for iROI = 1 : this.rd.nROIs;
    % make sure name is displayed with 3 digits
    this.rd.ROIs{iROI, 2} = sprintf('%03d', str2double(this.rd.ROIs{iROI, 2}));
    % common inputs for the imrois
    inputs = {this.GUI.handles.rd.axe, this.rd.ROIs{iROI, 3}};
    % set the type of the imroi in the 4th column
    this.rd.ROIs{iROI, 4} = this.rd.ROIs{iROI, 1};
    % recreate the imroi depending on its type
    switch(this.rd.ROIs{iROI, 1});
        case {'impoly', 'imfreehand'};
            this.rd.ROIs{iROI, 1} = impoly(inputs{:}, 'Closed', true);
            this.rd.ROIs{iROI, 1}.setVerticesDraggable(false);
        otherwise
            imroiFuncHandle = str2func(this.rd.ROIs{iROI, 1});
            this.rd.ROIs{iROI, 1} = imroiFuncHandle(inputs{:});
    end;
    % add the position callback
    ROIID = this.rd.ROIs{iROI, 2};
    this.rd.ROIs{iROI, 1}.addNewPositionCallback(@(h)RDUpdateImage(this, [], [], ROIID));
    this.rd.ROIs{iROI, 6} = true; % mark as modified/created
end;

o('#RDLoadROIs(): loading done.', 3, this.verb);
% get the plural marks for the display
plurROIs = ''; if this.rd.nROIs > 1;        plurROIs = 's'; end;
plurRuns = ''; if numel(runsValidity) > 1;  plurRuns = 's'; end;
showMessage(this, sprintf('Loaded %d ROI%s (%d run%s).', this.rd.nROIs, plurROIs, numel(runsValidity), plurRuns));

% update the display
RDUpdateGUI(this);

RDShowHideROIs(this, []);

% set back the ROICompare annotations
if get(this.GUI.handles.rd.refROISet, 'Value');
    
    set(this.GUI.handles.rd.showHideROIs, 'Value', 0);
    set(this.GUI.handles.rd.showHideROIsLab, 'Value', 0);
    RDShowHideROIs(this, []);
    
    RDCompareROIs(this);
    
end;

end
