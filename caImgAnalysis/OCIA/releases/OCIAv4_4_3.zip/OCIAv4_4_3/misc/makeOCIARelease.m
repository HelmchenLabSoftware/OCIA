% make a release of the OCIA

% define target directory
targetDirRoot = 'E:\';

% get the version
FID = fopen(which('OCIA'));
A = regexp(fscanf(FID, '%s'), 'version=.(?<version>[\d\.]+).;', 'names');
fclose(FID);
version = regexprep(A.version, '\.', '_');

% get the target dir
targetDir = regexprep(sprintf('%sOCIAv%s\\', targetDirRoot, version), '\\', '/');

% get the OCIA folder
OCIASrcDir = regexprep(which('OCIA'), '\\', '/');
OCIASrcDir = regexprep(OCIASrcDir, '@OCIA/OCIA.m$', '');

% copy the OCIA files
copyfile([OCIASrcDir '*'], targetDir);

% make an 'etc' folder and copy all required functions for the main OCIA file
etcDir = [targetDir 'etc/'];
exportMfiles('OCIA', 0, 0, etcDir);

% make an 'etc' folder and copy all required functions for the OCIA helper files
OCIAHelperFolders = dir([OCIASrcDir 'OCIAHelper/*']); % get OCIA helper folders
OCIAHelperFoldersNames = arrayfun(@(i)OCIAHelperFolders(i).name, 1 : numel(OCIAHelperFolders), 'UniformOutput', false);
OCIAHelperFoldersNames(1 : 2) = []; % remove '.' and '..'
% go through each folder and get each file's name
for iFolder = 1 : numel(OCIAHelperFoldersNames);
    OCIAHelperFiles = dir([OCIASrcDir 'OCIAHelper/' OCIAHelperFoldersNames{iFolder} '/*']); % get OCIA helper files
    OCIAHelperFilesNames = arrayfun(@(i)OCIAHelperFiles(i).name, 1 : numel(OCIAHelperFiles), 'UniformOutput', false);
    OCIAHelperFilesNames(1 : 2) = []; % remove '.' and '..'
    for iHelperFile = 1 : numel(OCIAHelperFilesNames);
        exportMfiles(OCIAHelperFilesNames{iHelperFile}, 0, 0, etcDir);
    end;
    
    % remove files that are in the OCIA helper files
    etcFiles = dir([etcDir '*']); % get etc folder files
    etcFilesNames = arrayfun(@(i)etcFiles(i).name, 1 : numel(etcFiles), 'UniformOutput', false);
    etcFilesNames(1 : 2) = []; % remove '.' and '..'
    for iEtcFile = 1 : numel(etcFilesNames);
        if ismember(etcFilesNames{iEtcFile}, OCIAHelperFilesNames);
            delete([etcDir etcFilesNames{iEtcFile}]);
        end;
    end;    
end;

% remove files that are already in the @OCIA folder or in the OCIA helper files
OCIATargetDir = [targetDir '@OCIA/'];
OCIAFiles = dir([OCIATargetDir '*']); % get OCIA files
OCIAFileNames = arrayfun(@(i)OCIAFiles(i).name, 1 : numel(OCIAFiles), 'UniformOutput', false);
OCIAFileNames(1 : 2) = []; % remove '.' and '..'
etcFiles = dir([etcDir '*']); % get etc folder files
etcFilesNames = arrayfun(@(i)etcFiles(i).name, 1 : numel(etcFiles), 'UniformOutput', false);
etcFilesNames(1 : 2) = []; % remove '.' and '..'
for iEtcFile = 1 : numel(etcFilesNames);
    if ismember(etcFilesNames{iEtcFile}, OCIAFileNames);
        delete([etcDir etcFilesNames{iEtcFile}]);
    end;
end;

zip(regexprep(targetDir, '/$', '.zip'), [targetDir '*']);
