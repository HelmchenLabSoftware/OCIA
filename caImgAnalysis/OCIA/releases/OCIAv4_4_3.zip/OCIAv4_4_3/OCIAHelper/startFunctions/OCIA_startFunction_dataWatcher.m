%% #OCIA:OCIA_startFunction_dataWatcher
function OCIA_startFunction_dataWatcher(this)

    % go to data watcher mode
    OCIAChangeMode(this, 'DataWatcher');

    % process the selected folder and extract the notebook informations
    DWProcessWatchFolder(this);
    pause(0.1);
    DWExtractNotebookInfo(this);

    % if there are any filters for row type or run type, select them
    GUIDWFiltH = this.GUI.handles.dw.filt;
    if ~isempty(get(GUIDWFiltH.rowtype, 'String')) || ~isempty(get(GUIDWFiltH.runtype, 'String'));
        DWFilterRunTable(this, 'new');
    end;

    % show welcome message
    showMessage(this, sprintf('Welcome to the OCIA v%s ! :-)', this.version));
            
end
