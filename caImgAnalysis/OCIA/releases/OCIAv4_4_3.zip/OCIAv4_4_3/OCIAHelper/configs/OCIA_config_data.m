function [this, inputParams] = OCIA_config_data(this)
% adds the data structures to the OCIA

inputParams = [];

%% - properties: Data
% structure holding all the data with :
%   - cell-array fields that have one cell per run/row
%   - structure for each data mode added
this.data = struct();
% raw data as cell array for each run/row
this.data.raw = cell(this.dw.dataNMaxRuns, 1);
% load type of the raw data as cell array for each run/row: can be either 'prev' (preview) or 'full' (fully loaded)
this.data.rawLoadType = cell(this.dw.dataNMaxRuns, 1);
% pre-processed data as cell array for each run/row
this.data.preProc = cell(this.dw.dataNMaxRuns, 1);
% pre-processing type of the pre-processed data as cell array for each run/row. Can contain any pre-processing
%   strings (example for imaging data: skipFrame, fShift, fJitt, moCorr, moDet, etc.)
this.data.preProcType = cell(this.dw.dataNMaxRuns, 1);

% apply different data modes' configuration
for iMode = 1 : numel(this.dw.dataModes);
    
    % get the data configuration function's name and check if it exists
    modeName = lower(this.dw.dataModes{iMode});
    funcName = sprintf('OCIA_config_data_%s', modeName);
    if ~exist(funcName, 'file');
        showWarning(this, 'OCIA:DataConfigFunctionNotFound', ...
            sprintf('Data configuration function "%s" not found, skipping.', funcName));
        continue;
    end;
    
    % call the appropriate data configuration function with an error catching block
    try
        OCIADataConfigFun = str2func(funcName);
        this = OCIADataConfigFun(this);
    catch err;
        showWarning(this, 'OCIA:DataConfigFunctionError', ...
            sprintf('Data configuration function "%s" run into an error: %s (%s)\n%s.', ...
            funcName, err.message, err.identifier, getStackText(err)));
    end;
    
end;

end
