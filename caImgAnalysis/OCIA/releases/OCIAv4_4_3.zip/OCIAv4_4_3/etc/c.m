
% Clear command window:
clc;

% Close figures:
try
  close('all', 'hidden');
catch e; % do nothing
end;

% Closing figures might fail if the CloseRequestFcn of a figure blocks the execution. Fallback:
AllFig = allchild(0);
if ~isempty(AllFig);
   set(AllFig, 'CloseRequestFcn', '', 'DeleteFcn', '');
   delete(AllFig);
end;

% Clear loaded functions:
clear('functions');
warning('off', 'MATLAB:ClassInstanceExists');
clear('classes');
warning('on', 'MATLAB:ClassInstanceExists');
clear('java');
clear('global');
clear('import');  % Not from inside a function!
clear('variables');

% Stop and delete timers:
AllTimer = timerfindall;
if ~isempty(AllTimer)
   stop(AllTimer);
   delete(AllTimer);
end

% Unlock M-files:
LoadedM = inmem;
for iLoadedM = 1:length(LoadedM)
   try
       % Use STRTOK to consider OO methods:
       aLoadedM = strtok(LoadedM{iLoadedM}, '.'); 
       munlock(aLoadedM);
       clear(aLoadedM);
   catch e;
   end;
end   

% Close open files:
fclose('all');

% Reset the warning status:
warning('on', 'all');

% clear created variables
clear all;

