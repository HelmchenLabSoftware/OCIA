%% #OCIA:DWSaveDataAsHDF5
function DWSaveDataAsHDF5(this, savePath)
    
showMessage(this, sprintf('Saving data to "%s" ...', savePath), 'yellow');

% get the rows of the current selection
rows = this.dw.selectedTableRows;    
nRows = numel(rows); % get the number of rows

% init wait bar
DWWaitBar(this, 0);

% get the data type IDs to flush from memory (if required)
dataTypeIDsToFlush = this.dw.dataTypesToFlushAfterSaving;
% if non required, get the data types from the selection
if isempty(dataTypeIDsToFlush);
    dataTypeIDsToFlush = this.main.dataConfig.id(get(this.GUI.handles.dw.SLROptDataList, 'Value'));
end;

saveDataTic = tic; % for performance timing purposes
% go through each row   
for iRow = 1 : nRows;

    iDWRow = rows(iRow); % get the DataWatcher's table index
    rowID = DWGetRowID(this, iDWRow); % get the row's ID

    % if required, process the row with the requested options
    if get(this.GUI.handles.dw.SLROpts.procBefSave, 'Value');
        OCIA_dataWatcherProcess_processRows(this, [], rows(iRow));
    end;

    % create the generic save text and show a message
    saveText = sprintf('Saving data for %s (%03d)', rowID, iDWRow);
    showMessage(this, sprintf('%s ...', saveText), 'yellow');

    % save the data for this single row
    DWSaveDataAsHDF5SingleRow(this, iDWRow, rowID, saveText, savePath);

    % if required, flush the data for the current row to avoid memory overflow
    if get(this.GUI.handles.dw.SLROpts.flushAfterSave, 'Value');
        showMessage(this, sprintf('%s ...', strrep(saveText, 'Saving', 'Flushing')), 'yellow');
        DWFlushData(this, iDWRow, true, dataTypeIDsToFlush{:});
    end;

    showMessage(this, sprintf('%s done.', saveText));
    DWWaitBar(this, 100 * (iRow / nRows));

end;

% get information about the saved file
saveFile = dir(savePath);
% show information if file is found
if ~isempty(saveFile);
    showMessage(this, sprintf('Saving data to "%s" done (%.3f sec, %.3f MB).', savePath, ...
        toc(saveDataTic), saveFile.bytes / (2^10 * 2^10)));
else
    showMessage(this, sprintf('Saving data to "%s" done but file not found (%.3f sec).', savePath, ...
        toc(saveDataTic)), 'yellow');
end;
    
end
