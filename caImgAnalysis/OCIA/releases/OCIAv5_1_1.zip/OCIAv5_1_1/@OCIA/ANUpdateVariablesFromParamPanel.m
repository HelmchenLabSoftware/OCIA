function ANUpdateVariablesFromParamPanel(this)

% update the parameter panel depending on the plot using the analysisParamConfig
nUICtrl = size(this.GUI.an.analysisParamConfig, 1);

% go through all elements and update their associated parameters
for iUICtrl = 1 : nUICtrl;
    
    % extract the elements of the parameter config
    rowParams = table2cell(this.GUI.an.analysisParamConfig(iUICtrl, 1 : 4));
    [categ, id, UIType, valueType] = rowParams{:};
    
    % if no field corresponds to the id, skip this element
    if ~isfield(this.GUI.handles.an.paramPanElems, id); continue; end;
    
    % process the different UI types
    switch UIType;
        
        % text input elements
        case 'text';
            
            % get the text
            txt = get(this.GUI.handles.an.paramPanElems.(id), 'String');            
            % make sure we do not have a cell here
            if iscell(valueType); valueType = valueType{1}; end;
            
            % process the different value types
            switch valueType;
                
                case 'numeric'; % single number
                    dblValue = str2double(txt); % get the value as double
                    % unless the value is a NaN, store it in the right variable
                    if ~isnan(dblValue); this.an.(categ).(id) = dblValue; end;
                    
                case 'text'; % string
                    % unless the value is a empty, store it in the right variable
                    if ~isempty(txt); this.an.(categ).(id) = txt; end;
                    
                case 'array'; % array of numbers
                    % remove anything that is not a number, a comma, a colon, a dot, a minus, a space or square brackets
                    val = regexprep(txt, '[^\[\]\d ,:;\.-]', '');
                    % single dash means leave empty
                    if strcmp(val, '-');
                        this.an.(categ).(id) = '';
                        continue;
                    end;
                    % if the text is not empty, evaluate the text to get the actual array, 
                    %   using try-catch to catch the eval errors
                    if ~isempty(val); try val = eval(val); catch e; val = []; end; end; %#ok<NASGU>
                    % if the array is not empty and does not contains NaNs, store its value
                    if ~isempty(val) && ~any(isnan(val(:))); this.an.(categ).(id) = val; end;
                    
                case 'cellArray'; % cell array of strings
                    % remove anything that is not a number, a comma, a colon, a dot, a minus, a space or square brackets
                    val = regexprep(txt, '^\{ (.+)\ }$', '$1');
                    % single dash means leave empty
                    if numel(val) == 1 && strcmp(val, '-');
                        this.an.(categ).(id) = { };
                        continue;
                    end;
                    % split by columns
                    rowSplitVal = regexp(regexprep(val, ';$', ''), '; ', 'split')';
                    % make sure val is a cell
                    if ~iscell(rowSplitVal); rowSplitVal = { rowSplitVal }; end;
                    nRows = numel(rowSplitVal);
                    % split each row
                    colSplitVal = regexp(rowSplitVal, ', ', 'split');
                    % split each row
                    nColsForEachRow = arrayfun(@(i)size(colSplitVal{i}, 2), 1 : nRows);
                    % if all columns do not have the same number of rows, show a warning and abort
                    if any(nColsForEachRow ~= nColsForEachRow(1));
                        showWarning(this, 'OCIA:ANUpdateVariablesFromParamPanel:BadNumOfRowsForColsCellArray', sprintf( ...
                            'Param. control "%s": all columns do not have the same number of rows. Aborting.', id));
                        continue;
                    end;
                    val = cell(nRows, nColsForEachRow(1));
                    % reshape values into a cell-array
                    for iRow = 1 : nRows;
                        val(iRow, :) = colSplitVal{iRow};
                    end;
                    % re-cast values as numbers if required
                    for iCell = 1 : numel(val);
                        % if cell is a number between brackets
                        if regexp(val{iCell}, '^\[[-\.\d]+\]$');
                            val{iCell} = eval(val{iCell});
                        end;
                    end;
                    % if the array is a cell array of strings, store it
                    if ~isempty(val) && iscell(val) && all(all(cellfun(@ischar, val))); this.an.(categ).(id) = val; end;
                    
            end; % end of valueType switch
            
        % drop down elements
        case 'dropdown';
            % get the possible values
            values = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            % store the selected value
            this.an.(categ).(id) = values{get(this.GUI.handles.an.paramPanElems.(id), 'Value')};
            
        % list elements
        case 'list';
            % get the possible values
            values = get(this.GUI.handles.an.paramPanElems.(id), 'String');
            % store the selected value
            this.an.(categ).(id) = values(get(this.GUI.handles.an.paramPanElems.(id), 'Value'));
            
    end; % end of UIType switch
    
end; % end of control element loop

end