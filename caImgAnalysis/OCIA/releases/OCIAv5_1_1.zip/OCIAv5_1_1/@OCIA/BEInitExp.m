%% #BEInitExp
function BEInitExp(this)

if ~this.be.configLoaded;
    showWarning(this, 'OCIA:Behavior:InitExp:configNotLoaded', ...
        'Cannot initialize experiment because config is not loaded.');
    return;
end;
if isempty(this.be.animalID);
    showWarning(this, 'OCIA:Behavior:InitExp:NoMouseId', ...
        'Cannot initialize experiment because there is no animalID.');
    return;
end;
o('  #BEInitExp: initializing experiment ... ', 2, this.verb);

%% - #BEInitExp - initializing settings
nTrials = this.be.config.training.nTrials;
this.be.times = struct();
this.be.times.start = nan(1, nTrials);
this.be.times.startDelay = nan(1, nTrials);
this.be.times.imag = nan(1, nTrials);
this.be.times.sound = nan(1, nTrials);
this.be.times.respWaitStart = nan(1, nTrials);
this.be.times.respMin = nan(1, nTrials);
this.be.times.respMax = nan(1, nTrials);
this.be.times.soundDur = nan(1, nTrials);
this.be.times.spoutIn = nan(1, nTrials);
this.be.times.spoutOut = nan(1, nTrials);
this.be.times.respTime = nan(1, nTrials);
this.be.times.rewCollEnd = nan(1, nTrials);
this.be.times.rewStart = nan(1, nTrials);
this.be.times.rewStop = nan(1, nTrials);
this.be.times.endImagExp = nan(1, nTrials);
this.be.times.endImagObs = nan(1, nTrials);
this.be.times.endPunish = nan(1, nTrials);
this.be.times.end = nan(1, nTrials);
this.be.nInTriLick = nan(1, nTrials);
this.be.resps = nan(1, nTrials);
this.be.punishTimeOuts = nan(1, nTrials);
this.be.respDelays = nan(1, nTrials);
% for each trial: 1 = correct detect, 2 = correct reject, 3 = false alarm, 4 = miss, 5 = early
this.be.respTypes = nan(1, nTrials);
this.be.giveRewards = nan(1, nTrials);
this.be.autoRewardModes = cell(1, nTrials);
this.be.autoRewardGiven = nan(1, nTrials);

this.be.isPaused = false;
this.be.isRunning = false;
this.be.isToReset = false;

set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);

this.be.saveTime = datestr(now(), 'yyyy_mm_dd__HH_MM_SS');
saveFolder = sprintf('%s/behav/', this.path.behavSave);
this.be.savePath = sprintf('%sBehavior_%s.mat', saveFolder, this.be.saveTime);
if exist(saveFolder, 'dir') ~=7; mkdir(saveFolder); end;
this.be.logDateFormat = 'yyyy-mm-dd HH:MM:SS.FFF';
o('  #BEInitExp: save folder initialized.', 2, this.verb);

% structure containing the recorded data (analog input )
this.be.record = struct();
for iChan = 1 : size(this.be.hw.analogIns, 2);
    anInName = this.be.hw.analogIns{iChan};
    this.be.record.(anInName) = cell(1, nTrials);
end;

end

