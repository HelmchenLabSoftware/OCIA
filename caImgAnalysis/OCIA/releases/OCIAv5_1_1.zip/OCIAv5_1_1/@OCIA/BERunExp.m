%% #BERunExp
function BERunExp(this)

displayedPause = 0;
this.be.expStartTime = nowUNIXSec;

while this.be.isRunning;

    o('#BERunExp: iTrial = %d.', this.be.iTrial, 4, this.verb);

    if ~this.be.isPaused;
        if displayedPause; o(' --- RESUMED --- ', 1, this.verb); displayedPause = 0; end;
        o('#BERunExp: running trial %03d.', this.be.iTrial, 3, this.verb);
        RP = BERunTrial(this);
        o('#BERunExp: trial %03d ended.', this.be.iTrial, 3, this.verb);

        %% - #BERunExp: end trial (post-trial tasks)
        BEEndTrial(this, RP);

        if this.be.isRunning;
%             o('Trial %d: pause ended, updating trial number.', this.be.iTrial, 2, this.verb);
            if this.be.iTrial == this.be.config.training.nTrials;
                this.be.isRunning = false;
                set(this.GUI.handles.be.startExp, 'BackgroundColor', 'red', 'Value', 0);
                set(this.GUI.handles.be.pauseExp, 'BackgroundColor', 'red', 'Value', 0);
            else
                this.be.iTrial = this.be.iTrial + 1;
                o('Trial %03d: updated trial number: %03d.', this.be.iTrial - 1, ...
                    this.be.iTrial, 3, this.verb);
            end;
        else
            o('Trial %d: not running anymore, no update of trial number.', ...
                this.be.iTrial, 2, this.verb);
        end;
        o('#BERunExp: running trial %03d done.', this.be.iTrial, 3, this.verb);
    else
        if ~displayedPause; o(' --- PAUSED --- ', 1, this.verb); displayedPause = 1; end;
        o('#BERunExp: waiting for %f sec (trial %d).', this.GUI.be.trialLoopUpdateRate, ...
            this.be.iTrial, 3, this.verb);
        pause(this.GUI.be.trialLoopUpdateRate);
    end;
end;

this.be.expEndTime = nowUNIXSec - this.be.expStartTime;
showMessage(this, sprintf('Experiment ended (%d/%d trials, %.0f seconds).', this.be.iTrial, ...
    this.be.config.training.nTrials, this.be.expEndTime));

% save the output the recorded data
BESaveOutput(this);

this.be.isToReset = true;

% restart the timer and recording channels
if ~strcmp(this.GUI.be.updateTimer.Running, 'on');
    start(this.GUI.be.updateTimer);
end;
this.be.hw.anIn.startBackground();

end

