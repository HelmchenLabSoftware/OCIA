%% #OCIA:AN:ANClearData
function ANClearData(this, varargin)

% get the field names of the analyser
analyserFields = fieldnames(this.an);
% go through them
for iField = 1 : numel(analyserFields);
    % if there is a dataHash field, reset it
    if isfield(this.an.(analyserFields{iField}), 'dataHash');
        this.an.(analyserFields{iField}).dataHash = struct();
    end;
end;


showMessage(this, 'Cleared cached data.');
    
end
