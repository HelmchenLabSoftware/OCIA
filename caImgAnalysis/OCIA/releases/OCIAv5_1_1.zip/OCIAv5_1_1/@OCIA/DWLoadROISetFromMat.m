%% #OCIA:DWLoadROISetFromMat
function [ROISet, runsValidity, refImage, nROIs, nRuns] = DWLoadROISetFromMat(this, loadPath)
        
    % load the ROISet
    ROISetMatStruct = load(loadPath);
    % extract variables
    ROIs = ROISetMatStruct.ROIs;
    runsValidity = ROISetMatStruct.runsValidity;
    refImage = ROISetMatStruct.refImage;
    ROIMask = ROISetMatStruct.ROIMask;
    
    % get the number of ROIs and runs of this ROISet
    nROIs = size(ROIs, 1);
    nRuns = size(runsValidity, 1);

    % create the ROISet cell-array
    ROISet = cell(nROIs, 2);
    % copy the names
    ROISet(:, 1) = ROIs(:, 2);
    % create the masks
    ROISet(:, 2) = arrayfun(@(x) ROIMask == x, 1 : nROIs, 'UniformOutput', false);
    % if no neuropil ROI yet, add it to the ROISet
    if ~ismember('npil', lower(ROISet(:, 1)));
        [ROISet, nROIs] = addNPilROIToROISet(ROISet, this.an.an.nPilMaskBord);
    end;
    
end
