function this = OCIA_dataConfig_behav(this)
% adds the behavior data structures to the OCIA

% defines the data storage options
this.main.dataConfig = [this.main.dataConfig; cell2table({ ...
...     rowType             id                  shortLabel              label                     saveFormat    defaultOn
        'Behavior data',    'behav',            'Behav. data (raw)',    'Behavior data (raw)',    'HDF5',       false;
}, 'VariableNames', this.main.dataConfig.Properties.VariableNames)];

% define the analysis parameters for this data type
this.an.be = struct();
this.an.be.nTrialsSkip = [3, 3];
this.an.be.nMinRespTrialSkip = [4, 7];

this.an.be.binWidth = 150;
this.an.be.behavVarToPlot = { 'days', 'session', 'training phase', 'hit rate - session', ...
    'false alarm rate - session', 'performance (d'') - session' };
this.an.be.miceInfoFilePath = '1410MiceInfo.txt';
this.an.be.plotLims = [];

this.an.be.groupBehavVar = { };
this.an.be.histBinWidth = 'sqrt';

% storage for the cached data
this.an.be.dataHash = struct();

end
