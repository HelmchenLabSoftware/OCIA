function this = OCIA_dataConfig_whisk(this)
% adds the whisker data structures to the OCIA

%% - properties: Data: Whisker
% structure *array* with one element per row of the DataWatcher's table
this.data.whisk = struct();
% average whisker angle
this.data.whisk.angle = [];
% frame rate of the whisker angle data
this.data.whisk.frameRate = [];

% expand to a structure array
this.data.whisk(this.dw.dataNMaxRuns) = this.data.whisk(1);
   

end
