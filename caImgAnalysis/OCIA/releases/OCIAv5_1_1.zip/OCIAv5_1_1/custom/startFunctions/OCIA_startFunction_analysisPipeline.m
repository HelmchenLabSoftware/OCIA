%% #OCIA:OCIA_startFunction_analysisPipeline
function OCIA_startFunction_analysisPipeline(this)

% load data and swtich to analyser mode
OCIA_startFunction_loadDataAndOpenAnalyser(this);

%% start analysis pipeline    
% remove PNG saving warning
warning('off', 'MATLAB:LargeImage');

% get the DataWatcher's and the Analyser's GUI handle
dwh = this.GUI.handles.dw;
anh = this.GUI.handles.an;

% shorten the name
plotAndSave = @OCIA_analysis_updatePlotAndSave;

% plot to save configuration
plotCaTraces = false;
plotCaTracesHeatMap = false;
plotPSCaTracesHeatMap = false;
plotSingleROIAverage = false;
plotSingleROIAllPhasesAverage = false;
plotGroupROIAverage = -1; % 0 or less to inactivate
%     plotGroupROIAverage = 6; % 0 or less to inactivate
plotPooledAnalysis = true;
plotAllCaTraces = false;

% get the currently analysed data's IDs
animalID = this.dw.animalIDs{get(dwh.filt.animalID, 'Value')};
shortAnimalID = regexprep(regexprep(animalID, 'mou_bl_', ''), '_', '');
spotID = this.dw.spotIDs{get(dwh.filt.spotID, 'Value')};

% abort if no rows loaded
if ~isfield(anh, 'paramPanElems'); return; end;

% get the relevant ROI names
uniqueROINames = get(anh.paramPanElems.selROINames, 'String');

% get all the unique days and go through them
days = unique(get(this, this.an.selectedTableRows, 'day'));

%{
iDay = 1;
rowsForDay = find(strcmp(get(this, this.an.selectedTableRows, 'day'), days{iDay}));
set(anh.rowList, 'Value', rowsForDay);
iMask = 1;
iStimType = 2;
%}

% only do the day-base analysis if requested
if plotCaTraces || plotCaTracesHeatMap || plotPSCaTracesHeatMap || plotSingleROIAverage || plotGroupROIAverage > 0;

    %% day loop
    for iDay = 1 : numel(days);

        % select all rows for the current day
        rowsForDay = find(strcmp(get(this, this.an.selectedTableRows, 'day'), days{iDay}));
        set(anh.rowList, 'Value', rowsForDay);

        %% mask loop
        % go through the saving once with and once without the mask
%         for iMask = 1 : 2;
        for iMask = 1;

            %% general plotting params
            set(anh.paramPanElems.sgFiltFrameSize, 'String', 15);
            set(anh.paramPanElems.exclFrames, 'Value', iMask);
            if isfield(anh.paramPanElems, 'PSPer');     set(anh.paramPanElems.PSPer, 'String', '[1, 1]');
            else                                        this.an.img.PSPer = [1 1];
            end;

            % get the save path
            currentDaySavePath = sprintf('%s%s_%s/%s_%s_%s_', this.path.OCIASave, shortAnimalID, spotID, shortAnimalID, ...
                spotID, regexprep(days{iDay}, '_', ''));

            %% caTraces plot
            set(anh.plotList, 'Value', 1); % select the calcium traces plot
            set(anh.paramPanElems.selROINames, 'Value', 1 : numel(uniqueROINames)); % all ROIs
            set(anh.paramPanElems.selStimTypeGroups, 'Value', 2); % low vs high
            anh = plotAndSave(this, sprintf('%scaTracesOverview', currentDaySavePath), iMask, plotCaTraces);

            % get ROIs valid for the current day
            ROIsForDay = get(anh.paramPanElems.selROINames, 'Value');
            nROIs = numel(ROIsForDay);

            %% caTraces heat map plot
            set(anh.plotList, 'Value', 2); % select the calcium traces heat map plot
            anh = plotAndSave(this, sprintf('%scaTracesOverviewHeatMap', currentDaySavePath), iMask, plotCaTracesHeatMap);

            %% PS-average plots for different stimulus combinations
            % get all stimulus types and go through them
            stimTypes = get(anh.paramPanElems.selStimTypeGroups, 'String');
            for iStimType = 1 : numel(stimTypes);

                if iStimType == 3; continue; end; % do not plot targ/distractor since its redundant with low/high

                %% PS-average heat map all ROIs
                set(anh.plotList, 'Value', 4); % select the peri-stimulus average heat map plot
                set(anh.paramPanElems.selROINames, 'Value', 1 : numel(uniqueROINames)); % all ROIs
                set(anh.paramPanElems.selStimTypeGroups, 'Value', iStimType); % current stim type
                % update the plot to get the stimulus types for sorting
                ANUpdatePlot(this, 'force'); anh = this.GUI.handles.an;
                set(anh.paramPanElems.sortMethod, 'Value', 5); % use max_evoked sorting method
                sortStims = get(anh.paramPanElems.sortStim, 'String'); % get current sorting stims
                set(anh.paramPanElems.sortStim, 'Value', numel(sortStims)); % use last stim to sort
                set(anh.paramPanElems.combineROIs, 'Value', 1); % do combine ROIs

                % if only one stimulus present in current selection and already saved that situation once, skip this
                if numel(sortStims) == 1 && iStimType > 1; ANClearData(this); continue; end;

                % update and save the PS-average heat map
                anh = plotAndSave(this, sprintf('%sPSAAverageHeatMapRedWhiteBlue_%s_maxEvoked_asc_%s', currentDaySavePath, ...
                    regexprep(stimTypes{iStimType}, '^soundStart_', ''), sortStims{end}), iMask, plotPSCaTracesHeatMap);

                % if only one stimulus present in current selection, skip the ROI PS-average saving
                if numel(sortStims) == 1; ANClearData(this); continue; end;

                %% PS-average for each ROI
                % ROI averages one by one
                if plotSingleROIAverage;  
                    % select the peri-stimulus average plot
                    set(anh.plotList, 'Value', 3); %#ok<*UNRCH>             
                    % go through each ROI and save its PS-average
                    for iROI = 1 : nROIs;
                        set(anh.paramPanElems.selROINames, 'Value', ROIsForDay(iROI));
                        set(anh.paramPanElems.combineROIs, 'Value', 1); % do combine ROIs
                        anh = plotAndSave(this, sprintf('%sPSAAverage_ROI%s_%s', currentDaySavePath, ...
                            uniqueROINames{ROIsForDay(iROI)}, regexprep(stimTypes{iStimType}, '^soundStart_', '')), iMask);
                    end;                    
                end;

                % ROI averages by group
                if plotGroupROIAverage > 0; 
                    set(anh.plotList, 'Value', 3); % select the peri-stimulus average plot  
                    set(anh.paramPanElems.combineROIs, 'Value', 1); % do combine ROIs                 
                    % go through each ROI and save its PS-average
                    iROI = 1;
                    while iROI < nROIs;
                        % get the last ROI for this group, without exceeding the total number of ROIs
                        lastROI = min(iROI + plotGroupROIAverage - 1, nROIs);
                        set(anh.paramPanElems.selROINames, 'Value', ROIsForDay(iROI : lastROI));
                        % plot the ROIs as a group
                        anh = plotAndSave(this, sprintf('%sPSAAverage_ROIGroup%sTo%s_%s', currentDaySavePath, ...
                            uniqueROINames{ROIsForDay(iROI)}, uniqueROINames{ROIsForDay(lastROI)}, ...
                            regexprep(stimTypes{iStimType}, '^soundStart_', '')), iMask);
                        % update the dounter
                        iROI = lastROI + 1;
                    end;                    
                end;

                % flush memory
                ANClearData(this);

            end; % stim types loop

            % flush memory
            ANClearData(this);

        end; % mask loop

        % flush memory
        ANClearData(this);

    end; % day loop

end; % if-else plot loop

%% pooled analysis
if plotPooledAnalysis || plotSingleROIAllPhasesAverage || plotAllCaTraces;

    % set plotting parameters
    set(anh.rowList, 'Value', 1 : numel(this.an.selectedTableRows)); % select all days        
    set(anh.paramPanElems.sgFiltFrameSize, 'String', 15); % filter
    set(anh.paramPanElems.exclFrames, 'Value', 1); % excluded frames
    set(anh.paramPanElems.selStimTypeGroups, 'Value', 2); % stim type = sound type
    set(anh.paramPanElems.selROINames, 'Value', 1 : numel(uniqueROINames)); % all ROIs
    % peri-stimulus period
    if isfield(anh.paramPanElems, 'PSPer');     set(anh.paramPanElems.PSPer, 'String', '[1, 1]');
    else                                        this.an.img.PSPer = [1 1];
    end;
    % responsiveness metrix
    if isfield(anh.paramPanElems, 'respMethod');set(anh.paramPanElems.respMethod, 'Value', 1);
    else                                        this.an.img.respMethod = 'mean';
    end;

    savePath = sprintf('%s%s_%s/%s_%s_pooled_meanResp_', this.path.OCIASave, shortAnimalID, spotID, shortAnimalID, spotID);

    if plotAllCaTraces;
        set(anh.plotList, 'Value', 1); % select the calcium traces plot
        anh = plotAndSave(this, sprintf('%sallCaTraces', savePath), 1);
    end;       

    if plotPooledAnalysis;
        % plot distributions
        
%         if isfield(anh.paramPanElems, 'ROIProp');   set(anh.paramPanElems.ROIProp, 'Value', 4);
%         else                                        this.an.img.ROIProp = 'respStimsMean';       end; 
%         set(anh.plotList, 'Value', 7); % select ROIProp distribution
%         anh = plotAndSave(this, sprintf('%sResponsivenessDistribution', savePath), 1, 0);
%         set(anh.paramPanElems.ROIProp, 'Value', 5);
%         anh = plotAndSave(this, sprintf('%sSelectivityDistribution', savePath), 1, 0);

        set(anh.plotList, 'Value', 7); % select ROIProp distribution
        % update the plot to get the stimulus types for sorting
        ANUpdatePlot(this, 'force'); anh = this.GUI.handles.an;
        plotTypeNames = { 'distribution', 'histogram', 'cumDistr' };
        for iStim = [6 7];
            for iPlotType = 1 : 3;
                set(anh.paramPanElems.ROIProp, 'Value', iStim);
                set(anh.paramPanElems.ROIPropPlotType, 'Value', iPlotType);
                anh = plotAndSave(this, sprintf('%sResponseTimeDistribution_%s_%s', savePath, ...
                    plotTypeNames{iPlotType}, iff(iStim == 6, 'low', 'high')), 1, 1);
            end;
        end;

        % save the output
        ANSaveOutput(this, [savePath 'output.mat']);
    end;

    % single ROI evolution over all phases plot
    if plotSingleROIAllPhasesAverage > 0; 

        % flush memory
        ANClearData(this);

        set(anh.plotList, 'Value', 3); % select the peri-stimulus average plot
        % do not combine ROIs
        if isfield(anh.paramPanElems, 'combineROIs');       set(anh.paramPanElems.combineROIs, 'Value', 2);
        else                                                this.an.img.combineROIs = 'false';
        end;
        % do not average ROIs
        if isfield(anh.paramPanElems, 'averageROI');        set(anh.paramPanElems.averageROI, 'Value', 2);
        else                                                this.an.img.averageROI = 'false';
        end;
        % select first ROI
        set(anh.paramPanElems.selROINames, 'Value', 1);
        % update the plot to get the stimulus types for sorting
        ANUpdatePlot(this, 'force'); anh = this.GUI.handles.an;
        % get the full ROIs names
        allROINames = get(anh.paramPanElems.selROINames, 'String');
        % get the clean ROIs names without the 'RSXX_' tag
        uniqueAllROINames = unique(regexprep(allROINames, 'RS\d+_', ''));
        % go through each ROI and save its PS-average
        for iROI = 1 : numel(uniqueAllROINames);
            set(anh.paramPanElems.selROINames, 'Value', ROIsForDay(iROI));
            anh = plotAndSave(this, sprintf('%sPSAAverageAllPhases_ROI%s_%s', currentDaySavePath, ...
                uniqueROINames{ROIsForDay(iROI)}, regexprep(stimTypes{iStimType}, '^soundStart_', '')), iMask);
        end;                  
    end;

    % flush memory
    ANClearData(this);
end;
    

end
