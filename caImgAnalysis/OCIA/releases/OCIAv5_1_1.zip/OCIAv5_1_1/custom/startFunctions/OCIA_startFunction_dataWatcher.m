%% #OCIA:OCIA_startFunction_dataWatcher
function OCIA_startFunction_dataWatcher(this)

% go to DataWatcher mode
OCIAChangeMode(this, 'DataWatcher');

% process the selected folder and extract the notebook informations
DWProcessWatchFolder(this);

% show welcome message
showMessage(this, sprintf('Welcome to the OCIA v%s ! :-)', this.main.version));
            
end
