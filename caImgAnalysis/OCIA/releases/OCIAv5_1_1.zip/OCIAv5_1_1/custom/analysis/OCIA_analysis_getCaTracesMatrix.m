function [caTraces, stims, ROINames, concatCaTraces, concatStims, allCaTraces, allStims, allStimTypeGroups, allROINames] ...
    = OCIA_analysis_getCaTracesMatrix(this, iDWRows, combineROIs)

totalTic = tic; % for performance timing purposes

% store the "'UniformOutput' false" argument pair in a more convenient form
UF = { 'UniformOutput', false };

% get the list of all rows
allIDWRows = this.an.selectedTableRows;

%% general plotting parameter UI controls
if ~ismember('sgFiltFrameSize', this.GUI.an.analysisParamConfig.id);
        paramConf = cell2table({ ...
...     categ  id                   UIType      valueType               UISize    isLabAbove  label               tooltip
        'img', 'selROINames',       'list',     { },                    [4 7],    true,       'Selected ROIs',    'Select the ROIs to show and use for the current analysis.';
        'img', 'selStimTypeGroups', 'list',     { },                    [2 2],  true,       'Selected stimulus types', 'Select the stimulus type to use for the current analysis.';
        'img', 'selStimIDs',        'list',     { },                    [2 2],    true,       'Stims',            'Selection of stimuli.';
        'img', 'allStimIDs',        'text',     { 'cellArray' },        [1 0], false,      'All stim. IDs',    'Stimulus IDs for all the stimulus type as a cell-array.';
        'img', 'sgFiltFrameSize',   'text',     { 'numeric' },          [1 0], false,      'Sav.-Gol. filt.',  'Frame size of the Savitzky-Golay filter, value must be an odd number.';
        'img', 'exclFrames',        'dropdown', { 'show', 'mask' }',    [1 0], false,      'Excluded frames',  'Show or mask (hide) the excluded frames (z-motion).';
        'img', 'combineROIs',       'dropdown', { 'true', 'false' }',   [1 0], false,      'Combine ROIs',     'Combine the ROIs from different days or keep them separate.';
    }, 'VariableNames', this.GUI.an.analysisParamConfig.Properties.VariableNames);
    % append the new configuration to the table and update the row names using the ids
    this.GUI.an.analysisParamConfig = [paramConf; this.GUI.an.analysisParamConfig];
    this.GUI.an.analysisParamConfig.Properties.RowNames = this.GUI.an.analysisParamConfig.id;
    
    % adjust the re-organisation of the ROINames depending on the size of their name
    if strcmp(this.an.img.combineROIs, 'false');
        this.GUI.an.analysisParamConfig{'selROINames', 'UISize'} = [4 2.5];
    end;
end;


%% fetch or extract data
% get the data in memory
hashStruct = struct('allIDWRows', allIDWRows, 'combineROIs', combineROIs, 'dataType', 'caTraces');
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the raw calcium traces matrix is not in cache yet, create it
if isempty(cachedData);
    % get the total number of rows analysed
    nTotRows = numel(allIDWRows);
    % get which ROISet each run belongs to, using the ROISet ID stored in the DataWatcher's table
    rowsROISetIDs = get(this, allIDWRows, 'ROISet');
    if ~iscell(rowsROISetIDs); rowsROISetIDs = { rowsROISetIDs }; end;

    % get all the unique ROISets for the data set currently analysed
    [ROISets, ~, iDWROISetRows] = ANGetROISetForRow(this, allIDWRows);
    if iscell(iDWROISetRows); iDWROISetRows = cell2mat(iDWROISetRows); end;
    % get the ROISet IDs
    ROISetRowIDs = DWGetRowID(this, iDWROISetRows);
    if ~iscell(ROISetRowIDs); ROISetRowIDs = { ROISetRowIDs }; end;
    % if first cell is not a cell, it means we have a single ROISet so transform it to a cell-array
    if ~iscell(ROISets{1}); ROISets = { ROISets }; end;
    % extract the number of ROIs for each ROISet
    nROIsForEachROISet = cell2mat(cellfun(@(ROISet) size(ROISet, 1), ROISets, UF{:}));
    % get the total number of ROIs
    nTotROIs = sum(nROIsForEachROISet);

    % get the calcium data of all rows as a cell array of matrices
    allCaTracesCell = getData(this, allIDWRows, 'caTraces', 'data');
    if ~iscell(allCaTracesCell); allCaTracesCell = { allCaTracesCell }; end;
    % get the number of frames for each row
    nFramesEachRow = arrayfun(@(iRow) size(allCaTracesCell{iRow}, 2), 1 : nTotRows, UF{:});
    % get the maximum number of frames of the currently analysed data set
    nMaxFrames = max(cell2mat(nFramesEachRow)) + 1;
    % get the stimulus vectors and their bit description for the current selection
    allStimsCell = getData(this, allIDWRows, 'stim', 'data');
    allStimsTypesCell = getData(this, allIDWRows, 'stim', 'stimTypes');
    if ~iscell(allStimsCell); allStimsCell = { allStimsCell }; end;
    if ~iscell(allStimsTypesCell); allStimsTypesCell = { allStimsTypesCell }; end;
    % hack for soundStart
    allStimsTypesCell = regexprep(allStimsTypesCell, 'soundStart_', '');
    
    % get the exclusion masks of all rows as a cell array of matrices
    allExclMaskCell = getData(this, allIDWRows, 'exclMask', 'data');
    if ~iscell(allExclMaskCell); allExclMaskCell = { allExclMaskCell }; end;

    % (re-)create the raw calcium traces matrix as a nrows x nROIs x nFrames matrix with NaNs where there is no data
    allCaTraces = nan(nTotRows, nTotROIs, nMaxFrames);
    allExclMask = nan(nTotRows, nTotROIs, nMaxFrames);
    allStims = nan(nTotRows, nMaxFrames);

    % store the ROI names
    allROINames = cell(nTotROIs, 1);
    for iGroup = 1 : numel(nROIsForEachROISet);
        iROIStart = sum(nROIsForEachROISet(1 : iGroup - 1)) + 1; % define the ROI indexing's start
        iROIEnd = iROIStart + nROIsForEachROISet(iGroup) - 1; % define the ROI indexing's end
        % create the list of all ROI names, either with the ROISet's number or without it
        if combineROIs;
            allROINames(iROIStart : iROIEnd) = ROISets{iGroup}(:, 1);
        else
            allROINames(iROIStart : iROIEnd) = arrayfun(@(iROI) sprintf('RS%02d_%s', iGroup, ROISets{iGroup}{iROI, 1}), ...
                1 : size(ROISets{iGroup}, 1), 'UniformOutput', false);
        end;
    end;

    % fill-in the raw calcium traces for each row
    for iRow = 1 : nTotRows;
        iROISetForRow = find(strcmp(rowsROISetIDs{iRow}, ROISetRowIDs)); % get the ROISet index of this row
        iROIStart = sum(nROIsForEachROISet(1 : iROISetForRow - 1)) + 1; % define the ROI indexing's start
        iROIEnd = iROIStart + nROIsForEachROISet(iROISetForRow) - 1; % define the ROI indexing's end
        % store the raw calcium traces
        allCaTraces(iRow, iROIStart : iROIEnd, 1 : nFramesEachRow{iRow}) = allCaTracesCell{iRow};
        % store the exclusion masks
        if isempty(allExclMaskCell{iRow}); allExclMaskCell{iRow} = ones(size(allCaTracesCell{iRow})); end;
        allExclMask(iRow, iROIStart : iROIEnd, 1 : nFramesEachRow{iRow}) = allExclMaskCell{iRow};
        % store the stimulus vector and the bit description
        allStims(iRow, 1 : nFramesEachRow{iRow}) = allStimsCell{iRow};
    end;
    
    % check for noisy ROIs
%     noisyStdThresh = 12;
    stdCaTraces = squeeze(nanstd(allCaTraces, [], 3));
    meanStd = nanmean(stdCaTraces(:));
    stdStd = nanstd(stdCaTraces(:));
    noisyStdThresh = meanStd + 2.5 * stdStd;
    o('%s#: mean SD: %.1f, SD of SD: %.1f, threshold: %.1f', mfilename(), meanStd, stdStd, noisyStdThresh, 0, this.verb);
    allCaTraces(repmat(stdCaTraces > noisyStdThresh, [1, 1, nMaxFrames])) = NaN;
    showMessage(this, sprintf('Excluded %02d noisy trials(s).', sum(sum(stdCaTraces > noisyStdThresh))), 'yellow');
    for iROI = 1 : nTotROIs;
        noisyTrialsString = regexprep(sprintf('%02d,', find(stdCaTraces(:, iROI) > noisyStdThresh)), ',$', '');
        if isempty(noisyTrialsString); continue; end;
        showMessage(this, sprintf('Excluded noisy trial(s) %s for ROI%s.', ...
            noisyTrialsString, allROINames{iROI}), 'yellow');
    end;

    % get all stimulus types
    [nTotRows, nTotFrames] = size(allStims); %#ok<NASGU>
    allStimTypeGroups = {};
    for iRow = 1 : nTotRows;
        allStimTypeGroups = unique([allStimTypeGroups regexp(allStimsTypesCell{iRow}, ',', 'split')], 'stable');
    end;
    
    %{
    meanStdCaTraces = nanmean(stdCaTraces);
    close all;
    figure(); plot(meanStdCaTraces);
    figure(); hist(stdCaTraces(:), 0.5 * sqrt(numel(stdCaTraces)));
    figure(); imagesc(stdCaTraces, [0 9]); colorbar(); colormap('hot');
    %}
    
    % store the variables in the cached structure
    cachedData = struct('allCaTraces', allCaTraces, 'allExclMask', allExclMask, 'allStims', allStims, ...
        'allStimsTypesCell', { allStimsTypesCell }, 'allStimTypeGroups', { allStimTypeGroups }, ...
        'allROINames', { allROINames }, 'dataType', 'caTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);

% if data was in memory, fetch it
else
    % fetch the data
    allCaTraces = cachedData.allCaTraces;
    allExclMask = cachedData.allExclMask;
    allStims = cachedData.allStims;
    allStimsTypesCell = cachedData.allStimsTypesCell;
    allStimTypeGroups = cachedData.allStimTypeGroups;
    allROINames = cachedData.allROINames;

end;

%% prepare data
% fetch or extract data from memory
hashStruct.dataType = 'selectedCaTraces';
hashStruct.iDWRows = iDWRows;
hashStruct.selStimTypeGroups = this.an.img.selStimTypeGroups;
hashStruct.selStimIDs = this.an.img.selStimIDs;
hashStruct.selROINames = this.an.img.selROINames;
cachedData = ANGetCachedData(this, 'img', hashStruct);

% if the processed calcium trace data is not in cache yet, create it
if isempty(cachedData);
    
    % get the selected calcium traces, stimulus vectors
    caTraces = allCaTraces(ismember(allIDWRows, iDWRows), :, :);
    exclMask = allExclMask(ismember(allIDWRows, iDWRows), :, :);
    stims = allStims(ismember(allIDWRows, iDWRows), :);
    [nRows, nROIs, nFrames] = size(caTraces); %#ok<ASGLU>

    %% get the list of selected stimulus types
    selStimTypeGroups = this.an.img.selStimTypeGroups;
    % get the indexes of the selected stimulus types
    selStimTypeGroupIndex = find(ismember(allStimTypeGroups, selStimTypeGroups));
    % if none selected, select the first one
    if isempty(selStimTypeGroupIndex);
        selStimTypeGroupIndex = 1;
        selStimTypeGroups = allStimTypeGroups(selStimTypeGroupIndex);
    end;
    
    % get the number of bits to use for all the selected stimuli
    nStimTypeGroups = numel(selStimTypeGroupIndex);
    % get the number of non-empty stimulus IDs for each group
    nStimIDsPerGroup = arrayfun(@(iGroup)sum(~cellfun(@isempty, this.an.img.allStimIDs(selStimTypeGroupIndex(iGroup), :))), 1 : nStimTypeGroups);
    % get the number of possible combinations with all stimulus IDs
    nStimIDCombinations = prod(nStimIDsPerGroup);
    
    % create the stimulus sets to get all combinations
    stimSets = cell(nStimTypeGroups, 1);
    for iGroup = 1 : nStimTypeGroups;
        stimSets{iGroup} = this.an.img.allStimIDs(selStimTypeGroupIndex(iGroup), :);
        stimSets{iGroup}(cellfun(@isempty, stimSets{iGroup})) = []; % remove empty stims
    end;
    
    % get all combinations
    allCombinations = allcomb(stimSets{:});
    allStimTypeIDs = cell(nStimIDCombinations, 1);
    % join them in a single string
    for iComb = 1 : nStimIDCombinations;
        allStimTypeIDs{iComb} = regexprep(sprintf('%s_', allCombinations{iComb, :}), '_$', '');
    end;

    % adapt the stimulus vector
    for iRow = 1 : nRows;

        % get the stimulus vector indices for this row
        stimIndices = find(stims(iRow, :) > 0);
        % get the stimulus vector indices for this row
        stimValues = stims(iRow, stimIndices);
        % reset the stimulus vector
        stims(iRow, stimIndices) = 0;

        % get the stimulus types for this row
        stimTypesForRow = regexp(allStimsTypesCell{iRow}, ',', 'split');
        % if this row has no stimulus type matching with the selected ones, skip
        if ~any(ismember(selStimTypeGroups, stimTypesForRow)); continue; end;
        
        % go through each stimulus
        for iStim = 1 : numel(stimIndices);
            
            % get which stimulus types are true for this stimulus
            stimTypesForStim = '';
            
            % go through all the selected stimulus types
            for iSelStimType = 1 : numel(selStimTypeGroupIndex);
                % store the value extracted from the bits for this stimulus type
                stimBitValue = 0;
                % check which index of the row's stimTypes the current selected stim type is
                stimTypeIndexInRowStimTypes = find(strcmp(selStimTypeGroups(iSelStimType), stimTypesForRow));
                % if it is in the row (index not 0)
                if ~isempty(stimTypeIndexInRowStimTypes);
                    % mark the stimulus with the decoded number from the appropriate bits
                    bitCode = bitget(stimValues(iStim), stimTypeIndexInRowStimTypes);
                    for iBitLoop = 1 : numel(bitCode);
                        stimBitValue = bitset(stimBitValue, iBitLoop, bitCode(iBitLoop));
                    end;
                    % if only one bit was used for the current stimulus type, do a binary encoding
                    if numel(stimSets{iSelStimType}) == 2;
                        % mark the stimuli with either 1 or 2 instead of 0 or 1
                        stimBitValue = stimBitValue + 1;
                        % invert the stimulus coding 1 becomes 2 and 2 becomes 1
                        stimBitValue = iff(stimBitValue == 1, 2, 1);                        
                    end;
                    % if the current bit value is not 0 (stimulus not encoded for this stimulus)
                    if stimBitValue;
                        % add the current stimulus type to the list for this stimulus
                        stimTypesForStim = regexprep(sprintf('%s_%s', stimTypesForStim, stimSets{iSelStimType}{stimBitValue}), '^_', '');
                    end;
                end;
            end;
            
            % get the index of this stimulus based on the stimulus types it had
            stimValue = find(strcmp(stimTypesForStim, allStimTypeIDs));
            stims(iRow, stimIndices(iStim)) = iff(isempty(stimValue), 0, stimValue);

        end;
    end;

    % check whether we only have one type of stimulus
    uniqueStimIndexes = unique(stims(:));
    uniqueStimIndexes(isnan(uniqueStimIndexes) | uniqueStimIndexes == 0) = [];
    allStimTypeIDs = allStimTypeIDs(uniqueStimIndexes);
    
    % get the selected stimulus IDs
    selStimIDs = this.an.img.selStimIDs;    
    % remove the selected stimulus IDs that are not part of the current set of stimulus IDs (allStimTypeIDs)
    selStimIDs(~ismember(selStimIDs, allStimTypeIDs)) = [];
    % if no stimulus ID selected, select them all
    if isempty(selStimIDs); selStimIDs = allStimTypeIDs; end;
    
    % remove non-selected stimuli: find the non-selected stimulus IDs
    toRemoveStimIndexes = find(~ismember(allStimTypeIDs, selStimIDs));
    for iStimToRemove = 1 : numel(toRemoveStimIndexes);
        stims(stims == toRemoveStimIndexes(iStimToRemove)) = 0;
    end;
    
    % re-map the stimulus indexes
    uniqueStimIndexes = unique(stims);
    uniqueStimIndexes(isnan(uniqueStimIndexes) | uniqueStimIndexes == 0) = [];
    oldStims = stims;
    for iStim = 1 : numel(uniqueStimIndexes);
        stims(oldStims == uniqueStimIndexes(iStim)) = iStim;
    end;
    

    %% get the list of selected ROIs
    ROINames = this.an.img.selROINames;
    % get the indexes of the selected ROIs
    selROIs = find(ismember(allROINames, ROINames));
    % if none selected, select all of them
    if isempty(selROIs);
        selROIs = 1 : numel(allROINames);
    end;

    % exclude the ROIs that have no data
    emptyROIs = false(numel(selROIs), 1);
    for iSelROI = 1 : numel(emptyROIs);
        caTracesForROI = caTraces(:, selROIs(iSelROI), :);
        emptyROIs(iSelROI) = ~any(~isnan(caTracesForROI(:)));
    end;
    selROIs(emptyROIs) = [];

    % get the selected calcium traces and ROIs
    caTraces = caTraces(:, selROIs, :);
    exclMask = exclMask(:, selROIs, :);
    ROINames = allROINames(selROIs);

    % apply masking of excluded frames if required
    if strcmp(this.an.img.exclFrames, 'mask');
        caTraces = caTraces .* exclMask;
    end;

    % get the indexing of the ROIs as unique names
    if iRow > 1 && combineROIs;
        [~, ROITrialIndex] = ismember(allROINames(selROIs), unique(allROINames(selROIs)));
        allGroupIDs = get(this, iDWRows, 'ROISet');
    %     allGroupIDs = get(this, iDWRows, 'day');
        uniqueIDs = unique(allGroupIDs);
        rowMatching = arrayfun(@(iRow) find(strcmp(allGroupIDs(iRow), uniqueIDs), 1), 1 : nRows);
        caTracesAll = caTraces;
        caTraces = nan(nRows, numel(unique(ROITrialIndex)), nFrames);
        for iRow = 1 : nRows;
            iGroup = 1;
            for iROI = 1 : numel(selROIs);
                if rowMatching(iRow) == iGroup;
                    caTraces(iRow, ROITrialIndex(iROI), :) = caTracesAll(iRow, iROI, :);
                end;
                if ROITrialIndex(iROI) == max(ROITrialIndex);
                    iGroup = iGroup + 1;
                end;
            end;
        end;
        ROINames = unique(ROINames);
    end;

    %% concatenate the data by putting together all runs:
    [nRows, nROIs, nFrames] = size(caTraces);
    nConcatFrames = nFrames * nRows; % total number of frames in the concatenated data
    % concatenate all the calcium traces and the stimulus vectors in a single vector
    concatCaTraces = nan(nROIs, nConcatFrames);
    concatStims = nan(1, nConcatFrames);
    for iRow = 1 : nRows;
        for iROI = 1 : nROIs;
            concatCaTraces(iROI, (iRow - 1) * nFrames + 1 : iRow * nFrames) = caTraces(iRow, iROI, :);
        end;
        concatStims(1, (iRow - 1) * nFrames + 1 : iRow * nFrames) = stims(iRow, :);
    end;
    
    % store the variables in the cached structure
    cachedData = struct('caTraces', caTraces, 'stims', stims, 'ROINames', { ROINames }, 'concatCaTraces', concatCaTraces, ...
        'concatStims', concatStims, 'selStimIDs', { selStimIDs }, 'selStimTypeGroups', { selStimTypeGroups }, ...
        'allStimTypeIDs', { allStimTypeIDs }, 'dataType', 'selectedCaTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'img', hashStruct, cachedData);

% if data was in memory, fetch it
else
    
    % fetch the data
    caTraces = cachedData.caTraces;
    stims = cachedData.stims;
    ROINames = cachedData.ROINames;
    concatCaTraces = cachedData.concatCaTraces;
    concatStims = cachedData.concatStims;
    selStimTypeGroups = cachedData.selStimTypeGroups;
    allStimTypeIDs = cachedData.allStimTypeIDs;
    selStimIDs = cachedData.selStimIDs;
    
end;
    
% set back the ROINames and stim types in the selection
this.an.img.selROINames = ROINames;
this.an.img.selStimTypeGroups = selStimTypeGroups;
this.an.img.selStimIDs = selStimIDs;

%% update the analysis parameters
% set the stimulus selection in the param. config to be displayed
this.GUI.an.analysisParamConfig{'selStimIDs', 'valueType'} = { allStimTypeIDs };
% set the stimulus types in the param. config to be displayed
this.GUI.an.analysisParamConfig{'selStimTypeGroups', 'valueType'} = { allStimTypeGroups };
% set the ROINames in the param. config to be displayed
this.GUI.an.analysisParamConfig{'selROINames', 'valueType'} = { unique(allROINames) };

o('#%s done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);

end