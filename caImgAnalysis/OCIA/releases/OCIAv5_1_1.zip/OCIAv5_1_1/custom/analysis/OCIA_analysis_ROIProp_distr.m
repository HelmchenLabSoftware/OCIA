function OCIA_analysis_ROIProp_distr(this, iDWRows)

%% plotting parameter UI controls
paramConf = cell2table({ ...
... categ  id                   UIType      valueType               UISize      isLabAbove  label           tooltip
    'img', 'plotLimits',        'text',     { 'array' },            [0.75 0],   false,      'Plot limits',  'Adjust the limits of the plot (color limit).';
    'img', 'ROIRespThresh',     'text',     { 'numeric' },          [0.75 0],   false,      'Resp. thresh.', 'Minimum responsiveness value for a ROI to be included in the analysis.';
%     'img', 'ROINonRespShow',    'dropdown', { 'show', 'hide'},      [0.75 0],   false,      'Non-resp. show', 'Specifies whether to show or hide the non-responsive ROIs.';
    'img', 'ROIProp',           'dropdown', { 'responsiveness', 'response time', 'SI', 'd''' }, ...
                                                                    [0.75 0],   false,      'ROI Prop.',    'Selects which ROI property should be plotted/analyzed.';
    'img', 'groupCurves',       'dropdown', { 'true', 'false' },    [0.75 0],   false,      'Group curves', 'Defines whether to group curves (histogram mode) in a single plot or not.';
    'img', 'ROIPropPlotType',   'dropdown', { 'distribution', 'histogram', 'cumDistr' }, ...
                                                                    [0.75 0],   false,      'Plot type',    'Defines which type of plot should be done: a scatter plot (distribution) or a histogram.';
}, 'VariableNames', this.GUI.an.analysisParamConfig.Properties.VariableNames);
% append the new configuration to the table and update the row names using the ids
this.GUI.an.analysisParamConfig = [this.GUI.an.analysisParamConfig; paramConf];
this.GUI.an.analysisParamConfig.Properties.RowNames = this.GUI.an.analysisParamConfig.id;

%% get the imaging data
ANShowHideMessage(this, 1, 'Loading data ...');
loadDataTic = tic; % for performance timing purposes

% do not combine ROIs
this.an.img.combineROIs = 'false';
this.an.img.averageROI = 'false';
% no sorting
this.an.img.sortMethod = 'none';
this.an.img.sortDirection = 'descending';
this.an.img.sortStim = 'low';

% get the per-stimulus calcium traces
[PSCaTraces, ROINames, stimIDs] = OCIA_analysis_getPSCaTracesMatrix(this, iDWRows);
% get the size of the dataset
[nStimTypes, nStims, nROIs, nPSFrames] = size(PSCaTraces); %#ok<NASGU>

showMessage(this, sprintf('Loading data done (%3.1f sec).', toc(loadDataTic)));

% check data consistency
if nStimTypes + nStims == 2;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot average a single ROI on a single Trial.');
    return;
end;
if nROIs == 1;
    ANShowHideMessage(this, 1, 'Problem during plotting: cannot show this plot for a single ROI.');
    return;
end;

%% prepare data
% get the averaged peri-stimulus traces, the selected ROI names and the time vector
[~, ~, ROIRespTrials, ~, ROINames, ~, ~, ROIRespsTime] = OCIA_analysis_getPSCaTraceMeans(this, iDWRows, PSCaTraces, ROINames, stimIDs);
[nStimTypes, ~, nROIs] = size(ROIRespTrials);
ROIResps = reshape(nanmean(ROIRespTrials, 2), nStimTypes, nROIs);

% if there is a threshold for remove non-responsive ROIs, use it
if ~isempty(this.an.img.ROIRespThresh);
    % get the non-responsive ROIs
    nonRespROIResps = ROIResps < this.an.img.ROIRespThresh;
    % remove them (by setting them to NaN)
    ROIResps(nonRespROIResps) = NaN;
end;

% remove some option from the analysis parameters
this.GUI.an.analysisParamConfig({ 'combineROIs', 'averageROI', 'sortMethod', 'sortDirection', 'sortStim' }, :) = [];

% get the stimulus IDs to use
stimIDs = regexprep(reshape(stimIDs, 1, numel(stimIDs)), '_', ' ');

% select which ROI property to analyse
switch this.an.img.ROIProp;
    
    case 'responsiveness';
        % get the mean responsiveness
        ROIProp = nanmean(ROIResps, 1);
        yLab = sprintf('Responsiveness (%s %%DFF/DRR)', this.an.img.respMethodd';
%         yLab = sprintf('Responsiveness (%s)', stimIDs{1});
        
    case 'response time';
        % get the mean response time
        ROIProp = nanmean(ROIRespsTime, 1);
        yLab = 'Response time (seconds)';
%         yLab = sprintf('Response timing for %s (seconds)', stimIDs{1});
        
    case 'SI';
        % calculate SI
        ROIResps(ROIResps < 0) = 0.001;
        ROIProp = (ROIResps(2, :) - ROIResps(1, :)) ./ (ROIResps(1, :) + ROIResps(2, :));
        yLab = sprintf('SI: %s (neg.) - %s (pos.)', stimIDs{:});
        
    case 'd''';
        % calculate d''
        ROIResps(ROIResps < 0) = 0.001;
        ROIProp = squeeze((nanmean(ROIResps(2, :), 2) - nanmean(ROIResps(1, :), 2)) ...
            ./ sqrt(0.5 * nanstd(ROIResps(1, :), [], 2) .^ 2 + 0.5 * nanstd(ROIResps(2, :), [], 2) .^ 2));
        yLab = sprintf('d'': %s (neg.) - %s (pos.)', stimIDs{:});
    
end;

% get the grouping from ROISet number
grouping = cellfun(@(ROIName)str2double(regexprep(regexp(ROIName, '^RS\d+_', 'match'), '[^\d]', '')), ROINames);
% get the days from the rows and from the ROISet IDs
allDays = regexprep(unique(get(this, iDWRows, 'day')), '_', '');
allROISetsDays = regexprep(unique(get(this, iDWRows, 'ROISet')), '_\d+$', '');
% re-map the grouping using the actual unique days
for iROISetDay = 1 : numel(allROISetsDays);
    grouping(grouping == iROISetDay) = find(strcmp(allROISetsDays{iROISetDay}, allDays));    
end;

% get the group labels phases
allPhases = this.an.img.groupNames;
groupLabels = allPhases(unique(grouping));

% random group labels
% groupLabels = [];

% get if the two groups are significantly different
% [~, p] = ttest2(ROIProp(grouping == 1), ROIProp(grouping == 2));
p = [];

% plot limits
plotLims = this.an.img.plotLimits;
% if isempty(plotLims);
%     plotLims = [-1 1];
% end;

%% plot
plotTic = tic; % for performance timing purposes
switch this.an.img.ROIPropPlotType;
    case 'distribution';
        plotROIPropScatter(this.GUI.handles.an.axe, ROIProp, grouping, groupLabels, p, '', plotLims, yLab, '');
    case 'histogram';
        plotROIPropHist(this.GUI.handles.an.axe, ROIProp, grouping, groupLabels, p, '', plotLims, yLab, '', strcmp(this.an.img.groupCurves, 'true'));
    case 'cumDistr';
        plotROIPropCumDistr(this.GUI.handles.an.axe, ROIProp, grouping, groupLabels, p, '', plotLims, yLab, '', 'dotted95%CIStairs');
end;
o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

        
% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
end
