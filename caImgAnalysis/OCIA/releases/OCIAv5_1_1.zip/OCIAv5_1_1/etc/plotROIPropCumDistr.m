function figHand = plotROIPropCumDistr(axeH, ROIProp, grouping, groupLabels, ~, saveName, plotLimits, xLab, titleString, plotStyle)

%% init
% get the size of the data set
[nStimTypes, ~] = size(ROIProp); %#ok<ASGLU>

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
    axeParent = get(axeH, 'Parent'); %#ok<NASGU>
end;

% get the number of groups
nGroups = numel(unique(grouping));

% general variables
groupCols = jet(nGroups);
% groupCols(1 : 3, :) = jet(3);
% groupCols = [0.2 0.2 0.2; jet(3)];
groupCols(3, :) = [1 0.75 0];

%% plot
hold(axeH, 'on');
% go through each group
plotHandles = zeros(nGroups, 1);
iGroupLoop = 1;
for iGroup = 1 : max(unique(grouping));
    % do not plot not represented groups
    if ~ismember(iGroup, unique(grouping)); continue; end;
    
    [f, x, fLow, fUp] = ecdf(ROIProp(grouping == iGroup));
    switch plotStyle;        
        case 'singleStairs';
            plotHandles(iGroupLoop) = stairs(axeH, x, f, 'LineWidth', 2, 'Color', groupCols(iGroupLoop, :));
        case 'dotted95%CIStairs';
            plotHandles(iGroupLoop) = stairs(axeH, x, f, 'LineWidth', 2, 'Color', groupCols(iGroupLoop, :));
            stairs(axeH, x, fLow, 'LineWidth', 0.5, 'LineStyle', ':', 'Color', groupCols(iGroupLoop, :));
            stairs(axeH, x, fUp, 'LineWidth', 0.5, 'LineStyle', ':', 'Color', groupCols(iGroupLoop, :));
        case 'singleLine';
            plotHandles(iGroupLoop) = plot(axeH, x, f, 'LineWidth', 2, 'Color', groupCols(iGroupLoop, :));
        case 'dotted95%CILine';
            plotHandles(iGroupLoop) = plot(axeH, x, f, 'LineWidth', 2, 'Color', groupCols(iGroupLoop, :));
            plot(axeH, x, fLow, 'LineWidth', 0.5, 'LineStyle', ':', 'Color', groupCols(iGroupLoop, :));
            plot(axeH, x, fUp, 'LineWidth', 0.5, 'LineStyle', ':', 'Color', groupCols(iGroupLoop, :));
        case 'shaded95%CI';
            hStruct = shadedErrorBar(x, f, fUp - fLow, { 'LineWidth', 2, 'Color', groupCols(iGroupLoop, :) }, 1, figHand, axeH);
            plotHandles(iGroupLoop) = hStruct.mainLine;
    end;
    iGroupLoop = iGroupLoop + 1;
end;
hold(axeH, 'off');

% add legend
legend(axeH, plotHandles, groupLabels, 'Location', 'SouthEast', 'Orientation', 'Vertical', 'FontSize', 15);

% adjust the Y limits
if ~isempty(plotLimits);
    set(axeH, 'YLim', plotLimits);
end;


% adjust font size
set(axeH, 'FontSize', 15);

% add labels
xlabel(axeH, xLab, 'FontSize', 15);
ylabel(axeH, 'ROI Fraction', 'FontSize', 15);
% add title
title(axeH, titleString);

%{
% plot the matrix as heat map
imagesc(1 : numel(stimIDs), 1 : nROIs, PSCaTraceMeans', 'Parent', axeH);
% if there are plot limits, apply them
if ~isempty(plotLimits);
    set(axeH, 'CLim', plotLimits);
end;
% change the colormap
colormap(axeH, colorMapName); close(gcf);
% remove ticks
set(axeH, 'XTick', 1 : numel(stimIDs), 'XTickLabel', stimIDs, 'YTick', [], 'FontSize', 15);

% add the color bar on the last axe
hColBar = colorbar('peer', axeH);
set(get(hColBar, 'YLabel'), 'String', colBarLab);

% create the ROI label axe
textAxeH = axes('Parent', axeParent, 'Color', 'blue', 'Position', get(axeH, 'Position'), 'Visible', 'off', ...
    'XLim', get(axeH, 'XLim'), 'YLim', get(axeH, 'YLim'));
% add ROI labels
ROINamesFlipped = flipud(ROINames);
for iROI = 1 : nROIs;
    text(0.5 - numel(stimIDs) / 50, iROI, ROINamesFlipped{iROI}, 'Parent', textAxeH, 'HorizontalAlignment', 'right', ...
        'Interpreter', 'none', 'FontSize', max(min(15 - (0.166 * nROIs), 20), 6));
end;
% link all these axes
linkaxes([axeH, textAxeH], 'y');
% put the label axe at the bottom
restackAxes(textAxeH, 'bottom');
% add title
title(axeH, titleString);

%}

end
