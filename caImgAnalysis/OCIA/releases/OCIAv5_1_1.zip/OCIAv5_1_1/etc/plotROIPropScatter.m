function figHand = plotROIPropScatter(axeH, ROIProp, grouping, groupLabels, pValue, saveName, plotLimits, yLab, titleString)

%% init
% get the size of the data set
[nStimTypes, nROIs] = size(ROIProp); %#ok<ASGLU>

% create the figure
if isempty(axeH);
    figHand = figure('Name', saveName, 'NumberTitle', 'off', 'Color', 'white');
    axeH = axes('Parent', figHand);
else
    figHand = getParentFigure(axeH);
    axeParent = get(axeH, 'Parent'); %#ok<NASGU>
end;

% get the number of groups
uniqueGroups = unique(grouping);
nGroups = numel(uniqueGroups);

%% plot
% xJitter = 0.08;
xJitter = 0.5;
hold(axeH, 'on');

% go through each group
for iGroupLoop = 1 : nGroups;
    % get the group index
    iGroup = uniqueGroups(iGroupLoop);
    
    % get the ROIProp for this group
    ROIPropForGroup = ROIProp(grouping == iGroup);
    nROIsForGroup = numel(ROIPropForGroup);
    
    % plot the points
    scatter(axeH, iGroupLoop * ones(nROIsForGroup, 1) + (rand(nROIsForGroup, 1) - 0.5) * xJitter, ROIPropForGroup, 25, 'ob', 'fill');
    
    % calculate the mean and error
    meanForGroups = nanmean(ROIPropForGroup);
    errorForGroups = nanstd(ROIPropForGroup);

    % plot the mean bars
    meanBarH = plot(axeH, [iGroupLoop - xJitter * 0.5, iGroupLoop + xJitter * 0.5], ones(2, 1) * meanForGroups, 'red', 'LineWidth', 3);
    % plot the error bars
    plot(axeH, ones(2, 1) * iGroupLoop, [meanForGroups - errorForGroups meanForGroups + errorForGroups], 'red', 'LineWidth', 3);

end;

% add legend
hLeg = legend(axeH, meanBarH, 'mean \pm SD');
set(hLeg, 'FontSize', 15);

% adjust the Y limits
if ~isempty(plotLimits);
    set(axeH, 'YLim', plotLimits);
else
    plotLimits = get(axeH, 'YLim');
end;

% add the significance
if ~isempty(pValue);
    sigText = 'n.s.';
    if pValue < 0.001; sigText = sprintf('*** (p = %.5f)', pValue);
    elseif pValue < 0.01; sigText = sprintf('** (p = %.5f)', pValue);
    elseif pValue < 0.05; sigText = sprintf('* (p = %.5f)', pValue);
    end;
    sigBarH = (plotLimits(2) - plotLimits(1)) * 0.05;
    sigBarY = plotLimits(2) - (plotLimits(2) - plotLimits(1)) * 0.1;
    plot(axeH, [1 1 NaN 1 2 NaN 2 2], [sigBarY - sigBarH sigBarY NaN sigBarY sigBarY NaN sigBarY sigBarY - sigBarH], 'Color', 'black', 'LineWidth', 2);
    text(1.5, sigBarY + sigBarH, sigText, 'Parent', axeH, 'FontSize', 15, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
end;


% adjust font size
set(axeH, 'FontSize', 22);

% create group labels if none provided
if isempty(groupLabels);
    groupLabels = regexp(regexprep(sprintf('Group %02d,', 1 : nGroups), ',$', ''), ',', 'split');
end;
set(axeH, 'XTick', 1 : nGroups, 'XTickLabel', groupLabels, 'FontSize', max(min(15 - (0.166 * nGroups), 20), 6));
xlim(axeH, [0.5 nGroups + 0.5]);

% add labels
ylabel(axeH, yLab, 'FontSize', 15);
title(axeH, titleString);

hold(axeH, 'off');

%{
% plot the matrix as heat map
imagesc(1 : numel(stimIDs), 1 : nROIs, PSCaTraceMeans', 'Parent', axeH);
% if there are plot limits, apply them
if ~isempty(plotLimits);
    set(axeH, 'CLim', plotLimits);
end;
% change the colormap
colormap(axeH, colorMapName); close(gcf);
% remove ticks
set(axeH, 'XTick', 1 : numel(stimIDs), 'XTickLabel', stimIDs, 'YTick', [], 'FontSize', 15);

% add the color bar on the last axe
hColBar = colorbar('peer', axeH);
set(get(hColBar, 'YLabel'), 'String', colBarLab);

% create the ROI label axe
textAxeH = axes('Parent', axeParent, 'Color', 'blue', 'Position', get(axeH, 'Position'), 'Visible', 'off', ...
    'XLim', get(axeH, 'XLim'), 'YLim', get(axeH, 'YLim'));
% add ROI labels
ROINamesFlipped = flipud(ROINames);
for iROI = 1 : nROIs;
    text(0.5 - numel(stimIDs) / 50, iROI, ROINamesFlipped{iROI}, 'Parent', textAxeH, 'HorizontalAlignment', 'right', ...
        'Interpreter', 'none', 'FontSize', max(min(15 - (0.166 * nROIs), 20), 6));
end;
% link all these axes
linkaxes([axeH, textAxeH], 'y');
% put the label axe at the bottom
restackAxes(textAxeH, 'bottom');
% add title
title(axeH, titleString);

%}

end
