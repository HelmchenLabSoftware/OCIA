function PSCaTraces = extractPSTrace(caTraces, stims, PSFrames)

% make sure the peri-stimulus frames are specified as a structure
if isnumeric(PSFrames) && numel(PSFrames) == 2;
    PSFrames = struct('base', [-PSFrames(1) 0], 'evoked', [0 PSFrames(2)]);
% make sure the peri-stimulus frames are specified as a structure
elseif isnumeric(PSFrames) && numel(PSFrames) == 4;
    PSFrames = struct('base', [PSFrames(1) PSFrames(2)], 'evoked', [PSFrames(3) PSFrames(4)]);
end;

% get all different stims "indexes"
stimTypes = unique(stims(stims ~= 0 & ~isnan(stims)));

% get the size of the dataset
nTrials = size(caTraces, 1);
nROIs = size(caTraces, 2);
nStims = numel(stimTypes);
% get the peri-stimulus frames' range
PSFramesRange = unique([PSFrames.base(1) : PSFrames.base(2) PSFrames.evoked(1) : PSFrames.evoked(2)]);
nPeriStimFrames = max(PSFramesRange) - min(PSFramesRange) + 1;

% create a nStims x nStims x nROIs x nPeriStimFrames matrix
PSCaTraces = nan(nStims, nTrials * 10, nROIs, nPeriStimFrames);
% go through each ROI and concatenate all repetitions
% parfor iROI = 1 : nROIs;
for iROI = 1 : nROIs;
    % collect relevant data, ignoring empty runs
    concatCaTraces = []; concatStims = [];
    % go trough each repetition
    for iPFTrial = 1 : nTrials;
        if ~isempty(caTraces(iPFTrial, iROI, :)); % ignore empty runs
            concatCaTraces = cat(3, concatCaTraces, caTraces(iPFTrial, iROI, :));
            concatStims = cat(2, concatStims, stims(iPFTrial, :)); %#ok<PFBNS>
        end;
    end;
    % extract the peri-stimulus averages
    PSCaTrace = extractPSTraceSingleTrace(concatCaTraces, concatStims, stimTypes, PSFrames.base, PSFrames.evoked); %#ok<PFBNS>
    % pad with nans
    PSCaTrace = cat(2, PSCaTrace, nan(nStims, nTrials * 10 - size(PSCaTrace, 2), nPeriStimFrames));
    % store in the output structure
    PSCaTraces(:, :, iROI, :) = PSCaTrace;
end

% remove empty trials
emptyTrials = arrayfun(@(iTrial) all(all(all(isnan(PSCaTraces(:, iTrial, :, :))))), 1 : size(PSCaTraces, 2));
PSCaTraces(:, emptyTrials, :, :) = [];

end