%% #OCIA:AN:ANExtractWhiskForRow
function validRow = ANExtractWhiskForRow(this, iDWRow, varargin)

% get the progress fraction
if nargin > 2;  prog = varargin{1};
else            prog = '';
end;

% get the runID
runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});
validRow = true; % default is valid

whiskExtrTic = tic;
o('#ANExtractWhiskForRow(): %s (%02d%s) ...', runID, iDWRow, prog, 3, this.verb);

% extract behavior data if not already extracted
if isempty(this.data.whisk(iDWRow).angle) || all(isnan(isempty(this.data.whisk(iDWRow).angle)));

    % display message
    showMessage(this, sprintf('Extracting whisker data for %s (%02d%s) ...', runID, iDWRow, prog), 'yellow');
    
    % get the experiment number
    expNum = str2double(this.dw.runTable{iDWRow, 9});
    
    % get the path to the correct file
    iWhiskTrackFolderRow = DWFindRunTableRows(this, 'whiskdata', '', '', '', '', '', '');
    parentFolder = DWGetRunTableRowFullPath(this, iWhiskTrackFolderRow);
    filePath = sprintf('%sWhisker_tracking/Experiment_%d_Whisker_Tracking.mat', parentFolder, expNum);
    
    % load the whisker data
    whiskDataMat = load(filePath);
    % store the whisker angle data
    this.data.whisk(iDWRow).angle = whiskDataMat.MovieInfo.AvgWhiskerAngle;
    % store the whisker angle data's frame rate
    this.data.whisk(iDWRow).frameRate = whiskDataMat.MovieInfo.FramesPerSecond;
        
    % display message
    showMessage(this, sprintf('Extracting whisker data for %s (%02d%s) done (%3.1f sec).', runID, iDWRow, ...
        prog, toc(whiskExtrTic)));


end;

end
