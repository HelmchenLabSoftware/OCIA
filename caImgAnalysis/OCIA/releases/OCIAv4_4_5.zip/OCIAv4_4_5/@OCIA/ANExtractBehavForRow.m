%% #OCIA:AN:ANExtractBehavForRow
function validRow = ANExtractBehavForRow(this, iDWRow, varargin)

% get whether to do plots or not
if nargin > 2;  doPlotsYscan = varargin{1}; doPlotsMicr = varargin{1};
else            doPlotsYscan = 0; doPlotsMicr = 0;
end;
% get the progress fraction
if nargin > 3;  prog = varargin{2};
else            prog = '';
end;

% get the runID
runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});
validRow = true; % default is valid

behavExtrTic = tic;
o('#ANExtractBehavForRow(): %s (%02d%s) ...', runID, iDWRow, prog, 3, this.verb);

% extract behavior data if not already extracted
if isempty(this.data.behav(iDWRow).rec);

    % display message
    showMessage(this, sprintf('Extracting behavior data for %s (%02d%s) ...', runID, iDWRow, prog), 'yellow');

    % check whether the run type row is empty, since it is needed to find which behavior file corresponds to this row
    if isempty(this.dw.runTable{iDWRow, 8});
        showWarning(this, 'OCIA:ANExtractBehavForRow:NoRunType', ...
            sprintf('No runType for %s (%d)! Cannot fetch behavior data. Skipping.', runID, iDWRow));
    end;

    %% - #OCIA:AN:ANExtractBehavForRow : behavior data fetch
    % get the behavior out file's index from the run type of this row
    runTypeTrialHits = regexp(this.dw.runTable{iDWRow, 8}, 'B(?<behavOutIndex>\d+)_Trial', 'names');
    
    if isempty(runTypeTrialHits);
        showWarning(this, 'OCIA:ANExtractBehavForRow:NoBehavDataFound', ...
            sprintf('Behavior data for %s (%d) not found.', runID, iDWRow));
        return;
    end;
    % get the behavior file's index
    behavOutIndex = str2double(runTypeTrialHits.behavOutIndex);
    
    if behavOutIndex > size(this.an.behav, 1);
        showWarning(this, 'OCIA:ANExtractBehavForRow:BehavDataNotInMemory', ...
            sprintf('Behavior data for %s (%d) is not in memory anymore.', runID, iDWRow));
        return;
    end;
    out = this.an.behav{behavOutIndex, 4}; % fetch the corresponding out file
    iTrial = str2double(this.dw.runTable{iDWRow, 9}); % fetch the trial number
    
    % fix missing fields
    if isfield(out, 'nTones');
        if numel(out.nTones) > 1;
            nTones = out.nTones(iTrial);
        else
            nTones = out.nTones;
        end;
    else
        nTones = 1;
    end;

    % extract the recorded behavior data from each analog input
    fieldNames = fieldnames(out.record);
    nSamples = size(out.record.(fieldNames{1}){iTrial}, 1);
    bRecData = zeros(size(fieldNames, 1), nSamples);
    for iFieldName = 1 : size(fieldNames, 1);
        bRecData(iFieldName, :) = out.record.(fieldNames{iFieldName}){iTrial};
    end
    this.data.behav(iDWRow).rec = bRecData;
    
    %% - #OCIA:AN:ANExtractBehavForRow : general informations about behavior
    if isfield(out, 'resps'); this.data.behav(iDWRow).resp = out.resps(iTrial); end;
    if isfield(out, 'respTypes'); this.data.behav(iDWRow).respType = out.respTypes(iTrial); end;
    if isfield(out, 'stims'); this.data.behav(iDWRow).stim = out.stims(iTrial); end;
    if isfield(out, 'respDelays'); this.data.behav(iDWRow).respDelay = out.respDelays(iTrial); end;
    if isfield(out, 'times');
        if isfield(out.times, 'respTime'); this.data.behav(iDWRow).respTime = out.times.respTime; end;
        if isfield(out.times, 'rewStart'); this.data.behav(iDWRow).rewTime = out.times.rewStart; end;
    end;
    if isfield(out, 'stims') && isfield(out, 'config') && isfield(out.config, 'tone') && ...
            isfield(out.config.tone, 'goStim');
        this.data.behav(iDWRow).target = double(out.stims(iTrial) == out.config.tone.goStim);
    end;

    %% - #OCIA:AN:ANExtractBehavForRow : delay and true frame rate analysis (yscan)
    if ismember('yscan', fieldNames);
        % extract the number of frames from the microscope's y scanner's position
        yscan = bRecData(strcmp(fieldNames, 'yscan'), :); % extract the y scanner's trace
        normThresh = 3 * std(yscan(1 : 1000)); % take the first 1000 frames for normalization threshold
        yscan(abs(yscan) < normThresh) = 0; % normalize to remove the noise of parts when scanner is not moving
        yscanTopPrctile = prctile(yscan, 80); % set a threshold at the 80th percentile
        yscanTop = find(yscan > yscanTopPrctile); % find all the peaks
        yscanTopDiff = diff(yscanTop); % get the differential of the peaks to find the real peak
        yscanTopDiffPeaks = [find(yscanTopDiff > 1) size(yscanTop, 2)]; % get the peaks
        nFramesBehav = size(yscanTopDiffPeaks, 2); % get the number of frames found using the recording of the y scanner
        nFramesImg = 0; % default: no frames
        % try to get the number of frames from the imaging data: from the extracted traces
        if ~isempty(this.data.img.caTraces{iDWRow});
            nFramesImg = size(this.data.img.caTraces{iDWRow}, 2) + 1; % add 1 frame for the first "skipped" frame
        % try to get the number of frames from the imaging data: from the dimension tag
        elseif ~isempty(this.dw.runTable{iDWRow, 5});
            imgDim = str2dim(this.dw.runTable{iDWRow, 5});
            % add 1 frame for the first "skipped" frame
            if numel(imgDim) < 3;   nFramesImg = 0;
            else                    nFramesImg = imgDim(3) - 1; end;
        end;

        % get the middle part of the frames (20%-80%) to exclude starting and ending artifacts
        middleFrames = round(nFramesBehav * 0.2) : round(nFramesBehav * 0.8);
        % calculate the true frame rate (based on the y position of the scanner)
        if isfield(out, 'anInSampRate'); % if there is a field containing the analog input sampling rate
            anInSampRate = out.anInSampRate;
            % calculate the true frame rate using the inter-peak interval
            trueFrameRate = anInSampRate / mean(diff(yscanTop(yscanTopDiffPeaks(middleFrames))));

        % calculate the true frame rate (based on the y position of the scanner)
        elseif isfield(out, 'anInSampleRate'); % if there is a field containing the analog input sampling rate
            anInSampRate = out.anInSampleRate;
            % calculate the true frame rate using the inter-peak interval
            trueFrameRate = anInSampRate / mean(diff(yscanTop(yscanTopDiffPeaks(middleFrames))));

        % no field containing the analog input rate
        else
            % try to find the sampling rate from the two possible values
            unknownBehavRate = [3000 3333];
            % two possible frame rates
            trueFrameRateOptions = unknownBehavRate / mean(diff(yscanTop(yscanTopDiffPeaks(middleFrames))));
            % find the closest frame rate to the expected frame rate
            [~, closestBehavRateInd] = min(abs(trueFrameRateOptions - 77.67));
            % get analog input sampling rate and the true frame rate corresponding to this closest frame rate
            anInSampRate = unknownBehavRate(closestBehavRateInd);
            trueFrameRate = trueFrameRateOptions(closestBehavRateInd);
            % show a warning for this assumption
            showWarning(this, 'OCIA:ANExtractBehavForRow:NoAnInSampRate', ...
                sprintf(['Missing analog in sample rate for %s (%d)! Assuming it was %d (=> true frame rate: ', ...
                '%.2f Hz).'], runID, iDWRow, anInSampRate, trueFrameRate));
        end;
        
        % get the imaging delay by substract the time of a single frame from the first y scanner peak
        frameLength = round(anInSampRate / trueFrameRate);
        firstFrameEndInd = yscanTop(yscanTopDiffPeaks(1));
        firstFrameStartInd = firstFrameEndInd - frameLength;
        imgDelay = firstFrameStartInd / anInSampRate;

        % store the extracted number: analog input sampling rate, imaging delay and true frame rate
        this.data.behav(iDWRow).behavSampRate = anInSampRate;
        this.data.behav(iDWRow).imgDelays = imgDelay;
        this.data.behav(iDWRow).imgFrameRate = trueFrameRate;
        
        % check whether there is a big frame difference between the imaging and the behavior recording
        nFrameDiff = nFramesBehav - nFramesImg;
        % if there is some imaging data and difference is too big, show a warning
        if nFramesImg && nFrameDiff > 20;
            showWarning(this, 'OCIA:ANExtractBehavForRow:FrameNumberMismatch', ...
                sprintf(['Missing a lot of frames for %s (%d)! Frames from behavior: %d, ' ...
                'from imaging: %d (~= %.1f ms difference).'], runID, iDWRow, nFramesBehav, nFramesImg, ...
                1000 * nFrameDiff / trueFrameRate));
            % exclude this run
            validRow = false;
            return;
        elseif nFramesImg && nFrameDiff < 0;
            showWarning(this, 'OCIA:ANExtractBehavForRow:FrameNumberMismatch', ...
                sprintf(['Frame number mismatch for %s (%d)! Frames from behavior: %d, ' ...
                'from imaging: %d (~= %.1f ms difference).'], runID, iDWRow, nFramesBehav, nFramesImg, ...
                1000 * nFrameDiff / trueFrameRate));
            % exclude this run
            validRow = false;
            return;
        end;        

        if doPlotsYscan > 0; % if requested, plot a figure illustrating the extraction procedure
            figure('Name', sprintf('%s_yscan', runID), 'WindowStyle', 'docked', 'NumberTitle', 'off');
            plot(yscan, 'k');
            title(sprintf('nFramesBehav: %d, nFramesImag: %d', nFramesBehav, nFramesImg));
            hold on;
            yLims = get(gca, 'YLim');
            plot(yscanTop, yscan(yscanTop), 'g');
            plot(yscanTop(1 : end - 1) + 0.5, yscanTopDiff / 100, 'r');
            plot(repmat(firstFrameStartInd, 2, 1), yLims, 'r:');
            scatter(yscanTop(yscanTopDiffPeaks), repmat(0.8, nFramesBehav, 1), 'b*');
        end;
        
    end; % end check yscan exists

    %% - #OCIA:AN:ANExtractBehavForRow : sound start (stimulus time) analysis (micr)
    if ismember('micr', fieldNames);
                
        % extract the stimulus start time and duration from the recorded sound
        micr = linScale(abs(bRecData(strcmp(fieldNames, 'micr'), :))); % extract the microphone's trace
        % get a range for the begining of the signal
        begRange = round(nSamples * 0.01 : nSamples * 0.1);
        % incrementally search for the right threshold
        nStimsDiff = 1; stimYThresh = 0; stimThreshFactor = 5; stimThreshFactorStep = 5; nLoops = 0;      
        while nStimsDiff && stimThreshFactor < 25;
            % get a threshold for the sound onset
            stimThreshFactor = stimThreshFactor + stimThreshFactorStep;
            stimYThresh = stimThreshFactor * std(micr(begRange));
            % get the samples that exceeds the threshold, adding the first sample to catch the start of the first stim
            upSamples = [0 find(micr > stimYThresh)];
            % get the derivative of the upSamples, drops in the sample indexes indicate interruption of upSamples,
            %   which means that there is a stimulus start
            upSamplesDiff = diff(upSamples);
            % use the ISI to find peaks. If no ISI, use 0.5 second
            ISI = out.config.tone.ISI;
            if ISI == 0; ISI = 0.5; end;
            % difference between detected upSample derivative's peaks must be at least half of the ISI
            minISI = ISI * 0.5 * anInSampRate;
            % get the index of the peaks where the derivative exceeds the ISI threshold and increment by one to get
            %   the stimulus start index
            stimStartInds = upSamples(find(upSamplesDiff >= minISI) + 1);

            if ~isempty(stimStartInds);
                % calculate the simulus start time
                stimStartTimes = stimStartInds / anInSampRate;
            else
                stimStartTimes = [];
            end;        

            % check whether there is a big frame difference between the imaging and the behavior recording
            nStimsDiff = abs(nTones - numel(stimStartTimes));
            nLoops = nLoops + 1;
            
        end;
        
        % if there is some imaging data and difference is too big, show a warning
        if nStimsDiff && ~isempty(stimStartTimes);
            showWarning(this, 'OCIA:ANExtractBehavForRow:MissingStim', ...
                sprintf(['Problem with number of stimuli found for %s (%d)! Number of stim detected in recorded ', ...
                'data: %d, expected number of stim: %d. Taking only the first %d stim(s).'], runID, iDWRow, ...
                numel(stimStartTimes), nTones, nTones));
            stimStartTimes = stimStartTimes(1 : nTones);
            doPlotsMicr = doPlotsMicr + 1;
        elseif nStimsDiff;
            showWarning(this, 'OCIA:ANExtractBehavForRow:MissingStim', ...
                sprintf(['Problem with number of stimuli found for %s (%d)! Number of stim detected in recorded ', ...
                'data: %d, expected number of stim: %d.'], runID, iDWRow, numel(stimStartTimes), nTones));
            doPlotsMicr = doPlotsMicr + 1;
        end;
        
        % stimulus vector is all zeros except where the stimulus start
        stimVect = zeros(1, nFramesImg);

        % if there is some imaging data, create the simulus vector
        if nFramesImg && ~isempty(stimStartTimes);
            % get the stimulus time, including the imaging start delay
            stimStartTimesImgReference = stimStartTimes - imgDelay;
            stimStartIndexesImgReference = round(stimStartTimesImgReference * trueFrameRate); % get the stimulus index
            % remove stim start times that are too early
            if any(stimStartIndexesImgReference < 0);
                nRemStims = sum(stimStartIndexesImgReference < 0);
                stimStartIndexesImgReference(stimStartIndexesImgReference <= 0) = [];
                showWarning(this, 'OCIA:ANExtractBehavForRow:EarlyStim', ...
                    sprintf('Removed %d early stimuli found for %s (%d)!', nRemStims, runID, iDWRow));
            end;
            % annotate the stimulus start with the stimulus ID
            stimVect(stimStartIndexesImgReference) = out.stims(iTrial);
            
            % if this is an oddball stimulus, label the last stim as oddball
            if strcmp(out.taskType, 'cotOdd') && ~isempty(stimStartIndexesImgReference);
                oddStim = 1;
                if out.stims(iTrial) == 1; oddStim = 2; end;
                stimVect(stimStartIndexesImgReference(out.oddPos(iTrial))) = oddStim;
            end;
        end;

        % store the extracted items: stimulus duration, start time and stimulus vector
        this.data.behav(iDWRow).stimStartTime = stimStartTimes;
        this.data.img.stim{iDWRow} = stimVect;
        
        if doPlotsMicr > 0; % if requested, plot a figure illustrating the extraction procedure
            figure('Name', sprintf('%s_micr', runID), 'WindowStyle', 'docked', 'NumberTitle', 'off');
            rectangle('Position', [begRange(1) 0 begRange(end) - begRange(1) stimYThresh * 1.1], ...
                'FaceColor', [0.8 1 0.8], 'EdgeColor', [0.8 1 0.8]);
            hold on;
            plot(micr, 'k');
            yLims = get(gca, 'YLim'); xLims = get(gca, 'XLim');
            plot(upSamples(1 : end - 1) - 0.5, (upSamplesDiff / max(upSamplesDiff)) * max(micr) * 0.9, 'r');
            plot(repmat(stimStartInds, 2, 1), repmat(yLims, numel(stimStartInds), 1)', 'r:');
            plot(xLims, repmat(stimYThresh, 2, 1), 'g:');
            title(sprintf('stimYThresh: %.5f, stimStartTimes: %s', stimYThresh, sprintf(' %.2fs', stimStartTimes)));
        end;
        
    end; % end check micr exists
    
    %% - #OCIA:AN:ANExtractBehavForRow : lick begin analysis (piezo)
    if ismember('piezo', fieldNames);
        piezo = bRecData(strcmp(fieldNames, 'piezo'), :); % extract the piezo's trace
%         piezoTresh = [];
        if isfield(out, 'piezoThresh');
            piezoThresh = out.piezoThresh;
        elseif isfield(out, 'params') && isfield(out.params, 'piezoThresh');
            piezoThresh = out.params.piezoThresh;
        else
            showWarning(this, 'OCIA:ANExtractBehavForRow:NoPiezoThresh', ...
                sprintf('Could not find piezo threshold for %s (%d)!', runID, iDWRow));
            piezoThresh = NaN;
        end;
        if isnan(piezoThresh);
            this.data.behav(iDWRow).lickRate = 0;
        else
            this.data.behav(iDWRow).lickRate = preprocLickData({piezo}, piezoThresh * 1.5, anInSampRate, 0);
        end;
    end; % end check piezo exists        

    %{
    %% - #OCIA:AN:ANExtractBehavForRow : lick begin analysis (piezo)
    piezo = bRecData(strcmp(fieldNames, 'piezo'), :); % extract the piezo's trace
    % lickRateBinWidth = out.sampToRec;
    lickYThresh = max(piezo(round(nSamples * 0.01) : round(nSamples * 0.2))) * 2;
    lickStartInd = find(piezo > lickYThresh, 1, 'first');
    lickEndInd = find(piezo > lickYThresh, 1, 'last');
    lickDur = (lickEndInd - lickStartInd) / anInSampRate;
    lickStartTime = lickStartInd / anInSampRate;

    this.data.behav(iDWRow).lickDur(iDWRow) = lickDur;
    this.data.behav(iDWRow).lickStartTime(iDWRow) = lickStartTime;

    if doPlots > 0;
        figure('Name', sprintf('%s_piezo', runID), 'WindowStyle', 'docked', 'NumberTitle', 'off');
        plot(piezo, 'k');
        yLims = get(gca, 'YLim'); xLims = get(gca, 'XLim');
        hold on;
        plot(xLims, repmat(lickYThresh, 2, 1), 'g:');
        if ~isempty(lickDur);
            plot(repmat(lickStartInd, 2, 1), yLims, 'r:');
            plot(repmat(lickEndInd, 2, 1), yLims, 'r:');
            title(sprintf('lickYThresh: %.5f, lickDur: %.4f (%d->%d), lickStartTime: %.4f (%d)', ...
                lickYThresh, lickDur, lickStartInd, lickEndInd, lickStartTime, lickEndInd));
        else
            title(sprintf('lickYThresh: %.5f, no lick detected', lickYThresh));
        end;
    end;
    %}

    % display message
    showMessage(this, sprintf(['Extracting behavior data for %s (%02d%s) done (frames behav: %d, ', ...
        'frames img: %d, nStims: %d, nLoops: %d, %3.1f sec).'], runID, iDWRow, prog, nFramesBehav, ...
        nFramesImg, numel(stimStartTimes), nLoops, toc(behavExtrTic)));


end;

end
