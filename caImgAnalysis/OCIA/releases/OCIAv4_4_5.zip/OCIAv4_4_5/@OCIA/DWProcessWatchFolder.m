%% #OCIA:DW:DWProcessWatchFolder
function DWProcessWatchFolder(this, ~, ~)

watchTic = tic;
o('#DWProcessWatchFolder(): in ''%s''.', this.dw.watchFolder, 4, this.verb);

runTable = cell(100, size(this.dw.runTable, 2));
% only set data if there is a GUI
if isGUI(this); set(this.GUI.handles.dw.runTable, 'Data', runTable); end;
DWWaitBar(this, 0);
showMessage(this, 'Processing watch folder ...', 'yellow');

% create the toKeepWatchTypes structure which defines which file types should be included in the runTable,
%   using the state of the GUI checkboxes
toKeepWatchTypes = DWCreateToKeepWatchTypeStruct(this, 1, 0);

% warn the user that processing the watch folder path flushes all data
if ~this.dw.ignoreDataFlushWarning;
    doFlush = questdlg('Processing the watch folder flushes all loaded data. Continue ?', ...
        '/!\ Warning ! Data flush !', 'Yes', 'No', 'Yes');
    if strcmp(doFlush, 'No'); return; end;
end;
DWFlushData(this, 'all');
DWFlushData(this, [], 'roisets');

% clear the filtering drop-down list
dropDownListFilterNames = this.GUI.dw.filtElems(strcmp(this.GUI.dw.filtElems(:, 2), 'dropdown'), 1);
for iName = 1 : numel(dropDownListFilterNames);
    filtName = dropDownListFilterNames{iName}; % get the filter name
    % create a list with only a dash element, which corresponds to no filtering
    this.dw.([filtName 'IDs']) = {'-'};
end;

% process the watch folder to get the new run table. The filter elements (animal, day, spot) list also get updated.
newRunTable = DWProcessFolder(this, this.dw.watchFolder, '.', '.', '', toKeepWatchTypes, 100);
DWWaitBar(this, 100);

% if new run table is not cell array, processing was interrupted, so stop here with an empty run table
if ~iscell(newRunTable);
    this.dw.runTable = cell(size(this.dw.runTable));
    this.dw.runTable(:) = {''};
    return;
else % otherwise use the processed table as new run table
    this.dw.runTable = newRunTable;
end;

% update the filtering drop-down list
for iName = 1 : numel(dropDownListFilterNames);
    filtName = dropDownListFilterNames{iName}; % get the filter name
    filtH = this.GUI.handles.dw.filt.([filtName 'ID']);
    if get(filtH, 'Value') > numel(this.dw.([filtName 'IDs']));
        set(filtH, 'Value', 1);
    end;
    % make sure the selected object stays selected
    oldStrings = get(filtH, 'String');
    oldSelString = oldStrings(get(filtH, 'Value'));
    
    % populate the drop-down list with the existing list
    set(filtH, 'String', this.dw.([filtName 'IDs']));
    
    % restore the previously selected string if still available
    if ismember(oldSelString, this.dw.([filtName 'IDs']));
        set(filtH, 'Value', find(strcmp(get(filtH, 'String'), oldSelString)));
    else % otherwise just select the first element
        set(filtH, 'Value', 1);
    end;
end;

% correct the 'Name' for '.\.\'
for iRow = 1 : size(this.dw.runTable, 1);
    this.dw.runTable{iRow, 1} = regexprep(this.dw.runTable{iRow, 1}, ' / ./', ' /');
    this.dw.runTable{iRow, 1} = regexprep(this.dw.runTable{iRow, 1}, '\./', '. / ');
end;

% if the runTable was not empty, display the message
nRowsInRunTable = DWDisplayRunTable(this);
if nRowsInRunTable;
    showMessage(this, sprintf('Processed watch folder: %d row(s) (%.1f sec).', nRowsInRunTable, toc(watchTic)));
else
    showMessage(this, sprintf('Processed watch folder: no matching rows found (%.1f sec).', toc(watchTic)));
end;

end
