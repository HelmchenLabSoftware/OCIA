%% #OCIA:AN:ANPlotBehavFrac
function ANPlotBehavFrac(this, selRows)

%% plotting parameter UI controls       
this.GUI.an.plotParamConfig = { ...
};

% get the axe handle where all the plotting elements should be displayed
anAxe = this.GUI.handles.an.axe;

% plotTrialImaged = true;
plotTrialImaged = false;
plotDays = true;
% plotDays = false;

% get the behavior data of the non-empty selected rows
behavDataBool = ~cellfun(@isempty, this.an.runTable(:, 13));
selRowBool = false(size(this.an.runTable, 1), 1);
selRowBool(selRows) = true;
% extract the day, time, spotID and behavior out file for the non-empty selected rows
selBehavData = this.an.runTable(behavDataBool & selRowBool, [1 2 7 13]);

% if any behavior data
if ~isempty(selBehavData);

    % gather all response types and classify behavior files by dates and morning/afternoon sessions
    allRespTypes = [];
    allBehavInds = [];
    allBehavDates = {};
    allNImgTrials = []; % number of imaged trials for each beahvior session
    
    nMinMissToRemove = 3;
%     nMinMissToRemove = 50000;

    fracs = zeros(size(selBehavData, 1), 3);
    daysStrs = cell(size(selBehavData, 1), 1);

    o('#an..atePlot(): gathering info about %d behavior files ...', size(selBehavData, 1), 2, this.verb);
    for iOut = 1 : size(selBehavData, 1);
        respTypes = selBehavData{iOut, 4}.respTypes;
        respTypes = respTypes(~isnan(respTypes));
        nRespTypes = size(respTypes, 2);
        
        if nRespTypes > nMinMissToRemove && all(respTypes(end - nMinMissToRemove + 1 : end) == 4) && ~all(respTypes == 4);
            while nRespTypes && respTypes(end) == 4;
                respTypes(end) = [];
                nRespTypes = size(respTypes, 2);
            end;
        end;
        
        if ~nRespTypes; continue; end;
        
        counts = analyseBehavPerf(respTypes, [], [], 0);        
        fracs(iOut, :) = [0.01 * counts.EARLYP, 0.0001 * counts.TGOP * (100 - counts.EARLYP), ...
            0.0001 * counts.TNGOP * (100 - counts.EARLYP)];
        
        daysStrs{iOut} = datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd');
        dateNumMidDay = datenum([daysStrs{iOut} '__14_00'], 'yyyy_mm_dd__HH_MM');
        dateNumWithHour = datenum(datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd__HH'), 'yyyy_mm_dd__HH');
        if dateNumMidDay > dateNumWithHour; daysStrs{iOut} = regexprep([daysStrs{iOut} 'am'], '_', '');
        else                                daysStrs{iOut} = regexprep([daysStrs{iOut} 'pm'], '_', '');
        end;
        
        %{
        allRespTypes = [allRespTypes respTypes]; %#ok<AGROW>
        allBehavInds = [allBehavInds repmat(iOut, 1, nRespTypes)]; %#ok<AGROW>
        dateStrDay = datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd');
        dateNumMidDay = datenum([dateStrDay '__14_00'], 'yyyy_mm_dd__HH_MM');
        dateNumWithHour = datenum(datestr(unix2dn(selBehavData{iOut, 4}.expStartTime * 1000), ...
            'yyyy_mm_dd__HH'), 'yyyy_mm_dd__HH');
        if dateNumMidDay > dateNumWithHour; dateStrDayWithSess = [dateStrDay '_am'];
        else                                dateStrDayWithSess = [dateStrDay '_pm'];
        end;
        allBehavDates = [allBehavDates, repmat({dateStrDayWithSess}, 1, nRespTypes)]; %#ok<AGROW>

        imgDataRows = DWFindRunTableRows(this, '(imgD|d)ata', '', '', sprintf('B%02d', iOut), '', '', '');
        trialNums = this.dw.runTable(imgDataRows, 9);
        trialImaged = zeros(1, nRespTypes);
        for iTrial = 1 : nRespTypes;
            trialImaged(iTrial) = ismember(sprintf('%02d', iTrial), trialNums);
        end;
        allNImgTrials = [allNImgTrials trialImaged]; %#ok<AGROW>
        %}
    end;
%     
%     h = bar(fracs, 'hist', 'Parent', anAxe);
%     set(h(1), 'FaceColor', ones(3, 1) * 0.8);
%     set(h(2), 'FaceColor', 'green');
%     set(h(3), 'FaceColor', 'red');
    
    h = plot(fracs, 'LineWidth', 5, 'Parent', anAxe);
    set(h(1), 'Color', ones(3, 1) * 0.8);
    set(h(2), 'Color', 'green');
    set(h(3), 'Color', 'red');

    legend(anAxe, { 'Early', 'Hit', 'Miss' });
    set(anAxe, 'XTick', 1 : size(fracs, 1), 'XTickLabel', daysStrs);
    rotateXLabels(anAxe, 30);
    set(anAxe, 'FontSize', 8);
    xlim(anAxe, [1, size(fracs, 1) + 1] - 0.5);
    
    ANShowHideMessage(this, 0, 'Update analyser plot done.');
    
else
    showWarning(this, 'OCIA:ANUpdatePlot:NoBehavDataToPlot', ...
        'No behavior data to plot in selected rows!');
    ANShowHideMessage(this, 1, 'No behavior data to plot in selected rows !');
end;
    
end
