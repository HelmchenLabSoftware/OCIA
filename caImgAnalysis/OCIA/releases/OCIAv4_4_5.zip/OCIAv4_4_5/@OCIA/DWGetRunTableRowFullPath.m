%% #OCIA:DW:DWGetRunTableRowFullPath
function fullPath = DWGetRunTableRowFullPath(this, iRow)

    % get the path and clean it
    parentPath = regexprep(this.dw.runTable{iRow, 1}, '^ ?\. ?/ ?', this.dw.watchFolder);
    parentPath = regexprep(parentPath, '( ?/ ?)?\w+$', '');
    parentPath = regexprep(parentPath, '\s+', ' ');
    parentPath = regexprep(parentPath, ' / ', '/');
    parentPath = regexprep(parentPath, '/\./', '/');
    rowType = DWGetRowType(this, iRow);

    % get the path depending on the row type
    switch rowType;
        
        % imaging data
        case 'imgData';
            
            imgDataFolderPattern = this.dw.watchTypes{strcmp(this.dw.watchTypes(:, 1), 'img'), 6};
            folderName = regexprep(imgDataFolderPattern, '[\^$]', '');
            folderName = regexprep(folderName, '\\\.', '.');
            folderName = regexprep(folderName, '\([?][<]date[>][^\)]+\)', this.dw.runTable{iRow, 2});
            folderName = regexprep(folderName, '\([?][<]time[>][^\)]+\)', this.dw.runTable{iRow, 3});
            if ~isempty(this.dw.runTable{iRow, 9});
                folderName = regexprep(folderName, '\([?][<]exp[>][^\)]+\)', this.dw.runTable{iRow, 9});
            end;
            if ~isempty(this.dw.runTable{iRow, 9});
                folderName = regexprep(folderName, '\([?][<]add[>][^\)]+\)', this.dw.runTable{iRow, 9});
            end;
            fullPath = sprintf('%s/%s/', parentPath, folderName);
            
        % ROISets
        case 'ROISet';
            timeStamp = sprintf('%s__%sh', this.dw.runTable{iRow, 2 : 3});
            fullPath = sprintf('%s/ROISets/ROISet_%s.mat', parentPath, timeStamp);
            
        % joint tracking movies
        case 'trackMovie';
            timeStamp = regexprep(sprintf('%s%s', this.dw.runTable{iRow, 2 : 3}), '_', '');
            searchPath = sprintf('%s/Trial_%s*', parentPath, timeStamp);
            files = dir(searchPath);
            fullPath = sprintf('%s/%s', parentPath, files(1).name);
          
        % fiber tracking movies
        case 'fiberMovie'
            fileName = regexprep(sprintf('%s%s%s%s%s', this.dw.runTable{iRow, 2 : 6}), '_', '');
            searchPath = sprintf('%s/%s*', parentPath, fileName);
            files = dir(searchPath);
            fullPath = sprintf('%s/%s', parentPath, files(1).name);
            
        % ROISets
        case 'ROIs';
            fullPath = sprintf('%s/ROIs/', parentPath);
            
        % whisker data
        case 'whiskdata';
            fullPath = [parentPath '/'];
            
        otherwise
            fullPath = '';
    end;

end