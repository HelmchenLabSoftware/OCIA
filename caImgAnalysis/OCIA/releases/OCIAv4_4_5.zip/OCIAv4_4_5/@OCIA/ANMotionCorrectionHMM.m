%% #OCIA:AN:ANMotionCorrectionHMM
function validRow = ANMotionCorrectionHMM(this, iDWRow, varargin)

validRow = true; % default is valid

% if pre-processing not required or if data was already pre-processed, abort
if ~any(strcmp(this.an.an.preProcOptions, 'moCorr')) || any(strcmp(this.data.preProcType{iDWRow}, 'moCorr'));
    return;
end;

% get whether to do plots or not
if nargin > 2;  doPlots = varargin{1};
else            doPlots = 0;
end;
% get the progress fraction
if nargin > 3;  prog = varargin{2};
else            prog = '';
end;

%% - #OCIA:AN:ANMotionCorrectionHMM: init
moCorrTic = tic;
% get the runID
runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});
runIDTitle = sprintf('Motion correction (HMM) for %s (%d%s)', runID, iDWRow, prog);



% mark row as processed for motion correction
this.data.preProcType{iDWRow} = unique([{'moCorr'}, this.data.preProcType{iDWRow}]);

showMessage(this, sprintf('%s done (%3.1f sec).', runIDTitle, toc(moCorrTic)));

end
