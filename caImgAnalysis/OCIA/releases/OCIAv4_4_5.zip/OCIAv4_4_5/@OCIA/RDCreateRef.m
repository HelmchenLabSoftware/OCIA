%% #OCIA:RD:RDCreateRef
function RDCreateRef(this, ~, ~)

    ON HOLD

    o('#RDCreateRef()', 4, this.verb);
    
    % get the selected runs
    selRuns = get(this.GUI.handles.rd.runSel, 'Value');
    nRuns = numel(selRuns);
    % abort if no selection
    if isempty(selRuns);
        return;
    end;
    
    % determine whether to load all the frames or just the first "couple" as preview
    if get(this.GUI.handles.rd.loadAllFrames, 'Value');
        loadType = 'full';
    else
        loadType = 'prev';
    end;
    
    % go through all runs and check the number of frames the data
    nFramesPerRun = nan(1, nRuns);
    for iRunLoop = 1 : nRuns;
        iRun = selRuns(iRunLoop);
        iDWRow = this.dw.selRunTableRows(iRun); % get the data watcher's row number
        if ~isempty(this.dw.runTable{iDWRow, 5});
            nFramesPerRun(iRunLoop) = str2double(regexprep(this.dw.runTable{iDWRow, 5}, '^\d+x\d+x', ''));
        end;
    end;
    
    % only average 50% of the frames
    nFramesToAveragePerRun = round(nFramesPerRun * 0.5);
    allFrames = zeros(size(this.GUI.rd.img, 1), size(this.GUI.rd.img, 2), sum(nFramesToAveragePerRun));
    
    % go through all runs and load the data
    for iRunLoop = 1 : nRuns;
        iRuns = selRuns(iRunLoop);
        
    end;

end
