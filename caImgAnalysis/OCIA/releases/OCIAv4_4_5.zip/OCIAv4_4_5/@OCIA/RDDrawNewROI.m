%% #OCIA:RD:RDDrawNewROI
function RDDrawNewROI(this, ~, ~)

% get the currently selected drawing tool
currentDrawTool = get(get(this.GUI.handles.rd.drawToolSelGroup, 'SelectedObject'), 'String');

o('#RDDrawNewROI(): current draw tool: %s.', currentDrawTool, 4, this.verb);

switch currentDrawTool;
    case 'Ellipse';
        newROI = imellipse(this.GUI.handles.rd.axe);
    case 'Freehand';
        newROI = imfreehand(this.GUI.handles.rd.axe);
    otherwise;
        showWarning(this, 'OCIA:RDDrawNewROI:UnknownTool', sprintf(...
            '#ROIDrawerImClick(): unknown tool selected: ''%s'' ! Ignoring click.', currentDrawTool));
end;

if isempty(newROI); return; end;

% make sur position is at the right resolution
ROIPos = newROI.getPosition();
ROIClass = class(newROI);
if isa(newROI, 'imfreehand');
    ROIPos = unique(round(ROIPos), 'rows', 'stable');
    delete(newROI);
    newROI = impoly(this.GUI.handles.rd.axe, ROIPos, 'Closed', true);
    newROI.setVerticesDraggable(false);
end;

this.rd.ROIs(end + 1, 1 : 2) = cell(2, 1);
this.rd.ROIs{end, 1} = newROI;
this.rd.nROIs = size(this.rd.ROIs, 1);
if this.rd.nROIs == 1;  this.rd.ROIs{end, 2} = sprintf('%03d', this.rd.nROIs);
else                    this.rd.ROIs{end, 2} = sprintf('%03d', str2double(this.rd.ROIs{end - 1, 2}) + 1);
end;
ROIID = this.rd.ROIs{end, 2};

this.rd.ROIs{end, 1}.addNewPositionCallback(@(h)RDUpdateImage(this, [], [], ROIID));
this.rd.ROIs{end, 3} = ROIPos;
this.rd.ROIs{end, 4} = ROIClass;
this.rd.ROIs{end, 5} = []; % will contain the text handles
this.rd.ROIs{end, 6} = true; % mark as modified/new ROI

RDUpdateGUI(this);

% if in ROICompare mode, give focus to the ROIRename
if get(this.GUI.handles.rd.refROISet, 'Value');
    set(this.GUI.handles.rd.selROIsList, 'Value', numel(get(this.GUI.handles.rd.selROIsList, 'String')));
    RDSelROI(this);
    set(this.GUI.handles.rd.ROIName, 'String', '');
    uicontrol(this.GUI.handles.rd.ROIName);
end;

end
