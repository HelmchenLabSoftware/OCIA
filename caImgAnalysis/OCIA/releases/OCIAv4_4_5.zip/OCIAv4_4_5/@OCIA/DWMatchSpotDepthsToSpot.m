%% - #DWMatchSpotDepthsToSpot
function DWMatchSpotDepthsToSpot(this, day, spotDepths)
    
    % find the spot rows for that day (spot only rows)
    spotRows = DWFindRunTableRows(this, sprintf('%s / spot\\d+$', day), '', '', '', '', '', '');
    
    % if no spot rows where found, try to find reference rows and add the depth information into their comments
    if isempty(spotRows);
        spotRows = DWFindRunTableRows(this, sprintf('%s / spot\\d+', day), '', '', 'Ref', '', '', '');
    end;
    
    % add the depth information into the comments of the rows
    for iSpotLoop = 1 : numel(spotRows);
        iSpot = str2double(regexprep(regexp(this.dw.runTable{spotRows(iSpotLoop), 1}, ...
            'spot\d+', 'match'), 'spot', ''));
        iRow = spotRows(iSpotLoop);
       
        % if spot has a depth and its neither empty nor 0
        if numel(spotDepths) >= iSpot && ~isempty(spotDepths(iSpot)) && spotDepths(iSpot) ~= 0 ...
                && (isempty(this.dw.runTable{iRow, end}) ...
                || isempty(regexp(this.dw.runTable{iRow, end}, '[dD]epth: \d+um', 'once')));
            % append to comment section
            this.dw.runTable{iRow, end} = regexprep(sprintf('%s, depth: %dum', this.dw.runTable{iRow, end}, ...
                spotDepths(iSpot)), '^, d', 'D');
        end;

    end;

end