%% #OCIA:DW:DWFilterRunTable
function DWFilterRunTable(this, filterType)

    %% - DWFilterRunTable: get all the filters
    nFilt = size(this.GUI.dw.filtElems, 1);
    rowSelState = true(1, size(this.dw.runTable, 1));   
    for iFilt = 1 : nFilt;
        filtName = this.GUI.dw.filtElems{iFilt, 1};
        filtType = this.GUI.dw.filtElems{iFilt, 2};
        filtCol = this.GUI.dw.filtElems{iFilt, 4};
        supportsRange = this.GUI.dw.filtElems{iFilt, 5};
        switch filtType;
            case 'dropdown';
                IDs = get(this.GUI.handles.dw.filt.([filtName 'ID']), 'String');
                filtText = IDs{get(this.GUI.handles.dw.filt.([filtName 'ID']), 'Value')};
                if strcmp(filtText, '-'); filtText = ''; end; % '-' means empty
            case 'textfield';
                filtText = get(this.GUI.handles.dw.filt.(filtName), 'String');
                if iscell(filtText); filtText = cell2mat(filtText); end; % make sure we have char not cell
                if supportsRange && ~isempty(regexp(filtText, '[:,]', 'once'));
                    filtRange = [];
                    eval(sprintf('filtRange = [%s];', filtText));
                    filtText = regexprep(sprintf('%02d|', filtRange), '\|$', '');
                end;
        end;
        % special case
        if strcmp(filtName, 'spot') && ~isempty(regexp(filtText, 'spot\d\d', 'once'));
            filtText = regexprep(filtText, 'spot', 'sp');
        end;
        [~, rowSelStateCurrFilt] = DWFindRunTableRowsByCol(this, filtText, filtCol);
        rowSelState = rowSelState & rowSelStateCurrFilt;
    end;
    
    %% - DWFilterRunTable: find the rows
    rows = find(rowSelState);
    
    %% - DWFilterRunTable: select the rows
    switch filterType;
        
        % add the new rows to the existing selection
        case 'add';
            rows = unique([rows this.dw.selRunTableRows]);
        % just select the rows clearing up the previous selection
        case 'new';
            % nothing to do, previous rows will be discarded
    end;
    
    % actually select the rows
    DWSelRunTableRows(this, rows);
    
    showMessage(this, sprintf('Selected %d row(s).', numel(this.dw.selRunTableRows)));

end
