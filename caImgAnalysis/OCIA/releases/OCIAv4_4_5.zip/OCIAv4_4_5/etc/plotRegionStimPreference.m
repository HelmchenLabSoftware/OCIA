function figHandle = plotRegionStimPreference(dimX, dimY, refImgPath, stimIDs, ROISet, saveName, tuningStruct, BSStat, pointSize)
    %Function to plot tuning maps for a set of ROIs. ROIStimPreference with
    %text-strings has to be present as it is used with galvotuninganalysis
    %metrics.
    %
    %Usage: figHandle = plotRegionStimPreference(dimX, dimY, refImgPath, stimIDs, ROISet, saveName, tuningStruct, BSStat, pointSize)
    %
    %Some code adapted from doSaveMaps routine by Balazs
    %
    %Author: A. van der Bourg, 2014
    
    
    %% Init variables
    nStims = size(stimIDs, 1);
    statTypes = unique(strrep(fieldnames(tuningStruct), 'Err', ''));
    iTargetStat = strcmp(statTypes, BSStat);
    tuning = tuningStruct.(statTypes{iTargetStat});
    nROIs = size(tuning,2);
    ROILocs = ROISet(1 : (nROIs - 1), 2);
    %diffMatrix = zeros(1,size(tuning,2));
    %Check if reference image exists
    if ischar(refImgPath);
        imgMat = tiffread2_wrapper(refImgPath);
        refImg = imgMat.data;
    else
        warning('The specified path does not point towards an image');
        return;
    end;
    
    refImg = linScale(reshape(refImg, dimX, dimY, 2));
    figHandle = [];
    %Go through all stimulus combinations and plot preference heatmap
    for xIndex = 1:(nStims-1)
        for yIndex = (xIndex+1):nStims
            hold on;
            
            
            xVal = tuning(xIndex, :);
            yVal = tuning(yIndex, :);
            
            % Small negative values as a result of an inactive, sometimes
            % noisy cell can lead to false tuning properties. Therefore we
            % assign the value of the compared tuningStat, so this tuning
            % candidate gets eliminated.
            for i = 1:size(tuning,2)
                if xVal(i) < 0 && yVal(i) > 0
                    xVal(i) = yVal(i);
                elseif xVal(i) < 0 && yVal(i) < 0
                    xVal(i) = 0;
                    yVal(i) = 0;
                elseif xVal(i) > 0 && yVal(i) < 0
                    yVal(i) = xVal(i);
                end;
            end;  
            
            % Express as normalized ratio of change
            scaledTuningSlopeMatrix = (xVal - yVal) ./ (xVal + yVal);
            
            colorBarTitle = sprintf('Tuning index, %s vs. %s', stimIDs{xIndex, 1}, stimIDs{yIndex, 1});
            figHandle(end+1) = plotROILocHeatMapPoint(scaledTuningSlopeMatrix, [-1 1], refImg, dimX, dimY, ROILocs, saveName, colorBarTitle, pointSize);
            %figHandle(end+1) = plotROILocHeatMapPoint(scaledTuningSlopeMatrix, [min(scaledTuningSlopeMatrix) max(scaledTuningSlopeMatrix)], refImg, dimX, dimY, ROILocs, saveName, colorBarTitle, pointSize);
            title(sprintf('Tuning index, %s vs. %s', stimIDs{xIndex, 1}, stimIDs{yIndex, 1}));
            
        end;
    end;
end

%% Old ideas
            %{
            %Express the ratio as a normalized ratio compared to the overall
            %response (bigger response ratios should be weighted more!)
            for i = 1:size(tuning, 2)
                xValNorm = tuning(xIndex,i)/(abs(sum(tuning(xIndex,:))-tuning(xIndex,i)));
                yValNorm = tuning(yIndex,i)/(abs(sum(tuning(yIndex,:))-tuning(yIndex,i)));
                tuningSlopeMatrix(1,i) = xValNorm ./ yValNorm;
            end;
            %Old alternative
            diffMatrix = xVal - yVal;
            absMaxValue = max(abs(tuningMatrix));
            scaledTuningSlopeMatrix = tuningMatrix / absMaxValue;
            
            % Express tuning as the normalized maximum difference
            %diffMatrix = xVal - yVal;
            %absMaxValue = max(abs(diffMatrix));
            %scaledTuningSlopeMatrix = diffMatrix / absMaxValue;
            
            %}