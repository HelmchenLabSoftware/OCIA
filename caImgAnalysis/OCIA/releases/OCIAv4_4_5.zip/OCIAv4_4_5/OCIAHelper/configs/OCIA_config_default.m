function [this, inputParams] = OCIA_config_default(this)
% OCIA default config file

% define some path
currentDir = regexprep(pwd(), '\\', '/');

%% - input parameters
inputParams = struct();
% defines which start function should be called, refering to a file named 'OCIA_startFunction_[NAME]'
inputParams.startFunctionName = 'default';

%% - properties: general
% verbosity, number telling how much debugging output should be printed out. The higher the more verbose.
this.verb = 2;

%% -- properties: general: paths to relevant locations (raw data, ect.)
this.path = struct();
% path of the raw data (usually stored on the server)
this.path.rawData = currentDir;
% path of the local data
this.path.localData = currentDir;
% path where the OCIA related things should be saved (OCIA object itself, data, plots, etc.)
this.path.OCIASave = currentDir;

%% - properties: GUI
% the different 'modes' of the online calcium imaging assistant
if ~ismember('GUI', fields(this)) || ~isfield(this.GUI, 'modes'); % only create if not already existing
    this.GUI.modes = { 'DataWatcher', 'dw'; 'ROIDrawer', 'rd'; 'Analyser', 'an'; 'Behavior', 'be' };
end;
% check if DataWatcher mode exists
if ~any(strcmp(this.GUI.modes(:, 1), 'DataWatcher')); % DataWatcher mode is obligatory
    this.GUI.modes = [ {'DataWatcher', 'dw'}; this.GUI.modes ];
    warning('OCIA:DataWatcherNotIncluded', '"DataWatcher" mode is obligatory for OCIA to run properly. Added it automatically.');
end;
% initial position of the main window
% this.GUI.pos = [345, 285, 1220, 805];
this.GUI.pos = [1950, 175, 1220, 805];
% option to hide or show any display/window/GUI
this.GUI.noGUI = false;
% properties of GUI elements to save
this.GUI.toSaveProps = { 'String', 'Value' };
% main window's handle (GUI figure)
this.GUI.figH = [];
% structure containing all GUI components' handle
this.GUI.handles = [];
% string to add to saved GUI handle properties in the GUIState structure to identify them as handle
this.GUI.saveHandleTag = '__HANDLE';    

% apply DataWatcher configuration
configHandle = str2func('OCIA_config_datawatcher');
this = configHandle(this);

% apply different modes' configuration
for iMode = 1 : size(this.GUI.modes, 1);
    
    % get the configuration function's name and check if it exists
    modeName = lower(this.GUI.modes{iMode, 1});
    
    % skip DataWatcher mode as it was already processed
    if strcmp(modeName, 'datawatcher'); continue; end;
    
    funcName = sprintf('OCIA_config_%s', modeName);
    if ~exist(funcName, 'file');
        showWarning(this, 'OCIA:ConfigFunctionNotFound', ...
            sprintf('Configuration function "%s" not found, skipping.', funcName));
        continue;
    end;
    
    % call the configuration function with an error catching block
    try
        OCIAConfigFun = str2func(funcName);
        this = OCIAConfigFun(this);
    catch err;        
        showWarning(this, 'OCIA:ConfigFunctionError', ...
            sprintf('Configuration function "%s" run into an error: %s (%s)\n%s.', ...
            funcName, err.message, err.identifier, getStackText(err)));          
    end;
    
end;


end
