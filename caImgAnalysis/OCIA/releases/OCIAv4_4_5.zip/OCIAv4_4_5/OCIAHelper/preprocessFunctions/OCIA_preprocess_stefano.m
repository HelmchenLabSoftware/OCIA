%% #OCIA:OCIA_preprocess_stefano
function runTableRows = OCIA_preprocess_stefano(this, runTableRows, varargin)

preProcRowsTic = tic;

% make sure input argument is not a non-empty cell with empty content
if ~isempty(varargin) && iscell(varargin) && isempty(varargin{1}); varargin = []; end;

% check whether there is a need to create the runTableRows
doCreateRunTable = nargout > 0;

nRows = size(runTableRows, 1); % get the number of rows

% update the waiting bar
nSteps = 5; iStep = 1; p = 0;
DWWaitBar(this, p);
p = 100 * (1 / (nSteps * nRows));

% get the jTable if in GUI mode
if isGUI(this); 
    jTable = getJTable(this, 'DWRunTable');
end;

% initialize the data watcher run table row number
iDWRow = [];
                
% analyse the type of each row
for iRow = 1 : nRows;
    
    preProcSingleRowTic = tic;
    iDWRow = runTableRows{iRow, 11}; % get the current row in the data watcher's run table reference
    rowType = DWGetRowType(this, iDWRow); % get the row type
    % get the runID as "YYYYMMDD_HHMMSS"
    runID = sprintf('%s__%s', this.dw.runTable{iDWRow, 2 : 3});
        
    % process differently depending on the row type
    switch rowType;

        case 'imgData';
        %% - #OCIA:OCIA_preprocess_stefano : imaging data

            dimTag = runTableRows{iRow, 5}; % get the dimension tag
            % if no dimtag from meta-data, try to get dimtag from the notebook
            if isempty(dimTag); dimTag = runTableRows{iRow, 10}; end;
            % get the number of frames
            nFrames = str2double(strrep(regexp(dimTag, 'x\d+$', 'match'), 'x', ''));

            % only process functional movies that have at least "funcMovieNFrames" frames
            if nFrames > this.an.img.funcMovieNFramesLimit;
                
                % create a display text if required
                if doCreateRunTable;
                    runTableRows{iRow, 12} = sprintf('%02d: %s__%s', runTableRows{iRow, [11, 2, 3]});
                end;
                
                %% -- #OCIA:OCIA_preprocess_stefano : imaging data : load/pre-process the data
                validRow = 1; % default is valid
                
                % if extraction of the behavior data is required
                if ~numel(varargin) || ~isempty(regexpi(varargin{1}, 'preProc', 'once'));
                    % extract the behavior data for the row
                    validRow = ANExtractWhiskForRow(this, iDWRow, sprintf(', %02d/%02d', iRow, nRows));
                end;
                % update the waiting bar
                DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));

                % if load the data is required
                if validRow && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'load', 'once'))) ...
                        && isempty(this.data.img.caTraces{iDWRow});
                    % load all frames for the row
                    DWLoadRow(this, iDWRow, 'full', sprintf(', %02d/%02d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));
                end;
                
                % only do pre-processing steps if the caTraces data is not ready set and pre-processing is required
                if validRow && isempty(this.data.img.caTraces{iDWRow}) ...
                        && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'preProc', 'once')));

                    % remove frames with a lot of motion artifacts
                    ANMotionDetection(this, iDWRow, 0, sprintf(', %02d/%02d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));

                    % correct for motion artifacts
                    validRow = ANMotionCorrection(this, iDWRow, 0, sprintf(', %02d/%02d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));
                    
                else
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 2; p = 100 * (iStep / (nSteps * nRows));
                end;

                % if row is not valid, abort and flush data
                if ~validRow;
                    showMessage(this, sprintf('Aborting row %s (%02d).', runID, iDWRow), 'red');
                    DWFlushData(this, iDWRow, 'raw,preproc,img,catraces,whisk');
                    DWWaitBar(this, 100 * (iRow / nRows)); % adjust the wait bar
                    continue;
                end;                

                % if pre-processing is required
                if validRow && (~numel(varargin) || ~isempty(regexpi(varargin{1}, 'preProc', 'once'))) ...
                        && isempty(this.data.img.caTraces{iDWRow});
                    % calculate the dFF/dRR trace for the row
                    ANCalcDRRForRow(this, iDWRow, 0, sprintf(', %02d/%02d', iRow, nRows));
                    % update the waiting bar
                    DWWaitBar(this, p); iStep = iStep + 1; p = 100 * (iStep / (nSteps * nRows));
                end;
                
                if isGUI(this) && exist('jTable', 'var');
                    loadType = this.data.rawLoadType{iDWRow};
                    if isempty(loadType); loadType = 'x'; end;
                    % fill in the state column
                    this.dw.runTable{iDWRow, 17} = sprintf('%s|P', upper(loadType(1)));
                    jTable.setValueAt([this.dw.runTable{iDWRow, 17}], iDWRow - 1, 17 - 1);
                end;
                
            end;
            
        otherwise;
        % otherwise do nothing :-/
        
    end;
    showMessage(this, sprintf('Preprocessing %s (%02d) done (%.1f sec).', runID, iDWRow, toc(preProcSingleRowTic)));
    
    % if required, flush some of the data between the runs to avoid memory overflow
    if ~isempty(this.dw.savedDataToFlushBetweenRuns);
        DWFlushData(this, iDWRow, this.dw.savedDataToFlushBetweenRuns{:});
        loadType = this.data.rawLoadType{iDWRow};
        if isempty(loadType); loadType = 'x'; end;
        % fill in the state column
        this.dw.runTable{iDWRow, 17} = sprintf('%s|P', upper(loadType(1)));
        jTable.setValueAt([this.dw.runTable{iDWRow, 17}], iDWRow - 1, 17 - 1);
    end;
    
end;

% update waiting bar
DWWaitBar(this, 100);

showMessage(this, sprintf('Preprocessing %02d rows done (%.1f sec).', nRows, toc(preProcRowsTic)));

end
