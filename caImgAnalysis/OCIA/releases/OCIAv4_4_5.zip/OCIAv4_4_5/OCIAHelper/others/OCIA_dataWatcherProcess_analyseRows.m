%% #OCIA_dataWatcherProcess_analyseRows
function OCIA_dataWatcherProcess_analyseRows(this, ~, ~)

analyseRowsTic = tic;

% empty/reset the run table, the plot list and the ROI list
set(this.GUI.handles.an.runTable, 'String', [], 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.plotList, 'String', this.an.plotTypes, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.selROIList, 'String', [], 'Value', [], 'ListBoxTop', 1);

% gather information on selected rows in a new run table
runTableRows = this.dw.runTable(this.dw.selRunTableRows, 1 : 10);
% count the number of selected rows
nRows = size(runTableRows, 1);
% if no row selected, select all rows
if nRows == 0;
    DWSelRunTableRows(this, 1 : size(this.dw.runTable, 1));
    runTableRows = this.dw.runTable(this.dw.selRunTableRows, 1 : 10); % get all selected rows
    nRows = size(runTableRows, 1);
end;

% if still no row selected, abort with a warning
if nRows == 0;
    showWarning(this, 'OCIA:OCIA_dataWatcherProcess_analyseRows:NoRows', 'No rows selected.');
    return;
end;

% call the right function
preProcFuncName = ['OCIA_preprocess_' this.dw.preProcessFunctionName];
if ~exist(preProcFuncName, 'file');
    showWarning(this, 'OCIA:OCIA_dataWatcherProcess_analyseRows:ProcessFunctionNameNotFound', ...
        sprintf('Pre-process function "%s" not found, using default.', preProcFuncName));
    preProcFuncName = 'OCIA_preprocess_default';
end;
    
% extend the runTable with 3 columns which will be: { data watcher's run table index, runID-text for listBox display, behavData }
runTableRows(:, 11 : 13) = cell(nRows, 3);
runTableRows(:, 11) = num2cell(this.dw.selRunTableRows); % store the data watcher's run table index
o('#OCIA_dataWatcherProcess_analyseRows(): selected rows (%d): %s', nRows, ...
    sprintf('%d ', this.dw.selRunTableRows), 2, this.verb);

%% - #OCIA_dataWatcherProcess_analyseRows : load/pre-process/analyse selected rows
loadDataTic = tic;
try
    % call the appropriate start function
    preProcFuncHandle = str2func(preProcFuncName);
    runTableRows = preProcFuncHandle(this, runTableRows);
catch err;
    showWarning(this, 'OCIA:OCIA_dataWatcherProcess_analyseRows:error', ...
        sprintf('Process function "%s" run into an error: %s (%s)\n%s.', ...
        preProcFuncName, err.message, err.identifier, getStackText(err))); 
end;

% remove empty rows
runTableRows(cellfun(@isempty, runTableRows(:, 11)), :) = [];
o('#OCIA_dataWatcherProcess_analyseRows(): pre-processing data done (%3.1f sec).', toc(loadDataTic), 2, this.verb);

%% - #OCIA_dataWatcherProcess_analyseRows : prepare analyser panel
% fill in the listBox items of the analyser panel
set(this.GUI.handles.an.runTable, 'String', runTableRows(:, 12), 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.plotList, 'String', this.an.plotTypes, 'Value', [], 'ListBoxTop', 1);

% clear the plot area and show the loading message
ANClearPlot(this);
ANShowHideMessage(this, 1);
OCIAChangeMode(this, 'Analyser');

% reset the lists
set(this.GUI.handles.an.plotList, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.runTable, 'Value', [], 'ListBoxTop', 1);
set(this.GUI.handles.an.selROIList, 'Value', [], 'ListBoxTop', 1);

%% - #OCIA_dataWatcherProcess_analyseRows : plot
plotDataTic = tic;
currPlot = [];
% select a default first plot to display depending on the data type
switch DWGetRowType(this, runTableRows{1, 11});
    case 'imgData';
        currPlot = find(strcmp(this.an.plotTypes, 'ROICaTraces'));
    case 'behavData';
        currPlot = find(strcmp(this.an.plotTypes, 'DPrime'));
end;

% select the first row and the default plot
set(this.GUI.handles.an.runTable, 'Value', 1);
set(this.GUI.handles.an.plotList, 'Value', currPlot);

% save the analysis run table
this.an.runTable = runTableRows;

% do the plot
ANUpdatePlot(this);

o('#OCIA_dataWatcherProcess_analyseRows(): plotting done (%3.1f sec).', toc(plotDataTic), 2, this.verb);
o('#OCIA_dataWatcherProcess_analyseRows(): analyse rows done (%3.1f sec).', toc(analyseRowsTic), 2, this.verb);

end
