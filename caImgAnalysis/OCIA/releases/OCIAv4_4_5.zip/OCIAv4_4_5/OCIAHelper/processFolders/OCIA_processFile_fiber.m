%% #OCIA:DW:OCIA_processFile_fiber
function runTableRow = OCIA_processFile_fiber(this, ~, ~, fileName, parentFolder, ~, ~)

processTic = tic;
o('  #OCIA_processFile_fiber: parentFolder: ''%s'', fileName: ''%s''.', ...
    parentFolder, fileName, 4, this.verb);

runTableRow = cell(1, size(this.dw.runTable, 2)); % create an information row
runTableRow{1, 1} = ' / fiberMovie';

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns
fiberMoviePattern = watchTypePatterns{strcmp(watchTypeIDs, 'fiber')};

% extract date and time from the notebook's file name
regexpHits = regexp(fileName, fiberMoviePattern, 'names');

% if there was a match, fill in the cells 
if ~isempty(regexpHits);
    runTableRow{1, 2} = regexpHits.direction;
    runTableRow{1, 3} = regexpHits.amplitude;
    runTableRow{1, 4} = regexpHits.gluestate;
    runTableRow{1, 5} = regexpHits.viewangle;
    runTableRow{1, 6} = regexpHits.trial;
end;

o('  #OCIA_processFile_fiber: %s done (%3.1f sec).', fileName, toc(processTic), 4, this.verb);

end
