%% #OCIA:DW:OCIA_processFile_trackmovie
function runTableRow = OCIA_processFile_trackmovie(this, ~, ~, fileName, parentFolder, ~, ~)

processTic = tic;
o('  #OCIA_processFile_trackmovie: parentFolder: ''%s'', fileName: ''%s''.', ...
    parentFolder, fileName, 4, this.verb);

runTableRow = cell(1, size(this.dw.runTable, 2)); % create an information row
runTableRow{1, 1} = ' / trackMovie';

watchTypeIDs = this.dw.watchTypes(:, 1); % get all watch type IDs
watchTypePatterns = this.dw.watchTypes(:, 6); % get the watch type patterns
trackmoviePattern = watchTypePatterns{strcmp(watchTypeIDs, 'trackmovie')};

% extract date and time from the notebook's file name
regexpHits = regexp(fileName, trackmoviePattern, 'names');

% if there was a match, fill in the cells 
if ~isempty(regexpHits);
    runTableRow{1, 2} = sprintf('%s_%s_%s', regexpHits.date(1:4), regexpHits.date(5:6), regexpHits.date(7:8));
    runTableRow{1, 3} = sprintf('%s_%s_%s', regexpHits.time(1:2), regexpHits.time(3:4), regexpHits.time(5:6));
% if there was no match, show a warning and leave empty
else
    showWarning(this, 'OCIA:OCIA_processFile_trackmovie:NotebookFileDateTimeMatchFailure', ...
        sprintf('Cannot match date-time to track movie file name: ''%s'' with pattern ''%s''.', ...
        fileName, trackmoviePattern));
end;

o('  #OCIA_processFile_trackmovie: %s done (%3.1f sec).', fileName, toc(processTic), 4, this.verb);

end
