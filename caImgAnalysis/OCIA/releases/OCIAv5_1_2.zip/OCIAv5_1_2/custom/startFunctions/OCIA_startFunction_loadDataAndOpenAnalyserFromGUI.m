%% #OCIA:OCIA_startFunction_loadDataAndOpenAnalyserFromGUI
function OCIA_startFunction_loadDataAndOpenAnalyserFromGUI(this)

%% get all the imaging data
OCIAChangeMode(this, 'DataWatcher');

% get the DataWatcher's GUI handle
dwh = this.GUI.handles.dw;

% save options
this.dw.dataSaveOptionsConfig{'saveGUI',            'defaultOn'} = true;
this.dw.dataSaveOptionsConfig{'overwriteSaveFile',  'defaultOn'} = false;
this.dw.dataSaveOptionsConfig{'procBefSave',        'defaultOn'} = true;
this.dw.dataSaveOptionsConfig{'flushAfterSave',     'defaultOn'} = false;
this.dw.dataSaveOptionsConfig{'HDF5GZip',           'defaultOn'} = false;
this.dw.dataSaveOptionsConfig{'HDF5OverwriteData',  'defaultOn'} = true;
this.dw.dataSaveOptionsConfig{'procDataShowDebug',  'defaultOn'} = false;

% save options
set(dwh.procOptsList, 'Value', []);
set(dwh.SLROptDataList, 'Value', []);
set(dwh.SLROpts.saveGUI, 'Value', 1);

% load GUI
DWLoad(this, sprintf('%sGUI.mat', this.path.OCIASave));

% set the watch types
set(dwh.watchTypes.animal,      'Value', 1);
set(dwh.watchTypes.day,         'Value', 1);
set(dwh.watchTypes.spot,        'Value', 1);
set(dwh.watchTypes.img,         'Value', 1);
set(dwh.watchTypes.notebook,    'Value', 1);
set(dwh.watchTypes.behav,       'Value', 1);
set(dwh.watchTypes.roiset,      'Value', 1);
set(dwh.watchTypes.intrinsic,   'Value', 0);

% set the filters (using the last animal, day, spot)
set(dwh.filt.animalID,          'Value', 1);
set(dwh.filt.dayID,             'Value', 1);
set(dwh.filt.spotID,            'Value', 1);
set(dwh.filt.rowTypeID,         'Value', 1);
set(dwh.filt.dataLoadStatus,    'String', '');
set(dwh.filt.rowNum,            'String', '');
set(dwh.filt.runNum,            'String', '');
set(dwh.filt.all,               'String', 'runType = Trial AND day != 2014_10_25');
pause(0.5); % wait to avoid Java exception
DWFilterSelectTable(this, 'new');

% select data type filters
set(dwh.SLROptDataList,         'Value', find(ismember(get(dwh.SLROptDataList, 'String'), ...
    { 'Calcium traces', 'Stimulus vectors', 'Exclusion masks' }))); 
% load the data from the right file
DWLoad(this, sprintf('%s1410_chronic.h5', this.path.OCIASave));

%% switch to analyser
% set the filters and select the rows
set(dwh.filt.dataLoadStatus,    'String', 'caTraces = full');
DWFilterSelectTable(this, 'new');
% go to analyser mode
OCIA_dataWatcherProcess_analyseRows(this);
    
end  
