%% #OCIA:OCIA_startFunction_discriminator
function OCIA_startFunction_discriminator(this)

    OCIAChangeMode(this, 'Discriminator');
    
end
