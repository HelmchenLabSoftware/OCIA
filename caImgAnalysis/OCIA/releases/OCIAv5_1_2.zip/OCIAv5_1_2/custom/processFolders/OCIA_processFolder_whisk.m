%% #OCIA:DW:OCIA_processFolder_whisk
function tableRow = OCIA_processFolder_whisk(this, tableRow, fullPath, patternName, hits)

processTic = tic; % for performance timing purposes
o('#%s: in "%s", full path: %s.', mfilename, fullPath, 3, this.verb);

% fill in the table's variable that are independant on the match type
% tableRow = set(this, 1, 'path', fullPath,  tableRow);
o('  #%s: %s done (%3.1f sec).', mfilename, fullPath, toc(processTic), 4, this.verb);

end
