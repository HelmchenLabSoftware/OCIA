%% #OCIA:AN:OCIA_analysis_caTraces_whisk
function OCIA_analysis_caTraces_whisk(this, iDWRows)

%% plotting parameter UI controls
paramConf = cell2table({ ...
... categ  id                   UIType      valueType       UISize    isLabAbove    label           tooltip
    'whisk', 'traceScaling',   'text',     { 'numeric' },  [1 0],   false,         'Whisk. scale', 'Whiker traces scaling factor (will be multiplied by the number of ROIs).';
    'img', 'traceTypeToShow',   'dropdown', {{ 'raw only', 'filtered only', 'raw and filtered' }}, ...
                                                            [1 0],   false,         'Trace type',   'Selects which traces are displayed in case of filtering.';    
}, 'VariableNames', this.GUI.an.analysisParamConfig.Properties.VariableNames);
% append the new configuration to the table and update the row names using the ids
this.GUI.an.analysisParamConfig = [this.GUI.an.analysisParamConfig; paramConf];
this.GUI.an.analysisParamConfig.Properties.RowNames = this.GUI.an.analysisParamConfig.id;

%% get the data
% get the concatenated trace (raw and filtered), the stimuli, the selected ROI names and the time vector
[concatCaTraces, concatStims, concatCaTracesSGFilt, ROINames, t] = OCIA_analysis_getConcatCaData(this, iDWRows);
% abort if no traces came out
if isempty(concatCaTraces); return; end;

% get the matrix of the whisker traces
[~, procWhiskTraces] = OCIA_analysis_getWhiskTracesMatrix(this, iDWRows, true);

% extend the whisker traces by one NaN frame at the end to be aligned to the calcium traces
%   (this is also done on the calcium traces)
procWhiskTraces = [procWhiskTraces, nan(size(procWhiskTraces, 1), 1)];

% concatenate the whisker traces
procWhiskTracesConcat = reshape(procWhiskTraces', 1, numel(procWhiskTraces));
% scale the amplitude of the whisking according to the calcium data
procWhiskTracesConcat = linScale(procWhiskTracesConcat, 0, size(ROINames, 1) * this.an.whisk.traceScaling);
% extend the calcium traces with the whisker traces
allTraces = [procWhiskTracesConcat; concatCaTraces];   
allTracesSGFilt = [procWhiskTracesConcat; concatCaTracesSGFilt];
% adapt the ROINames
ROINames = [{'Whisk'}; ROINames];

% create color map
ROIColors = jet(size(ROINames, 1));
ROIColors(ROIColors > 0.4) = 0.4;
ROIColors(1, :) = [1 0 0];

% get the stimulus IDs to use
stimIDs = this.an.img.selStimIDs;
stimIDs = regexprep(reshape(stimIDs, 1, numel(stimIDs)), '_', ' ');

%% plot
ANShowHideMessage(this, 1, 'Plotting ...');
plotTic = tic; % for performance timing purposes

% plot the data depending on the selected trace type to show
if strcmp(this.an.img.traceTypeToShow, 'raw and filtered');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', allTraces, allTracesSGFilt, concatStims, stimIDs, ROINames, t, t, ROIColors);
elseif strcmp(this.an.img.traceTypeToShow, 'filtered only');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', allTracesSGFilt, [], concatStims, stimIDs, ROINames, t, [], ROIColors);
elseif strcmp(this.an.img.traceTypeToShow, 'raw only');
    plotCaTraces(this.GUI.handles.an.axe, 0, '', allTraces, [], concatStims, stimIDs, ROINames, t, [], ROIColors);
else
    ANShowHideMessage(this, 0, sprintf('Unknown trace type option: "%s". Cannot plot.', this.an.img.traceTypeToShow));
end;

o('#%s: plot done (%3.1f sec).', mfilename(), toc(plotTic), 2, this.verb);

% hide the message and show plot
ANShowHideMessage(this, 0, 'Update analyser plot done.');


end
