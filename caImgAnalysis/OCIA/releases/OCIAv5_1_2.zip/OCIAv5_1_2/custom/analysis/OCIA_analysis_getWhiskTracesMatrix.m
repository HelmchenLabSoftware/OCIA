function [whiskTraces, procWhiskTraces] = OCIA_analysis_getWhiskTracesMatrix(this, iDWRows, doDownSampling)

totalTic = tic; % for performance timing purposes

%% general plotting parameter UI controls
if ~ismember('procMethod', this.GUI.an.analysisParamConfig.id);
        paramConf = cell2table({ ...
...     categ       id                      UIType      valueType       UISize  isLabAbove
...         label              tooltip
        'whisk',    'procMethod', 'dropdown', {{ 'raw', 'enveloppe' }}, [1 0],  false, ...
            'Whisk. proc.',    'Select which whisker trace processing type should be used.';
        'whisk',    'envWinSize', 'text', { 'numeric' },                [1 0],  false, ...
            'Whisk. env.',    'Fraction of the number of frames to use as window size for the enveloppe calculation.';
            
    }, 'VariableNames', this.GUI.an.analysisParamConfig.Properties.VariableNames);
    % append the new configuration to the table and update the row names using the ids
    this.GUI.an.analysisParamConfig = [this.GUI.an.analysisParamConfig; paramConf];
    this.GUI.an.analysisParamConfig.Properties.RowNames = this.GUI.an.analysisParamConfig.id;    
end;


%% fetch or extract data
ANShowHideMessage(this, 1, 'Loading raw whisker traces ...');
% get the data in memory
hashStruct = struct('iDWRows', iDWRows, 'doDownSampling', doDownSampling, 'dataType', 'whiskTraces');
cachedData = ANGetCachedData(this, 'whisk', hashStruct);

% if the raw calcium traces matrix is not in cache yet, create it
if isempty(cachedData) || iscell(cachedData);
    
    % get the (eventually down-sampled) whisker traces matrix for the requested rows
    whiskTraces = OCIA_analysis_getRawWhiskTracesMatrix(this, iDWRows, doDownSampling);
    
    % store the variables in the cached structure
    cachedData = struct('whiskTraces', whiskTraces, 'dataType', 'whiskTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'whisk', hashStruct, cachedData);

% if data was in memory, fetch it
else
    % fetch the data
    whiskTraces = cachedData.whiskTraces;

end;

%% prepare data
ANShowHideMessage(this, 1, 'Loading processed whisker traces ...');
% fetch or extract data from memory
hashStruct.dataType = 'procWhiskTraces';
hashStruct.procMethod = this.an.whisk.procMethod;
hashStruct.envWinSize = this.an.whisk.envWinSize;
cachedData = ANGetCachedData(this, 'whisk', hashStruct);

% if the processed calcium trace data is not in cache yet, create it
if isempty(cachedData) || iscell(cachedData);
    
    % get the processed whisker traces and count the number of rows
    procWhiskTraces = whiskTraces;
    nRows = size(procWhiskTraces, 1);

    % apply different processing steps to the whisker traces
    switch this.an.whisk.procMethod;
        
        % nothing to do, use the raw whisker traces
        case 'raw';
            
        
        % get the enveloppe of the whiskers using a maximum sliding window
        case 'enveloppe';
            
            % get the window size factor
            envWinSize = this.an.whisk.envWinSize;
            % loop through each row and calculate the enveloppe
            parfor iRow = 1 : nRows;
                % calculate the envelope
                whiskTrace = procWhiskTraces(iRow, :);
                nWhiskFrames = numel(whiskTrace); %count the frames
                winSize = round(nWhiskFrames * envWinSize); % use a fraction of frames window size
                whiskTraceEnv = zeros(1, nWhiskFrames);
                for iFrame = 1 : nWhiskFrames;
                    r = iFrame - winSize : iFrame + winSize;
                    r(r < 1 | r > nWhiskFrames) = [];
                    whiskTraceEnv(iFrame) = max(whiskTrace(r));
                end;
                procWhiskTraces(iRow, :) = whiskTraceEnv;
            end;
            
            
        case 'OTHER_OPTIONS';
            % other options can be implemented here. To make them appear in the dropdown-menu of the GUI,
            %   add them to the line 10 of this file.
            
    end;
    
    % store the variables in the cached structure
    cachedData = struct('procWhiskTraces', procWhiskTraces, 'dataType', 'procWhiskTraces', 'params', hashStruct);
    % store the data in memory
    ANStoreCachedData(this, 'whisk', hashStruct, cachedData);

% if data was in memory, fetch it
else
    
    % fetch the data
    procWhiskTraces = cachedData.procWhiskTraces;
    
end;

o('#%s done (%3.1f sec).', mfilename(), toc(totalTic), 2, this.verb);

end