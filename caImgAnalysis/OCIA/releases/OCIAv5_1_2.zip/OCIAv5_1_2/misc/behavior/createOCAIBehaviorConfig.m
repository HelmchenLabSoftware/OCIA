
% load previous config
load('C:\Users\laurenczy\Documents\LabVIEW Data\mainConf.mat');

%% basic stuff
TDTSampFreq = 97656.25;
standardSampFreq = 44100;

COTUniqueFreqs_4To21kHz_25freqs = 4000 * (2 .^ (((1 : 25) - 1) * (0.1))); % used for chronic_1402
COTUniqueFreqs_4To32kHz_25freqs = 4000 * (2 .^ (((1 : 25) - 1) * (2 ^ -3))); % use for chronic_1406-1410
COTUniqueFreqs_5To40kHz_24freqs = 5000 * (2 .^ (((1 : 24) - 1) * (2 ^ -3))); % alternative
COTUniqueFreqs_5To20kHz_33freqs = 5000 * (2 .^ (((1 : 33) - 1) * (2 ^ -4))); % alternative
COTUniqueFreqs_4To16kHz_33freqs = 4000 * (2 .^ (((1 : 33) - 1) * (2 ^ -4))); % use for chronic_1502

%% stim matrices
o('Generating stim matrices ...', 0, 0);

% 50 trials, 1 as start
stimTypes = [1 2]; stimSize = 50; blockSize = 10; maxConsec = 3; nSeqs = 10; seqStart = 1; plotMatrix = 0;
try
    stimMatrix_50stim_10block_3max_10seq_1start = configs.behavior.cotDiscr.CA1.tone.stimMatrix; % 1 as start
    stimMatrix_50stim_10block_3max_10seq_2start = configs.behavior.cotDiscr.CA2.tone.stimMatrix; % 2 as start
catch e;
end; 
if ~exist('stimMatrix_50stim_10block_3max_10seq_1start', 'var');
    stimMatrix_50stim_10block_3max_10seq_1start = genStimMatrix(stimTypes, stimSize, blockSize, maxConsec, nSeqs, ...
        seqStart, plotMatrix);
end;
% 50 trials, 2 as start
if ~exist('stimMatrix_50stim_10block_3max_10seq_2start', 'var');
    stimMatrix_50stim_10block_3max_10seq_2start = stimMatrix_50stim_10block_3max_10seq_1start;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 1) = 3;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 2) = 1;
    stimMatrix_50stim_10block_3max_10seq_2start(stimMatrix_50stim_10block_3max_10seq_2start == 3) = 2;
end;
o('Generating stim/nTones matrices 1 / 4 done.', 0, 0);

% 30 trials, 1 as start
stimSize = 30; plotMatrix = 0;
try stimMatrix_30stim_10block_3max_10seq_1start = configs.behavior.cotDiscr.AA.tone.stimMatrix;
catch e; end;
if ~exist('stimMatrix_30stim_10block_3max_10seq_1start', 'var');
    stimMatrix_30stim_10block_3max_10seq_1start = genStimMatrix(stimTypes, stimSize, blockSize, maxConsec, nSeqs, ...
        seqStart, plotMatrix);
end;
o('Generating stim/nTones matrices 2 / 4 done.', 0, 0);

% 30 trials, only 1s or 2s
stimSize = 30;
stimMatrix_30stim_10block_1sOnly = ones(stimSize, blockSize);
stimMatrix_30stim_10block_2sOnly = 2 * ones(stimSize, blockSize);
% 30 trials, 1 as start
stimSize = 50;
stimMatrix_50stim_10block_1sOnly = ones(stimSize, blockSize);
stimMatrix_50stim_10block_2sOnly = 2 * ones(stimSize, blockSize);
o('Generating stim/nTones matrices 3 / 4 done.', 0, 0);

stimTypes = 6 : 10; stimSize = 50; seqStart = []; plotMatrix = 0;
try nTones_50stim_10block_3max_10seq = configs.behavior.cotOdd.A.tone.nTonesMatrix;
catch e; end;
if ~exist('nTones_50stim_10block_3max_10seq', 'var');
    nTones_50stim_10block_3max_10seq = genStimMatrix(stimTypes, stimSize, blockSize, maxConsec, nSeqs, seqStart, ...
        plotMatrix);
end;
o('Generating stim/nTones matrices 3 / 4 done.', 0, 0);

%% - configs: animals
configs.animals = { ...
    '150217_01',    'cotDiscr',     'QW';   ... low target (1)
    '150217_02',    'cotDiscr',     'QW';   ... high target (2)
    '150217_03',    'cotDiscr',     'QW';   ... low target (1)
    '150217_04',    'cotDiscr',     'QW';   ... high target (2)
    '150217_05',    'cotDiscr',     'QW';   ... low target (1)
    '150217_06',    'cotDiscr',     'QW';   ... high target (2)
    '150217_07',    'cotDiscr',     'QW';   ... low target (1)
    'testing',      'cotDiscr',     'QW';   ...
    'testing',      'cotDiscr',     'AA1';   ...
    'testing',      'cotDiscr',     'AA2';   ...
    'testing',      'cotDiscr',     'AB1';   ...
    'testing',      'cotDiscr',     'AB2';   ...
    'testing',      'cotDiscr',     'AC1';   ...
    'testing',      'cotDiscr',     'AC2';   ...
    'testing',      'cotDiscr',     'BA1';   ...
    'testing',      'cotDiscr',     'BA2';   ...
    'testing',      'cotDiscr',     'BB1';   ...
    'testing',      'cotDiscr',     'BB2';   ...
};

%% - configs: behavior: cloud of tones discrimination base config
% - configs: behavior: cloud of tones discrimination QW (quiet wakefulness)
s.tone.samplingFreq = TDTSampFreq;
s.tone.toneDur = 0.03;
s.tone.toneISI = 0.01;
s.tone.stimDur = 0.5; % half second sound
s.tone.uniqueFreqs = COTUniqueFreqs_4To32kHz_25freqs;
s.tone.cloudDispersion = 2; % narrow cloud
s.tone.freqIndexes = [10 26];
s.tone.freqs = s.tone.uniqueFreqs(s.tone.freqIndexes);
s.tone.goStim = []; % no go stim
s.tone.stimProba = [];
s.tone.nTones = 1;
s.tone.ISI = 0;
s.tone.stimProba = [];
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
s.training.nTrials = 50;
s.training.startDelay = 3;
s.training.startDelayRand = 1;
s.training.minRespTime = 0;
s.training.maxRespTime = 0;
s.training.rewCollTime = 0;
s.training.rewDur = 0;
s.training.timeoutPunish = 0;
s.training.endDelay = 10;
sBase = s;
configs.behavior.cotDiscr.QW = s;

% - configs: behavior: cloud of tones discrimination A (learn to lick)
s.training.nTrials = 30;
s.training.minRespTime = 5;
respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
s.training.rewCollTime = 2;
s.training.rewDur = 0.02;
s.training.timeoutPunish = 0;
    % -- 3-sec end delay version
    s.training.endDelay = 3;
        % --- low cloud version
        s.tone.goStim = 1; % low cloud is the target
        s.tone.stimMatrix = stimMatrix_30stim_10block_1sOnly;
        configs.behavior.cotDiscr.AA1 = s;
        % --- high cloud version
        s.tone.stimMatrix = stimMatrix_30stim_10block_2sOnly;
        s.tone.goStim = 2; % high cloud is the target
        configs.behavior.cotDiscr.AA2 = s;
    % -- longer end delay version
    s.training.endDelay = 5;
        % --- low cloud version
        s.tone.goStim = 1; % low cloud is the target
        s.tone.stimMatrix = stimMatrix_30stim_10block_1sOnly;
        configs.behavior.cotDiscr.AB1 = s;
        % --- high cloud version
        s.tone.stimMatrix = stimMatrix_30stim_10block_2sOnly;
        s.tone.goStim = 2; % high cloud is the target
        configs.behavior.cotDiscr.AB2 = s;
    % -- 50 trials version
        % --- low cloud version
        s.tone.goStim = 1; % low cloud is the target
        s.tone.stimMatrix = stimMatrix_50stim_10block_1sOnly;
        configs.behavior.cotDiscr.AC1 = s;
        % --- high cloud version
        s.tone.stimMatrix = stimMatrix_50stim_10block_2sOnly;
        s.tone.goStim = 2; % high cloud is the target
        configs.behavior.cotDiscr.AC2 = s;
      
% - configs: behavior: cloud of tones discrimination B (shorter sound-lightCue time interval)
    % -- shorter sound-lightCue time interval
    s.training.minRespTime = 4;
    respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
        % --- low cloud version
        s.tone.goStim = 1; % low cloud is the target
        s.tone.stimMatrix = stimMatrix_50stim_10block_1sOnly;
        configs.behavior.cotDiscr.BA1 = s;
        % --- high cloud version
        s.tone.stimMatrix = stimMatrix_50stim_10block_2sOnly;
        s.tone.goStim = 2; % high cloud is the target
        configs.behavior.cotDiscr.BA2 = s;
    % -- even shorter sound-lightCue time interval
    s.training.minRespTime = 3;
    respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
        % --- low cloud version
        s.tone.goStim = 1; % low cloud is the target
        s.tone.stimMatrix = stimMatrix_50stim_10block_1sOnly;
        configs.behavior.cotDiscr.BB1 = s;
        % --- high cloud version
        s.tone.stimMatrix = stimMatrix_50stim_10block_2sOnly;
        s.tone.goStim = 2; % high cloud is the target
        configs.behavior.cotDiscr.BB2 = s;

% - configs: behavior: cloud of tones discrimination C (discrimination)
s.training.timeoutPunish = 8;
s.training.minRespTime = 3;
respTime = 2; s.training.maxRespTime = s.training.minRespTime + respTime;
    % --- low cloud version
    s.tone.goStim = 1; % low cloud is the target
    s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
        configs.behavior.cotDiscr.CA1 = s;
    % --- high cloud version
    s.tone.goStim = 2; % high cloud is the target
    s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_2start;
        configs.behavior.cotDiscr.CA2 = s;

%% - configs: behavior: cloud of tones oddball
s = sBase;
s.tone.uniqueFreqs = COTUniqueFreqs_4To32kHz_25freqs;
s.tone.cloudDispersion = 2; % narrow cloud
s.tone.freqIndexes = [6 11];
s.tone.freqs = s.tone.uniqueFreqs(s.tone.freqIndexes);
s.tone.goStim = [];
s.tone.nTonesMatrix = nTones_50stim_10block_3max_10seq;
s.tone.nTones = unique(s.tone.nTonesMatrix);
s.tone.ISI = 0.6;
s.tone.stimMatrix = stimMatrix_50stim_10block_3max_10seq_1start;
s.training.nTrials = 50;
configs.behavior.cotOdd.A = s;

%% - configs: hardware
configs.hardware.H30 = struct();

configs.hardware.H30.adaptorID = 'ni';

configs.hardware.H30.analogIn.piezo.deviceName = 'BehaviorBox';
configs.hardware.H30.analogIn.piezo.channel = 'ai0';
configs.hardware.H30.analogIn.piezo.range = [-1 1];
configs.hardware.H30.analogIn.piezo.inputType = 'SingleEnded';

configs.hardware.H30.analogIn.micr.deviceName = 'BehaviorBox';
configs.hardware.H30.analogIn.micr.channel = 'ai1';
configs.hardware.H30.analogIn.micr.range = [-10 10];
configs.hardware.H30.analogIn.micr.inputType = 'SingleEnded';

configs.hardware.H30.analogIn.yscan.channel = 'ai2';
configs.hardware.H30.analogIn.yscan.deviceName = 'BehaviorBox';
configs.hardware.H30.analogIn.yscan.range = [-10 10];
configs.hardware.H30.analogIn.yscan.inputType = 'SingleEnded';

% configs.hardware.H30.analogIn.motion.deviceName = 'ExtraChannels';
% configs.hardware.H30.analogIn.motion.channel = 'ai0';
% configs.hardware.H30.analogIn.motion.range = [-10 10];
% configs.hardware.H30.analogIn.motion.inputType = 'SingleEnded';

configs.hardware.H30.digitalOut.valve.deviceName = 'BehaviorBox';
configs.hardware.H30.digitalOut.valve.portLine = 'Port0/Line0';
configs.hardware.H30.digitalOut.valve.defaultState = 1;

configs.hardware.H30.digitalOut.airPuff.deviceName = 'BehaviorBox';
configs.hardware.H30.digitalOut.airPuff.portLine = 'Port0/Line1';
configs.hardware.H30.digitalOut.airPuff.defaultState = 1;

configs.hardware.H30.analogOut.spoutPos.deviceName = 'BehaviorBox';
configs.hardware.H30.analogOut.spoutPos.range = [0 5];
configs.hardware.H30.analogOut.spoutPos.channel = 'ao0';

configs.hardware.H30.analogOut.imagTTL.deviceName = 'BehaviorBox';
configs.hardware.H30.analogOut.imagTTL.range = [0 5];
configs.hardware.H30.analogOut.imagTTL.channel = 'ao1';


% save configs
save('C:\Users\laurenczy\Documents\programming\Work\PhD\matlab\caImgAnalysis\OCIA\misc\behavior\mainConf.mat', 'configs');
save('C:\Users\laurenczy\Documents\LabVIEW Data\mainConf.mat', 'configs');
