%% #BESaveOutput
function BESaveOutput(this)

showMessage(this, 'Saving output...', 'red');
out = this.be;
out.sampToRec = this.be.hw.sampToRec;
out.anInSampRate = this.be.hw.anInSampRate;
out.anOutSampRate = this.be.hw.anOutSampRate;
out.anInFilt = this.GUI.be.anInFilt;
out.anInDoAbs = this.GUI.be.anInDoAbs;

removeFields = {'anInData', 'toneArray', 'hw', 'configLoaded', 'logDateFormat'};
for iRemField = 1 : size(removeFields, 2);
    fieldName = removeFields{iRemField};
    if isfield(out, fieldName); out = rmfield(out, fieldName); end;
end;

saveFolder = sprintf('%s/behav/', this.path.behavSave);
if exist(saveFolder, 'dir') ~= 7; mkdir(saveFolder); end;
save(out.savePath, 'out');
showMessage(this, 'Output saved.');

end

