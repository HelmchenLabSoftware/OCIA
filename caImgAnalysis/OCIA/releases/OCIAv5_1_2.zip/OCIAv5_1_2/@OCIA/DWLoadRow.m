%% #OCIA:DW:DWLoadRow
function DWLoadRow(this, iDWRow, loadType)
% get the row's ID
rowID = DWGetRowID(this, iDWRow);

o('#DWLoadRow(): loading %s (%03d) (loadType: %s) ...', rowID, iDWRow, loadType , 4, this.verb);

% get the row type's ID: go through all watch types
rowTypeID = DWGetRowTypeID(this, iDWRow);
% if no row type ID, abort
if isempty(rowTypeID); return; end;

% call the custom load function
OCIAGetCallCustomFile(this, 'loadData', rowTypeID, 1, { this, iDWRow, loadType }, false);

% update the row's loading and processing status
DWGetUpdateDataLoadStatus(this, iDWRow);

end
