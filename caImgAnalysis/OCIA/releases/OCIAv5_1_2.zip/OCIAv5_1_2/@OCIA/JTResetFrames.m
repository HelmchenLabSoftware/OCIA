%% #OCIA:JT:JTResetFrames
function JTResetFrames(this, ~, ~)

% reset frames and display message
this.jt.frames = this.jt.oriFrames;
showMessage(this, 'Frames reset.');

% set the focus to the frame setter
uicontrol(this.GUI.handles.jt.frameSetter);

end
