%% #BEEndTrial
function BEEndTrial(this, RP)

%% - #BEEndTrial: stop tasks
% stop TDT
if ~isempty(RP);
    RP.Halt;
    delete(RP);
end;

% stop analog input
if this.be.hw.anIn.IsRunning;
    this.be.hw.anIn.stop();
end;


%% stop video recording
r = java.awt.Robot();
r.keyPress(java.awt.event.KeyEvent.VK_ALT);
pause(0.1);
r.keyPress(java.awt.event.KeyEvent.VK_TAB);
r.keyRelease(java.awt.event.KeyEvent.VK_TAB);
r.keyRelease(java.awt.event.KeyEvent.VK_ALT);
pause(0.1);
r.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);
r.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);
destroy();
clear('runtime r');

%% - #BEEndTrial: record end time
iTrial = this.be.iTrial;
this.be.times.end(iTrial) = nowUNIXSec - this.be.times.start(iTrial);
o('Times:end: %.4f', this.be.times.end(iTrial), 3, this.verb);

%% - #BEEndTrial: stop imaging
BEImagingTTL(this, 0); % make sure imaging is stopped
BESpoutPos(this, 0); % make sure spout is low

BEUpdatePerformance(this);

% store the recorded and eventually filtered data
for iAnIn = 1 : size(this.be.hw.analogIns, 2);
    anInName = this.be.hw.analogIns{iAnIn};
    anInData = this.be.anInData.(anInName);
    filtSize = this.GUI.be.anInFilt(iAnIn);
    if filtSize && ~isempty(anInData);
        if mod(filtSize, 2) == 0; filtSize = filtSize + 1; end;
        anInData = sgolayfilt(anInData, 1, filtSize);
    end;
    this.be.record.(anInName){iTrial} = anInData;
end;

end

