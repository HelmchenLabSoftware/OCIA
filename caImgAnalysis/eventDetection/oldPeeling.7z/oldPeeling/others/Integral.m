function handles = Integral(handles)
% calculates both cumulative integral and derivative of the Ca trace

% set to 1 if calling this program on its own (plots will be generated)
doPlot = 0;

ca_trace = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
ca_amp = handles.sim_pars.ca_amp;
ca_tau = handles.sim_pars.ca_tau / 1000;

handles = SchmittTrig(handles);
schmitt3 = handles.data.schmitt3;

% force all values to be positive (set smallest value to 0)
ca_trace = ca_trace - min(ca_trace);

dff_int = cumtrapz(time_axis,ca_trace);
dff_grad = gradient(ca_trace);

handles.data.dff_int = dff_int;
handles.data.dff_grad = dff_grad;

% estimate AP numbers for each Schmitt3 segment
integral_matrix = zeros(1,4);
segment_no = 0;
toggle = 0;
for n = 1:numel(schmitt3)
    if schmitt3(n) == 1 && toggle == 0
        % beginning of segment
        toggle = 1;
        segment_no = segment_no + 1;
        integral_matrix(segment_no,1) = dff_int(n);
    elseif schmitt3(n) == 0 && toggle == 1
        % end of segment
        toggle = 0;
        integral_matrix(segment_no,2) = dff_int(n-1);
    end
end
% difference between integral at end and beginning of segment
integral_matrix(:,3) = integral_matrix(:,2) - integral_matrix(:,1);
% AP estimate (usually somewhat underestimated, so we use ceil
% function)
if ~segment_no
    warning('No segment detected based on schmitt3');
    integral_matrix(:,4) = NaN;
else
    integral_matrix(:,4) = ceil(integral_matrix(:,3) ./ (ca_amp*ca_tau));
end
for n = 1:size(integral_matrix,1)
    fprintf('\nDetected %s APs in segment %s',...
        int2str(integral_matrix(n,4)),int2str(n));
    if integral_matrix(n,4) < 0
        warning('Number of APs is smaller 0! Forcing 0 AP in segment.');
        integral_matrix(n,4) = 0;
    end
end
fprintf('\n');

% make a nice cell array
for n = 1:size(integral_matrix,1)
    rows{n,1} = sprintf('segment %s',int2str(n));
end
columns = {'' 'Int1' 'Int2' 'Int2-Int1' 'APs'};
ones_rows = ones(1,size(integral_matrix,1));
ones_cols = ones(1,size(integral_matrix,2));
integral_matrix = mat2cell(integral_matrix,ones_rows,ones_cols);
integral_matrix = [rows integral_matrix];
integral_matrix = [columns; integral_matrix];
handles.data.ap_stats = integral_matrix;

if ~doPlot
    return
end

% Plot data
plot_data{1,1} = ca_trace;
plot_data{1,2} = dff_int;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{1,2} = 'dff\_int';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
    'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');


% e.o.f.



