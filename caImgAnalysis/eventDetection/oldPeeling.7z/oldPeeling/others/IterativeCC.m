function handles = IterativeCC(handles)
% in1 ... handles structure

% check if all args really needed
dff = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
ca_amp = handles.sim_pars.ca_amp;
ca_tau = handles.sim_pars.ca_tau / 1000;
smooth_alg = handles.sim_pars.smooth_alg;
windowSize = handles.sim_pars.windowSize;

% max. number of iterations during coarse search
max_iters = 50000;
% correlation threshold for entering fine search
% overridden later on (only largest value chosen)
sim_thresh = 0.9;
% radius for fine search
search_radius = 5;
% similarity measure ('cc' for correlation or 'rmse' for root mean squared
% error
% we try to find the model with highest similarity (i.e. largest
% correlation or smallest rmse)
% for easier coding, minimum is always found, so that for cc-analysis we
% deal with -cc
sim_measure = 'rmse';

doLinePlot = 1;
doSurfPlot = 0;
handles = SchmittTrig(handles);
schmitt3 = handles.data.schmitt3;
% detect events based on Schmitt trigger
events = 0;
events_vect = zeros(size(schmitt3));
state = 0;
for n = 1:length(schmitt3)
    if schmitt3(n) == 1 && state == 0
        state = 1;
        events = events + 1;
        events_vect(n) = events;
    elseif schmitt3(n) == 0 && state == 1
        state = 0;
    elseif schmitt3(n) == 1 && state == 1
        events_vect(n) = events;
    end
end
fprintf('\nDetected %s events based on schmitt3\n',int2str(events));
handles = Integral(handles);
ap_stats = handles.data.ap_stats;
% run iterative correlation for each event
for current_event = 1:events
    ap_no = ap_stats{current_event+1,5};
    fprintf('\nNow processing segment %s with %s APs\n',...
        int2str(current_event),int2str(ap_no));
    event_trace = dff(events_vect==current_event);
    event_time_axis = 0.1:0.1:length(event_trace)/10;

    % place ap_no spikes into the spike train, perform convolution and measure
    % similarity
    % subsequent APs spread randomly
    % collect model and similarity in cell array
    vector_list = cell(max_iters,2);
    sim_list = zeros(max_iters,ap_no+1);
    for iter = 1:max_iters
        if iter == 1
            fprintf('\nRunning coarse search iterations .');
        elseif ~rem(iter,max_iters/20)
            fprintf(' .');
        end
        %         fprintf('\nIteration %s\n',int2str(iter));
        spike_train = zeros(size(event_trace));
        for n = 1:ap_no
            while true
                ap_pos = ceil(rand*length(spike_train));
                if spike_train(ap_pos) == 0
                    spike_train(ap_pos) = 1;
                    break
                end
            end
        end
        model = ca_amp*exp(-time_axis/ca_tau);
        model = conv(spike_train,model);
        model(length(event_trace)+1:end) = [];
        % smooth model
        if ~strcmp(smooth_alg,'none')
            model = SmoothModel(smooth_alg,event_time_axis,model,...
                windowSize);
        end
        if strcmp(sim_measure,'cc')
            % fast cc function (mex)
            cc = prcorr2(event_trace,model);
            sim_list(iter,1) = -cc;
        elseif strcmp(sim_measure,'rmse')
            rmse = sqrt(mean((event_trace-model).^2));
            sim_list(iter,1) = rmse;
        end
        sim_list(iter,2:(ap_no+1)) = find(spike_train==1);
        vector_list{iter,1} = spike_train;
        vector_list{iter,2} = model;
        clear model
    end
    if strcmp(sim_measure,'cc')
        fprintf('\nLargest correlation (coarse search): %s\n',...
            num2str(-min(sim_list(:,1))));
    elseif strcmp(sim_measure,'rmse')
        fprintf('\nSmallest root mean squared difference (coarse search): %s\n',...
            num2str(min(sim_list(:,1))));
    end
    sim_thresh = min(sim_list(:,1));
    for n = 1:size(sim_list,1)
        if sim_list(n,1) == sim_thresh
            disp('Max. similarity detected at:');
            disp(sim_list(n,2:end));
            break
        end
    end
    best_spike = vector_list{find(sim_list==min(sim_list(:,1))),1};
    best_model = vector_list{find(sim_list==min(sim_list(:,1))),2};
    best_spike(best_spike==0) = NaN;
    best_spike(best_spike==1) = min(event_trace);
    
    if doLinePlot
        if strcmp(sim_measure,'cc')
            title_string = sprintf('Event %s (%s AP) r=%s',int2str(current_event),...
                int2str(ap_no),num2str(-min(sim_list(:,1)),2));
        elseif strcmp(sim_measure,'rmse')
            title_string = sprintf('Event %s (%s AP) rmse=%s',...
                int2str(current_event),int2str(ap_no),...
                num2str(min(sim_list(:,1)),2));
        end
        figure('Name',title_string,'NumberTitle','off');
        hold on
        plot(event_time_axis,event_trace);
        plot(event_time_axis,best_model,'g');
        plot(event_time_axis,best_spike,'k','Marker','+','MarkerSize',4);
        legend('Ca trace','best model (coarse)',...
            'best spikes (coarse)');

        hold off
    end

    % plot results as surface plots for the 2D case
    %     if ap_no == 2 && doSurfPlot
    %         figure
    %         cc_matrix = zeros(max(cc_list(:,2)),max(cc_list(:,3)));
    %         for n = 1:size(cc_list,1)
    %             cc_matrix(cc_list(n,2),cc_list(n,3)) = cc_list(n,1);
    %         end
    %
    %         [rows,cols] = meshgrid(1:size(cc_matrix,1),1:size(cc_matrix,2));
    %
    %         % interpolate grid
    %         [rowsI,colsI] = meshgrid(1:0.5:size(cc_matrix,1),...
    %             1:0.5:size(cc_matrix,2));
    %         cc_matrixI = interp2(rows,cols,cc_matrix',rowsI,colsI);
    %         meshc(rowsI,colsI,cc_matrixI);
    %     end
    
    peak_no = 0;
    sim_list_peaks = zeros(size(sim_list));
    for n = 1:size(sim_list,1)
        if sim_list(n,1) <= sim_thresh
            peak_no = peak_no + 1;
            sim_list_peaks(peak_no,:) = sim_list(n,:);
            break
        end
    end
    sim_list_peaks(peak_no+1:end,:) = [];
    clear sim_list vector_list
    if ~peak_no
        fprintf('\nNo points with similarity higher than %s found during coarse search!!!\n',...
            num2str(sim_thresh));
        fprintf('Increase the number of iterations\n');
        return
    end
    disp('Now starting fine tuning. This may take some time.');
    % matrix with ap_no dimensions and size of length(event_trace) in each
    % dimension
%     dim_vector = zeros(1,ap_no);
%     dim_vector(dim_vector==0) = numel(event_trace);
    % this loop reduces the size of each dimension to what is actually
    % needed based on the max. index where APs are located
%     for n = 1:numel(dim_vector)
%         dim_vector(n) = max(sim_list_peaks(:,n+1))+search_radius;
%     end
%     sim_matrix_peaks = zeros(dim_vector); % this can get very large
%     sim_matrix_peaks(sim_matrix_peaks==0)=sim_thresh+10;
%     for n = 1:size(sim_list_peaks,1)
%         index = sim_list_peaks(n,2:end);
%         idx_string = 'sim_matrix_peaks(';
%         for m = 1:numel(index)
%             if m == 1
%                 idx_string = sprintf('%s%s',idx_string,num2str(index(m)));
%             else
%                 idx_string = sprintf('%s,%s',idx_string,num2str(index(m)));
%             end
%         end
%         current_sim = sim_list_peaks(n,1);
%         idx_string = [idx_string ') = current_sim;'];
%         eval(idx_string);
%     end
    sim_list_fine = zeros(size(sim_list_peaks,1)*100,ap_no+1);
    vector_list_fine = cell(size(sim_list_peaks,1)*100,2);
    counter = 1;
    % reformat into vector so that we can iterate over all entries
%     sim_vect_peaks = reshape(sim_matrix_peaks,1,numel(sim_matrix_peaks));
%     sim_matrix_peaks_size = size(sim_matrix_peaks);
    
    total_elements = 1;
    for n = 2:size(sim_list_peaks,2)
        total_elements = total_elements.*...
            (max(sim_list_peaks(:,n))+search_radius);
    end
    if size(sim_list_peaks,1) > 1
        matrix_size_vector = max(sim_list_peaks(:,2:end))+search_radius;
    else
        matrix_size_vector = (sim_list_peaks(1,2:end))+search_radius;
    end
    hit = 0;
    for n = 1:total_elements
        ap_times = ind2sub_ap_gui(matrix_size_vector,n);
        for list_row = 1:size(sim_list_peaks,1)
            if sim_list_peaks(list_row,2:end) == ap_times
                hit = 1;
            end
        end
        if hit == 1
            %         if sim_vect_peaks(n) <= sim_thresh
            hit = 0;
            % calculate matrix subscript for vector point
            sub_ind = ind2sub_ap_gui(matrix_size_vector,n);
            for m = 1:total_elements
                if n == m
                    continue
                end
                current_sub_ind = ind2sub_ap_gui(matrix_size_vector,m);
                % calculate distance between current point and point with
                % high similarity
                Z = sub_ind - current_sub_ind;
                d = sqrt(Z*Z');
                if d <= search_radius
                    spike_train = zeros(size(event_trace));
                    % recalculate model and similarity for this point
                    for spike = 1:numel(current_sub_ind)
                        spike_train(current_sub_ind(spike)) = 1;
                    end
                    model = ca_amp*exp(-time_axis/ca_tau);
                    model = conv(spike_train,model);
                    model(length(event_trace)+1:end) = [];
                    % smooth model
                    if ~strcmp(smooth_alg,'none')
                        model = SmoothModel(smooth_alg,event_time_axis,model,...
                            windowSize);
                    end
                    if strcmp(sim_measure,'cc')
                        % fast cc function (mex)
                        cc = prcorr2(event_trace,model);
                        if -cc < sim_thresh
                            sim_list_fine(counter,1) = -cc;
                            sim_list_fine(counter,2:end) = current_sub_ind;
                            vector_list_fine{counter,1} = spike_train;
                            vector_list_fine{counter,2} = model;
                            counter = counter + 1;
                        end
                    elseif strcmp(sim_measure,'rmse')
                        rmse = sqrt(mean((event_trace-model).^2));
                        if rmse < sim_thresh
                            sim_list(iter,1) = rmse;
                            sim_list_fine(counter,2:end) = current_sub_ind;
                            vector_list_fine{counter,1} = spike_train;
                            vector_list_fine{counter,2} = model;
                            counter = counter + 1;
                        end

                    end
                    clear model
                end
            end
        end
    end
    if counter > 1
        fprintf('\nFound %s points with higher similarity in fine search\n',...
            int2str(counter-1));
    else
        disp('Fine search did not improve results of coarse search');
        return
    end
%     clear sim_vect_peaks
    sim_list_fine(counter:end,:) = [];
    vector_list_fine(counter:end,:) = [];
    max_sim_fine = min(sim_list_fine(:,1));
    for n = 1:size(sim_list_fine,1)
        if sim_list_fine(n,1) == max_sim_fine
            max_idx = sim_list_fine(n,2:end);
        end
    end
    if strcmp(sim_measure,'cc')
        fprintf('\nLargest correlation (fine search): %s\n',...
            num2str(-max_sim_fine));
    elseif strcmp(sim_measure,'rmse')
        fprintf('\nSmallest root mean squared difference (fine search): %s\n',...
            num2str(max_sim_fine));
    end
    fprintf('detected at %s\n\n',num2str(max_idx));

    best_spike = vector_list_fine{find(sim_list_fine==min(sim_list_fine(:,1))),1};
    best_model = vector_list_fine{find(sim_list_fine==min(sim_list_fine(:,1))),2};
    best_spike(best_spike==0) = NaN;
    best_spike(best_spike==1) = min(event_trace);
    if doLinePlot
        if strcmp(sim_measure,'cc')
        title_string = sprintf('Event %s (%s AP) r=%s',int2str(current_event),...
            int2str(ap_no),num2str(-min(sim_list_fine(:,1)),2));
        elseif strcmp(sim_measure,'rmse')
            title_string = sprintf('Event %s (%s AP) rmse=%s',int2str(current_event),...
            int2str(ap_no),num2str(min(sim_list_fine(:,1)),2));
        end
        figure('Name',title_string,'NumberTitle','off');
        hold on
        plot(event_time_axis,event_trace);
        plot(event_time_axis,best_model,'g');
        plot(event_time_axis,best_spike,'k','Marker','+','MarkerSize',4);
        legend('Ca trace','best model (fine)','best spikes (fine)');
        hold off
    end

    % plot results as surface plots for the 2D case
    %     if ap_no == 2 && doSurfPlot
    %         figure
    %         cc_matrix = zeros(max(cc_list_fine(:,2)),max(cc_list_fine(:,3)));
    %         for n = 1:size(cc_list_fine,1)
    %             cc_matrix(cc_list_fine(n,2),cc_list_fine(n,3)) = cc_list_fine(n,1);
    %         end
    %
    %         [rows,cols] = meshgrid(1:size(cc_matrix,1),1:size(cc_matrix,2));
    %
    %         % interpolate grid
    %         [rowsI,colsI] = meshgrid(1:0.5:size(cc_matrix,1),1:0.5:size(cc_matrix,2));
    %         cc_matrixI = interp2(rows,cols,cc_matrix',rowsI,colsI);
    %         meshc(rowsI,colsI,cc_matrixI);
    %     end

end

end

function model = SmoothModel(method,event_time_axis,model,windowSize)

if strcmp(method,'moving average')
    % 1. Moving average
    method = 'moving';
    span = windowSize * 10;
    model = smooth(event_time_axis,model,span,method);
elseif strcmp(method,'local regression')
    % 2. Local regression using weighted linear least squares
    method = 'lowess';
    span = windowSize / event_time_axis(length(event_time_axis));
    model = smooth(event_time_axis,model,span,method);
elseif strcmp(method,'robust local regression')
    % 3. robust local regression (slow)
    method = 'rlowess';
    span = windowSize / event_time_axis(length(event_time_axis));
    model = smooth(event_time_axis,model,span,method);
end


end


% e.o.f.


