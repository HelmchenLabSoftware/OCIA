function results = oopsi_SpikeRecon(varargin)

% this file written by Henry Luetcke (hluetck@gmail.com)

% force analysis of whole trace (even if startStop is provided)
doFullTrace = 1;

if nargin
    for n = 1:nargin
       config{n} = varargin{n};
       id{n} = inputname(n);
    end
else
    vars = evalin('base','who');
    [var_no status] = listdlg('PromptString','Select variables:',...
        'ListString',vars,'ListSize',[300 400]);
    if status
        for n = 1:length(var_no)
            config{n} =  evalin('base',vars{var_no(n)});
            id{n} = vars{var_no(n)};
        end
    else
        return
    end
end

pos = 1;
duration = 0;
results = zeros(length(config),10);
roc_mat = zeros(length(config),2);
for n = 1:length(config)
    current_exp = config{n};
    freq_ca = current_exp.freq_ca;
    freq_ap = current_exp.freq_ap;
    dff = current_exp.roi_dff_trace;
    [dur,time_ca] = gui_CalculateTimeVector(dff,freq_ca,[]);
    spikes = current_exp.ephys;
    [dur,time_ap] = gui_CalculateTimeVector(spikes,freq_ap,[]);
    spikes_bin = BinariseSpikeTrain(spikes,freq_ap);
    handles.sim_pars.freq_ap = freq_ap;
    handles.sim_pars.freq_ca = freq_ca;
    if isfield(current_exp,'ca_shift')
       handles.ca_shift = current_exp.ca_shift; 
    end
    handles.id = id{n};
    if ~isfield(current_exp,'startStop')
        if ~doFullTrace
            fprintf('\nExperiment %s\n',id{n});
            response = input('No startStop field. Full analysis (y/n)? ','s');
            switch lower(response)
                case 'y'
                    startStop = [0 max(time_ca)];
                otherwise
                    continue
            end
        end
    else
        startStop = current_exp.startStop;
    end
    if doFullTrace || isempty(startStop)
        startStop = [0 max(time_ca)];
    end
    for m = 1:size(startStop,1)
        [val,startPosCa] = min(abs(time_ca-startStop(m,1)));
        [val,stopPosCa] = min(abs(time_ca-startStop(m,2)));
        [val,startPosAP] = min(abs(time_ap-time_ca(startPosCa)));
        [val,stopPosAP] = min(abs(time_ap-time_ca(stopPosCa)));
        handles.data.denoised_dff = dff(startPosCa:stopPosCa);
        handles.data.spikes = spikes(startPosAP:stopPosAP);
        handles.data.spikes_bin = spikes_bin(startPosAP:stopPosAP);
        handles.data.filtered_dff = smooth(handles.data.denoised_dff,...
            7,'sgolay',2);
        duration = duration + (startStop(2) - startStop(1));
        [handles,results(pos,:)] = fast_oopsi_wrapper(handles);
        roc_mat(pos,1) = results(pos,3) / results(pos,1); % true positive rate
        roc_mat(pos,2) = results(pos,5) / results(pos,2); % false positive rate
        pos = pos + 1;
    end
end

sum_res = nansum(results,1); mean_res = nanmean(results,1);

fprintf('\nSpikes observed / predicted: %s / %s\n',int2str(sum_res(1)),...
    int2str(sum_res(2)));
fprintf('Correct / Missed / False: %s / %s / %s\n',int2str(sum_res(3)),...
    int2str(sum_res(4)),int2str(sum_res(5)));
fprintf('Mean dt: %s\n',num2str(mean_res(6)));

% sensitivity index
dprime = roc_mat(:,1) - roc_mat(:,2);
[h,p,ci,stats] = ttest(dprime);
fprintf('Detection sensitivity d'': %1.4f (+- %1.4f SEM, t=%1.4f p=%1.4f)\n',...
    mean(dprime),sem(dprime),stats.tstat,p);

% single AP
fprintf('\n1AP\n');
fprintf('1AP observed: %s\n',int2str(sum_res(7)));
fprintf('Correct / Missed: %s / %s\n',int2str(sum_res(8)),...
    int2str(sum_res(9)));
fprintf('Mean dt: %s\n',num2str(mean_res(10)));


% fprintf('1AP observed / Correct / Missed: %s / %s / %s\n',int2str(sum_res(6)),...
%     int2str(sum_res(7)),int2str(sum_res(8)));
% fprintf('2AP observed / Correct / Missed: %s / %s / %s\n',int2str(sum_res(9)),...
%     int2str(sum_res(10)),int2str(sum_res(11)));
% fprintf('3AP observed / Correct / Missed: %s / %s / %s\n',int2str(sum_res(12)),...
%     int2str(sum_res(13)),int2str(sum_res(14)));

fprintf('\nRecording duration: %s s\n\n',num2str(duration));

% plot in ROC space
figure, hold all 
scatter(roc_mat(:,2),roc_mat(:,1),'+');
set(gca,'xlim',[0 1],'ylim',[0 1]);
chance_level = [0:0.001:1];
plot(chance_level,chance_level,'--k')
xlabel('False positive rate'); ylabel('True positive rate');
SaveAndAssignInBase(roc_mat,'roc_mat','AssignOnly');


results = [];
for n = 1:length(sum_res)
   results{n} = sum_res(n); 
end

