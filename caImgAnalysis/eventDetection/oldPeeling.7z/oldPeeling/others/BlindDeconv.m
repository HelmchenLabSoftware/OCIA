function handles = BlindDeconv(handles)
% Blind deconvolution based on Matlabs deconvblind function

doPlot = 0;

noisy_dff = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
baseline = handles.sim_pars.baseline;
if ~handles.deconv_pars.blind_par_baseYN
        baseline = 0;
end
ca_amp = handles.sim_pars.ca_amp;
ca_tau = handles.sim_pars.ca_tau;
percent_max = handles.deconv_pars.blind_par_cutoff;
weightYN = handles.deconv_pars.blind_par_weightYN;
iters = handles.deconv_pars.blind_par_iters;
plotPSF = handles.deconv_pars.blind_par_psfYN;

if size(noisy_dff) ~= size(time_axis)
    time_axis = reshape(time_axis,size(noisy_dff));
end

% initial guess for deconv. function
% (adjusted by blind deconv. procedure using max. likelihood)
tfunc = ca_amp*exp(-time_axis/ca_tau);
% cut-off (when function reaches 0.01% of max.)
cut_off = (max(tfunc)*percent_max)/100;
tfunc(tfunc<= cut_off) = [];

% including the noise, at least in this way, does not help much
if baseline
    noise = noisy_dff(1:baseline);
    % propagate noise assuming characteristics remain constant
    noise = zeros(size(noisy_dff));
    index = ceil(length(baseline).*rand(length(noise),1));
    for n = 1:length(noise)
        noise(n) = baseline(index(n));
    end
else
    noise = [];
end

% scale noisy_dff between 0 and 1 and use as weight vector
% weighting may be better to detect APs in trains (high signal intensity)
% but might make 1AP detection harder (low signal intensity --> not
% included in deconvolution)
if weightYN
    min_value = min(noisy_dff);
    max_value = max(noisy_dff);
    range_value = max_value - min_value;
    weight = noisy_dff;
    for n = 1:length(noisy_dff)
        weight(n) = (1/range_value) * ...
            noisy_dff(n) - (1/range_value) * min_value;
    end
else
    weight = [];
end

restore = noisy_dff;
% deconvblind(input,initial guess,iterations,dunno,weight,noise)
% initial guess should be Ca decay function
% iterations should be a lot more than MLs default (in the order of 2000)
% --> also possible to restart again after one round by feeding psf as
% tfunc
% weights / noise, see above
[restore,psf] = deconvblind(restore,tfunc,iters,[],weight,noise);
% if ~baseline
%     restore_adj = restore(round(length(tfunc)/2)+1:end);
%     restore_adj = [restore_adj restore(1:round(length(tfunc)/2))];
%     restore = restore_adj;
% end

handles.data.blind_restore = restore;
handles.data.blind_initPSF = tfunc;
handles.data.blind_finalPSF = psf;

if plotPSF
    figure
    plot(tfunc,'b'); hold on
    plot(psf,'r');
    legend('tfunc','psf');
end

if ~doPlot
    return
end

% Plotting
plot_data{1,1} = noisy_dff;
plot_data{1,2} = spikes;
plot_data{2,1} = restore;
plot_data{3,1} = tfunc;
plot_data{3,2} = psf;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{1,2} = 'spikes';
plot_legend{2,1} = 'Blind deconv';
plot_legend{3,1} = 'Initial PSF';
plot_legend{3,2} = 'Final PSF';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');


% e.o.f.