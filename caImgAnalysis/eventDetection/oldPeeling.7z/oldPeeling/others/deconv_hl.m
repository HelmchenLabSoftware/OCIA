function [fOut,res] = deconv_hl(f,rate,A1,tauOn,tauOff)

% filter parameters
lpFiltCutoff = 0.5; % in s
lpFiltCutoff = round(lpFiltCutoff.*rate);
if ~rem(lpFiltCutoff,2)
    lpFiltCutoff = lpFiltCutoff+1;
end
sgolayOrder = 1; % filter order
f = sgolayfilt(f,sgolayOrder,lpFiltCutoff);

totalkerneltime = round(5*tauOff*rate);
t = 0:totalkerneltime;
t = t/rate; % time in seconds;
% filtkernel = exp(-t/taudecay) * CaAmplitude;
% filtkernel = A1 * (exp(-t/tauOff)-exp(-t/tauOn));
filtkernel = A1 * (exp(-t/tauOff));
% filtkernel(1,1)=0.001;

[fOut,res] = deconv(f,filtkernel);

% tempdata = zeros(size(data,1),size(data,2)+length(filtkernel),size(data,3));
% deconvdata = tempdata;
% tempdata(:,1:size(data,2),:)=data;
% %deconvdata = zeros(size(data));
% 
% for j=1:size(data,3) % for each trial
%     for i=1:size(data,1) % for each cell)
%         [deconvdata(i,1:end-totalkerneltime,j), r] = deconv(tempdata(i,:,j),filtkernel);
%     end;
% end;
% deconvdata(:,size(data,2)+1:end,:) = [];
% end