function handles = WienerFilt_FH(handles)
% Wiener filter based on code in WienerFilter Igor macro

% set to 1 to switch on plotting in standalone-mode
doPlot = 0;

dff = handles.data.dff;
noisy_dff = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
phi1 = handles.deconv_pars.wienerFH_par_phi1;
phi2 = handles.deconv_pars.wienerFH_par_phi2;
phi3 = handles.deconv_pars.wienerFH_par_phi3;
ca_amp = handles.sim_pars.ca_amp;
ca_tau = handles.sim_pars.ca_tau;

if size(dff) ~= size(noisy_dff)
    noisy_dff = reshape(noisy_dff,size(dff));
end
if size(dff) ~= size(time_axis)
    time_axis = reshape(time_axis,size(dff));
end

noise = noisy_dff - dff;

% % Parameters
% ca_amp = 8; % in DF/F %
% ca_tau = 1.2; % in s
%
% %phi_theory=phi1.*exp(-time_axis.^2./phi2)+phi3;
% % TODO: proper calculation of these parameters
% phi1 = 0.7;
% phi2 = 1.2;
% phi3 = 0.3;

% time_axis = 0.1:0.1:(length(noisy_dff)/10);

tfunc = ca_amp*exp(-time_axis/ca_tau);

% Fourier transforms of input variables
signal_fft = fft(noisy_dff);
kk_fft = fft(tfunc);
cc_fft = fft(dff);
noise_fft = fft(noise);

% magnitude of fft (squared?!)
cc_psd = real(cc_fft).^2 + imag(cc_fft).^2;
noise_psd = real(noise_fft).^2 + imag(noise_fft).^2;

% observed phi, derived from known signal and noise vectors
phi_data = cc_psd ./ (cc_psd + noise_psd);

% theoretical phi value, dependent on a priori parameters
phi_theory=phi1.*exp(-time_axis.^2./phi2)+phi3;

% Wiener filter kernel
restore_phi_data = phi_data .* signal_fft./kk_fft;

restore_phi_theory = phi_theory .* signal_fft./kk_fft;

restore_phi_data = ifft(restore_phi_data);
restore_phi_theory = ifft(restore_phi_theory);
restore_phi_theory = sqrt(real(restore_phi_theory).^2 + ...
    imag(restore_phi_theory).^2);

handles.data.wienerFH_restore_phi_theory = restore_phi_theory;
handles.data.wienerFH_restore_phi_data = restore_phi_data;

if ~doPlot
    return
end

% Plotting
close all
plot_data{1,1} = noisy_dff;
plot_data{2,1} = restore_phi_data;
plot_data{3,1} = restore_phi_theory;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{2,1} = 'phi\_data';
plot_legend{3,1} = 'phi\_theory';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
    'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');


% e.o.f.


