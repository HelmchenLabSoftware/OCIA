function handles = SchmittTrig(handles)
% Schmitt trigger thresholding of Ca trace

% set to 1 if calling this program on its own (plots will be generated)
doPlot = 0;

ca_trace = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
baseline = handles.sim_pars.baseline;
base_trace = ca_trace(baseline(1):baseline(numel(baseline)));
base_mean = mean(base_trace);
base_sd = std(base_trace);

schmitt_lower = base_mean + handles.deconv_pars.schmitt_par_lthresh*base_sd;
schmitt_upper = base_mean + handles.deconv_pars.schmitt_par_uthresh*base_sd;
schmitt_minpoints = handles.deconv_pars.schmitt_par_width;
schmitt_minsep = handles.deconv_pars.schmitt_par_minsep;

% minpoints and minsep specified in s --> convert to frames
schmitt_minpoints = round(schmitt_minpoints*handles.sim_pars.freq_ca);
schmitt_minsep = round(schmitt_minsep*handles.sim_pars.freq_ca);

schmitt1 = zeros(size(ca_trace));

toggle = 0;

for n = 1:length(ca_trace)
    if ~toggle
        if ca_trace(n) > schmitt_upper
            toggle = 1;
        end
    else
        if ca_trace(n) < schmitt_lower
            toggle = 0;
        end
    end
    schmitt1(n) = toggle;
end

% hold on
schmitt2 = schmitt1;
schmitt3 = schmitt1;
i = 1;
j = 0;
while true
    if schmitt1(i) == 1
        while true
            j = j + 1;
            if i+j >= length(schmitt1)
                schmitt2(i:i+j) = 0;
                schmitt3(i:i+j) = 0;
                break
            end
            if schmitt1(i+j) == 0
                break
            end
        end
        if j >= schmitt_minpoints
            schmitt2(i+1:i+j) = 0;
        elseif j < schmitt_minpoints
            schmitt2(i:i+j) = 0;
            schmitt3(i:i+j) = 0;
        end
    end
    i = i+j+1;
    j = 0;
    if i == length(schmitt1)
        schmitt2(i) = 0;
        schmitt3(i) = 0;
        break
    elseif i > length(schmitt1)
        break
    end
end

% join schmitt3 segments that are separated by schmitt_minsep points (or
% less)
if schmitt_minsep
    for n = 2:(length(schmitt3)-schmitt_minsep)
        if schmitt3(n-1)==1 && schmitt3(n)==0
            segment = schmitt3(n:(n+schmitt_minsep-1));
            if numel(segment(segment==1))>0
                schmitt3(n:(n+schmitt_minsep-1)) = 1;
            end
        end
    end
end

% the event starts a few frames before schmitt3 onset
for n = 3:length(schmitt3)
   if schmitt3(n) &&  ~schmitt3(n-1)
       schmitt3(n-2:n-1) = 1;
   end
end

handles.data.schmitt1 = schmitt1;
handles.data.schmitt2 = schmitt2;
handles.data.schmitt3 = schmitt3;

if ~doPlot
    return
end

% Plot data
plot_data{1,1} = ca_trace;
plot_data{1,2} = schmitt1;
plot_data{2,1} = ca_trace;
plot_data{2,2} = schmitt2;
plot_data{3,1} = ca_trace;
plot_data{3,2} = schmitt3;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{1,2} = 'Schmitt1';
plot_legend{2,1} = 'noisy\_dff';
plot_legend{2,2} = 'Schmitt2';
plot_legend{3,1} = 'noisy\_dff';
plot_legend{3,2} = 'Schmitt3';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
    'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');


% e.o.f.



