function handles = TemplateMatch(handles)
% Template matching

doPlot = 0;

dff = handles.data.dff;
time_axis = handles.data.time_ca;
baseline = handles.sim_pars.baseline;
ca_tau = handles.sim_pars.ca_tau;
smooth_alg = handles.sim_pars.smooth_alg;
windowSize = handles.sim_pars.windowSize;

if size(dff) ~= size(time_axis)
   time_axis = reshape(time_axis,size(time_axis)); 
end

handles = SchmittTrig(handles);
schmitt3 = handles.data.schmitt3;

events = 0;
events_vect = zeros(size(schmitt3));
state = 0;
for n = 1:length(schmitt3)
    if schmitt3(n) == 1 && state == 0
        state = 1;
        events = events + 1;
        events_vect(n) = events;
    elseif schmitt3(n) == 0 && state == 1
        state = 0;
    elseif schmitt3(n) == 1 && state == 1
        events_vect(n) = events;
    end
end
fprintf('\nDetected %s events based on schmitt3\n',int2str(events));

% perform template matching on each event
cc_vect = nan(size(dff));
rsquare_vect = nan(size(dff));
for n = 1:events
    event_trace = dff(events_vect==n);
    % template exp. decay based on max. event height
    event_max = max(event_trace);
    tfunc = event_max*exp(-(1:length(event_trace))/ca_tau);
    %     plot(event_trace); hold on
    %     plot(tfunc,'r'); legend('trace','tfunc');
    %     input('Press enter to continue');
    %     hold off
    % correlation between tfunc and event_trace
    cc = corrcoef(event_trace,tfunc);
    cc_vect(events_vect==n) = cc(1,2);
    % fit exponential curve to event_trace
    % e.g. if value for ca_tau is not known
    % start points for the parameters can be chosen sensibly
    s = fitoptions('Method','NonlinearLeastSquares','StartPoint',[event_max 100]);
    f = fittype('a*exp(-x/b)','options',s);
    [c,gof] = fit((1:length(event_trace))',event_trace',f);
    rsquare_vect(events_vect==n) = gof.rsquare;
%     plot(event_trace); hold on
%     plot(c,'r');
%     input('Press enter to continue');
%     hold off
end
handles.data.cc_vect = cc_vect;
handles.data.rsquare_vect = rsquare_vect;

if ~doPlot
    return
end

plot_data = {dff schmitt3; cc_vect rsquare_vect};
plot_legend = {'dff' 'schmitt3'; 'cc' 'rsquare'};
PlotVectors(plot_data,plot_legend,time_axis);







