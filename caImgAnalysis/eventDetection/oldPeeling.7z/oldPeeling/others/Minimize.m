function handles = Minimize(handles)
% Optimization algorithm for AP detection

doPlot = 0;

dff = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
ca_tau = handles.deconv_pars.min_par_decay/1000;
ca_amp = handles.deconv_pars.min_par_amp;
smooth_alg = handles.sim_pars.smooth_alg;
windowSize = handles.sim_pars.windowSize;
method = handles.deconv_pars.min_par_method;
error_func = handles.deconv_pars.min_par_erf;
expand = handles.deconv_pars.min_par_expand;
expand = 0;
saturate = handles.sim_pars.saturate;
delay = handles.sim_pars.delay;

freq_ap = handles.sim_pars.freq_ap;
freq_ca = handles.sim_pars.freq_ca;

handles = SchmittTrig(handles);
schmitt3 = handles.data.schmitt3;
handles = Integral(handles);
ap_stats = handles.data.ap_stats;

if size(dff) ~= size(time_axis)
    dff = reshape(dff,size(time_axis));
end
model_ca = zeros(size(schmitt3));
[duration time_axis] = gui_CalculateTimeVector(...
    model_ca,handles.sim_pars.freq_ca,[]);
% calculate model_spikes based ephys frequency and duration
model_spikes = zeros(1,round(duration*handles.sim_pars.freq_ap));
% detect events based on Schmitt trigger
% expand if required
events = 0;
events_vect = zeros(size(schmitt3));
state = 0;
for n = 1:length(schmitt3)
    if schmitt3(n) == 1 && state == 0
        state = 1;
        events = events + 1;
        if n-expand > 0
            events_vect(n-expand:n) = events;
        else
            events_vect(1:n) = events;
        end
    elseif schmitt3(n) == 0 && state == 1
        state = 0;
    elseif schmitt3(n) == 1 && state == 1
        events_vect(n) = events;
    end
end

if isstruct(handles.deconv_pars.min_par_opt)
    options = handles.deconv_pars.min_par_opt;
    if strcmp(method,'Scatter Search')
        options = ssmoptimset(options);
    end
else
    if strcmp(method,'Simulated Annealing')
        options = saoptimset;
    elseif strcmp(method,'Pattern Search')
        options = psoptimset;
    elseif strcmp(method,'Genetic')
        options = gaoptimset;
    elseif strcmp(method,'Scatter Search')
        options = ssmoptimset;
    end
end

ap_no_jitter = 0;

mean_fval = 0;
mean_amp = 0;
mean_tau = 0;
% run minimization for each event
for current_event = 1:events
    ap_no = ap_stats{current_event+1,5};
    if isnan(ap_no)
        warning('No events detected based on schmitt3. Skipping minimize!');
        mean_fval = NaN;
%         varargout{1} = model_ca;
%         varargout{2} = model_spikes;
%         varargout{3} = mean_fval;
        return
    end
    if ap_no == 0
        warning('No AP detected in current segment. Skipping minimize!');
        mean_fval = NaN;
%         varargout{1} = model_ca;
%         varargout{2} = model_spikes;
%         varargout{3} = mean_fval;
        continue
    end
    fprintf('\nEstimated %1.0f APs based on Schmitt trigger\n.',ap_no);
    ap_no = input('Specify number of APs for minimization: ');
    ap_no_vect = ap_no-ap_no_jitter:ap_no+ap_no_jitter;
    ap_no_vect(ap_no_vect<1) = [];
    best_gof = 99999;
    event_start = find(events_vect==current_event,1,'first')/freq_ca;
    event_stop = find(events_vect==current_event,1,'last')/freq_ca;
    for ap_no = ap_no_vect(1):ap_no_vect(length(ap_no_vect))
        fprintf('\nNow processing segment %s with %s APs\n',...
            int2str(current_event),int2str(ap_no));
        event_trace = dff(events_vect==current_event);
%         event_time_axis = 0.1:0.1:length(event_trace)/10;
        [event_duration event_time_axis] = gui_CalculateTimeVector(...
            event_trace,handles.sim_pars.freq_ca,[]);
       % take into account data after the interval
        event_tail = find(events_vect==current_event,1,'last');
        if event_tail + 1 <= numel(dff)
            event_tail = dff(event_tail+1:end);
            if numel(event_tail) > numel(event_trace)
               event_tail(numel(event_trace)+1:end) = [];
            end
        else
            event_tail = [];
        end
        x0 = zeros(1,ap_no);
        % most APs will usually be found at the beginning
        init_pos = randperm(round(length(event_time_axis)/4));
        x0(x0==0) = event_time_axis(init_pos(1:ap_no));
        lbound = zeros(1,ap_no);
%         lbound(lbound==0) = min(event_time_axis);
        ubound = zeros(1,ap_no);
        % APs are never found at the very end of the interval
        ubound(ubound==0) = event_time_axis...
            (floor(length(event_time_axis)-(length(event_time_axis)/2)));
        if numel(ca_tau) > 1 && numel(ca_amp) > 1
            % optimize decay and amplitude, in addition to spike times
            % read first 3 entries from each vector as x0, lbound, ubound
            % entries are prepended to x0, lbound and ubound (tau first, then
            % amplitude)
            x0 = [ca_tau(1) ca_amp(1) x0];
            lbound = [ca_tau(2) ca_amp(2) lbound];
            ubound = [ca_tau(3) ca_amp(3) ubound];
        end
        % setup structure with further input arguments for objective
        % function
        opt_args.error_func = error_func;
        opt_args.event_trace = event_trace;
        opt_args.event_time_axis = event_time_axis;
        opt_args.event_tail = event_tail;
        opt_args.ca_amp = ca_amp;
        opt_args.ca_tau = ca_tau;
        opt_args.freq_ca = freq_ca;
        opt_args.freq_ap = freq_ap;
        opt_args.saturate = saturate;
        opt_args.smooth_alg = smooth_alg;
        opt_args.windowSize = windowSize;
        opt_args.delay = delay;
        
        if strcmp(method,'Simulated Annealing')
            [x fval exitflag output] = simulannealbnd(...
                @(x) MinimizeObjFunc(x,opt_args),x0,lbound,ubound,options);
        elseif strcmp(method,'Pattern Search')
            [x fval exitflag output] = patternsearch(...
                @(x) MinimizeObjFunc(x,opt_args),x0,[],[],[],[],lbound,...
                ubound,[],options);
        elseif strcmp(method,'Genetic')
            [x fval exitflag] = ga(...
                @(x) MinimizeObjFunc(x,opt_args),length(x0),[],[],[],[],...
                lbound,ubound,[],options);
        elseif strcmp(method,'Scatter Search')
            problem.f = 'MinimizeObjFunc';
            problem.x_L = lbound;
            problem.x_U = ubound;
            problem.x_0 = x0;
            [results] = ssm_kernel(problem,options,error_func,event_trace,...
                event_time_axis,ca_amp,ca_tau,saturate,smooth_alg,windowSize);
            x = results.xbest;
            fval = results.fbest;
        end
        % only update if improved
        if fval < best_gof
            spike_train = zeros(1,round(event_duration*...
                handles.sim_pars.freq_ap));
            event_time_axis = round(event_time_axis.*10)/10;
            fprintf('\nError function\t%s',error_func);
            if numel(ca_tau) > 1 && numel(ca_amp) > 1
                ca_tau_final = x(1);
                ca_amp_final = x(2);
                fprintf('\nFound minimum (%s) at %s\n',num2str(fval),...
                    num2str(sort(x(3:end))));
                fprintf('Ca tau\t%s\nCa amp\t%s\n',...
                    num2str(ca_tau_final*1000),num2str(ca_amp_final));
%                 model = ca_amp_final*exp(-event_time_axis/ca_tau_final);
                mean_amp = mean_amp + ca_amp_final;
                mean_tau = mean_tau + ca_tau_final;
            else
                fprintf('\nFound minimum (%s) at %s\n',num2str(fval),...
                    num2str(sort(x)));
                ca_amp_final = ca_amp;
                ca_tau_final = ca_tau;
%                 model = ca_amp*exp(-event_time_axis/ca_tau);
                mean_amp = mean_amp + ca_amp;
                mean_tau = mean_tau + ca_tau;
            end
            for n = 1:length(x)
                current_spike_time = round(x(n)*freq_ap)/freq_ap;
                spike_train(floor(current_spike_time*freq_ap)) = ....
                    spike_train(floor(current_spike_time*freq_ap)) + 1;
            end
            model_ca_event = Spike2DFF(spike_train,ca_amp_final,ca_tau_final,...
                freq_ap,freq_ca,saturate,delay);
%             model_ca_event = conv(spike_train,model);
%             model_ca_event(length(event_trace)+1:end) = [];
            % smooth model
            if ~strcmp(smooth_alg,'none')
                model_ca_event = SmoothModel(smooth_alg,event_time_axis,...
                    model_ca_event,windowSize);
            end
            if doPlot
                fig_title = sprintf('Event %s (%s APs)',int2str(current_event),...
                    int2str(ap_no));
                h = figure('Name',fig_title);
                plot(event_time_axis,event_trace,'r');hold on
                plot(event_time_axis,model_ca_event,'b');
                legend('data','model');
            end
            %     model_ca(events_vect==current_event) = model_ca_event;
            start_idx = round(event_start*freq_ap);
            for pos = 1:length(spike_train)
                model_spikes(start_idx+pos-1) = spike_train(pos);
            end
            best_gof = fval;
        end
        clear x fval exitflag output
    end
    mean_fval = mean_fval + best_gof;
end
mean_fval = mean_fval / events;
mean_amp = mean_amp / events;
mean_tau = mean_tau / events;

model_ca = Spike2DFF(model_spikes,mean_amp,mean_tau,freq_ap,freq_ca,saturate,delay);
% model = mean_amp*exp(-time_axis/mean_tau);
% model_ca = conv(model_spikes,model);
% model_ca(length(model_spikes)+1:end) = [];

% add some noise
for n = 1:numel(model_spikes)
   if ~model_spikes(n)
      model_spikes(n) = 0.05*randn;
   end
end

handles.data.min_modelCa = model_ca;
handles.data.min_modelAP = model_spikes;
handles.data.spikes_predict = model_spikes;
handles.data.spikes_gof = mean_fval;
[dur handles.data.time_ap] = gui_CalculateTimeVector(model_spikes,freq_ap,[]);
end

function model = SmoothModel(method,event_time_axis,model,windowSize)

if strcmp(method,'moving average')
    % 1. Moving average
    method = 'moving';
    span = windowSize * 10;
    model = smooth(event_time_axis,model,span,method);
elseif strcmp(method,'local regression')
    % 2. Local regression using weighted linear least squares
    method = 'lowess';
    span = windowSize / event_time_axis(length(event_time_axis));
    model = smooth(event_time_axis,model,span,method);
elseif strcmp(method,'robust local regression')
    % 3. robust local regression (slow)
    method = 'rlowess';
    span = windowSize / event_time_axis(length(event_time_axis));
    model = smooth(event_time_axis,model,span,method);
end


end


% e.o.f.


