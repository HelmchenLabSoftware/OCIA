function varargout = fast_oopsi_wrapper(handles)
% run fast_oopsi routine by Joshua Vogelstein

% this file written by Henry Luetcke (hluetck@gmail.com)

SavePlot = 0;
doFilter = 0;

% cost for spike time distance measure (cost per unit time to move a spike)
spikeDistCost = 1;


% threshold applied to the oopsi output
if isfield(handles,'oopsi_thr')
    oopsi_thr = handles.oopsi_thr;
else
    oopsi_thr = 0.3;
end
if isfield(handles,'integral_thr')
    % minimum AP number, based on integral calculation
    APno_thr = handles.integral_thr;
else
    APno_thr = 0;
end

if isfield(handles,'base_frames')
    base_frames = handles.base_frames;
else
    base_frames = 10;
end

if isfield(handles,'amp')
    ca_amp = handles.amp;
else
    ca_amp = 2.5;
end

if isfield(handles,'tau')
    ca_tau = handles.tau;
else
    ca_tau = 0.6;
end

if isfield(handles,'id')
    fprintf('%s\n',handles.id);
end

if isfield(handles,'doPlot')
    doPlot = handles.doPlot;
else
    doPlot = 1;
end

if isfield(handles,'minGof')
    minGof = handles.minGof;
else
    minGof = 0.5;
end

if isfield(handles,'lam')
    lam = handles.lam;
else
    lam = 0.2;
end

% output matrix A with results from spike detection
A = [];

freq_ca = handles.sim_pars.freq_ca;

dff = handles.data.denoised_dff;
[dur,time_ca] = gui_CalculateTimeVector(dff,freq_ca,[]);
if isfield(handles,'ca_shift')
    time_ca = time_ca - handles.ca_shift;
end

% SD of calcium trace
% use high-pass filtered calcium trace to remove transients
filtDFF = mpi_BandPassFilterTimeSeries(dff,1/freq_ca,0.5,100);
SDdff = std(filtDFF);

P.lam = lam;
% P.gam = (1-(1/freq_ca)) / ca_tau;

V.dt = 1/freq_ca;
V.est_gam = 1; % estimate decay time parameter (does not work)
V.est_sig = 1; % estimate baseline noise SD
V.est_lam = 1; % estimate firing rate
V.est_a = 0; % estimate spatial filter
V.est_b = 0; % estimate background fluo.
V.fast_thr = 1;
V.fast_iter_max = 3;

[n_best,P_best,V] = fast_oopsi_new(dff,V,P);

% create spike train from n_best
oopsi = n_best';
% oopsi(oopsi<oopsi_thr) = 0;

% if fast_oopsi failed, try with more iterations
if ~sum(oopsi)
    disp('Nothing found. Running fast_oopsi again.');
    V.dt = 1/freq_ca;
    %     V.est_gam = 1;
    %     V.est_sig = 1;
    %     V.est_lam = 1;
    %     V.est_a = 1;
    %     V.est_b = 1;
    V.fast_thr = 0;
    V.fast_iter_max = 5;
    [n_best,P_best,V] = fast_oopsi_new(dff,V,P);
    oopsi = n_best';
end
oopsi(oopsi<oopsi_thr) = 0;

fprintf('\nEstimated parameters:\n');
disp(P_best)

% histogram of oopsi result - threshold at oopsi value of second bin
% [freq,xout] = hist(n_best,sqrt(numel(n_best)));
% if doPlot
%     figure('Name','Oopsi histogram','NumberTitle','off')
%     plot(xout,freq)
% end
% oopsi = n_best';
% fprintf('\nOopsi thresholding\n');
% fprintf('bin 1: %s (n=%s)\n',num2str(xout(1)),int2str(freq(1)));
% fprintf('bin 2 (threshold): %s (n=%s)\n',num2str(xout(2)),int2str(freq(2)));
% oopsi(oopsi<xout(2)) = 0;

% allocate AP numbers to detected events
spikes_predict = zeros(size(dff));
pos = 1;
isBurst = 0;
while true
    if pos >= length(oopsi)
        break
    end
    if ~oopsi(pos)
        pos = pos + 1;
        continue
    end
    % preceeding baseline
    if pos - base_frames-1 > 0
        baseline = dff(pos-base_frames:pos-1);
        time_base = time_ca(pos-base_frames:pos-1);
    else
        baseline = dff(1:pos-1);
        time_base = time_ca(1:pos-1);
    end
    % estimate baseline trend (linear fit)
    if isBurst
        p = polyfit(time_base,baseline,1);
        dff_fit = p(1) .* time_ca + p(2);
        dff_deDrift = dff - dff_fit;
        
        if p(1) > 0
            dff_deDrift = dff - dff_fit;
        else
            dff_deDrift = dff - mean(baseline);
        end
        
        
        
%         if doPlot
%             figure
%             subplot(2,1,1), hold all
%             plot(time_ca,dff)
%             plot(time_ca,dff_deDrift)
%             plot(time_ca,dff_fit,'k:')
%             legend({'orig' 'corrected' 'fit'})
%             text(time_ca(pos),mean(baseline),'\downarrow','FontSize',16)
%             if pos > 10 && pos + 50 <= length(dff)
%                 xmin = time_ca(pos-10);
%                 xmax = time_ca(pos+50);
%             elseif pos <= 10
%                 xmin = time_ca(1);
%                 xmax = time_ca(pos+50);
%             else
%                 xmin = time_ca(pos-10);
%                 xmax = max(time_ca);
%             end
%             set(gca,'xlim',[xmin xmax])
%             
%             subplot(2,1,2), hold all
%             plot(time_base,baseline)
%             base_fit = p(1).*time_base+p(2);
%             plot(time_base,base_fit,'k:')
%             legend({'base' 'fit'});
% %             text(time_base(2),mean(baseline),num2str(gof.rsquare,2))
%         end
    else
        dff_deDrift = dff - mean(baseline);
    end
    
    % find end of current segment
    dff_seg = dff_deDrift(pos+1:end);
    dff_segPlot = dff(pos+1:end);
    
    oopsi_seg = oopsi(pos+1:end);
    stop = find(dff_seg<=mean(baseline));
    
    if isempty(stop) || length(stop) < 1
        stop = length(dff_seg);
    end
    % search through oopsi_seg --> if event is found further than 3x ca_tau
    % but less than stop, take this point as new stop (this prevents
    % run-away integrals)
    start_point = round(3*ca_tau*freq_ca);
    if start_point < length(oopsi_seg) && start_point < stop(1)
        isBurst = 0;
        for n = start_point:stop(1)
            if oopsi_seg(n)
                stop = n;
                isBurst = 1;
                break
            end
        end
    end
    if isempty(stop) || length(stop) < 1
        stop = length(dff);
    else
        stop = pos+1+stop(1);
    end
    if stop > length(dff)
        stop = length(dff);
    end
    % integral over whole segment
    if isfield(handles.data,'filtered_dff') && doFilter
        dff_seg = dff_deDrift(pos:stop);
        dff_segPlot = handles.data.filtered_dff(pos:stop);
    else
        dff_seg = dff_deDrift(pos:stop);
        dff_segPlot = dff(pos:stop);
    end
    time_ca_seg = time_ca(pos:stop);
    
    dff_integral = trapz(time_ca_seg,dff_seg);
    APno = dff_integral / (ca_amp*ca_tau);
    % threshold based on calculated number of APs and noise of the trace
    if (APno * ca_amp) < SDdff || isnan(APno)
        %     if APno < APno_thr || isnan(APno)
        pos = stop;
        continue
    end
    APno = round(APno);
    
    % allocate calculated AP no. to detected events in segment
    oopsi_seg = oopsi(pos:stop);
    spikes_predict_seg = zeros(size(oopsi_seg));
    detectedEvents = length(find(oopsi_seg>0));
    allocatedAPs = 0;
    segPos = 1;
    while true
        if allocatedAPs >= APno
            break
        end
        if oopsi_seg(segPos)
            spikes_predict_seg(segPos) = spikes_predict_seg(segPos) + 1;
            allocatedAPs = allocatedAPs + 1;
            if segPos == length(oopsi_seg)
                segPos = 1;
            else
                segPos = segPos + 1;
            end
        else
            if segPos == length(oopsi_seg)
                segPos = 1;
            else
                segPos = segPos + 1;
            end
            continue
        end
    end
    spikes_predict(pos:stop) = spikes_predict_seg;
    pos = stop;
end

handles.data.spike_predict = spikes_predict;
handles.data.oopsi = oopsi;
handles.data.P = P_best;
handles.data.SD = SDdff;

[handles, A] = SpikeTrainCompare(handles,doPlot,time_ca,dff,oopsi,...
    spikeDistCost,spikes_predict);

varargout{1} = handles;

if nargout > 1
   varargout{2} = A; 
end
