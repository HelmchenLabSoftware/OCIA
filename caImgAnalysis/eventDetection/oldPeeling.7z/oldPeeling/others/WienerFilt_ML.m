function handles = WienerFilt_ML(handles)
% Deconvolution using Wiener filter

doPlot = 0;

noisy_dff = handles.data.denoised_dff;
time_axis = handles.data.time_ca;
baseline = handles.sim_pars.baseline;
ca_amp = handles.sim_pars.ca_amp;
ca_tau = handles.sim_pars.ca_tau;
percent_max = handles.deconv_pars.wienerML_par_cutoff;

if ~handles.deconv_pars.wienerML_par_baseYN
    baseline = 0;
end
if size(noisy_dff) ~= size(time_axis)
    time_axis = reshape(time_axis,size(noisy_dff));
end

restore = noisy_dff;

% deconvolution function
tfunc = ca_amp*exp(-time_axis/ca_tau);
% tfunc = 0.7.*exp(-time_axis.^2./1.2)+0.3;

% cut-off (when function reaches 0.01% of max.)
cut_off = (max(tfunc)*percent_max)/100;
tfunc(tfunc<= cut_off) = [];

if baseline
    noise = noisy_dff(1:baseline);
    % propagate noise assuming characteristics remain constant
    noise_long = zeros(size(noisy_dff));
    index = ceil(length(noise).*rand(length(noise_long),1));
    for n = 1:length(noise_long)
        noise_long(n) = noise(index(n));
    end
    noise = noise_long;

    % noise power
    NP = abs(fft(noise)).^2;
    NPOW = sum(NP(:))/prod(size(noise));

    % noise autocorrelation function, centered
    NCORR = fftshift(real(ifftn(NP)));

    % original image power
    IP = abs(fft(noisy_dff)).^2;
    IPOW = sum(IP(:))/prod(size(noisy_dff));

    % image autocorrelation function, centered
    ICORR = fftshift(real(ifft(IP)));
    ICORR1 = ICORR(:,ceil(length(noisy_dff)/2));

    restore_noise = deconvwnr(restore',tfunc',NCORR',ICORR');
    restore_noise = restore_noise';
else
    restore = deconvwnr(restore,tfunc);
end

% adjust timing by shifting half the length of the convolution function to
% the left (not very elegant but works)
if ~baseline
    restore_adj = restore(round(length(tfunc)/2)+1:end);
    restore_adj = [restore_adj restore(1:round(length(tfunc)/2))];
    restore = restore_adj;
end
handles.data.wienerML_restore = restore;

if ~doPlot
    return
end

% Plotting
plot_data{1,1} = noisy_dff;
plot_data{1,2} = spikes;
plot_data{2,1} = restore;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{1,2} = 'spikes';
plot_legend{2,1} = 'Wiener';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
    'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');



% e.o.f.


