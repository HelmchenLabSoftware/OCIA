% test of saturation of Ca amplitude following train of stimuli

% variable 'spikes' contains spike train
% load('spike_train10AP.mat');
% simple convolution, without saturation
freq = 10; % sampling frequency in Hz
ca_amp = 10; % in DF/F %
ca_tau = 1.2; % in s
snr = 8; % desired SNR in % (1AP)
sd_noise = ca_amp / snr;
time = (1/freq):(1/freq):(length(spikes)/freq);
% tfunc = ca_amp*exp(-time/ca_tau);
% dff = conv(spikes,tfunc);
% dff(length(spikes)+1:end) = [];
% noise = sd_noise*randn(size(dff));
% noisy_dff = dff + noise;

% DFF max. (in %)
dff_max = 100;
% start point for less than linear response to increasing Ca (in %)
dff_nl = 80;


% calculate DFF and allow for indicator saturation
dff = zeros(size(spikes));
dff_sat = zeros(size(spikes));
for n = 1:length(spikes)
   if spikes(n) > 0
       current_ca_amp = spikes(n) * ca_amp;
       current_time = 1:(length(spikes)-n+1);
       current_time = current_time ./ freq;
       tfunc = current_ca_amp*exp(-current_time/ca_tau);
       current_dff = dff(n:end)';
       current_dff = current_dff + tfunc;
       dff(n:end) = current_dff';
   end
end
% indicator saturation
dff_sat = dff;
for n = 1:length(dff)
   if dff(n) >= dff_nl
      dff_sat(n) =  (dff_nl*dff_max)./...
          (dff_nl+(dff_max-dff_nl)*exp(-0.05*(dff(n)-dff_nl)));
   end
end

% Plot
plot_data = {spikes dff dff_sat};
plot_legend = {'Spikes' 'dff' 'dff\_sat'};
hPlot = PlotVectors(plot_data,plot_legend,time);
% tag figure
set(hPlot,'Tag','scratch');
set(hPlot,'Units','normalized','Position',[0.01 0.42 0.98 0.28]);
