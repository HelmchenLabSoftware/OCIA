function varargout = Spike2Ca(varargin)
% in1 ... spike train vector
% out1 ... noiseless Ca signal vector
% out2 ... noisy Ca signal vector

spikes = varargin{1};

% Parameters
ca_amp = 8; % in DF/F %
ca_tau = 1.2; % in s
snr = 3; % desired SNR in % (1AP)

% bleaching
bleach_amp = 0; % amplitude (0 for none)
bleach_tau = 60; % decay time in s

ca_amp = ca_amp;
sd_noise = ca_amp / snr;
time_axis = 0.1:0.1:(length(spikes)/10);
tfunc = ca_amp*exp(-time_axis/ca_tau);
dff = conv(spikes,tfunc);
dff(length(spikes)+1:end) = [];
plot(time_axis,dff,'r');

% add the noise
% high f
noise = sd_noise*randn(size(dff));
noisy_dff = dff + noise;
% bleaching
if bleach_amp
   bleach_curve = bleach_amp*exp(-time_axis/bleach_tau);
   noisy_dff = noisy_dff + bleach_curve;
end
plot(time_axis,noisy_dff,'k');

varargout{1} = dff;
varargout{2} = noisy_dff;
hold off