function cc = sim_anneal_fun(spikes,ca_amp,ca_tau)
% spikes is a vector with spike times
% spikes is modified by the optimization algorithm such that cc --> min

% ca_amp = 0.8;
% ca_tau = 1.2;

load('noisy_dff_10ap.mat');

time_axis = 0.1:0.1:length(noisy_dff)/10;

spike_train = zeros(size(noisy_dff));

for n = 1:length(spikes)
    index = round(spikes(n));
    spike_train(index) = spike_train(index) + 1;
end

model = ca_amp*exp(-time_axis/ca_tau);
model = conv(spike_train,model);
model(length(noisy_dff)+1:end) = [];

% fast cc function (mex)
cc = prcorr2(noisy_dff,model);

cc = -cc;