function varargout = DiffInt(varargin)
% in1 ... dff
% in2 ... noisy_dff
% in3 ... spikes
% out1 ... gradient vector
% out2 ... cumulative integral vector

dff = varargin{1};
noisy_dff = varargin{2};
spikes = varargin{3};

% noisy_dff = PreprocCa(noisy_dff)';

close all

% Parameters
ca_amp = 8; % in DF/F %
ca_tau = 1.2; % in s
time_axis = 0.1:0.1:(length(dff)/10);

% cumulative integration of Ca signal
int_dff = cumtrapz(time_axis,noisy_dff);
% gradient
grad_dff = gradient(noisy_dff);

% Plotting
plot_data{1,1} = noisy_dff;
plot_data{1,2} = spikes;
plot_data{2,1} = grad_dff;
plot_data{3,1} = int_dff;
plot_legend{1,1} = 'noisy\_dff';
plot_legend{1,2} = 'spikes';
plot_legend{2,1} = 'gradient';
plot_legend{3,1} = 'cummulative integral';
h = PlotVectors(plot_data,plot_legend,time_axis,'Color','lines');
set(h,'Name',mfilename,'Units','normalized',...
'Position',[0.01 0.032 0.98 0.9],'NumberTitle','off');

% figure
% set(gcf,'Name','Diff&Int','Units','normalized',...
% 'Position',[0.01 0.032 0.98 0.9]);
% 
% subplot(311);
% plot(time_axis,noisy_dff);hold on
% plot(time_axis,spikes,'r');
% xlim([0.1 time_axis(length(time_axis))]);
% legend('noisy\_dff','spikes','Location','Best');
% subplot(312);
% plot(time_axis,grad_dff);
% xlim([0.1 time_axis(length(time_axis))]);
% legend('Gradient','Location','Best');
% subplot(313);
% plot(time_axis,int_dff);
% xlim([0.1 time_axis(length(time_axis))]);
% legend('Cumulative integral','Location','Best');



