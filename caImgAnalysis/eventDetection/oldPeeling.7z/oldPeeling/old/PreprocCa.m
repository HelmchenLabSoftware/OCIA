function ca_preproc = PreprocCa(ca_trace)
% preprocess Ca trace for subsequent analysis

% figure
% set(gcf,'Name','Preproc','Units','normalized','Position',...
%     [0.01 0.032 0.98 0.395]);
% axes('Units','normalized','Position',[0.05 0.05 0.9 0.9]);
time_axis = 0.1:0.1:(length(ca_trace)/10);

% smooth time series (different algorithms, in order of cpu time)
window_size = 1; % window size of filter in s
method = 'lowess';
if strcmp(method,'moving')
    % 1. Moving average
    span = window_size * 10;
    ca_preproc = smooth(time_axis,ca_trace,span,method);
elseif strcmp(method,'lowess') || strcmp(method,'rlowess')
    % 2. Local regression using weighted linear least squares
    % or robust local regression (slow)
    span = window_size / time_axis(length(time_axis));
    ca_preproc = smooth(time_axis,ca_trace,span,method);
end
return
plot(time_axis,ca_preproc,'r');
xlim([0.1 time_axis(length(time_axis))]);
hold on