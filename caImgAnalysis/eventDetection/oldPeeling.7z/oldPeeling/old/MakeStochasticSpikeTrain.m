function [spikes] = MakeStochasticSpikeTrain(varargin)
% generate spike train with given characteristics
% in1 ... duration of simulation in ms
% in2 ... initial baseline length in ms
% in3 ... final baseline length in ms
% in4 ... AP frequency in Hz
% in5 ... Sampling frequency in Hz

% TODO: create bursts?

msgstring = nargchk(5, 5, nargin);
if ~isempty(msgstring)
    error(msgstring);
end

duration = varargin{1};
init_baseline = varargin{2};
final_baseline = varargin{3};
ap_freq = varargin{4};
sampling = varargin{5};

spikes = zeros(1,duration*(sampling/1000));

for n = 1:numel(spikes)
    rand_no = ceil(sampling*rand);
    if ap_freq >= 1
        if rand_no <= ap_freq
            spikes(n) = 1;
        end
    else
        if rand_no <= ap_freq*10
            if rand <= 0.1
                spikes(n) = 1;
            end
        end
    end
end
spikes(1:(init_baseline*(sampling/1000))) = 0;
spikes(length(spikes)-(init_baseline*(sampling/1000)):length(spikes)) = 0;
ap_no = numel(find(spikes==1));
fprintf('Generated %s APs\n',int2str(ap_no));

% add some noise
for n = 1:numel(spikes)
   if ~spikes(n)
      spikes(n) = 0.05*randn;
   end
end




