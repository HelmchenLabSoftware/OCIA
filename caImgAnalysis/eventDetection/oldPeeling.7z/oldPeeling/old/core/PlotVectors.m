function varargout = PlotVectors(varargin)
% in1 ... y-data cell array (compulsory)
% in2 ... x-data cell array (default: 1:length(y_vect))
% in3 ... legend cell array (default: no legend)
% cell arrays: each row is plotted as separate subplot, each column as
% separate graph within a subplot
% legends are assigned correspondingly
% expect vectors of equal sizes in each cell array location
% e.g. size(in1{1,1}) = [1 length(in3)]
% additional input options
% 'Color' followed by valid Matlab color map (default: 'lines')
% 'Error' followed by cell array of errorbar values (array must be same
% size as data cell array)
% TODO: more input args for specifying figure / axis properties

msgstring = nargchk(1, 9, nargin);
if ~isempty(msgstring)
    error(msgstring);
end

plot_ydata = varargin{1};

% parse additional input arguments
% XData cell array
SpInput = find(strcmp(varargin, 'XData'));
if numel(SpInput)
    plot_xdata = varargin{SpInput+1};
else
    plot_xdata = {};
end
% Legend cell array
SpInput = find(strcmp(varargin, 'Legend'));
if numel(SpInput)
    plot_legend = varargin{SpInput+1};
else
    plot_legend = {};
end
% specify plot color according to Matlab color map
map_fig = figure;
SpInput = find(strcmp(varargin, 'Color'));
if numel(SpInput)
    cmap = varargin{SpInput+1};
    cstring = sprintf('%s(%s)',cmap,int2str(size(plot_ydata,2)));
    try evalc(cstring);
    catch
        fprintf(...
            '\n''%s'' is not a valid Matlab color map. Using ''lines''.\n',...
            cmap);
        cmap = 'lines';
    end
else
    cmap = 'lines';
end
cstring = sprintf('%s(%s)',cmap,int2str(size(plot_ydata,2)));
group_colors = colormap(cstring);
close(map_fig);

% error bars
SpInput = find(strcmp(varargin, 'Error'));
if numel(SpInput)
    ebar = varargin{SpInput+1};
else
    ebar = {};
end
if ~isempty(ebar) & size(ebar) ~= size(plot_ydata)
    warning('Error bar array must be same size as data array.');
end

h = figure;
hold on
legend_string = [];
for n = 1:size(plot_ydata,1)
    for m = 1:size(plot_ydata,2)
        if m == 1
            if ~isempty(legend_string)
                legend(legend_string,'Location','West');
                legend('boxoff');
            end
            abs_min = min(plot_ydata{n,1});
            abs_max = max(plot_ydata{n,1});
            legend_string = [];
            hSub = subplot(size(plot_ydata,1),1,n);
            current_pos = get(hSub,'Position');
            set(hSub,'Position',[0.04 current_pos(2) 0.9 current_pos(4)]);
            set(hSub,'TickDir','out','TickLength',[0.001 1]);
            hold on
        end
        if ~isempty(plot_xdata)
            x = plot_xdata{n,m};
        else
            x = 1:length(plot_ydata{n,m});
        end
        if ~isempty(plot_ydata{n,m})
            if length(x) > length(plot_ydata{n,m})
                x = x(1:length(plot_ydata{n,m}));
            end
            if ~isempty(ebar)
                errorbar(x,plot_ydata{n,m},ebar{n,m},...
                    'Color',group_colors(m,:));
                min_val = min(plot_ydata{n,m})-min(ebar{n,m});
                max_val = max(plot_ydata{n,m})+max(ebar{n,m});
            else
                plot(x,plot_ydata{n,m},'Color',group_colors(m,:));
                min_val = min(plot_ydata{n,m});
                max_val = max(plot_ydata{n,m});
            end
            if min_val < abs_min
                abs_min = min_val;
            end
            if max_val > abs_max
                abs_max = max_val;
            end
            if ~isempty(plot_legend)
                legend_string{m} = plot_legend{n,m};
            else
                legend_string = [];
            end
            if abs_min < abs_max
                xlim([x(1) x(length(x))]);
                ylim([abs_min abs_max]);
            end
        end
    end
end
if ~isempty(legend_string)
    legend(legend_string,'Location','West');
    legend('boxoff');
end
hold off
varargout{1} = h;



