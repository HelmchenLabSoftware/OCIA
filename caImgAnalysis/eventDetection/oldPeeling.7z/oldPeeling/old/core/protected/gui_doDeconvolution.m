function varargout = gui_doDeconvolution(handles)

switch lower(handles.deconv_pars.alg)
    case 'schmitt trigger'
        handles = SchmittTrig(handles);
    case 'wiener fh'
        handles = WienerFilt_FH(handles); 
    case 'wiener ml'
        handles = WienerFilt_ML(handles);
    case 'blind deconvolution'
        handles = BlindDeconv(handles);
    case 'template match'
        handles = TemplateMatch(handles);
    case 'integral'
        handles = Integral(handles);
    case 'iterative correlation'
        handles = IterativeCC(handles);
    case 'minimization'
        handles = Minimize(handles);
    case 'oopsi'
        handles = fast_oopsi_wrapper(handles);
    otherwise
       % TODO: more algorithms to be implemented
    varargout{1} = handles;
    return 
end

varargout{1} = handles;


% e.o.f.

