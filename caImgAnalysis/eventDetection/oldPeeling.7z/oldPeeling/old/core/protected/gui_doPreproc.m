function handles = gui_doPreproc(handles)
time_axis = handles.data.time_ca;
method = handles.sim_pars.smooth_alg;
noisy_dff = handles.data.noisy_dff;
%% Low-pass
% smooth time series (different algorithms, in order of cpu time)
window_size = handles.sim_pars.windowSize; % window size of filter in s
%         method = 'lowess';
if strcmp(method,'moving average')
    % 1. Moving average
    method = 'moving';
    span = window_size * 10;
    denoised_dff = smooth(time_axis,noisy_dff,span,method);
elseif strcmp(method,'local regression')
    % 2. Local regression using weighted linear least squares
    method = 'lowess';
    span = window_size / time_axis(length(time_axis));
    denoised_dff = smooth(time_axis,noisy_dff,span,method);
elseif strcmp(method,'robust local regression')
    % 3. robust local regression (slow)
    method = 'rlowess';
    span = window_size / time_axis(length(time_axis));
    denoised_dff = smooth(time_axis,noisy_dff,span,method);
elseif strcmp(method,'none')
    denoised_dff = noisy_dff;
end

%% High-pass
method = handles.sim_pars.hp_filter;
if strcmp(method,'Fourier')
    % 1. Fourier-based hp-filter
    denoised_dff = mpi_BandPassFilterTimeSeries(denoised_dff,...
        1/handles.sim_pars.freq_ca,handles.sim_pars.hp_cutoff,...
        handles.sim_pars.freq_ca);
elseif strcmp(method,'Difference')
    % 2. Difference between ca_trace and smoothed version of trace
    denoised_dff = hp_filter(denoised_dff,handles.sim_pars.hp_cutoff);
end
handles.data.denoised_dff = denoised_dff;

