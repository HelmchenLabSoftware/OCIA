function [handles,plot_ydata,plot_xdata,plot_legend] = gui_SetupPlotData(handles)
dff = handles.data.dff;
noisy_dff = handles.data.noisy_dff;
denoised_dff = handles.data.denoised_dff;
baseline = zeros(size(noisy_dff));
baseline(handles.sim_pars.baseline(1):handles.sim_pars.baseline...
    (numel(handles.sim_pars.baseline))) = 1;
baseline(baseline==0) = NaN;

time_ca = handles.data.time_ca;

if ~isempty(handles.data.spikes)
    time_ap = handles.data.time_ap;
    spikes = handles.data.spikes;
    if strcmp(handles.deconv_pars.alg,'Schmitt trigger')
        schmitt1 = handles.data.schmitt1;
        schmitt2 = handles.data.schmitt2;
        schmitt3 = handles.data.schmitt3;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) ...
            baseline dff; noisy_dff denoised_dff []; ...
            schmitt1 schmitt2 schmitt3};
        plot_xdata = {time_ap time_ca time_ca; time_ca time_ca []; ...
            time_ca time_ca time_ca};
        plot_legend = {'Spikes' 'baseline' 'dff'; 'noisy\_dff' 'denoised' ''; ...
            'Schmitt1' 'Schmitt2' 'Schmitt3'};
    elseif strcmp(handles.deconv_pars.alg,'Wiener FH')
        restore_phi_theory = handles.data.wienerFH_restore_phi_theory;
        restore_phi_data = handles.data.wienerFH_restore_phi_data;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) ...
            dff; noisy_dff denoised_dff; restore_phi_theory restore_phi_data};
        plot_xdata = {time_ap time_ca; time_ca time_ca; time_ca time_ca};
        plot_legend = {'Spikes' 'dff'; 'noisy\_dff' 'denoised'; ...
            'Wiener FH theory' 'Wiener FH data'};
    elseif strcmp(handles.deconv_pars.alg,'Wiener ML')
        restore = handles.data.wienerML_restore;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff; ...
            noisy_dff denoised_dff; restore []};
        plot_xdata = {time_ap time_ca; time_ca time_ca; ...
            time_ca time_ca};
        plot_legend = {'Spikes' 'dff'; 'noisy\_dff' 'denoised'; ...
            'Wiener ML' ''};
    elseif strcmp(handles.deconv_pars.alg,'Blind deconvolution')
        restore = handles.data.blind_restore;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff; ...
            noisy_dff denoised_dff; restore []};
        plot_xdata = {time_ap time_ca; time_ca time_ca; ...
            time_ca time_ca};
        plot_legend = {'Spikes' 'dff'; 'noisy\_dff' 'denoised'; ...
            'Blind deconv.' ''};
    elseif strcmp(handles.deconv_pars.alg,'OOPSI')
        oopsi = handles.data.oopsi;
        spike_predict = handles.data.spike_predict;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff spike_predict; ...
            noisy_dff denoised_dff []; oopsi spike_predict []};
        plot_xdata = {time_ap time_ca time_ca; time_ca time_ca time_ca; ...
            time_ca time_ca time_ca};
        plot_legend = {'Spikes' 'dff' 'Spike est'; 'noisy\_dff' 'denoised' ''; ...
            'oopsi' 'Spike est' ''};
    elseif strcmp(handles.deconv_pars.alg,'Template match')
        schmitt3 = handles.data.schmitt3;
        cc_vect = handles.data.cc_vect;
        rsquare_vect = handles.data.rsquare_vect;
        % adjust height of schmitt3 to improve visibility on plot
        schmitt3(schmitt3==1) = max(noisy_dff);
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff []; ...
            noisy_dff denoised_dff schmitt3; cc_vect rsquare_vect []};
        plot_xdata = {time_ap time_ca []; time_ca time_ca time_ca; ...
            time_ca time_ca []};
        plot_legend = {'Spikes' 'dff' ''; 'noisy\_dff' 'denoised' 'schmitt3'; ...
            'CorCoef' 'Rsquare' ''};
    elseif strcmp(handles.deconv_pars.alg,'Integral')
        dff_int = handles.data.dff_int;
        dff_grad = handles.data.dff_grad;
        schmitt3 = handles.data.schmitt3;
        schmitt3(schmitt3==1) = max(noisy_dff)/2;
        % adjust height of gradient trace to max. of integral
        scale_factor = max(dff_int)/max(dff_grad);
        dff_grad_scaled = dff_grad .* scale_factor;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff []; ...
            noisy_dff denoised_dff schmitt3; dff_int dff_grad_scaled []};
        plot_xdata = {time_ap time_ca []; time_ca time_ca time_ca; ...
            time_ca time_ca []};
        plot_legend = {'Spikes' 'dff' ''; 'noisy\_dff' 'denoised' 'schmitt3'; ...
            'Integral' 'Gradient' ''};
    elseif strcmp(handles.deconv_pars.alg,'Minimization')
        modelCa = handles.data.min_modelCa;
        modelAP = handles.data.min_modelAP;
        %         modelAP(modelAP==1) = max(modelCa) / 2;
%         modelAP = modelAP * 10;
        schmitt3 = handles.data.schmitt3;
        schmitt3(schmitt3==1) = max(modelCa) / 2;
        dff_int = handles.data.dff_int;
        % adjust height of integral trace to max. of denoised_dff
        scale_factor = max(denoised_dff)/max(dff_int);
        dff_int_scaled = dff_int .* scale_factor;
        plot_ydata = {ScaleToMinMax(spikes,min(dff),max(dff)) dff ...
            baseline; noisy_dff denoised_dff dff_int_scaled; ...
            ScaleToMinMax(modelAP,min(modelCa),max(modelCa)) modelCa schmitt3};
        [duration time_ap_model] = gui_CalculateTimeVector(...
            modelAP,handles.sim_pars.freq_ap,[]);
        plot_xdata = {time_ap time_ca time_ca; time_ca time_ca time_ca; ...
            time_ap_model time_ca time_ca};
        plot_legend = {'Spikes' 'dff' 'baseline'; 'noisy\_dff' ...
            'denoised' 'Integral'; 'Model AP' 'Model Ca' 'schmitt3'};
    else
        plot_ydata = {spikes dff; noisy_dff denoised_dff};
        plot_xdata = {time_ap time_ca; time_ca time_ca};
        plot_legend = {'Spikes' 'dff'; 'noisy\_dff' 'denoised'};
    end
else
    if strcmp(handles.deconv_pars.alg,'Schmitt trigger')
        schmitt1 = handles.data.schmitt1;
        schmitt2 = handles.data.schmitt2;
        schmitt3 = handles.data.schmitt3;
        plot_ydata = {noisy_dff denoised_dff baseline; ...
            schmitt1 schmitt2 schmitt3};
        plot_xdata = {time_ca time_ca time_ca; time_ca time_ca time_ca};
        plot_legend = {'noisy\_dff' 'denoised' 'baseline'; ...
            'Schmitt1' 'Schmitt2' 'Schmitt3'};
    elseif strcmp(handles.deconv_pars.alg,'Wiener FH')
        restore_phi_theory = handles.data.wienerFH_restore_phi_theory;
        restore_phi_data = handles.data.wienerFH_restore_phi_data;
        plot_ydata = {noisy_dff denoised_dff baseline; ...
            restore_phi_theory restore_phi_data []};
        plot_xdata = {time_ca time_ca time_ca; time_ca time_ca []};
        plot_legend = {'noisy\_dff' 'denoised' 'baseline'; ...
            'Wiener FH theory' 'Wiener FH data' ''};
    elseif strcmp(handles.deconv_pars.alg,'Wiener ML')
        restore = handles.data.wienerML_restore;
        plot_ydata = {noisy_dff denoised_dff baseline; ...
            restore [] []};
        plot_xdata = {time_ca time_ca time_ca; time_ca [] []};
        plot_legend = {'noisy\_dff' 'denoised' 'baseline'; ...
            'Wiener ML' '' ''};
    elseif strcmp(handles.deconv_pars.alg,'Blind deconvolution')
        restore = handles.data.blind_restore;
        plot_ydata = {noisy_dff denoised_dff baseline; ...
            restore [] []};
        plot_xdata = {time_ca time_ca time_ca; time_ca [] []};
        plot_legend = {'noisy\_dff' 'denoised' 'baseline'; ...
            'Blind deconv.' '' ''};
    elseif strcmp(handles.deconv_pars.alg,'Template match')
        cc_vect = handles.data.cc_vect;
        rsquare_vect = handles.data.rsquare_vect;
        % adjust height of schmitt3 to improve visibility on plot
        schmitt3(schmitt3==1) = max(noisy_dff);
        plot_ydata = {schmitt3 noisy_dff denoised_dff; ...
            cc_vect rsquare_vect []};
        plot_xdata = {time_ca time_ca time_ca; time_ca time_ca []};
        plot_legend = {'schmitt3' 'noisy\_dff' 'denoised'; ...
            'CorCoef' 'Rsquare' ''};
    elseif strcmp(handles.deconv_pars.alg,'Integral')
        dff_int = handles.data.dff_int;
        dff_grad = handles.data.dff_grad;
        schmitt3 = handles.data.schmitt3;
        schmitt3(schmitt3==1) = max(noisy_dff)/2;
        % adjust height of gradient trace to max. of integral
        scale_factor = max(dff_int)/max(dff_grad);
        dff_grad_scaled = dff_grad .* scale_factor;
        plot_ydata = {noisy_dff denoised_dff; ...
            dff_int dff_grad_scaled};
        plot_xdata = {time_ca time_ca; time_ca time_ca};
        plot_legend = {'noisy\_dff' 'denoised'; ...
            'Integral' 'Gradient'};
    elseif strcmp(handles.deconv_pars.alg,'Minimization')
        modelCa = handles.data.min_modelCa;
        modelAP = handles.data.min_modelAP;
        %         modelAP(modelAP==1) = max(modelCa) / 2;
%         modelAP = modelAP * 10;
        schmitt3 = handles.data.schmitt3;
        schmitt3(schmitt3==1) = max(modelCa) / 2;
        dff_int = handles.data.dff_int;
        % adjust height of integral trace to max. of denoised_dff
        scale_factor = max(denoised_dff)/max(dff_int);
        dff_int_scaled = dff_int .* scale_factor;
        % adjust height of spike train to max. of modelCa
        scale_factor = max(modelCa)/max(modelAP);
        modelAP_scaled = modelAP .* scale_factor;
        plot_ydata = {noisy_dff denoised_dff dff_int_scaled; ...
            schmitt3 modelCa modelAP_scaled};
        plot_xdata = {time_ca time_ca time_ca; time_ca time_ca ...
            handles.data.time_ap};
        plot_legend = {'noisy\_dff' 'denoised' 'Integral'; ...
            'schmitt3' 'Model Ca' 'Model AP'};
    else
        plot_ydata = {noisy_dff denoised_dff};
        plot_xdata = {time_ca time_ca};
        plot_legend = {'noisy\_dff' 'denoised'};
    end
end

% enforce row vectors in output cell arrays
for n = 1:numel(plot_ydata)
   mat = plot_ydata{n};
   mat = reshape(mat,1,numel(mat));
   plot_ydata{n} = mat;
end
for n = 1:numel(plot_xdata)
   mat = plot_xdata{n};
   mat = reshape(mat,1,numel(mat));
   plot_xdata{n} = mat;
end

% e.o.f.


