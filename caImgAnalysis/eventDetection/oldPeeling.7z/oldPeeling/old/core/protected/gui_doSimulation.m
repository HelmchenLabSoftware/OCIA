function varargout = gui_doSimulation(handles)

%% init
% don't do anything if update box not checked
if handles.common.update == 0
    varargout{1} = handles;
    return
end
disabled_items = findobj('Enable','on');
set(disabled_items,'Enable','off');
% switch status indicator to 'busy'
set(findobj('Tag','status_text1'),'Visible','off');
set(findobj('Tag','busy_text1'),'Visible','on','Enable','on');
drawnow

if strcmp(handles.common.fixRand,'on')
    rand('twister',handles.common.randSeed(handles.common.randSeedPos));
    randn('state',handles.common.randSeed(handles.common.randSeedPos));
    handles.common.randSeedPos = handles.common.randSeedPos + 1;
    if handles.common.randSeedPos > numel(handles.common.randSeed)
        handles.common.randSeedPos = 1;
    end
end

% check if file paths have been provided for spikes and ca --> load
if isstr(handles.data.spikes)
    if exist(handles.data.spikes,'file') ~= 2
        restoreGUIstate;
        error('The specified spike train mat-file %s could not be found',...
            handles.data.spikes);
    else
        handles.data.spikes = LoadMatData(handles.data.spikes);
        [handles.data.dur_ap handles.data.time_ap] = ...
            gui_CalculateTimeVector(handles.data.spikes,handles.sim_pars.freq_ap,[]);
    end
end
if isstr(handles.data.ca)
    if exist(handles.data.ca,'file') ~= 2
        restoreGUIstate;
        error('The specified Ca trace mat-file %s could not be found',...
            handles.data.spikes);
    else
        handles.data.ca = LoadMatData(handles.data.ca);
        [handles.data.dur_ca handles.data.time_ca] = ...
            gui_CalculateTimeVector(handles.data.ca,handles.sim_pars.freq_ca,[]);
    end
end

%% Scenario
% there are three possible scenarios to continue from here, based on which
% inputs the user has provided
% 1. Spike train only --> Simulation (perform convolution, deconvolution
% and evaluation)
% 2. Ca trace only --> 'Real-world' scenario (perform deconvolution and
% return the putative spike train; evaluation not possible in this case)
% 3. Both Spike train and Ca trace --> assess 'goodness' of algorithm
% (deconvolve Ca trace and compare with the provided spike train)
% these possibilities will be coded in handles.common.scenario
if ~isempty(handles.data.spikes) && isempty(handles.data.ca)
    handles.common.scenario = 1;
elseif isempty(handles.data.spikes) && ~isempty(handles.data.ca)
    handles.common.scenario = 2;
elseif ~isempty(handles.data.spikes) && ~isempty(handles.data.ca)
    handles.common.scenario = 3;
else
    restoreGUIstate;
    errordlg('You MUST provide at least one of spike train or Ca trace (or both)',...
        'Input Error');
    varargout{1} = handles;
    return
end

%% Simulate Ca trace
% if simulation, create simulated Ca trace
if handles.common.scenario == 1
    ca_amp = handles.sim_pars.ca_amp; % in DF/F %
    ca_tau = handles.sim_pars.ca_tau/1000; % in s
    snr = handles.sim_pars.snr; % desired SNR in % (1AP)
    sd_noise = ca_amp / snr;
    spikes = handles.data.spikes;
    try
        handles.data.dff = Spike2DFF(CleanSpikeTrain(spikes,handles.sim_pars.freq_ap),...
            ca_amp,ca_tau,handles.sim_pars.freq_ap,handles.sim_pars.freq_ca,...
            handles.sim_pars.saturate,handles.sim_pars.delay/1000);
    catch
        restoreGUIstate;
        alt_freqs = handles.sim_pars.freq_ca:handles.sim_pars.freq_ca+500;
        alt_rems = rem(handles.sim_pars.freq_ap,alt_freqs);
        closest_match = find(alt_rems==0,1);
        closest_match = alt_freqs(closest_match);
        fprintf('\nCould not compute DFF from spike train.');
        fprintf('\nMost likely cause is frequency inconsistency between DFF and Ephys.')
        fprintf('\nTry frequencies that are multiples of each other, e.g. %3.0f Hz Ca freq.\n',...
            closest_match);
        rethrow(lasterror);
    end
    [handles.data.dur_ca handles.data.time_ca] = ...
            gui_CalculateTimeVector(handles.data.dff,handles.sim_pars.freq_ca,[]);
    noise = sd_noise*randn(size(handles.data.dff));
    handles.data.noisy_dff = handles.data.dff + noise;
    clear spikes noise current_time tfunc current_dff
elseif handles.common.scenario == 2
    handles.data.dff = handles.data.ca;
    handles.data.noisy_dff = handles.data.ca;
elseif handles.common.scenario == 3
    handles.data.dff = handles.data.ca;
    handles.data.noisy_dff = handles.data.ca;
end

%% Preprocessing module
try
    handles = gui_doPreproc(handles);
catch
    restoreGUIstate;
    fprintf('\nAn error occured during preprocessing.\n');
    varargout{1} = handles;
    rethrow(lasterror);
end

%% Deconvolution module
try
    handles = gui_doDeconvolution(handles);
catch
    restoreGUIstate;
    fprintf('\nAn error occured during deconvolution.\n');
    varargout{1} = handles;
    rethrow(lasterror);
end

%% Plotting module
if handles.common.doPlot
    % Setup plots
    try
        if ~isempty(findobj('Tag','ap_ui_fig')) && ...
                handles.common.keep_figs == 0
            close(findobj('Tag','ap_ui_fig'));
        end
        [handles,plot_ydata,plot_xdata,plot_legend] = ...
            gui_SetupPlotData(handles);
    catch
        restoreGUIstate;
        fprintf('\nAn error occured during plot setup.\n');
        varargout{1} = handles;
        rethrow(lasterror);
    end

    % Plot
    try
        hPlot = PlotVectors(plot_ydata,'XData',plot_xdata,...
            'Legend',plot_legend);
        % tag figure
        set(hPlot,'Tag','ap_ui_fig');
        set(hPlot,'Units','normalized','Position',[0.01 0.42 0.98 0.28]);
    catch
        restoreGUIstate;
        fprintf('\nAn error occured during plotting.\n');
        varargout{1} = handles;
        rethrow(lasterror);
    end
end

varargout{1} = handles;

restoreGUIstate;

    function restoreGUIstate
        % switch status indicator back to 'ready'
        set(findobj('Tag','status_text1'),'Visible','on');
        set(findobj('Tag','busy_text1'),'Visible','off');
        % enable disabled items (this may fail at times, so we catch the error
        % simply by setting all items that are Enable 'off' to 'on')
        try
            set(disabled_items,'Enable','on');
        catch
            set(findobj('Enable','off'),'Enable','on');
        end
        clear disabled_items
        drawnow
    end
end



% e.o.f.
