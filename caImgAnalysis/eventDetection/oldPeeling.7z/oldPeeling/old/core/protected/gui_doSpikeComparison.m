function varargout = gui_doSpikeComparison(handles,spike_model,spike_gof)
% evaluate the similarity between two spike train vectors
% compare no. of spikes, no. of coincident spikes
% count misses, false alarms (SDT)
% quantify similarity
data = handles.data.spikes;
sumAP_data = sum(data);
data_bin = reshape(data,1,numel(data));
data_bin(data==0) = 1;
data_bin(data>0) = 2;
best_align_score = swalign(data_bin,data_bin,...
            'Alphabet','NT','GapOpen',20);
% save results in cell array with parameter values (e.g. different SNRs) in
% columns and measures of accuracy (e.g. GOF, Misses) in rows
% each cell entry contains a vector with length of number of samples
% this can be used to calculate mean, SD etc.
% measures of accuracy: 1 gof, 2 coincident APs / total APs, 3 Miss, 4 FA,
% 5 true positive rate, 6 false positive rate, 7 Matthew's cc (see
% http://en.wikipedia.org/wiki/Matthews_Correlation_Coefficient)
% some more measures
% 8 alignment
% 9 levenshtein distance
measure_no = 9;
results = cell(measure_no+1,size(spike_model,1));
results(2:end,1) = {'gof'; 'coincAP'; 'Miss'; 'FA'; 'TPR'; ...
    'FPR'; 'cc_m'; 'align'; 'ldist'};
results(1,1) = {handles.eval.var};
for n = 1:numel(handles.eval.range)
    results(1,n+1) = {handles.eval.range(n)};
end
for param = 2:size(spike_model,1)
    fprintf('\n%s %s\n',handles.eval.var,...
        num2str(spike_model{param,1}));
    iteration_matrix = zeros(measure_no,size(spike_model,2)-1);
    for iter = 2:size(spike_model,2)
        model = spike_model{param,iter};
        gof = spike_gof{param,iter};
        if size(data) ~= size(model)
            model = reshape(model,size(data));
        end
        sumAP_model = sum(model);
        model_bin = reshape(model,1,numel(model));
        model_bin(model==0) = 1;
        model_bin(model>0) = 2;
        fprintf('\nFinal goodness-of-fit (%s): %s',...
            handles.deconv_pars.min_par_erf,num2str(gof));
        iteration_matrix(1,iter-1) = gof;
        fprintf('\nTotal AP (data / model): %s / %s',int2str(sumAP_data),...
            int2str(sumAP_model));
        APcoinc = length(find(data==model&data~=0)) / sumAP_model;
        fprintf('\nCoincident APs per total APs: %s',...
            int2str(APcoinc));
        iteration_matrix(2,iter-1) = APcoinc;
        % misses
        APmiss = 0;
        for n = 1:numel(data)
            if model(n) < data(n)
                APmiss = APmiss + (data(n)-model(n));
            end
        end
        fprintf('\nMissed APs per total APs: %s',...
            num2str(APmiss / sumAP_model));
        iteration_matrix(3,iter-1) = APmiss / sumAP_data;
        % FAs
        APfalse = 0;
        for n = 1:numel(data)
            if model(n) > data(n)
                APfalse = APfalse + (model(n)-data(n));
            end
        end
        fprintf('\nFalsely detected APs per total APs: %s',...
            num2str(APfalse / sumAP_model));
        iteration_matrix(4,iter-1) = APfalse / sumAP_data;
        % TP ... true positive
        % TN ... true negative
        % Accuracy ... [TP + TN] / Total
        APtn = length(find(model==0&data==0));
        APtp = 0;
        for n = 1:numel(model)
            if model(n) > 0 && data(n) == model(n)
                APtp = APtp + 1;
            end
        end
%         APaccuracy = (APtn+APtp)/numel(model);
%         fprintf('\nAP detection accuracy: %s',...
%             num2str(APaccuracy));
%         iteration_matrix(5,iter-1) = APaccuracy;        

        % TPR ... true positive rate (TP / [TP + Miss])
        % FPR ... false positive rate (FA / [FA + TN])
        % these values can be plotted for different measurements to obtain ROC
        % curves
        APtpr = APtp / (APtp + APmiss);
        APfpr = APfalse / (APfalse + APtn);
        fprintf('\nAP true / false positive rates: %s / %s\n\n',...
            num2str(APtpr),num2str(APfpr));
        iteration_matrix(5,iter-1) = APtpr;
        iteration_matrix(6,iter-1) = APfpr;
        
        % confusion matrix (TP FP; FN TN)
        conf_matrix = [APtp APfalse; APmiss APtn];
        col_sum=sum(conf_matrix); %columns sum
        row_sum=sum(conf_matrix,2); %rows sum
        % Mathews correlation coefficient
        cc_m=(prod(diag(conf_matrix))-prod(diag(rot90(conf_matrix))))/...
            sqrt(prod([col_sum row_sum']));
        iteration_matrix(7,iter-1) = cc_m;
        
        % Alignment based on sequence homology (bioinformatics)
        observed_align_score = swalign(data_bin,model_bin,...
            'Alphabet','NT','GapOpen',20);
        rel_align_score = observed_align_score / best_align_score;
        iteration_matrix(8,iter-1) = rel_align_score;
        
        % Levenshtein distance
        ldist = levenshtein_distance(num2str(data_bin),num2str(model_bin));
        iteration_matrix(9,iter-1) = ldist;
        
        
    end
    % collect vector of all samples in results cell array
    for n = 1:measure_no
        results(n+1,param) = {iteration_matrix(n,:)};
    end
end
% calculate summary stats and plot them

APdetect.data = results;
clear results
APdetect.mean = APdetect.data;
APdetect.sd = APdetect.data;
APdetect.sem = APdetect.data;
APdetect.samples = numel(APdetect.data{2,2});
for n = 2:size(APdetect.data,1)
    for m = 2:size(APdetect.data,2)
        APdetect.mean(n,m) = {nanmean(APdetect.data{n,m})};
        APdetect.sd(n,m) = {nanstd(APdetect.data{n,m})};
        APdetect.sem(n,m) = {nanstd(APdetect.data{n,m})/sqrt(APdetect.samples)};
    end
end
save('APdetect_accuracy.mat','APdetect');

% first plot for GOF
x_label = handles.eval.var;
y_label = ['gof\_as\_' handles.deconv_pars.min_par_erf ' (\pm SEM)'];
name_string = [x_label '-' y_label];
name_string = strrep(name_string,'\_as\_','_as_');
name_string = strrep(name_string,' (\pm SEM)','');
current_plot = ap_ui_errorbar(cell2mat(APdetect.data(1,2:end)),...
    cell2mat(APdetect.mean(2,2:end)),cell2mat(APdetect.sem(2,2:end)),...
    'XLabel',x_label,'YLabel',y_label,'Name',name_string,...
    'Color','lines');
saveas(current_plot,[name_string '.fig']);
saveas(current_plot,[name_string '.png']);
close(current_plot);

% second plot for all AP counts (they are relative to the total expected 
% AP no and therefore on the same y-axis scale)
y_label = ['APcount (\pm SEM)'];
name_string = [x_label '-' y_label];
name_string = strrep(name_string,' (\pm SEM)','');
current_plot = ap_ui_errorbar(cell2mat(APdetect.data(1,2:end)),...
    cell2mat(APdetect.mean(3:5,2:end)),cell2mat(APdetect.sem(3:5,2:end)),...
    'XLabel',x_label,'YLabel',y_label,'Name',name_string,...
    'Color','lines','Legend',APdetect.mean(3:5,1));
saveas(current_plot,[name_string '.fig']);
saveas(current_plot,[name_string '.png']);
close(current_plot);

% third plot for Matthew's cc
y_label = ['Matthews_cc (\pm SEM)'];
name_string = [x_label '-' y_label];
name_string = strrep(name_string,' (\pm SEM)','');
current_plot = ap_ui_errorbar(cell2mat(APdetect.data(1,2:end)),...
    cell2mat(APdetect.mean(8,2:end)),cell2mat(APdetect.sem(8,2:end)),...
    'XLabel',x_label,'YLabel',y_label,'Name',name_string,...
    'Color','lines');
saveas(current_plot,[name_string '.fig']);
saveas(current_plot,[name_string '.png']);
close(current_plot);

% fourth plot for alignment score
y_label = ['RelativeAlignmentScore (\pm SEM)'];
name_string = [x_label '-' y_label];
name_string = strrep(name_string,' (\pm SEM)','');
current_plot = ap_ui_errorbar(cell2mat(APdetect.data(1,2:end)),...
    cell2mat(APdetect.mean(9,2:end)),cell2mat(APdetect.sem(9,2:end)),...
    'XLabel',x_label,'YLabel',y_label,'Name',name_string,...
    'Color','lines');
saveas(current_plot,[name_string '.fig']);
saveas(current_plot,[name_string '.png']);
close(current_plot);

% fourth plot for alignment score
y_label = ['LevenshteinDistance (\pm SEM)'];
name_string = [x_label '-' y_label];
name_string = strrep(name_string,' (\pm SEM)','');
current_plot = ap_ui_errorbar(cell2mat(APdetect.data(1,2:end)),...
    cell2mat(APdetect.mean(10,2:end)),cell2mat(APdetect.sem(10,2:end)),...
    'XLabel',x_label,'YLabel',y_label,'Name',name_string,...
    'Color','lines');
saveas(current_plot,[name_string '.fig']);
saveas(current_plot,[name_string '.png']);
close(current_plot);

varargout{1} = handles;


