function spikes = CleanSpikeTrain(spikes,freq)
% replace a realistic spike train with a binary vector
% 1 codes for AP
spikes = mpi_BandPassFilterTimeSeries(spikes,1/freq,2,freq*2);
max_spikes = max(spikes);
spikes(spikes<(max_spikes/2)) = 0;
spikes(spikes~=0) = 1;

