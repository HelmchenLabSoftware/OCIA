function gui_DeconvAlgChanged(alg)

if strcmp(alg,'Schmitt trigger')
    visible_handles = findobj('-regexp','Tag','schmitt_par_\w*');
    invisible_handles = findobj('-regexp','Tag','[^schmitt]\w*_par_\w*');
    set(visible_handles,'Visible','on');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Wiener FH')
    visible_handles = findobj('-regexp','Tag','wienerFH_par_\w*');
    invisible_handles = findobj('-regexp','Tag','[^wienerFH]\w*_par_\w*');
    set(visible_handles,'Visible','on');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Wiener ML')
    visible_handles = findobj('-regexp','Tag','wienerML_par_\w*');
    invisible_handles = findobj('-regexp','Tag','[^wienerML]\w*_par_\w*');
    set(visible_handles,'Visible','on');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Blind deconvolution')
    visible_handles = findobj('-regexp','Tag','blind_par_\w*');
    invisible_handles = findobj('-regexp','Tag','[^blind]\w*_par_\w*');
    set(visible_handles,'Visible','on');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Template match')
    invisible_handles = findobj('-regexp','Tag','\w*_par_\w*');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Integral')
    invisible_handles = findobj('-regexp','Tag','\w*_par_\w*');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Iterative correlation')
    invisible_handles = findobj('-regexp','Tag','\w*_par_\w*');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'Minimization')
    visible_handles = findobj('-regexp','Tag','min_par_\w*');
    invisible_handles = findobj('-regexp','Tag','[^min]\w*_par_\w*');
    set(visible_handles,'Visible','on');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
elseif strcmp(alg,'OOPSI')
    invisible_handles = findobj('-regexp','Tag','\w*_par_\w*');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
else
    invisible_handles = findobj('-regexp','Tag','\w*_par_\w*');
    set(invisible_handles,'Visible','off');
    setInfoText(alg);
    warndlg('Method not implemented yet!','!! Warning !!')
end

function setInfoText(alg)
text_handle = findobj('Tag','alg_descr_text');
if strcmp(alg,'Schmitt trigger')
    content = 'Implementation of Schmitt trigger thresholding using 2 thresholds. Copied directly from Igor macro FH.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Wiener FH')
    content = 'Implementation of Wiener filter deconvolution. Copied from Igor macro FH.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Wiener ML')
    content = 'Wiener deconvolution build around Matlabs own deconvwnr function.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Blind deconvolution')
    content = 'Blind deconvolution using maximum likelihood. Requires initial guess for deconvolution function. Optimal function is then derived iteratively.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Template match')
    content = 'Match Schmitt3-events against model exp. decay function. Provides correlation of data and generic exp. function plus fit of exp. function to data.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Integral')
    content = 'Calculates the cumulative integral and gradient of the denoised trace.';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Iterative correlation')
    content = 'Optimization approach using random AP placement with subsequent fine tuning. Works for low AP numbers (<10).';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'Minimization')
    content = 'Optimization approach that searches the global minimum in the spike time distribution using either simulated annealing or pattern search (requires Schmitt trigger+Integral).';
    set(text_handle,'String',content,'FontSize',7);
elseif strcmp(alg,'OOPSI')
    content = 'Runs fast_oopsi routine for spike detection from Joshua Vogelstein.';
    set(text_handle,'String',content,'FontSize',7);
else
    content = sprintf('\n   Currently not supported ...');
    set(text_handle,'String',content,'FontSize',7);
end
