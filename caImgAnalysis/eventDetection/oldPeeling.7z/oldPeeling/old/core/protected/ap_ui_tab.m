function varargout = ap_ui_tab(varargin)

%
% Usage: ap_ui_tab
%
% This script provides a template on how to create simple tab panels within a GUI. Each
% tab panel should be a different panel with different components and can be easily
% created with GUIDE. By using GUIDE, you can create as many different panels as you want
% and layout them in a comfortable way for building. When the script initiates, it places
% them one behind the other and handles their visibilities accordingly.
%
% The main idea behind ap_ui_tab is that you can create the tab labels by creating an
% equal number of static text uicontrols and layout them properly over an empty panel of
% proper defined size (see ap_ui_tab.fig in GUIDE). You can use then their positions to
% create axes objects (so that an edge line can be displayed around tabs without having to
% define the 'CData' property) and then create text objects (which are also more
% customizable than static text uicontrols) inside them. The control and highlighting of
% different tabs is performed through properly defined object callbacks (see code). The
% initial static text uicontrols are invisible in the final window. They are only used
% inside GUIDE for positioning purposes only.
%
% Make sure that the panel which is used for the proper placement of the static text
% uicontrols is the bigger one as the others will acquire its position. Ideally, the
% other panels should not be designed to be very different from the first one in terms of
% their dimensions because normally, in a multitab window all tabs should have the same
% size and the desired uicontrols should be fitted into them.
%
%
% this file written by Henry Luetcke (hluetck@gmail.com)
%

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @ap_ui_tab_OpeningFcn, ...
    'gui_OutputFcn',  @ap_ui_tab_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

%% GUI core
% --- Executes just before ap_ui_tab is made visible.
function ap_ui_tab_OpeningFcn(hObject, eventdata, handles, varargin)
if ismac
    set(handles.ap_ui_tab,'Renderer','zbuffer');
end
% Set the colors indicating a selected/unselected tab
handles.unselectedTabColor=get(handles.tab1text,'BackgroundColor');
handles.selectedTabColor=handles.unselectedTabColor-0.1;

% Set units to normalize for easier handling
set(handles.tab1text,'Units','normalized')
set(handles.tab2text,'Units','normalized')
set(handles.tab3text,'Units','normalized')
set(handles.tab1Panel,'Units','normalized')
set(handles.tab2Panel,'Units','normalized')
set(handles.tab3Panel,'Units','normalized')

% set(gcf,'Units','normalized','Position',[0.1 1 0.8 0.6]);

% Create tab labels (as many as you want according to following code template)

% Tab 1
pos1=get(handles.tab1text,'Position');
handles.a1=axes('Units','normalized',...
    'Box','on',...
    'XTick',[],...
    'YTick',[],...
    'Color',handles.selectedTabColor,...
    'Position',[pos1(1) pos1(2) pos1(3) pos1(4)+0.01],...
    'ButtonDownFcn','ap_ui_tab(''a1bd'',gcbo,[],guidata(gcbo))');
handles.t1=text('String','Simulation',...
    'Units','normalized',...
    'Position',[(pos1(3)-pos1(1))/2,pos1(2)/2+pos1(4)],...
    'HorizontalAlignment','left',...
    'VerticalAlignment','middle',...
    'Margin',0.001,...
    'FontSize',12,...
    'Backgroundcolor',handles.selectedTabColor,...
    'ButtonDownFcn','ap_ui_tab(''t1bd'',gcbo,[],guidata(gcbo))');

% Tab 2
pos2=get(handles.tab2text,'Position');
pos2(1)=pos1(1)+pos1(3);
handles.a2=axes('Units','normalized',...
    'Box','on',...
    'XTick',[],...
    'YTick',[],...
    'Color',handles.unselectedTabColor,...
    'Position',[pos2(1) pos2(2) pos2(3) pos2(4)+0.01],...
    'ButtonDownFcn','ap_ui_tab(''a2bd'',gcbo,[],guidata(gcbo))');
handles.t2=text('String','Deconvolution',...
    'Units','normalized',...
    'Position',[pos2(3)/2,pos2(2)/2+pos2(4)],...
    'HorizontalAlignment','left',...
    'VerticalAlignment','middle',...
    'Margin',0.001,...
    'FontSize',12,...
    'Backgroundcolor',handles.unselectedTabColor,...
    'ButtonDownFcn','ap_ui_tab(''t2bd'',gcbo,[],guidata(gcbo))');

% Tab 3
pos3=get(handles.tab3text,'Position');
pos3(1)=pos2(1)+pos2(3);
handles.a3=axes('Units','normalized',...
    'Box','on',...
    'XTick',[],...
    'YTick',[],...
    'Color',handles.unselectedTabColor,...
    'Position',[pos3(1) pos3(2) pos3(3) pos3(4)+0.01],...
    'ButtonDownFcn','ap_ui_tab(''a3bd'',gcbo,[],guidata(gcbo))');
handles.t3=text('String','Evaluation',...
    'Units','normalized',...
    'Position',[pos3(3)/2,pos3(2)/2+pos3(4)],...
    'HorizontalAlignment','left',...
    'VerticalAlignment','middle',...
    'Margin',0.001,...
    'FontSize',12,...
    'Backgroundcolor',handles.unselectedTabColor,...
    'ButtonDownFcn','ap_ui_tab(''t3bd'',gcbo,[],guidata(gcbo))');

% Manage panels (place them in the correct position and manage visibilities)
pan1pos=get(handles.tab1Panel,'Position');
set(handles.tab2Panel,'Position',pan1pos)
set(handles.tab3Panel,'Position',pan1pos)
set(handles.tab2Panel,'Visible','off')
set(handles.tab3Panel,'Visible','off')

% structures for simulation, deconvolution and evaluation
if nargin > 3
    % loading configuration is not yet implemented
    [handles common sim_pars deconv_pars] = ...
        SetGUIParameters(handles,varargin{4});
else
    [common sim_pars deconv_pars data eval] = GetGUIParameters(handles);
end
handles.sim_pars = sim_pars;
handles.deconv_pars = deconv_pars;
handles.common = common;
handles.data = data;
handles.eval = eval;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ap_ui_tab wait for user response (see UIRESUME)
% uiwait(handles.ap_ui_tabfig);


% --- Outputs from this function are returned to the command line.
function varargout = ap_ui_tab_OutputFcn(hObject, eventdata, handles)

% Text object 1 callback (tab 1)
function t1bd(hObject,eventdata,handles)
set(hObject,'BackgroundColor',handles.selectedTabColor)
set(handles.t2,'BackgroundColor',handles.unselectedTabColor)
set(handles.t3,'BackgroundColor',handles.unselectedTabColor)
set(handles.a1,'Color',handles.selectedTabColor)
set(handles.a2,'Color',handles.unselectedTabColor)
set(handles.a3,'Color',handles.unselectedTabColor)
set(handles.tab1Panel,'Visible','on')
set(handles.tab2Panel,'Visible','off')
set(handles.tab3Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);


% Text object 2 callback (tab 2)
function t2bd(hObject,eventdata,handles)
set(hObject,'BackgroundColor',handles.selectedTabColor)
set(handles.t1,'BackgroundColor',handles.unselectedTabColor)
set(handles.t3,'BackgroundColor',handles.unselectedTabColor)
set(handles.a2,'Color',handles.selectedTabColor)
set(handles.a1,'Color',handles.unselectedTabColor)
set(handles.a3,'Color',handles.unselectedTabColor)
set(handles.tab2Panel,'Visible','on')
set(handles.tab1Panel,'Visible','off')
set(handles.tab3Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);

% Text object 3 callback (tab 3)
function t3bd(hObject,eventdata,handles)
set(hObject,'BackgroundColor',handles.selectedTabColor)
set(handles.t1,'BackgroundColor',handles.unselectedTabColor)
set(handles.t2,'BackgroundColor',handles.unselectedTabColor)
set(handles.a3,'Color',handles.selectedTabColor)
set(handles.a1,'Color',handles.unselectedTabColor)
set(handles.a2,'Color',handles.unselectedTabColor)
set(handles.tab3Panel,'Visible','on')
set(handles.tab1Panel,'Visible','off')
set(handles.tab2Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);

% Axes object 1 callback (tab 1)
function a1bd(hObject,eventdata,handles)
set(hObject,'Color',handles.selectedTabColor)
set(handles.a2,'Color',handles.unselectedTabColor)
set(handles.a3,'Color',handles.unselectedTabColor)
set(handles.t1,'BackgroundColor',handles.selectedTabColor)
set(handles.t2,'BackgroundColor',handles.unselectedTabColor)
set(handles.t3,'BackgroundColor',handles.unselectedTabColor)
set(handles.tab1Panel,'Visible','on')
set(handles.tab2Panel,'Visible','off')
set(handles.tab3Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);

% Axes object 2 callback (tab 2)
function a2bd(hObject,eventdata,handles)
set(hObject,'Color',handles.selectedTabColor)
set(handles.a1,'Color',handles.unselectedTabColor)
set(handles.a3,'Color',handles.unselectedTabColor)
set(handles.t2,'BackgroundColor',handles.selectedTabColor)
set(handles.t1,'BackgroundColor',handles.unselectedTabColor)
set(handles.t3,'BackgroundColor',handles.unselectedTabColor)
set(handles.tab2Panel,'Visible','on')
set(handles.tab1Panel,'Visible','off')
set(handles.tab3Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);

% Axes object 3 callback (tab 3)
function a3bd(hObject,eventdata,handles)
set(hObject,'Color',handles.selectedTabColor)
set(handles.a1,'Color',handles.unselectedTabColor)
set(handles.a2,'Color',handles.unselectedTabColor)
set(handles.t3,'BackgroundColor',handles.selectedTabColor)
set(handles.t1,'BackgroundColor',handles.unselectedTabColor)
set(handles.t2,'BackgroundColor',handles.unselectedTabColor)
set(handles.tab3Panel,'Visible','on')
set(handles.tab1Panel,'Visible','off')
set(handles.tab2Panel,'Visible','off')
% handles = gui_doSimulation(handles);
guidata(hObject, handles);

%% Simulation
% --- Executes on button press in load_mat_button.
function load_mat_button_Callback(hObject, eventdata, handles)
[FileName,PathName,FilterIndex] = uigetfile(...
    {'*.mat';'*.*'},'Select file with spike train specification');
if FileName ~= 0
    matfile = fullfile(PathName,FileName);
else
    matfile = [];
end
if ~isempty(matfile)
    if FilterIndex == 1
        handles.data.spikes = LoadMatData(matfile);
    else
        handles.data.spikes = ReadEphys(matfile);
    end
    [handles.data.dur_ap handles.data.time_ap] = ...
        gui_CalculateTimeVector(handles.data.spikes,handles.sim_pars.freq_ap,[]);
    % threshold at half the max. value (for real spike trains)
%     handles.data.spikes(handles.data.spikes<(max(handles.data.spikes)/2)) = 0;
else
    handles.data.spikes = [];
    handles.data.time_ap = [];
end

handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes on button press in load_ca_pushbutton.
function load_ca_pushbutton_Callback(hObject, eventdata, handles)
[FileName,PathName,FilterIndex] = uigetfile(...
    {'*.mat';'*.txt'},'Select file with Ca trace specification');
if FileName ~= 0
   matfile = fullfile(PathName,FileName);
else
    matfile = [];
end
if ~isempty(matfile)
    if FilterIndex == 1
        handles.data.ca = LoadMatData(matfile);
    elseif FilterIndex == 2
        handles.data.ca = importdata(matfile);
        if isstruct(handles.data.ca)
            % assume data columns with first row headers
            colheaders = handles.data.ca.colheaders;
            [col status] = listdlg('PromptString','Select column',...
                'ListString',colheaders,'ListSize',[300 400]);
            handles.data.ca = handles.data.ca.data(:,col);
            handles.data.ca = handles.data.ca / 50;
        else
            handles.data.ca(:,1) = [];
        end
    end
    [handles.data.dur_ca handles.data.time_ca handles.sim_pars.baseline] = ...
        gui_CalculateTimeVector(handles.data.ca,handles.sim_pars.freq_ca,...
        str2num(get(handles.baseline_edit,'String')));
else
    handles.data.ca = [];
    handles.data.time = [];
end

handles = gui_doSimulation(handles);
guidata(hObject, handles);

function freq_ca_edit_Callback(hObject, eventdata, handles)
% need a ca vector (non-empty)
handles.sim_pars.freq_ca = round(str2double(get(hObject,'String')));
set(hObject,'String',int2str(handles.sim_pars.freq_ca));
if isfield(handles.data,'ca') && ~isempty(handles.data.ca)
    [handles.data.dur_ca handles.data.time_ca handles.sim_pars.baseline] = ...
        gui_CalculateTimeVector(handles.data.ca,handles.sim_pars.freq_ca,...
        str2num(get(handles.baseline_edit,'String')));
    handles = gui_doSimulation(handles);
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function freq_ca_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function freq_ap_edit_Callback(hObject, eventdata, handles)
% need an ap vector (non-empty)
handles.sim_pars.freq_ap = round(str2double(get(hObject,'String')));
set(hObject,'String',int2str(handles.sim_pars.freq_ap));
if isfield(handles.data,'spikes') && ~isempty(handles.data.spikes)
    [handles.data.dur_ap handles.data.time_ap] = ...
        gui_CalculateTimeVector(handles.data.spikes,handles.sim_pars.freq_ap,[]);
    handles = gui_doSimulation(handles);
end
guidata(hObject, handles);

function freq_ap_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function decay_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.ca_tau = str2double(get(hObject,'String'));
handles.deconv_pars.min_par_decay = handles.sim_pars.ca_tau;
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function decay_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ca_amp_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.ca_amp = str2double(get(hObject,'String'));
handles.deconv_pars.min_par_amp = handles.sim_pars.ca_amp;
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function ca_amp_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ca_snr_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.snr = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function ca_snr_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
% function decay_slider_Callback(hObject, eventdata, handles)
% handles.sim_pars.ca_tau = get(hObject,'Value');
% set(handles.decay_edit,'String',num2str(handles.sim_pars.ca_tau));
% handles = gui_doSimulation(handles);
% guidata(hObject, handles);
% 
% % --- Executes during object creation, after setting all properties.
% function decay_slider_CreateFcn(hObject, eventdata, handles)
% if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor',[.9 .9 .9]);
% end

function onset_delay_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.delay = str2double(get(hObject,'String')) / 1000;
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function onset_delay_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% % --- Executes on slider movement.
% function ca_amp_slider_Callback(hObject, eventdata, handles)
% handles.sim_pars.ca_amp = get(hObject,'Value');
% set(handles.ca_amp_edit,'String',num2str(handles.sim_pars.ca_amp));
% handles = gui_doSimulation(handles);
% guidata(hObject, handles);
% 
% % --- Executes during object creation, after setting all properties.
% function ca_amp_slider_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to ca_amp_slider (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: slider controls usually have a light gray background.
% if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor',[.9 .9 .9]);
% end
% 
% % --- Executes on slider movement.
% function ca_snr_slider_Callback(hObject, eventdata, handles)
% handles.sim_pars.snr = get(hObject,'Value');
% set(handles.ca_snr_edit,'String',num2str(handles.sim_pars.snr));
% handles = gui_doSimulation(handles);
% guidata(hObject, handles);
% 
% % --- Executes during object creation, after setting all properties.
% function ca_snr_slider_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to ca_snr_slider (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: slider controls usually have a light gray background.
% if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor',[.9 .9 .9]);
% end

function saturate_checkbox_Callback(hObject, eventdata, handles)
handles.sim_pars.saturate = get(hObject,'Value');
% always disable
handles.sim_pars.saturate = 0;
handles = gui_doSimulation(handles);
guidata(hObject, handles);



% --- Executes on button press in update_checkbox1.
function update_checkbox1_Callback(hObject, eventdata, handles)
handles.common.update = get(hObject,'Value');
set(handles.update_checkbox2,'Value',handles.common.update);
% set(handles.eval_checkbox,'Value',handles.common.update);
handles = gui_doSimulation(handles);
guidata(hObject,handles);

% --- Executes on button press in update_checkbox2.
function update_checkbox2_Callback(hObject, eventdata, handles)
handles.common.update = get(hObject,'Value');
set(handles.update_checkbox1,'Value',handles.common.update);
% set(handles.eval_checkbox,'Value',handles.common.update);
handles = gui_doSimulation(handles);
guidata(hObject,handles);


% --- Executes on button press in eval_checkbox.
function eval_checkbox_Callback(hObject, eventdata, handles)
handles.common.eval = get(hObject,'Value');
% set(handles.update_checkbox1,'Value',handles.common.update);
% set(handles.update_checkbox2,'Value',handles.common.update);
handles.common.eval = get(hObject,'Value');
handles = gui_doEvaluation(handles);
guidata(hObject,handles);

%% Preprocessing
% --- Executes on selection change in smooth_popupmenu.
function smooth_popupmenu_Callback(hObject, eventdata, handles)
handles.sim_pars.smooth_alg = get(hObject,'String');
handles.sim_pars.smooth_alg = handles.sim_pars.smooth_alg{get(hObject,'Value')};
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function smooth_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function windowSize_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.windowSize = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function windowSize_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function hp_filter_popupmenu_Callback(hObject, eventdata, handles)
handles.sim_pars.hp_filter = get(hObject,'String');
handles.sim_pars.hp_filter = handles.sim_pars.hp_filter{get(hObject,'Value')};
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function hp_filter_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function hp_cutoff_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.hp_cutoff = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function hp_cutoff_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




%% Deconvolution
% --- Executes on selection change in alg_popupmenu.
function alg_popupmenu_Callback(hObject, eventdata, handles)
previous_alg = handles.deconv_pars.alg;
handles.deconv_pars.alg = get(handles.alg_popupmenu,'String');
handles.deconv_pars.alg = handles.deconv_pars.alg{get(handles.alg_popupmenu,'Value')};
% if strcmp(handles.deconv_pars.alg,'Minimization')
%     if isfield(handles,'data') && isfield(handles.data,'schmitt3') ...
%             && isfield(handles.data,'dff_int')
%     else
%         previous_value = find(strcmp(get(handles.alg_popupmenu,'String'),...
%             previous_alg));
%         set(handles.alg_popupmenu,'Value',previous_value);
%         handles.deconv_pars.alg = previous_alg;
%         helpdlg('You MUST run Schmitt trigger and Integral to use this option.',...
%             'Invalid algorithm selection');
%     end
% end
gui_DeconvAlgChanged(handles.deconv_pars.alg);
handles = gui_doSimulation(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function alg_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to alg_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline_edit_Callback(hObject, eventdata, handles)
handles.sim_pars.baseline = str2num(get(hObject,'String'));
handles.sim_pars.baseline = round(handles.sim_pars.baseline...
    .*handles.sim_pars.freq_ca);
if isscalar(handles.sim_pars.baseline)
   handles.sim_pars.baseline = 1:handles.sim_pars.baseline;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function baseline_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to baseline_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% Schmitt settings
function schmitt_par_lthresh_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_lthresh = str2double(get(hObject,'String'));
if handles.deconv_pars.schmitt_par_lthresh >= ...
        get(handles.schmitt_par_lthresh_slider,'Min') && ...
        handles.deconv_pars.schmitt_par_lthresh <= ...
        get(handles.schmitt_par_lthresh_slider,'Max')
    set(handles.schmitt_par_lthresh_slider,'Value',...
        handles.deconv_pars.schmitt_par_lthresh);
else
    handles.deconv_pars.schmitt_par_lthresh = ...
        get(handles.schmitt_par_lthresh_slider,'Value');
    set(hObject,'String',num2str(handles.deconv_pars.schmitt_par_lthresh));
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_lthresh_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to schmitt_par_lthresh_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function schmitt_par_uthresh_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_uthresh = str2double(get(hObject,'String'));
if handles.deconv_pars.schmitt_par_uthresh >= ...
        get(handles.schmitt_par_uthresh_slider,'Min') && ...
        handles.deconv_pars.schmitt_par_uthresh <= ...
        get(handles.schmitt_par_uthresh_slider,'Max')
    set(handles.schmitt_par_uthresh_slider,'Value',...
        handles.deconv_pars.schmitt_par_uthresh);
else
    handles.deconv_pars.schmitt_par_uthresh = ...
        get(handles.schmitt_par_uthresh_slider,'Value');
    set(hObject,'String',num2str(handles.deconv_pars.schmitt_par_uthresh));
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_uthresh_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to schmitt_par_uthresh_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function schmitt_par_width_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_width = str2double(get(hObject,'String'));
if handles.deconv_pars.schmitt_par_width >= ...
        get(handles.schmitt_par_width_slider,'Min') && ...
        handles.deconv_pars.schmitt_par_width <= ...
        get(handles.schmitt_par_width_slider,'Max')
    set(handles.schmitt_par_width_slider,'Value',...
        handles.deconv_pars.schmitt_par_width);
else
    handles.deconv_pars.schmitt_par_width = ...
        get(handles.schmitt_par_width_slider,'Value');
    set(hObject,'String',num2str(handles.deconv_pars.schmitt_par_width));
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function schmitt_par_width_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function schmitt_par_minsep_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_minsep = str2double(get(hObject,'String'));
set(hObject,'String',num2str(handles.deconv_pars.schmitt_par_minsep));
if handles.deconv_pars.schmitt_par_minsep >= ...
        get(handles.schmitt_par_minsep_slider,'Min') && ...
        handles.deconv_pars.schmitt_par_minsep <= ...
        get(handles.schmitt_par_minsep_slider,'Max')
    set(handles.schmitt_par_minsep_slider,'Value',...
        handles.deconv_pars.schmitt_par_minsep);
else
    handles.deconv_pars.schmitt_par_minsep = ...
        get(handles.schmitt_par_minsep_slider,'Value');
    set(hObject,'String',num2str(handles.deconv_pars.schmitt_par_minsep));
end
if handles.deconv_pars.min_par_expand
    handles.deconv_pars.min_par_expand = ...
        handles.deconv_pars.schmitt_par_minsep;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_minsep_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function schmitt_par_lthresh_slider_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_lthresh = get(hObject,'Value');
set(handles.schmitt_par_lthresh_edit,'String',...
    num2str(handles.deconv_pars.schmitt_par_lthresh));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_lthresh_slider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function schmitt_par_uthresh_slider_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_uthresh = get(hObject,'Value');
set(handles.schmitt_par_uthresh_edit,'String',...
    num2str(handles.deconv_pars.schmitt_par_uthresh));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_uthresh_slider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function schmitt_par_width_slider_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_width = get(hObject,'Value');
set(handles.schmitt_par_width_edit,'String',...
    num2str(handles.deconv_pars.schmitt_par_width));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function schmitt_par_width_slider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function schmitt_par_minsep_slider_Callback(hObject, eventdata, handles)
handles.deconv_pars.schmitt_par_minsep = get(hObject,'Value');
set(hObject,'Value',handles.deconv_pars.schmitt_par_minsep);
set(handles.schmitt_par_minsep_edit,'String',...
    num2str(handles.deconv_pars.schmitt_par_minsep));
if handles.deconv_pars.min_par_expand
    handles.deconv_pars.min_par_expand = ...
        handles.deconv_pars.schmitt_par_minsep;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function schmitt_par_minsep_slider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%% Wiener
function wienerFH_par_phi1_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.wienerFH_par_phi1 = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function wienerFH_par_phi1_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wienerFH_par_phi1_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function wienerFH_par_phi2_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.wienerFH_par_phi2 = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function wienerFH_par_phi2_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wienerFH_par_phi2_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function wienerFH_par_phi3_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.wienerFH_par_phi3 = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function wienerFH_par_phi3_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wienerFH_par_phi3_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function wienerML_par_cutoff_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.wienerML_par_cutoff = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function wienerML_par_cutoff_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wienerML_par_cutoff_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function blind_par_cutoff_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.blind_par_cutoff = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function blind_par_cutoff_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blind_par_cutoff_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in wienerML_par_baseYN_checkbox.
function wienerML_par_baseYN_checkbox_Callback(hObject, eventdata, handles)
handles.deconv_pars.wienerML_par_baseYN = get(hObject,'Value');
if get(hObject,'Value') == 1
    warndlg('Experimental! Use with caution','!! Warning !!')
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes on button press in blind_par_baseYN_checkbox.
function blind_par_baseYN_checkbox_Callback(hObject, eventdata, handles)
handles.deconv_pars.blind_par_baseYN = get(hObject,'Value');
if get(hObject,'Value') == 1
    warndlg('Experimental! Use with caution','!! Warning !!')
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes on button press in blind_par_weightYN_checkbox.
function blind_par_weightYN_checkbox_Callback(hObject, eventdata, handles)
handles.deconv_pars.blind_par_weightYN = get(hObject,'Value');
if get(hObject,'Value') == 1
    warndlg('Experimental! Use with caution','!! Warning !!')
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes on button press in blind_par_psfYN_checkbox.
function blind_par_psfYN_checkbox_Callback(hObject, eventdata, handles)
handles.deconv_pars.blind_par_psfYN = get(hObject,'Value');
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function blind_par_iters_edit_Callback(hObject, eventdata, handles)
handles.deconv_pars.blind_par_iters = str2double(get(hObject,'String'));
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function blind_par_iters_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blind_par_iters_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% Minimize
function min_par_method_popupmenu_Callback(hObject, eventdata, handles)
handles.deconv_pars.min_par_method = get(hObject,'String');
handles.deconv_pars.min_par_method = handles.deconv_pars.min_par_method...
    {get(hObject,'Value')};
if ~strcmp(handles.deconv_pars.min_par_opt,'default')
   if strcmp(handles.deconv_pars.min_par_method,'Simulated Annealing')
       if ~isfield(handles.deconv_pars.min_par_opt,'AnnealingFcn')
           warning('Invalid options structure. Using defaults.');
           handles.deconv_pars.min_par_opt = 'default';
           set(handles.min_par_opt_popupmenu,'Value',1);
       end
   elseif strcmp(handles.deconv_pars.min_par_method,'Pattern Search')
       if ~isfield(handles.deconv_pars.min_par_opt,'MeshContraction')
           warning('Invalid options structure. Using defaults.');
           handles.deconv_pars.min_par_opt = 'default';
           set(handles.min_par_opt_popupmenu,'Value',1);
       end
   elseif strcmp(handles.deconv_pars.min_par_method,'Genetic')
       if ~isfield(handles.deconv_pars.min_par_opt,'PopulationType')
           warning('Invalid options structure. Using defaults.');
           handles.deconv_pars.min_par_opt = 'default';
           set(handles.min_par_opt_popupmenu,'Value',1);
       end
   end
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);


function min_par_method_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function min_par_erf_popupmenu_Callback(hObject, eventdata, handles)
handles.deconv_pars.min_par_erf = get(hObject,'String');
handles.deconv_pars.min_par_erf = handles.deconv_pars.min_par_erf...
    {get(hObject,'Value')};
handles = gui_doSimulation(handles);
guidata(hObject, handles);



function min_par_erf_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function min_par_opt_popupmenu_Callback(hObject, eventdata, handles)
handles.deconv_pars.min_par_opt = get(hObject,'String');
handles.deconv_pars.min_par_opt = handles.deconv_pars.min_par_opt...
    {get(hObject,'Value')};
if ~strcmp(handles.deconv_pars.min_par_opt,'default')
    handles.deconv_pars.min_par_opt = evalin('base',handles.deconv_pars.min_par_opt);
    % check what kind of structure we have and adjust algorithm accordingly
    if isfield(handles.deconv_pars.min_par_opt,'AnnealingFcn')
        fprintf('\nDetected SA options structure. Adjusting settings for SA.\n');
        if ~strcmp(handles.deconv_pars.min_par_method,'Simulated Annealing')
            handles.deconv_pars.min_par_method = 'Simulated Annealing';
            set(handles.min_par_method_popupmenu,'Value',1);
        end
    elseif isfield(handles.deconv_pars.min_par_opt,'MeshContraction')
        fprintf('\nDetected PS options structure. Adjusting settings for PS.\n');
        if ~strcmp(handles.deconv_pars.min_par_method,'Pattern Search')
            handles.deconv_pars.min_par_method = 'Pattern Search';
            set(handles.min_par_method_popupmenu,'Value',2);
        end
    elseif isfield(handles.deconv_pars.min_par_opt,'PopulationType')
        fprintf('\nDetected GA options structure. Adjusting settings for GA.\n');
        if ~strcmp(handles.deconv_pars.min_par_method,'Genetic')
            handles.deconv_pars.min_par_method = 'Genetic';
            set(handles.min_par_method_popupmenu,'Value',3);
        end
    else
        warning('Invalid options structure. Using defaults.');
        handles.deconv_pars.min_par_method = 'default';
        set(hObject,'Value',1);
    end
end
% add workspace variables
vars = evalin('base','who');
vars = ['default'; vars];
set(hObject,'String',vars);
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function min_par_opt_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function min_par_decay_edit_Callback(hObject, eventdata, handles)
if ~isempty(get(hObject,'String'))
    handles.deconv_pars.min_par_decay = str2num(get(hObject,'String'));
else
    handles.deconv_pars.min_par_decay = ...
        handles.sim_pars.ca_tau;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);


function min_par_decay_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function min_par_amp_edit_Callback(hObject, eventdata, handles)
if ~isempty(get(hObject,'String'))
    handles.deconv_pars.min_par_amp = str2num(get(hObject,'String'));
else
    handles.deconv_pars.min_par_amp = ...
        handles.sim_pars.ca_amp;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);


function min_par_amp_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function min_par_satur_edit_Callback(hObject, eventdata, handles)
if ~isempty(get(hObject,'String'))
    handles.deconv_pars.min_par_satur = str2num(get(hObject,'String'));
else
    handles.deconv_pars.min_par_satur = ...
        handles.sim_pars.satur_amp;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function min_par_satur_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function min_par_expand_checkbox_Callback(hObject, eventdata, handles)
if get(hObject,'Value')
    handles.deconv_pars.min_par_expand = ...
        handles.deconv_pars.schmitt_par_minsep;
else
    handles.deconv_pars.min_par_expand = 0;
end
handles = gui_doSimulation(handles);
guidata(hObject, handles);

function min_par_smooth_checkbox_Callback(hObject, eventdata, handles)
handles.deconv_pars.min_par_smooth = get(hObject,'Value');
handles = gui_doSimulation(handles);
guidata(hObject, handles);

% --- Executes on button press in keep_fig_checkbox1.
function keep_fig_checkbox1_Callback(hObject, eventdata, handles)
handles.common.keep_figs = get(hObject,'Value');
set(handles.keep_fig_checkbox2,'Value',handles.common.keep_figs);
set(handles.keep_fig_checkbox3,'Value',handles.common.keep_figs);
guidata(hObject, handles);

% --- Executes on button press in keep_fig_checkbox2.
function keep_fig_checkbox2_Callback(hObject, eventdata, handles)
handles.common.keep_figs = get(hObject,'Value');
set(handles.keep_fig_checkbox1,'Value',handles.common.keep_figs);
set(handles.keep_fig_checkbox3,'Value',handles.common.keep_figs);
guidata(hObject, handles);

% --- Executes on button press in keep_fig_checkbox3.
function keep_fig_checkbox3_Callback(hObject, eventdata, handles)
handles.common.keep_figs = get(hObject,'Value');
set(handles.keep_fig_checkbox1,'Value',handles.common.keep_figs);
set(handles.keep_fig_checkbox2,'Value',handles.common.keep_figs);
guidata(hObject, handles);

%% Evaluation
% --- Executes on selection change in criteria_popupmenu.
function criteria_popupmenu_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function criteria_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in param_eval_popupmenu.
function param_eval_popupmenu_Callback(hObject, eventdata, handles)
handles.eval.var = get(hObject,'String');
handles.eval.var = handles.eval.var{get(hObject,'Value')};
handles = gui_doEvaluation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function param_eval_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function var_range_eval_edit_Callback(hObject, eventdata, handles)
handles.eval.range = str2num(get(hObject,'String'));
handles = gui_doEvaluation(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function var_range_eval_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function load_range_pushbutton_Callback(hObject, eventdata, handles)
[FileName,PathName] = uigetfile(...
    '.mat','Select mat-file with range specification');
if FileName ~= 0
   matfile = fullfile(PathName,FileName);
else
    matfile = [];
end
if ~isempty(matfile)
    handles.eval.range = LoadMatData(matfile);
else
    handles.eval.range = [];
end


function eval_samples_edit_Callback(hObject, eventdata, handles)
handles.eval.samples = round(str2double(get(hObject,'String')));
handles = gui_doEvaluation(handles);
guidata(hObject, handles);


function eval_samples_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function eval_output_popupmenu_Callback(hObject, eventdata, handles)
handles.eval.output = get(hObject,'String');
handles.eval.output = handles.eval.output{get(hObject,'Value')};
handles = gui_doEvaluation(handles);
guidata(hObject, handles);


function eval_output_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function logfile_eval_pushbutton_Callback(hObject, eventdata, handles)
[filename pathname] = uiputfile('*.txt','Save logfile as',...
    fullfile(pwd,'logfile.txt'));
if ~isempty(filename)
    handles.eval.logfile = fullfile(pathname,filename);
else
    handles.eval.logfile = '';
end
set(handles.logfile_eval_edit,'String',handles.eval.logfile);
guidata(hObject, handles);

function logfile_eval_edit_Callback(hObject, eventdata, handles)
handles.eval.logfile = get(hObject,'String');
handles = gui_doEvaluation(handles);
guidata(hObject, handles);

function logfile_eval_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% Menus
function menu_file_Callback(hObject, eventdata, handles)


function menu_file_save_Callback(hObject, eventdata, handles)
[file,path,FilterIndex] = uiputfile({'*.mat','MAT files (*.mat)';...
    '*.txt','Text files (*.txt)'},'Save As');
if file
    if FilterIndex == 1
        ap_ui.common = handles.common;
        ap_ui.sim_pars = handles.sim_pars;
        ap_ui.deconv_pars = handles.deconv_pars;
        if isfield(handles,'eval')
            ap_ui.eval = handles.eval;
        end
        if isfield(handles,'data')
            ap_ui.data = handles.data;
        end
        save(fullfile(path,file),'ap_ui');
        clear ap_ui
    elseif FilterIndex == 2
        ap_ui.common = handles.common;
        ap_ui.sim_pars = handles.sim_pars;
        ap_ui.deconv_pars = handles.deconv_pars;
        if isfield(handles,'eval')
            ap_ui.eval = handles.eval;
        end
        if isfield(handles,'data')
            ap_ui.data = handles.data;
        end
        ap_ui_Struct2Txt(ap_ui,fullfile(path,file));
        clear ap_ui
    end
else
    helpdlg('Please select a file for writing.',...
        'Nothing saved ...');
end

function menu_file_open_Callback(hObject, eventdata, handles)
helpdlg('This will restore a previous GUI state in future versions.',...
    'Currently not supported');

function menu_file_import_seg_Callback(hObject, eventdata, handles)
[FileName PathName] = uigetfile('.txt','Select segmentation results file');
if ~FileName
   errordlg('Please select a valid segmentation results file'); 
   return
end
seg_results = importdata(fullfile(PathName,FileName));
% assume 4 initial columns of extra information
% assume 1 time course per row
cell_no = size(seg_results,1);
prompt = sprintf('Choose cell number (%s segmentations)',...
    int2str(cell_no));
target_cell = inputdlg(prompt,'Select cell for analysis',1,{'1'});
target_cell = str2num(cell2mat(target_cell));
ca_trace = seg_results(target_cell,4:end);
handles.data.ca = ca_trace;
[handles.data.dur_ca handles.data.time_ca] = ...
            gui_CalculateTimeVector(handles.data.ca,handles.sim_pars.freq_ca,[]);
guidata(hObject, handles);

function menu_file_import_sce3_Callback(hObject, eventdata, handles)
% need to check update checkbox for figure labelling to work
set(handles.update_checkbox1,'Value',1);
handles.common.update = get(handles.update_checkbox1,'Value');
vars = evalin('base','who');
if ~isempty(vars)
    [choice,status] = listdlg('PromptString','Select a variable:',...
        'SelectionMode','single',...
        'ListString',vars);
    if ~status return; end
else
    warndlg('No variables in base workspace!');return
end
target_var = vars{choice};
config = evalin('base',target_var);

% backwards compatibility
if isfield(config,'roi_dff_trace')
   config.roi_stats = config.roi_dff_trace; 
end

if ~iscell(config.roi_stats)
    roi_number = 1;
    handles.data.ca = config.roi_stats;
else
    if length(config.roi_stats) > 1
        % multiple ROIs have been encoded
        roi_number = length(config.roi_stats);
        % ask user which ROI to choose
        if isfield(config,'roi_id')
            list_str = config.roi_id;
        else
            list_str = {'1'};
            for n = 2:roi_number
                list_str{length(list_str)+1} = int2str(n);
            end
        end
        [selection] = listdlg('PromptString','Select a ROI:',...
            'SelectionMode','single',...
            'ListString',list_str);
        roi_number = list_str{selection};
        handles.data.ca = config.roi_stats{selection};
    else
        roi_number = '1';
        handles.data.ca = config.roi_stats{1};
        selection = 1;
    end
end
handles.data.spikes = config.ephys;
handles.sim_pars.freq_ap = config.freq_ap;
set(handles.freq_ap_edit,'String',num2str(config.freq_ap));
handles.sim_pars.freq_ca = config.freq_ca;
set(handles.freq_ca_edit,'String',num2str(config.freq_ca));
if length(config.baseline) > 1
    base_string = sprintf('[%s %s]',num2str(config.baseline(1)),...
        num2str(config.baseline(2)));
else
    base_string = sprintf('[%s]',num2str(config.baseline(1)));
end
set(handles.baseline_edit,'String',base_string);
handles.sim_pars.baseline = str2num(get(handles.baseline_edit,'String'));
handles.sim_pars.baseline = round(handles.sim_pars.baseline...
    .*handles.sim_pars.freq_ca);
[handles.data.dur_ca handles.data.time_ca] = gui_CalculateTimeVector(...
    handles.data.ca,handles.sim_pars.freq_ca,[]);
% correct Ca-trace for ROI acquisition time
if isfield(config,'ca_shift')
    if iscell(config.ca_shift)
       ca_shift = config.ca_shift{selection};
    else
        ca_shift = config.ca_shift;
    end
    handles.data.dur_ca = handles.data.dur_ca - ca_shift;
    handles.data.time_ca = handles.data.time_ca - ca_shift;
    fprintf('\nAdjusted Ca time by %1.2f frames based on mean ROI location\n',...
        ca_shift/(1/config.freq_ca));
end
[handles.data.dur_ap handles.data.time_ap] = gui_CalculateTimeVector(...
    handles.data.spikes,handles.sim_pars.freq_ap,[]);
clear config
handles = gui_doSimulation(handles);
set(findobj('Tag','ap_ui_fig'),'Name',...
    [target_var ' - ROI ' roi_number]);
guidata(hObject, handles);


function menu_file_exit_Callback(hObject, eventdata, handles)
current_fig = gcf;
% delete any associated plot windows
delete(findobj('Tag','ap_ui_fig'));
% destroy the GUI
delete(current_fig);

% Extras menu items
function menu_extras_Callback(hObject, eventdata, handles)

function menu_extras_clear_Callback(hObject, eventdata, handles)
data_struct = handles.data;
names = fieldnames(data_struct);
for n = 1:numel(names)
    data_struct.(names{n}) = [];
    fprintf('Data field ''%s'' now empty\n',names{n});
end
handles.data = data_struct;
clear data_struct names
guidata(hObject, handles);

function menu_extras_fixRand_Callback(hObject, eventdata, handles)
if strcmp(get(hObject, 'Checked'),'on')
    set(hObject,'Checked','off');
    rand('twister',etime(clock,[2008 1 1 0 0 0])*10);
    randn('state',etime(clock,[2008 1 1 0 0 0])*10);
else
    set(hObject,'Checked','on');
    handles.common.randSeed = inputdlg('Random seed','Select a seed',1,...
        cellstr(num2str(handles.common.randSeed(1))));
    if ~isnan(str2double(handles.common.randSeed{1}))
        handles.common.randSeed = str2double(handles.common.randSeed);
    else
        % treat input as 'base' workspace variable
        handles.common.randSeed = evalin('base',...
            char(handles.common.randSeed));
    end
end
handles.common.randSeedPos = 1;
handles.common.fixRand = get(hObject,'Checked');
guidata(hObject, handles);

function menu_extras_base_Callback(hObject, eventdata, handles)
global HANDLES
handle_copy.common = handles.common;
handle_copy.sim_pars = handles.sim_pars;
handle_copy.deconv_pars = handles.deconv_pars;
if isfield(handles,'data')
    handle_copy.data = handles.data;
end
HANDLES = handle_copy;
evalin('base', 'global HANDLES; ap_ui=HANDLES; clear HANDLES');
clear HANDLES handle_copy


function menu_extras_spike_Callback(hObject, eventdata, handles)
in_args = {'Duration / ms' 'Initial baseline / ms' 'Final baseline / ms' ...
    'AP frequency / Hz'};
default_params = {'20000' '2000' '2000' '1'};
pars = inputdlg(in_args,'Spike Train Parameters',1,default_params);
handles.data.spikes = MakeStochasticSpikeTrain(str2num(pars{1}),...
    str2num(pars{2}),str2num(pars{3}),str2num(pars{4}),handles.sim_pars.freq_ap);
[handles.data.dur_ap handles.data.time_ap] = ...
    gui_CalculateTimeVector(handles.data.spikes,handles.sim_pars.freq_ap,[]);
guidata(hObject, handles);

function menu_extras_figure_Callback(hObject, eventdata, handles)
prompt = {'Graph number:'};
dlg_title = 'Select graph to increase';
num_lines = 1;
def = {'1'};
number = str2num(cell2mat(inputdlg(prompt,dlg_title,num_lines,def)));
[handles,plot_ydata,plot_xdata,plot_legend] = ...
    gui_SetupPlotData(handles);
plot_ydata = plot_ydata(number,:);
plot_xdata = plot_xdata(number,:);
plot_legend = plot_legend(number,:);
hPlot_large = PlotVectors(plot_ydata,'XData',plot_xdata);
% tag figure
set(hPlot_large,'Tag','ap_ui_fig');
set(hPlot_large,'Units','normalized','Position',[0.01 0.2 0.98 0.5]);


% e.o.f.





% --------------------------------------------------------------------
function menu_file_import_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file_import (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





