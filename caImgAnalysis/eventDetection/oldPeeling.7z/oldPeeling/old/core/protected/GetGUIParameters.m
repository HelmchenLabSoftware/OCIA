function [common sim_pars deconv_pars data eval] = GetGUIParameters(handles)

%% common parameters
common.basedir = fileparts(mfilename('fullpath'));
common.keep_figs = get(handles.keep_fig_checkbox1,'Value');
common.update = get(handles.update_checkbox1,'Value');
common.eval = get(handles.eval_checkbox,'Value');
common.fixRand = get(handles.menu_extras_fixRand,'Checked');
common.randSeed = 10;
common.randSeedPos = 1;
% not (yet) in GUI
common.doPlot = 1; % turn off plotting (doPlot = 0)

%% simulation parameters
sim_pars.freq_ca = str2double(get(handles.freq_ca_edit,'String'));
sim_pars.freq_ap = str2double(get(handles.freq_ap_edit,'String'));
sim_pars.baseline = str2num(get(handles.baseline_edit,'String'));
sim_pars.baseline = round(sim_pars.baseline...
    .*sim_pars.freq_ca);
if isscalar(sim_pars.baseline)
   sim_pars.baseline = 1:sim_pars.baseline;
end
sim_pars.ca_amp = str2double(get(handles.ca_amp_edit,'String'));
sim_pars.ca_tau = str2double(get(handles.decay_edit,'String'));
sim_pars.snr = str2double(get(handles.ca_snr_edit,'String'));
sim_pars.delay = str2double(get(handles.onset_delay_edit,'String'))/1000;

%% Preprocessing parameters
sim_pars.smooth_alg = get(handles.smooth_popupmenu,'String');
sim_pars.smooth_alg = sim_pars.smooth_alg{get(handles.smooth_popupmenu,'Value')};
sim_pars.windowSize = str2double(get(handles.windowSize_edit,'String'));
sim_pars.hp_filter = get(handles.hp_filter_popupmenu,'String');
sim_pars.hp_filter = sim_pars.hp_filter{get(handles.hp_filter_popupmenu,'Value')};
sim_pars.hp_cutoff = str2double(get(handles.hp_cutoff_edit,'String'));

sim_pars.saturate = get(handles.saturate_checkbox,'Value');
% saturation not implemented --> always disable
sim_pars.saturate = 0;

%% parameters for spike reconstruction
deconv_pars.alg = get(handles.alg_popupmenu,'String');
deconv_pars.alg = deconv_pars.alg{get(handles.alg_popupmenu,'Value')};
deconv_pars.blind_par_psfYN = get(handles.blind_par_psfYN_checkbox,'Value');
set(handles.blind_par_weightYN_checkbox,'Value',0);
deconv_pars.blind_par_weightYN = get(handles.blind_par_weightYN_checkbox,'Value');
set(handles.blind_par_baseYN_checkbox,'Value',0);
deconv_pars.blind_par_baseYN = get(handles.blind_par_baseYN_checkbox,'Value');
deconv_pars.blind_par_cutoff = str2double(get(handles.blind_par_cutoff_edit,'String'));
deconv_pars.blind_par_iters = str2double(get(handles.blind_par_iters_edit,'String'));
set(handles.wienerML_par_baseYN_checkbox,'Value',0);
deconv_pars.wienerML_par_baseYN = get(handles.wienerML_par_baseYN_checkbox,'Value');
deconv_pars.wienerML_par_cutoff = str2double(get(handles.wienerML_par_cutoff_edit,'String'));
deconv_pars.wienerFH_par_phi3 = str2double(get(handles.wienerFH_par_phi3_edit,'String'));
deconv_pars.wienerFH_par_phi2 = str2double(get(handles.wienerFH_par_phi2_edit,'String'));
deconv_pars.wienerFH_par_phi1 = str2double(get(handles.wienerFH_par_phi1_edit,'String'));
deconv_pars.schmitt_par_width = str2double(get(handles.schmitt_par_width_edit,'String'));
deconv_pars.schmitt_par_minsep = round(str2double(get(handles.schmitt_par_minsep_edit,'String')));
deconv_pars.schmitt_par_uthresh = str2double(get(handles.schmitt_par_uthresh_edit,'String'));
deconv_pars.schmitt_par_lthresh = str2double(get(handles.schmitt_par_lthresh_edit,'String'));
deconv_pars.min_par_method = get(handles.min_par_method_popupmenu,'String');
deconv_pars.min_par_method = deconv_pars.min_par_method{get(handles.min_par_method_popupmenu,'Value')};
deconv_pars.min_par_erf = get(handles.min_par_erf_popupmenu,'String');
deconv_pars.min_par_erf = deconv_pars.min_par_erf{get(handles.min_par_erf_popupmenu,'Value')};
if ~isempty(get(handles.min_par_decay_edit,'String'))
    deconv_pars.min_par_decay = str2num(get(handles.min_par_decay_edit,'String'));
else
    deconv_pars.min_par_decay = sim_pars.ca_tau;
end
if ~isempty(get(handles.min_par_amp_edit,'String'))
    deconv_pars.min_par_amp = str2num(get(handles.min_par_amp_edit,'String'));
else
    deconv_pars.min_par_amp = sim_pars.ca_amp;
end
if get(handles.min_par_expand_checkbox,'Value')
    deconv_pars.min_par_expand = deconv_pars.schmitt_par_minsep;
else
    deconv_pars.min_par_expand = 0;
end
deconv_pars.min_par_smooth = get(handles.min_par_smooth_checkbox,'Value');
% set parameter fields (in)visible depending on deconvolution algorithm
gui_DeconvAlgChanged(deconv_pars.alg);

%% data fields
data.spikes = [];
data.ca = [];

%% evaluation fields
eval.var = get(handles.param_eval_popupmenu,'String');
eval.var = eval.var{get(handles.param_eval_popupmenu,'Value')};
eval.output = get(handles.eval_output_popupmenu,'String');
eval.output = eval.output{get(handles.eval_output_popupmenu,'Value')};
eval.range = str2num(get(handles.var_range_eval_edit,'String'));
eval.samples = round(str2double(get(handles.eval_samples_edit,'String')));
eval.logfile = '';

%% General
% change some GUI settings
% modify parameters for Schmitt thresholds
set(handles.schmitt_par_lthresh_slider,'Min',0.5);
set(handles.schmitt_par_lthresh_slider,'Max',10);
set(handles.schmitt_par_uthresh_slider,'Min',0.5);
set(handles.schmitt_par_uthresh_slider,'Max',10);
set(handles.schmitt_par_width_edit,'TooltipString',...
    'Width for accepting for Schmitt3 in s');
set(handles.schmitt_par_width_slider,'TooltipString',...
    'Width for accepting for Schmitt3 in s');
set(handles.schmitt_par_width_edit,'String','2');
set(handles.schmitt_par_width_slider,'Value',2);
set(handles.schmitt_par_width_slider,'Min',0);
set(handles.schmitt_par_width_slider,'Max',10);
set(handles.schmitt_par_minsep_edit,'TooltipString',...
    'Min. distance of Schmitt3 segments in s (Segments separated by less then this time will be joined)');
set(handles.schmitt_par_minsep_slider,'TooltipString',...
    'Min. distance of Schmitt3 segments in s (Segments separated by less then this time will be joined)');
set(handles.schmitt_par_minsep_edit,'String','1.5');
set(handles.schmitt_par_minsep_slider,'Value',1.5);
set(handles.schmitt_par_minsep_slider,'Min',0);
set(handles.schmitt_par_minsep_slider,'Max',50);

% more reconstruction algorithms
alg_text = get(handles.alg_popupmenu,'String');
alg_text = [alg_text; 'OOPSI'];
set(handles.alg_popupmenu,'String',alg_text);

% more optimization algorithms
alg_text = get(handles.min_par_method_popupmenu,'String');
alg_text = [alg_text; 'Scatter Search'];
set(handles.min_par_method_popupmenu,'String',alg_text);

% add workspace variables to min_par_opt_popupmenu
vars = evalin('base','who');
vars = ['default'; vars];
set(handles.min_par_opt_popupmenu,'String',vars);
set(handles.min_par_opt_popupmenu,'Value',1);
deconv_pars.min_par_opt = get(handles.min_par_opt_popupmenu,'String');
deconv_pars.min_par_opt = deconv_pars.min_par_opt...
    {get(handles.min_par_opt_popupmenu,'Value')};
if ~strcmp(deconv_pars.min_par_opt,'default')
    deconv_pars.min_par_opt = evalin('base',deconv_pars.min_par_opt);
end



% e.o.f.


