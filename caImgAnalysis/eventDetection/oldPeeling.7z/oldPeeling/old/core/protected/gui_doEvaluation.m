function varargout = gui_doEvaluation(handles)
% don't do anything if update box not checked
if handles.common.eval == 0
    varargout{1} = handles;
    return
end
disabled_items = findobj('Enable','on');
set(disabled_items,'Enable','off');
% switch status indicator to 'busy'
%     set(handles.status_text1,'Visible','off');
%     set(handles.busy_text1,'Visible','on');
set(findobj('Tag','status_text1'),'Visible','off');
set(findobj('Tag','busy_text1'),'Visible','on','Enable','on');
drawnow

if ~isempty(handles.eval.logfile)
    fid = fopen(handles.eval.logfile,'w');
    fclose(fid);
    diary(handles.eval.logfile);
end

start_time = clock;
username = char(java.lang.System.getProperty('user.name'));
osname = char(java.lang.System.getProperty('os.name'));
fprintf('\n\nEvaluation started on %s by user %s on %s\n\n',...
    datestr(start_time),username,osname);


% there are three possible scenarios to continue from here, based on which
% inputs the user has provided
% 1. Spike train only --> Simulation (perform convolution, deconvolution
% and evaluation)
% 2. Ca trace only --> 'Real-world' scenario (perform deconvolution and
% return the putative spike train; evaluation not possible in this case)
% 3. Both Spike train and Ca trace --> assess 'goodness' of algorithm
% (deconvolve Ca trace and compare with the provided spike train)
% these possibilities will be coded in handles.common.scenario
if ~isempty(handles.data.spikes) && isempty(handles.data.ca)
    handles.common.scenario = 1;
elseif isempty(handles.data.spikes) && ~isempty(handles.data.ca)
    handles.common.scenario = 2;
    restoreGUIstate;
    errordlg('Cannot do evaluation with just a Ca trace. Please provide a spike train.',...
        'Input Error');
    varargout{1} = handles;
    return
elseif ~isempty(handles.data.spikes) && ~isempty(handles.data.ca)
    handles.common.scenario = 3;
    restoreGUIstate;
    errordlg('Comparison of real Ca trace with real spike trains currently not supported.',...
        'Input Error');
    varargout{1} = handles;
    return
else
    restoreGUIstate;
    errordlg('You MUST provide a spike train to run evaluation',...
        'Input Error');
    varargout{1} = handles;
    return
end

% check for required information (fields 'spikes' and 'spikes_predict',
% both not empty)
% if ~isfield(handles.data,'spikes') || ~isfield(handles.data,'spikes_predict') ...
%         || isempty(handles.data.spikes) || isempty(handles.data.spikes_predict)
%     restoreGUIstate;
%     errordlg(...
%         'Provide non-empty observed and predicted spike trains to perform evaluation!',...
%         'Consistency Error');
%     varargout{1} = handles;
%     return
% end

% if we run a simulation, multiple iterations can be performed for multiple
% parameter values (as defined in GUI)
if handles.common.scenario == 1
    % save results of iterations in 2D cell array with
    % numel(handles.eval.range) rows and handles.eval.samples columns
    % each entry contains the predicted spike train for the given combination
    % of parameter and sampling
    % same cell array for GOF measure from minimization
    spike_model = cell(numel(handles.eval.range)+1,handles.eval.samples+1);
    %     spike_model(2:end,1) = {handles.eval.range};
    spike_gof = cell(numel(handles.eval.range)+1,handles.eval.samples+1);
    %     spike_gof(2:end,1) = {handles.eval.range};
    for n = 1:numel(handles.eval.range)
        spike_model(n+1,1) = {handles.eval.range(n)};
        spike_gof(n+1,1) = {handles.eval.range(n)};
    end
    for n = 1:handles.eval.samples
        spike_model(1,n+1) = {n};
        spike_gof(1,n+1) = {n};
    end
    total_iters = numel(handles.eval.range)*handles.eval.samples;
    % no plotting if number of iterations is high (speeds up eval.)
    if total_iters > 10
        handles.common.doPlot = 0;
    end
    % random number generator: either not fixed seed or as many seeds
    % provided as total iterations
    if strcmp(handles.common.fixRand,'on')
        if numel(handles.common.randSeed) == total_iters
            handles.common.randSeedPos = 1;
        else
            restoreGUIstate;
            errordlg(...
                'Evaluation requires different random number state!',...
                'Consistency error');
            varargout{1} = handles;
            return
        end
    end
    if handles.common.update == 0
        handles.common.update = 1;
        switch_back = 1;
    else
        switch_back = 0;
    end
    if strcmp(handles.eval.var,'SNR')
        param_string = 'snr';
    elseif strcmp(handles.eval.var,'Tau')
        param_string = 'ca_tau';
    elseif strcmp(handles.eval.var,'Amplitude')
        param_string = 'ca_amp';
    elseif strcmp(handles.eval.var,'Sampling')
        param_string = 'freq';
    else
        restoreGUIstate;
        errordlg(...
            'Selected evaluation parameter is not supported!',...
            'User error');
        varargout{1} = handles;
        return
    end

    % number of processors
    %     import java.lang.*;
    %     no_proc = Runtime.getRuntime();
    %     no_proc = no_proc.availableProcessors;

    % parallel processing if possible
    %     if license('test','distrib_computing_toolbox') && no_proc > 1
    %         % maximum pool size for local config is 4
    %         if no_proc > 4
    %             no_proc = 4;
    %         end
    %         matlabpool('open','local',no_proc);
    %         % run deconvolution iterations and save results of each iteration
    %         for param = 1:numel(handles.eval.range)
    %             for iter = 1:handles.eval.samples
    %                 handles.sim_pars.(param_string) = handles.eval.range(param);
    %                 handles.deconv_pars.alg = 'Minimization';
    %                 handles = gui_doSimulation(handles);
    %                 spike_model(param+1,iter+1) = {handles.data.spikes_predict};
    %                 spike_gof(param+1,iter+1) = {handles.data.spikes_gof};
    %             end
    %         end
    %
    %         matlabpool close
    %     else
    %         % run deconvolution iterations and save results of each iteration
    total_iter_count = 1;
    total_duration = 0;
    for param = 1:numel(handles.eval.range)
        handles.sim_pars.(param_string) = handles.eval.range(param);
        fprintf('\nNow evaluating %s %s\n',param_string,...
            num2str(handles.eval.range(param)));
        for iter = 1:handles.eval.samples
            start_t = clock;
            % hard-coded for minimization procedure
            handles.deconv_pars.alg = 'Minimization';
            handles = gui_doSimulation(handles);
            spike_model(param+1,iter+1) = {handles.data.spikes_predict};
            spike_gof(param+1,iter+1) = {handles.data.spikes_gof};
            fprintf('\nCompleted iteration %s of %s total iterations',...
                int2str(total_iter_count),int2str(total_iters));
            end_t = etime(clock,start_t);
            total_duration = total_duration + end_t;
            mean_duration = total_duration / total_iter_count;
            remaining = mean_duration * (total_iters - total_iter_count);
            if remaining > 3600
                remaining = remaining / 3600;
                units = 'h';
            elseif remaining > 60
                remaining = remaining / 60;
                units = 'min';
            else
                units = 'sec';
            end
            fprintf('\nAbout %s %s remaining\n',num2str(remaining,3),units);
            total_iter_count = total_iter_count + 1;
        end
    end
    %     end

    if switch_back == 1
        handles.common.update = 0;
    end

    % if we compare the derived spike train to a measured spike train, only 1
    % evaluation needs to be performed (ignore parameters and samples settings)
elseif handles.common.scenario == 3

end
handles.common.doPlot = 1;
% varargout{1} = handles;
% save('spike_model.mat','spike_model');
% return

try
    handles = gui_doSpikeComparison(handles,spike_model,spike_gof);
catch
    restoreGUIstate;
    fprintf('\nAn error occured during spike train comparison.\n');
    varargout{1} = handles;
    rethrow(lasterror);
end

varargout{1} = handles;

restoreGUIstate;
duration = etime(clock,start_time);
if duration > 7200
    duration = duration / 3600;
    units = 'hours';
elseif duration > 120
    duration = duration / 60;
    units = 'minutes';
else
    units = 'seconds';
end
fprintf('\n\nEvaluation completed on %s (%s %s)\n\n',...
    datestr(clock),num2str(duration,2),units);
diary off

    function restoreGUIstate
        % switch status indicator back to 'ready'
        set(findobj('Tag','status_text1'),'Visible','on');
        set(findobj('Tag','busy_text1'),'Visible','off');
        % enable disabled items (this may fail at times, so we catch the error
        % simply by setting all items that are Enable 'off' to 'on')
        try
            set(disabled_items,'Enable','on');
        catch
            set(findobj('Enable','off'),'Enable','on');
        end
        drawnow

    end

end





% e.o.f.
