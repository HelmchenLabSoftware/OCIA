function [dff_final time] = Spike2DFF(spikes,ca_amp,ca_tau,freq_ap,...
    freq_ca,saturate,delay)
% Spike2DFF calculates DFF trace from spike train
% Usage:
% in1 ... spike train vector
% in2 ... amplitude of single AP transient (% in % DF/F0)
% in3 ... decay time in s
% in4 ... sampling frequency of spike vector
% in5 ... sampling frequency of dff vector
% in6 ... include saturation term (0 ... no; 1 ... yes)
% in7 ... delay of response in s

% this file written by Henry Luetcke (hluetck@gmail.com)

if nargin ~= 7
   help Spike2DFF
   error('Please specify 7 input arguments');
end

if ~isscalar(freq_ap)
   freq_ap = 1 / (freq_ap(2) - freq_ap(1));
end
if ~isscalar(freq_ca)
   freq_ca = 1 / (freq_ca(2) - freq_ca(1));
end

% delay in units of freq_ap
delay = round(delay * freq_ap);
spikes = reshape(spikes,1,numel(spikes));
dff = zeros(size(spikes));
spike_no = 0;
for n = 1:length(spikes)
    if spikes(n) > 0
        current_ca_amp = spikes(n) * ca_amp;
        if spike_no == 0
            first_spike = n;
            spike_no = spike_no + spikes(n);
        else
            % saturation: see Helmchen & Tank (Single-compartment model
            % of calcium dynamics)
            if saturate
                % TODO: implement saturation model
            end
        end
        current_time = (1:(length(spikes) - n + 1)) ./ freq_ap;
%         current_time = current_time + delay;
        tfunc = current_ca_amp*exp(-current_time/ca_tau);
        tfunc = reshape(tfunc,size(dff(n:end)));
        tfunc = [zeros(1,delay) tfunc];
        tfunc(length(tfunc)-delay+1:length(tfunc)) = [];
        dff(n:end) = dff(n:end) + tfunc;
    end
end

% downsample DFF to freq_ca
% if freq_ap ~= freq_ca
%     bin_width = round(freq_ap/freq_ca);
%     dff_final = zeros(1,round(numel(dff)/bin_width));
%     frame = 1;
%     counter = 1;
%     frame_mean = 0;
%     for n = 1:numel(dff)
%         frame_mean = frame_mean + dff(n);
%         if counter == bin_width
%             dff_final(frame) = frame_mean / bin_width;
%             frame = frame + 1;
%             frame_mean = 0;
%             counter = 1;
%         else
%             counter = counter + 1;
%         end
%     end
% else
%     dff_final = dff;
% end

if freq_ca > freq_ap
    error('Imaging at higher rate than ephys is still a dream ...');
elseif freq_ca < freq_ap
    % calculate the number of ephys data points corresponding to 1 imaging
    % sampling interval
    % if the two frequencies are not multiples of each, we have to
    % interpolate dff so that they are
    % LeastCommonMultiple may be very large, thus causing OUT OF MEMORY
    % errors
    if ~rem(freq_ap,freq_ca)
        interval_points = (1/freq_ca)*freq_ap;
    else
        LeastCommonMultiple = lcm(round(freq_ap),round(freq_ca));
        dff = interp(dff,LeastCommonMultiple/freq_ap);
        interval_points = round((1/freq_ca)*LeastCommonMultiple);
    end
    
    % pre-allocate dff_final
    dff_final = zeros(1,length(dff));
    % now just cycle through dff and select points at every interval_points
    % position
    counter = 1;
    frame_counter = 0;
    for n = 1:numel(dff)
        if counter == interval_points
            frame_counter = frame_counter + 1;
            dff_final(frame_counter) = dff(n);
            counter = 1;
        else
            counter = counter + 1;
        end
    end
    if length(dff_final) > frame_counter
       dff_final((frame_counter+1):(length(dff_final))) = []; 
    end
else
    dff_final = dff;
end

[base,time] = gui_CalculateTimeVector(dff_final,freq_ca,[]);

% e.o.f.


