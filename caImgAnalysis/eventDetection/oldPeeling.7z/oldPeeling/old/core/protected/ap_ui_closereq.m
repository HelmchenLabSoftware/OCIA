function ap_ui_closereq
% closereq function for the ap_ui_tab GUI
% closes all associated plot windows first, then destroys the GUI

% delete any associated plot windows
delete(findobj('Tag','ap_ui_fig'));

if isempty(gcbf)
    if length(dbstack) == 1
        warning('MATLAB:closereq', ...
                'Calling closereq from the command line is now obsolete, use close instead');
    end
    close force
else
    delete(gcbf);
end

