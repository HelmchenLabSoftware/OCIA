function varargout = ap_main(varargin)
% Entry function to the ap_ui tools
% ap_main on its own calls the ap_ui_tab GUI (or brings an existing GUI to
% the foreground)
% TODO: ap_main may be called with additional arguments
% if in1 is the full path to a .mat or .txt file, parameters in this file
% will be converted into the main configuration structure and the program 
% is then run with these parameters
% in1 can also be a variable in the workspace, corresponding to the
% configuration structure
% in2 may be either 'gui' (restores GUI with specified parameters) 
% or 'run' (default; runs the program with specified parameters)
% out1 ... if run in command line mode ('run'; the default), ap_main
% returns the configuration structure

if nargin == 0
    ap_ui_tab
elseif nargin > 0
    if ~isempty(strfind(varargin{1},'.mat'))
        S = load(varargin{1});
        field_names = fieldnames(S);
        if length(field_names) > 1
           warning('Specified MAT file contains more than 1 variable. Loading only first variable (%s)',...
               field_names(1));
        end
        config = S.(cell2mat(field_names(1)));
        clear S
    elseif ~isempty(strfind(varargin{1},'.txt'))
        config = Txt2ap_ui_struct(varargin{1});
    end
    if nargin == 1
        % run gui_doSimulation with config
        config = gui_doSimulation(config);
    elseif nargin == 2
        if strcmp(varargin{2},'run')
            % same as calling without second input argument
            config = ap_main(varargin{1});
        elseif strcmp(varargin{2},'gui')
            % restore previous GUI state
        end
    else
        error('Wrong input number');
    end
    varargout{1} = config;
end







