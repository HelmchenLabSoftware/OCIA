function deltaF_mat = DeltaF(raw_mat,bg_mat)
% calculate dF/F for input matrix raw_mat using baseline fluorescence
% derived from bg_mat
% deltaF_mat = (F0 - raw_mat) / F0
% if bg_mat is scalar, its used as value for F0
% if bg_mat is not scalar, it must be of same dimensions as raw_mat
% non-zero values in bg_mat are used to calculate F0 based on corresponding
% values in raw_mat

if nargin ~= 2
    error('Wrong number of input arguments');
end

if isscalar(bg_mat)
   f0 = bg_mat;
else
    if size(raw_mat) ~= size(bg_mat)
       error('Raw and background matrices must be of equal sizes'); 
    end
    f0 = mean(raw_mat(bg_mat~=0));
end

deltaF_mat = (raw_mat - f0) ./ f0;
