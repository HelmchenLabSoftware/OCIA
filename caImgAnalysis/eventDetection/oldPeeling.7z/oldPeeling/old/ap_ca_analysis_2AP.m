function varargout = ap_ca_analysis_2AP(varargin)
% analyse Ca-trace and ephys trace
% find doublets and analyse them
% in1 ... scenario3-structure with infos about Ca-trace, ephys, sampling
% frequencies etc. (specify as string)
% this file written by Henry Luetcke (hluetck@gmail.com)

% assign variable or open dialog to import from base workspace
if ~nargin
    [config,exp_title] = GetConfigFromBase;
    time_restrict = [];
else
    if isstruct(varargin{1})
        config = varargin{1};
        exp_title = 'unknown_exp';
    elseif isstr(varargin{1})
        exp_title = varargin{1};
        config = evalin('base',exp_title);
    else
        [config,exp_title] = GetConfigFromBase;
    end
end
% restrict part of trace to be analyzed (e.g. only the first 20 s)
% [start_s end_s]
if nargin == 2
    time_restrict = varargin{2};
end
exp_title = strrep(exp_title,'_config','');

ephys = config.ephys;
ca_trace = config.roi_dff_trace;
ephys = ScaleToMinMax(ephys,min(ca_trace),max(ca_trace));

% create time vectors for AP and Ca
[dur_ap time_ap] = gui_CalculateTimeVector(ephys,config.freq_ap,[]);
[dur_ca time_ca] = gui_CalculateTimeVector(ca_trace,config.freq_ca,[]);

if ~isempty(time_restrict)
    [diff start] = min(abs(time_ap-time_restrict(1)));
    [diff stop] = min(abs(time_ap-time_restrict(2)));
    ephys = ephys(start:stop); time_ap = time_ap(start:stop);
    [diff start] = min(abs(time_ca-time_restrict(1)));
    [diff stop] = min(abs(time_ca-time_restrict(2)));
    ca_trace = ca_trace(start:stop); time_ca = time_ca(start:stop);
    clear start stop
else
    time_restrict = [0 max([dur_ap dur_ca])];
end

% filter and threshold ephys trace
h1 = figure('Name',[exp_title ' - data']);
% plot(time_ap,ephys);
hold all;
xlim([min([min(time_ca) min(time_ap)]) max([max(time_ca) max(time_ap)])])
% xlabel = 'Time / s'; ylabel = 'DRR / %';

% APs are ca. 1ms wide --> high-pass filter at 50 Hz (also demeans the
% signal)
ephys = mpi_BandPassFilterTimeSeries(ephys,1/config.freq_ap,50,...
    config.freq_ap*10);
ephys = ephys';
plot(time_ap,ephys)

% detect the APs (threshold at half the max. ephys_hp amplitude)
ephys(ephys<(max(ephys)/2)) = 0;
ephys(ephys~=0)=max(ephys)/5;
% plot(time_ap,ephys)

% select the first timepoint of each spike as the time of occurence
ap_yn = 0;
APonset = zeros(size(ephys));
for n = 1:length(ephys)
    if ~ephys(n) && ~ap_yn
        continue
    end
    if ephys(n) && ~ap_yn
        ap_yn = 1;
        APonset(n) = max(ephys);
    elseif ~ephys(n) && ap_yn
        ap_yn = 0;
    end
end
APonset_plot = APonset;
APonset_plot(~APonset)=NaN;
% plot(time_ap,APonset_plot,'x')
clear APonset_plot

% hp-filter Ca-trace and plot
% plot(time_ca,ca_trace);
ca_trace = mpi_BandPassFilterTimeSeries(ca_trace,1/config.freq_ca,0.1,...
    config.freq_ca*10);
plot(time_ca,ca_trace);
% legend('ephys\_hp','Ca\_hp');
ephys = APonset; clear APonset
% warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
% setWindowState(h1,'minimize');

% find the doublets
max_sep = 0.05; % max. time difference is 50 ms
% max. time difference in ephys timepoints
max_sep = round(max_sep * config.freq_ap);
ap_detect = 0;
doublets = zeros(size(ephys));
for n = 1:length(ephys)
    if ~ephys(n)
        continue
    end
    if doublets(n)
        % this point has been paired up already
        % there should be no other point in the next 50 ms
        for m = 1:max_sep
            if (n+m) <= length(ephys) && ephys(n+m)
                ap_detect = ap_detect + 1;
            end
        end
        if ap_detect
            doublets(n) = 0;
            % find the previous spike and also delete it
            for m = 1:max_sep
                if (n-m) > 0 && doublets(n-m)
                    doublets(n-m) = 0;
                end
            end
        end
        ap_detect = 0;
        continue
    end
    for m = 1:max_sep
        if (n+m) <= length(ephys) && ephys(n+m)
            ap_detect = ap_detect + 1;
            ap_pos = n+m;
        end
    end
    if ap_detect == 1
        doublets(n) = 1;
        doublets(ap_pos) = 1;
    end
    ap_detect = 0;
end
doublets(doublets>0)=max(ephys)/2;
% doublets now contains spikes occuring in doublets
% doublets(doublets>0) = max(ephys);
plot(time_ap,doublets);
doublets(doublets>0) = 1;


% for each doublet, there should be no further AP from ap_start to ap_stop
% so that we can average
ap_start = -1;
ap_start_frame = abs(ap_start*config.freq_ap);
ap_stop = 2;
ap_stop_frame = ap_stop*config.freq_ap;
doublets_start = 0;
del_doublets = 0;
for n = 1:length(doublets)
    if ~doublets(n)
        continue
    end
    if ~doublets_start
        % find any spikes occuring in time interval before first spike
        doublets_start = 1;
        if (n-ap_start_frame)<=0
            if sum(ephys(1:n-1))
                del_doublets = 1;
            end
        else
            if sum(ephys(n-ap_start_frame:n-1))
                del_doublets = 1;
            end
        end
        if del_doublets
            del_doublets = 0;
            doublets_start = 0;
            doublets(n) = 0;
            % find the associated doublet
            for m = 1:max_sep
                if (n+m) <= length(doublets) && doublets(n+m)
                    doublets(n+m) = 0;
                end
            end
            
        end
    else
        % find any spikes occuring in time interval after second spike
        doublets_start = 0;
        if (n+ap_stop_frame)>length(doublets)
            if sum(ephys(n+1:length(ephys)))
                del_doublets = 1;
            end
        else
            if sum(ephys(n+1:n+ap_stop_frame))
                del_doublets = 1;
            end
        end
        if del_doublets
            del_doublets = 0;
            doublets(n) = 0;
            % find the associated doublet
            for m = 1:max_sep
                if (n-m) > 0 && doublets(n-m)
                    doublets(n-m) = 0;
                end
            end
        end
    end
end
doublets(doublets>0)=max(ephys)/4;
plot(time_ap,doublets);
legend('ephys\_hp','Ca\_hp','Doublets1','Doublets2');

ap_detect = 0;
for n = 1:length(doublets)
    if ~doublets(n)
        continue
    end
    if doublets(n) && ap_detect
        doublets(n) = 2;
        ap_detect = 0;
    elseif doublets(n)
        doublets(n) = 1;
        ap_detect = 1;
    end
end
fprintf('\nFound %s valid doublets\n',int2str(numel(find(doublets==1))));

if ~numel(find(doublets==1))
    varargout{1} = [];
    return
end

% pad each of the vectors with gaussian noise to ensure that AP-locked
% averaging still works if APs occur close to start or end
pad_start =zeros(ceil(abs(ap_start)*config.freq_ap),1);
pad_stop = zeros(ceil(abs(ap_stop)*config.freq_ap),1);
doublets = [pad_start; doublets; pad_stop];
pad_start = mean(ca_trace)+std(ca_trace)*randn(1,ceil(abs(ap_start)*config.freq_ca));
pad_stop = mean(ca_trace)+std(ca_trace)*randn(1,ceil(abs(ap_stop)*config.freq_ca));
ca_trace = [pad_start ca_trace pad_stop];
[dur_ap time_ap] = gui_CalculateTimeVector(doublets,config.freq_ap,[]);
[dur_ca time_ca] = gui_CalculateTimeVector(ca_trace,config.freq_ca,[]);
% figure
% plot(time_ca,ca_trace); hold all
% plot(time_ap,ephys);
ap_no = 0;
periAP_matrix = []; % collect periAP timecourse (1 AP per row)
for n = 1:length(doublets)
    if doublets(n) == 0 || doublets(n) == 2
        continue
    else
        ap_no = ap_no + 1;
        if ap_no > 100
            warning('More than 100 APs detected till now.');
            answer=input('Continue (y or n)? ','s');
            if strcmp(answer,'n')
                clear all
                varargout{1} = {''};
                return
            end
        end
        ap_time = time_ap(n);
        start_time = ap_time+ap_start;
        end_time = ap_time+ap_stop;
        % corresponding closest values in time_ca (they are different, due
        % to sampling, etc)
        [diff pos] = min(abs(time_ca-start_time));
        start_time = time_ca(pos);
        [diff pos] = min(abs(time_ca-end_time));
        end_time = time_ca(pos);
        [diff pos] = min(abs(time_ca-ap_time));
        ap_time_ca = time_ca(pos);
        tp = 1;
        for m = 1:length(ca_trace)
            if time_ca(m) >= start_time && time_ca(m) <= end_time
                periAP_matrix(ap_no,tp) = ca_trace(m);
                if time_ca(m) == ap_time_ca
                   stop_base = tp; 
                end
                tp = tp+1;
            end
        end
        % normalize to baseline mean
        base_mean = mean(periAP_matrix(ap_no,1:stop_base-1));
        periAP_matrix(ap_no,:) = periAP_matrix(ap_no,:) - base_mean;
    end
end
% calculate time axis and adjust array sizes
time = ap_start:time_ca(2)-time_ca(1):ap_stop;
if size(periAP_matrix,2) > length(time)
    periAP_matrix(:,length(time)+1:size(periAP_matrix,2)) = [];
elseif size(periAP_matrix,2) < length(time)
    time(size(periAP_matrix,2)+1:length(time)) = [];
end

if ap_no > 1
    meanAPtrace = mean(periAP_matrix);
    sdAPtrace = std(periAP_matrix);
else
    meanAPtrace = periAP_matrix;
    sdAPtrace = zeros(size(meanAPtrace));
end

% plot each AP-locked timecourse separately
h2 = figure('Name',[exp_title ' - AP locked Ca']);
hold all

for n = 1:size(periAP_matrix,1)
    plot(time,periAP_matrix);
end
hold off

% plot mean AP-locked timecourses (with SD)
h3 = figure;
plot(time,meanAPtrace,'r');hold all
plot(time,meanAPtrace+sdAPtrace,'k');
plot(time,meanAPtrace-sdAPtrace,'k');
set(h3,'Name',[exp_title ' - mean Ca (' int2str(ap_no) ' APs)']);
hold all
% some statistics for the mean timecourse
baseline = meanAPtrace(time<0);
APevoked = meanAPtrace(time>=0);
mean_baseline = mean(baseline);
sd_baseline = std(baseline);
% max. signal would be expected within 700 ms, or so
max_frame = round(0.5*config.freq_ca);
ca_amp = max(APevoked(1:max_frame));
delay = time(find(meanAPtrace==ca_amp));
fprintf('\nMean timecourse statistics for %s (%s APs)\n',exp_title,...
    int2str(ap_no));
fprintf('Ca-amplitude: %s %%DRR\tTtP: %s s\n',num2str(ca_amp),...
    num2str(delay));
fprintf('Baseline mean: %s %%DRR\tSD: %s\n',num2str(mean_baseline),...
    num2str(sd_baseline));

% fit exponential model from the peak of the curve
time_fit = time(find(time==delay):end);
data_fit = meanAPtrace(find(time==delay):end);
data_fit = data_fit(1:length(time_fit));

% fit exponential decay to mean AP-locked timecourses
% set initial and boundary values for the gaussian fit
% amplitude factor (in % DRR)
a1_init = ca_amp;
a1_low = 0.9*ca_amp;
a1_high = 1.1*ca_amp;
% delay constant (in s)
b1_init = delay;
b1_low = 0;
b1_high = delay*2;
% decay constant (in s)
c1_init = 0.5;
c1_low = 0.2;
c1_high = 5;
% fit using Matlab advanced fitting procedure
% with constraints on parameter values as well as start points
fo_ = fitoptions('method','NonlinearLeastSquares',...
    'Lower',[a1_low b1_low c1_low], 'Upper',[a1_high b1_high c1_high]);
%start points for parameters
st_ = [a1_init b1_init c1_init];
set(fo_,'Startpoint',st_);
%equation, variables and parameters for fit
ft_ = fittype('a1*exp(-(x-b1)/c1)' ,...
    'dependent',{'y'},'independent',{'x'},...
    'coefficients',{'a1','b1','c1'});
[fresult, gof, fit_info] = fit(time_fit',data_fit',ft_ ,fo_);

coef = coeffvalues(fresult);
fit_amp = coef(1); fit_delay = coef(2); fit_decay = coef(3);
fprintf('Fit results (R^2=%s)\n',num2str(gof.rsquare));
fprintf('Amplitude: %s %%DRR\tDelay: %s s\tDecay: %s s\n',...
    num2str(fit_amp),num2str(fit_delay),num2str(fit_decay));
time_fit = time_fit(1):0.001:time_fit(length(time_fit));
data_fit = fit_amp.*exp(-(time_fit-fit_delay)/fit_decay);
% plot the fit
plot(time_fit,data_fit,'r');
legend('Mean Ca','Fit');
hold off

% save important info in cell array and return
% in columns: exp., eval.start, eval.stop, AP number, mean start,
% mean stop, mean ca. amp.,mean ttp, mean baseline amp.,baseline SD,
% fit ca. amp.,fit ttp, fit decay, gof
varargout{1} = {exp_title time_restrict(1) time_restrict(2) ap_no ...
    ap_start ap_stop ca_amp delay mean_baseline sd_baseline fit_amp ...
    fit_delay fit_decay gof.rsquare};

function [config,exp_title] = GetConfigFromBase
vars = evalin('base','who');
if ~isempty(vars)
    [choice,status] = listdlg('PromptString','Select a variable:',...
        'SelectionMode','single',...
        'ListString',vars);
    if ~status return; end
else
    warndlg('No variables in base workspace!');return
end
config = evalin('base',vars{choice});
exp_title = vars{choice};


