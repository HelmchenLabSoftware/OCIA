function config = Txt2ap_ui_struct(filename)
% reads text file with specifications for ap_ui_tab
% in1 ... full path to text file with specifications
% out1 ... structure containing data (can be feed into ap_ui_tab)
config = struct;
[fid,message] = fopen(filename);
if ~isempty(message)
    error('The specified file could not be opened. Aborting ...');
end
% everything is read as strings and collected in cell array C (first cell
% contains all the variables and second cell all the values)
% tab delimiter chosen to allow spaces in file paths (Windows)
C = textscan(fid,'%s %s','commentStyle','%','Delimiter','\t');
fclose(fid);
names = C{1};
group_field = {};
param_field = {};
for n = 1:numel(names)
    fullfield = names{n};
    dot_pos = strfind(fullfield,'.');
    group_field{n,1} = fullfield(1:(dot_pos-1));
    param_field{n,1} = fullfield((dot_pos+1):end);
end
values = C{2};
for n = 1:numel(values)
   if ~isempty(str2num(values{n}))
      values{n} = str2num(values{n}); 
   end
end

% elements of 'common'
common = cell2struct(values(strcmp(group_field,'common')),...
    param_field(strcmp(group_field,'common')),1);
% elements of 'sim_pars'
sim_pars = cell2struct(values(strcmp(group_field,'sim_pars')),...
    param_field(strcmp(group_field,'sim_pars')),1);
% elements of 'deconv_pars'
deconv_pars = cell2struct(values(strcmp(group_field,'deconv_pars')),...
    param_field(strcmp(group_field,'deconv_pars')),1);

for n = 1:numel(names)
    config = setfield(config,'common',common);
    config = setfield(config,'sim_pars',sim_pars);
    config = setfield(config,'deconv_pars',deconv_pars);
end