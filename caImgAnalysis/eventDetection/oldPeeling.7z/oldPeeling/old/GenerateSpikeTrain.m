function GenerateSpikeTrain

% complete set
num_spikes = 378;
spike_times(1) = 20;
spike_times(2:3) = 35;
spike_times(4:8)=50;
spike_times(9:18)=65;
for n = 19:28
   spike_times(n) = 80+ 0.5*(n-19); 
end
for n = 29:48
   spike_times(n) = 95+ 0.2*(n-29); 
end
for n = 49:98
   spike_times(n) = 110+ 0.1*(n-49); 
end
for n = 99:198
   spike_times(n) = 125+ 0.05*(n-99); 
end
spike_times(199) = 140;
counter = 200;
while true
%     Poison-distributed, mean rate 2 Hz
    spike_times(counter) = spike_times(counter-1) + (-log(0.5+(rand-0.5)))/2;
    counter = counter + 1;
    if counter >= 228
        break
    end
end
spike_times(229) = 170;
counter = 230;
while true
%     Poison-distributed, mean rate 10 Hz
    spike_times(counter) = spike_times(counter-1) + (-log(0.5+(rand-0.5)))/10;
    counter = counter + 1;
    if counter >= 379
        break
    end
end
spikes = zeros(1,num_spikes+10);
for n = 1:num_spikes
    index = round(spike_times(n));
    if index == 0
        continue
    end
    spikes(index) = spikes(index) + 1;
end

plot(spikes);



% e.o.f.