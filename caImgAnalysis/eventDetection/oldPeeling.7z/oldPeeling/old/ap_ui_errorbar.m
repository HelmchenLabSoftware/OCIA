% nfb_errorbar is a generic function which produces a bar chart with error
% bars
% its main advantage is that it readily plots each bar and errorbar
% separately, making it easy to change colours, filling etc for each bar
% individually later on
%
% USAGE:
% [out1] = ap_ui_errorbar(in1, in2)
%
% Comulsory input arguments
% in1 ... x-axis vector
% in2 ... y-axis matrix or vector
% in3 ... y-axis error matrix or vector
% each matrix entry corresponds to 1 data point / (symmetric) errorbar
% values in the same row will be grouped in one line plot
% values in different rows are plotted in different lines
% in2 and in3 MUST be of equal size; in1 must have same number of columns
% as in2 / in3 and 1 row
%
% Optional input arguments (in any order)
% 'Figure', add errorbar to an existing figure (provide handle to figure)
% 'Color', string specification of valid Matlab colormap (see doc colormap)
% (default is 'gray')
% 'Labels', cellstring of row*columns length (one label
% per bar); will be applied first along rows then down columns
% i.e. 'Labels',{'value1' 'value2' 'value3'}
% 'Legend', cellstring provides legend tags for bars (must not be longer
% than number of bars, i.e. rows*columns of input matrices)
% String args: 'Title', 'XLabel', 'YLabel', 'Name' (Figure Name, if
% specified, also switches NumberTitle off)
%
% out1 ... handle to figure

% this file written by Henry Luetcke (hluetck@gwdg.de)

function [chart] = ap_ui_errorbar(varargin)

if nargin < 3
    error('You MUST provide at least 3 input arguments');
end

xaxis = varargin{1};
yaxis_val = varargin{2};
yaxis_err = varargin{3};

if size(yaxis_val) ~= size(yaxis_err)
    error('y-axis value and error matrices must be of equal size');
end

if length(size(yaxis_val)) > 2 || length(size(yaxis_err)) > 2
    error('y-axis value and error matrices must be vectors or 2D matrices.');
end

if ~isvector(xaxis)
    error('x-axis must be a vector.');
end

% Option to add errorbar plot to existing figure
SpInput = find(strcmp(varargin, 'Figure'));
if numel(SpInput)
    chart = varargin{SpInput+1};
else
    chart = figure;
end
hold on

% specify bar color according to Matlab color map
SpInput = find(strcmp(varargin, 'Color'));
if numel(SpInput) 
    cmap = varargin{SpInput+1};
    cstring = sprintf('%s(%s)',cmap,int2str(size(yaxis_val,1)));
    try evalc(cstring);
    catch
        fprintf(...
            '\n''%s'' is not a valid Matlab color map. Using ''gray''.\n',...
            cmap);
        cmap = 'gray';
    end
else
    cmap = 'gray';
end
cstring = sprintf('%s(%s)',cmap,int2str(size(yaxis_val,1)));
group_colors = colormap(cstring);

for n = 1:size(yaxis_val,1)
    errorbar(xaxis,yaxis_val(n,:),yaxis_err(n,:),...
        'Color',group_colors(n,:));
end

% parse opional input arguments
if nargin > 3
    opt_args = varargin(3:nargin);
    for n = 1:length(opt_args)
        % hluetck::23.02.2008
        % modified legend creation (it does actually work now)
        % create column legend
        if strcmp(opt_args{n},'Legend') == 1
            col_legend = opt_args{n+1};
            if length(col_legend) > size(yaxis_val,1)
                disp('Incorrect number of legend values has been given');
                disp(' ');
                help ap_ui_errorbar
                return
            end
            legend(col_legend,'Location','BestOutside');
        end

        % add a title
        if strcmp(opt_args{n},'Title') == 1
            plot_title = opt_args{n+1};
            h_title = title(plot_title);
            set(h_title,'Interpreter','none');
        end

        % y-axis label
        if strcmp(opt_args{n},'YLabel') == 1
            plot_ylabel = opt_args{n+1};
            ylabel(plot_ylabel);
        end

        % x-axis label
        if strcmp(opt_args{n},'XLabel') == 1
            plot_xlabel = opt_args{n+1};
            xlabel(plot_xlabel);
        end

        % Figure Name
        if strcmp(opt_args{n},'Name') == 1
            fig_name = opt_args{n+1};
            set(gcf,'Name',fig_name,'NumberTitle','off');
        end
    end
end


% e.o.f.