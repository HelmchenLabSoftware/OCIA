% base config variable (e.g. ephys01_config) must be in base workspace
% these parameters should be the same for all analyses included in the
% batch process
% wild-card string that identifies the ephys file
e_string = 'b090416*';

% type of stats ('drr' or 'dff')
stats_type = 'dff';

dir_list = dir('ser*');
for n = 1:length(dir_list)
    fprintf('\nStarted work in directory %s at %s\n',...
        dir_list(n).name,datestr(clock));
    if dir_list(n).isdir
        cd(dir_list(n).name);
        ephys_file = dir(e_string);
        ephys_file = ephys_file.name;
        ephys_no = ephys_file(length(ephys_file)-1:...
            length(ephys_file));
        ephys_no = strrep(ephys_no,'_','');
        if length(ephys_no) == 1
            ephys_no = ['0' ephys_no];
        end
        config_var = ['ephys' ephys_no '_config'];
        stats_image = ['*_' stats_type '.tif'];
        stats_image = dir(stats_image);
        stats_image = stats_image.name;
        stats_image = tif2mat(stats_image,'nosave');
        stats_image = stats_image.data;
        % number of roi-files
        roi_files = dir('*.roi');
        roi_number = length(roi_files);
        for current_roi = 1:roi_number
            %             drr_file = ['cell' int2str(current_roi) '_' stats_type '.txt'];
            current_roi_file = roi_files(current_roi).name;
            mask = ij_roiDecoder(current_roi_file,[size(stats_image,1) ...
                size(stats_image,2)]);
            roi_mat = GetRoiTimeseries(stats_image,mask);
            if size(roi_mat,1) > 1
                roi_mat = mean(roi_mat);
            end
            if current_roi == 1
                a = eval(config_var);
            end
            a= Prepare4SpikeRecon(roi_mat',a);
        end
        config_var = ['ephys' ephys_no '_withROI_config'];
        assignin('base',config_var,a); clear a
        savename = [config_var '.mat'];
        save(savename,config_var)
    end
    fprintf('\nFinished work in directory %s at %s\n',...
        dir_list(n).name,datestr(clock));
    cd ..
end