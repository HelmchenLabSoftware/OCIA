% function varargout = ca_deconv(varargin)
% main function that implements several approaches for extraction of APs
% from calcium signal traces
% in1 ... Ca signal trace as vector (variable, .mat, or .txt)
% in2 ... algorithm ('threshold', 'template', 'deconv','reverse_cc')
% [OPTIONAL: in3 ... reference AP vector (derived from simulation or real
% data); if in3 is provided, the similarity of the AP vector obtained from Ca
% signal will be compared with the reference]
% out1 ... the derived AP vector
% [out2 ... similarity between reference and derived AP vector, e.g. FAs,
% Misses, correlation); only if in3 is provided]

%TODO: baseline vector is currently hard-coded

% main function
function varargout = ca_deconv(varargin)

[ca_vect alg ref_ap] = ParseInputs(varargin{:});

% 'ca_ap' is the vector containing Ca-derived APs
ca_ap = zeros(size(ca_vect));

ca_vect_preproc = PreprocCaVect(ca_vect);

hold on
% f1 = plot(ca_vect,'r','LineWidth',1);
f1 = plot(ca_vect_preproc,'b','LineWidth',1);

% smooth line through trace
smooth_line = smooth(ca_vect_preproc,length(ca_vect_preproc)/10);
f1 = plot(smooth_line,'g','LineWidth',1);

diff_preproc = ca_vect_preproc - smooth_line;
diff_preproc(diff_preproc<0) = 0;
f1 = plot(diff_preproc,'c','LineWidth',1);

mean_diff = mean(diff_preproc);
std_diff = std(diff_preproc);

% find peaks
[pks,locs] = findpeaks(diff_preproc);

% allow only peaks where distance is larger than 'n_stds' SDs
n_stds = 1;
pks_vect = nan(size(ca_vect));
for n = 1:length(locs)
    if diff_preproc(locs(n)) > (mean_diff + n_stds*std_diff)
        pks_vect(locs(n)) = mean(ca_vect_preproc);
    end
end

f1 = plot(pks_vect,'k','LineWidth',1,'Marker','s','MarkerEdgeColor','k',...
    'MarkerFaceColor','k','MarkerSize',3);

pks_vect(~isnan(pks_vect)) = 1;
pks_vect(isnan(pks_vect)) = 0;

if strcmp(alg,'template')
    [pks_match] = TemplateMatch(pks_vect,diff_preproc);
    pks_match(pks_match==1) = mean(diff_preproc);
    pks_match(pks_match==0) = NaN;
    f1 = plot(pks_match,'r','LineWidth',1,'Marker','+',...
        'MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',3);
    ca_ap = pks_match;
end

varargout{1} = ca_ap;
if ~isempty(ref_ap)
    % compare 'ref_ap' and 'ca_ap'
    stats = CompareVectors(ca_ap,ref_ap);
    varargout{2} = stats;
end

end

% implementation of template matching algorithm
function [pks_match] = TemplateMatch(pks_vect,diff_preproc)
% perform template matching of identified peaks
% template time constant for Ca-decay in ms
tau_template = 500;
% range for template matching (as fraction of tau)
match_range = 1;

pks_match = [];
covar_vect = zeros(size(pks_vect));
for n = 1:length(pks_vect)
    if pks_vect(n) == 1
        timepoints = n:(n+tau_template*match_range);
        observed = diff_preproc(n:(n+tau_template*match_range));
        predicted = diff_preproc(n)*exp(-(timepoints-n+1)/tau_template);
        %        figure
        %        f2 = plot(timepoints,observed,'b');
        %        hold on
        %        f2 = plot(timepoints,predicted,'r');
        covar = cov(observed,predicted);
        covar_vect(n) = covar(1,2);
    end
end
% threshold covar_vect (as in Kerr et al., '05)
% cut-off as fraction of SD (should be 2 - 4)
thresh = 1;
mean_covar = mean(covar_vect(covar_vect~=0));
std_covar = std(covar_vect(covar_vect~=0));

pks_match = zeros(size(covar_vect));
for n = 1:length(covar_vect)
    if covar_vect(n) > mean_covar + thresh*std_covar
        pks_match(n) = 1;
    end
end

end

% assesses 'goodness' of deconvolution
function stats = CompareVectors(ca_ap,ref_ap)
ref_ap((~isnan(ref_ap))) = 0.8;
ca_ap((~isnan(ca_ap))) = 1.2;
figure
hold on
f2 = plot(ref_ap,'b','LineWidth',1,'Marker','+',...
    'MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',3);
f2 = plot(ca_ap,'r','LineWidth',1,'Marker','+',...
    'MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',3);
set(gca,'YLim',[0 2]);
legend('Reference AP','Calcium AP','Location','BestOutside');
miss = 0;
fa = 0;
hits = 0;
for n = 1:length(ref_ap)
    if ca_ap(n) == 1.2 && ref_ap(n) == 0.8
        hits = hits + 1;
    end
    if ca_ap(n) == 1.2 && ref_ap(n) ~= 0.8
        fa = fa + 1;
    end
    if ca_ap(n) ~= 1.2 && ref_ap(n) == 0.8
        miss = miss + 1;
    end
end
stats.hits = hits;
stats.fa = fa;
stats.miss = miss;
end

% preprocessing routine
function ca_vect_preproc = PreprocCaVect(ca_vect)
% bandpass filter for removing frequencies outside the range of interest
% high-pass cutoff: 0.25 Hz
% low-pass cutoff: 50 Hz
ca_vect_preproc = mpi_BandPassFilterTimeSeries(ca_vect,0.001,0.25,50);

% smooth timeseries by robust local regression using weighted linear least
% squares and a 1st degree polynomial model (influence of outlier points is
% reduced)
% span is a percentage of the total number of data points, less than or
% equal to 1
% quite slow
% window size in ms
window_size = 100;
span = window_size/length(ca_vect);
ca_vect_preproc = smooth(ca_vect_preproc,span,'rlowess');

% baseline vector
baseline = ca_vect(1:60);
bl_mean = mean(baseline);
bl_sd = std(baseline);



end

% evaluate inputs
function [out1 out2 out3] = ParseInputs(varargin)
if nargin < 1 || nargin > 3
    error('Incorrect number of input arguments');
end
for n = 1:nargin
    if n == 1
        if isvector(varargin{n})
            out1 = varargin{n};
        elseif ischar(varargin{n})
            if strcmp(varargin{n},'.mat')
                % interprets first variable in mat-file as input vector
                out1 = load(varargin{n});
                fields = fieldnames(out1);
                out1 = out1.(cell2mat(fields(1)));
            elseif strcmp(varargin{n},'.txt')
                out1 = importdata(varargin{n});
            end
            if ~isvector(out1)
                error('Input argument 1 returns wrong type');
            end
        else
            error('Input argument 1 is of incorrect type');
        end
        out3 = [];
    elseif n == 2
        if ~ischar(varargin{n})
            error('Input argument 1 is of incorrect type');
        end
        out2 = varargin{n};
    elseif n == 3
        if isvector(varargin{n})
            out3 = varargin{n};
        elseif ischar(varargin{n})
            if strcmp(varargin{n},'.mat')
                % interprets first variable in mat-file as input vector
                out3 = load(varargin{n});
                fields = fieldnames(out1);
                out3 = out3.(cell2mat(fields(1)));
            elseif strcmp(varargin{n},'.txt')
                out3 = importdata(varargin{n});
            end
            if ~isvector(out3)
                error('Input argument 3 returns wrong type');
            end
        else
            error('Input argument 3 is of incorrect type');
        end
    end
end


end



% e.o.f.