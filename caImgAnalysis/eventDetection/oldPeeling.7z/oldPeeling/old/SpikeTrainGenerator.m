function S = SpikeTrainGenerator(varargin)
% inputs supported as 'Property' - Value pair or as structure with
% 'Property' fieldnames and values as field values
% supported arguments:
% {default} ... the default value if parameter is not provided
% 'Method' ... a string specifying the type of spike train to be generated,
% one of {'Poisson'}, 'Burst'
% 'Resolution' ... sampling resolution of spike train in Hz, {10000}
% 'Duration' ... duration of spike train in s, {50}
% 'Rate' ... average firing rate in Hz, {0.1} or burst firing rate
% 'SpikeNumber' ... number of spikes (for burst), {5}
% 'doPlot' ... display plot of spike train, {0}
% output:
% S ... structure with all plus field SpkTime (spike times in s)

% this file written by Henry Luetcke (hluetck@gmail.com)

S = parseInputArgs(varargin);

S.SpkTime=[];

% call subfunctions depending on generation method
switch S.Method
    case 'Poisson'
        S = doPoisson(S);
    case 'Burst'
        S = doBurst(S);
end

if S.doPlot
    doPlot(S);
end

%% Function - Poisson distributed spike train
function S = doPoisson(S)
deltaT = 1 / S.Resolution;
% Generating spikes from a exponential distribution
for t = 0:deltaT:S.Duration
    if (S.Rate*deltaT) >= rand(1)
        S.SpkTime(end+1,1) = t;
    end
end
% really Poisson? Histogram of spike time differences should be exponential
% diffSpkTime = diff(S.SpkTime);
% hist(diffSpkTime,sqrt(numel(diffSpkTime)))

%% Function - Burst
function S = doBurst(S)
deltaT = 1 / S.Resolution;
deltaT_burst = 1/ S.Rate;
% inter-spike interval in frames
isi = round(deltaT_burst * S.Resolution);
S.SpkTime = zeros(1,S.SpikeNumber);
if S.SpikeNumber > 1
    for n = 2:length(S.SpkTime)
        S.SpkTime(n) = S.SpkTime(n-1) + deltaT_burst;
    end
end
% offset so that burst is in the middle of vector
offset = S.Duration - S.SpkTime(end);
if offset > 0
   S.SpkTime = S.SpkTime + offset/2; 
end


%% Function - Plot spike train
function doPlot(S)
SpkVector = zeros(1,S.Resolution*S.Duration);
for n = 1:length(S.SpkTime)
    idx = round(S.SpkTime(n) * S.Resolution);
    SpkVector(1,idx) = 1;
end
deltaT = 1 / S.Resolution;
tVector = deltaT:deltaT:S.Duration;
plot(tVector,SpkVector)
set(gca,'Box','off'); xlabel('Time / s')


%% Function - Parse inputs
function S = parseInputArgs(inargs)
if ~isempty(inargs) && isstruct(inargs{1})
    % convert structure to pseudo-input cellarray
    inargs = struct2cellArray(inargs{1});
end
SpInput = find(strcmpi(inargs,'Method'));
if numel(SpInput)
    S.Method = inargs{SpInput+1};
else
    S.Method = 'Poisson';
end
SpInput = find(strcmpi(inargs,'Resolution'));
if numel(SpInput)
    S.Resolution = inargs{SpInput+1};
else
    S.Resolution = 10000;
end
SpInput = find(strcmpi(inargs,'Duration'));
if numel(SpInput)
    S.Duration = inargs{SpInput+1};
else
    S.Duration = 50;
end
SpInput = find(strcmpi(inargs,'Rate'));
if numel(SpInput)
    S.Rate = inargs{SpInput+1};
else
    S.Rate = 0.1;
end
SpInput = find(strcmpi(inargs,'SpikeNumber'));
if numel(SpInput)
    S.SpikeNumber = inargs{SpInput+1};
else
    S.SpikeNumber = 5;
end
SpInput = find(strcmpi(inargs,'doPlot'));
if numel(SpInput)
    S.doPlot = inargs{SpInput+1};
else
    S.doPlot = 0;
end


