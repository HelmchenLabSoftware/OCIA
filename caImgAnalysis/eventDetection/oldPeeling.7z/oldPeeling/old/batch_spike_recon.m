% these parameters should be the same for all analyses included in the
% batch process
% wild-card string that identifies the ephys file
e_string = 'b090415*';
ca_freq = 7.81;
ephys_freq = 20000;
ephys_timepoints = 1000000;
del_slice = 40;

dir_list = dir('ser34*');
for n = 1:length(dir_list)
    fprintf('\nStarted work in directory %s at %s\n',...
        dir_list(n).name,datestr(clock));
    if dir_list(n).isdir
        cd(dir_list(n).name);
        fcs_file = dir('*.fcs');
        fcs_file = fcs_file.name;
        ephys_file = dir(e_string);
        ephys_file = ephys_file.name;
        ephys_no = ephys_file(length(ephys_file)-1:...
            length(ephys_file));
        config_var = ['ephys' ephys_no '_config'];
        eval('a = Prepare4SpikeRecon(fcs_file,ephys_file,ca_freq,ephys_freq,ephys_timepoints,del_slice,[1 4])');
        assignin('base',config_var,a);
        plot_title = ['ephys' ephys_no];
        h = figure;
        plot(a.ephys);
        set(h,'Name',plot_title,'NumberTitle','off');
        setWindowState(h,'minimize');
        % optionally, delete fcs-file
%         delete(fcs_file);
        fprintf('\nFinished work in directory %s at %s\n',...
            dir_list(n).name,datestr(clock));
        cd ..
    end
end

% make some noise so that we know that processing has finished
for n = 1:10
    beep
    pause(0.1)
end