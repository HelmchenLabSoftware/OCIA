function options = ssmoptimset(varargin)
% creates options structure for use with scatter search optimization
% in the ca_deconv toolbox
% optionally provide an options structure (all fields in this structure
% will not be modified, aditional fields will be added with default
% parameters)

if nargin
    options = varargin{1};
else
    options = struct;
end

fields = OptionStructFields;
for n = 1:size(fields,1)
    fieldname = fields{n,1}; fieldval = fields{n,2};
    if ~isfield(options,fieldname)
       options.(fieldname) = fieldval; 
    end
end
fields = OptionLocalStructFields;
if ~isfield(options,'local')
   options.local = []; 
end
for n = 1:size(fields,1)
    fieldname = fields{n,1}; fieldval = fields{n,2};
    if ~isfield(options.local,fieldname)
       options.local.(fieldname) = fieldval; 
    end
end

    function fields = OptionStructFields
        fields{1,1} = 'maxeval'; fields{1,2} = 1000;
        fields{2,1} = 'maxtime'; fields{2,2} = 60;
        fields{3,1} = 'iterprint'; fields{3,2} = 0;
        fields{4,1} = 'plot'; fields{4,2} = 0;
        fields{5,1} = 'weight'; fields{5,2} = 1000000;
        fields{6,1} = 'log_var'; fields{6,2} = [];
        fields{7,1} = 'tolc'; fields{7,2} = 0.00001;
        fields{8,1} = 'save_report'; fields{8,2} = 0;
        fields{9,1} = 'report_name'; fields{9,2} = 'ssm_report.mat';
        fields{10,1} = 'prob_bound'; fields{10,2} = 0.5;
        fields{11,1} = 'strategy'; fields{11,2} = 1;
        fields{12,1} = 'dim_refset'; fields{12,2} = 'auto';
        fields{13,1} = 'ndiverse'; fields{13,2} = 'auto';
        fields{14,1} = 'initiate'; fields{14,2} = 0;
        fields{15,1} = 'combination'; fields{15,2} = 1;
        fields{16,1} = 'regenerate'; fields{16,2} = 3;
        fields{17,1} = 'delete'; fields{17,2} = 'standard';
        fields{18,1} = 'intens'; fields{18,2} = 10;
        fields{19,1} = 'tolf'; fields{19,2} = 0.0001;
        fields{20,1} = 'diverse_criteria'; fields{20,2} = 1;
        fields{21,1} = 'tolx'; fields{21,2} = 0.001;
    end

    function fields = OptionLocalStructFields
        fields{1,1} = 'solver'; fields{1,2} = 'solnp';
        fields{2,1} = 'tol'; fields{2,2} = [];
        fields{3,1} = 'iterprint'; fields{3,2} = 0;
        fields{4,1} = 'n1'; fields{4,2} = [];
        fields{5,1} = 'n2'; fields{5,2} = [];
        fields{6,1} = 'finish'; fields{6,2} = [];
        fields{7,1} = 'bestx'; fields{7,2} = 0;
        fields{8,1} = 'merit_filter'; fields{8,2} = 1;
        fields{9,1} = 'distance_filter'; fields{9,2} = 1;
        fields{10,1} = 'thfactor'; fields{10,2} = 0.2;
        fields{11,1} = 'maxdistfactor'; fields{11,2} = 0.2;
        fields{12,1} = 'wait_maxdist_limit'; fields{12,2} = 20;
        fields{13,1} = 'wait_th_limit'; fields{13,2} = 20;        
    end

end