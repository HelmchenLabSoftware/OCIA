function ap_ui_Struct2Txt(config,filename)
% in1 ... config structure used in ap_ui_tab (specifying common, simulation and
% deconvolution parameters)
% in2 ... path and filename of text file
% in the config structure the field names 'common, 'sim_pars', 'deconv_pars' 
% and 'data' are processed
% values for each of the fields are written into the text file alongside
% their field ID
% e.g. common.update\tab1
% for 'data' fields saving to text is not feasible --> offer to save each
% data field as .mat and save full path to mat-file

% this file written by Henry Luetcke (hluetck@gmail.com)

fid = fopen(filename,'w');
fprintf(fid,...
    '%% Configuration file for ap_ui program written on %s',datestr(clock));
fprintf(fid,'\n%% This is ignored (Matlab comment style)');
fprintf(fid,'\n%% Separate keywords and parameters by tabs\n\n');
level2_fields = fieldnames(config);
try
    % start with parameters
    for n = 1:numel(level2_fields)
        if strcmp(level2_fields(n),'common') || ...
                strcmp(level2_fields(n),'sim_pars') || ...
                strcmp(level2_fields(n),'deconv_pars') || ...
                strcmp(level2_fields(n),'eval')
            level3_fields = fieldnames(config.(char(level2_fields(n))));
            for m = 1:numel(level3_fields)
                value = ...
                    config.(char(level2_fields(n))).(char(level3_fields(m)));
                if isnumeric(value)
                    value = num2str(value);
                end
                fprintf(fid,'\n%s.%s\t%s',char(level2_fields(n)),...
                    char(level3_fields(m)),value);
            end
        end
    end
    % now save data as mat files
    for n = 1:numel(level2_fields)
        if strcmp(level2_fields(n),'data')
            level3_fields = fieldnames(config.(char(level2_fields(n))));
            for m = 1:numel(level3_fields)
                value = ...
                    config.(char(level2_fields(n))).(char(level3_fields(m)));
                qstring = sprintf('Save %s as mat-file and store path to file in text?',...
                    char(level3_fields(m)));
                button = questdlg(qstring,'Save data?','Yes','No','Yes');
                if strcmp(button,'Yes')
                    [FileName,PathName,FilterIndex] = uiputfile('.mat','Select mat-file for saving');
                    if FilterIndex
                        save(fullfile(PathName,FileName),'value');
                        fprintf(fid,'\n%s.%s\t%s',char(level2_fields(n)),...
                            char(level3_fields(m)),fullfile(PathName,FileName));
                    end
                end
            end
        end
    end
    fclose(fid);
catch
    fclose(fid);
    fprintf('\n\nAn error occured while writing to file %s\n',...
        filename);
    rethrow(lasterror);
end


% e.o.f.

