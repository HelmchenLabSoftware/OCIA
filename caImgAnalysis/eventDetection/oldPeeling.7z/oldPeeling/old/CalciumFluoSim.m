function S = CalciumFluoSim(varargin)
% inputs supported as 'Property' - Value pair or as structure with
% 'Property' fieldnames and values as field values
% supported arguments:
% {default} ... the default value if parameter is not provided
% 'SpikeData' ... a structure as returned by SpikeTrainGenerator, default
% is GUI-selection
% 'Resolution' ... sampling resolution of final fluorescence trace / Hz, {10}
% 'AmpCa' ... amplitude of single-transient calcium influx (nM), {200}
% 'TauCa' ... time constant of single-transient calcium influx (s), {0.1}

% 'doPlot' ... display plot of all traces, {0}
% output:
% S ... structure with all pertinent fields

% this file written by Henry Luetcke (hluetck@gmail.com)

S = parseInputArgs(varargin);

S = doCalcium(S);

if S.doPlot
    doPlot(S);
end

%% Function - Calcium dynamics
function S = doCalcium(S)
CaTrace = zeros(1,S.SpikeData.Resolution*S.SpikeData.Duration);
tauFrames = S.TauCa * S.SpikeData.Resolution;
for n = 1:numel(S.SpikeData.SpkTime)
    spkFrame = round(S.SpikeData.SpkTime(n)*S.SpikeData.Resolution);
    t = 0:length(CaTrace)-spkFrame;
    tfunc = S.AmpCa .* exp(-t ./ tauFrames);
    CaTrace(spkFrame:end) = CaTrace(spkFrame:end) + tfunc;
end
S.CaTrace = CaTrace;


%% Function - Fluorescence dynamics
function S = doFluo(S)


%% Function - Plot spike train
function doPlot(S)
SpkVector = zeros(1,S.SpikeData.Resolution*S.SpikeData.Duration);
for n = 1:length(S.SpikeData.SpkTime)
    idx = round(S.SpikeData.SpkTime(n) * S.SpikeData.Resolution);
    SpkVector(1,idx) = 1;
end
deltaT = 1 / S.SpikeData.Resolution;
tVector = deltaT:deltaT:S.SpikeData.Duration;
figure, hold on
plot(tVector,S.CaTrace,'r')
plot(tVector,ScaleToMinMax(SpkVector,min(S.CaTrace),max(S.CaTrace)/2),'--k')
set(gca,'Box','off'); xlabel('Time / s')

%% Function - Parse inputs
function S = parseInputArgs(inargs)
if ~isempty(inargs) && isstruct(inargs{1})
    % convert structure to pseudo-input cellarray
    inargs = struct2cellArray(inargs{1});
end
SpInput = find(strcmpi(inargs,'SpikeData'));
if numel(SpInput)
    S.SpikeData = inargs{SpInput+1};
else
    vars = evalin('base','who');
    [var_no status] = listdlg('PromptString','Select SpikeData variable:',...
        'ListString',vars,'ListSize',[300 400]);
    if status
        for n = 1:length(var_no)
            S.SpikeData =  evalin('base',vars{var_no(n)});
        end
    else
        return
    end
end
if ~isstruct(S.SpikeData)
    error('Modifier for spike data property must be a structure (as returned by SpikeTrainGenerator)');
end
SpInput = find(strcmpi(inargs,'Resolution'));
if numel(SpInput)
    S.Resolution = inargs{SpInput+1};
else
    S.Resolution = 10;
end
SpInput = find(strcmpi(inargs,'AmpCa'));
if numel(SpInput)
    S.AmpCa = inargs{SpInput+1};
else
    S.AmpCa = 200;
end
SpInput = find(strcmpi(inargs,'TauCa'));
if numel(SpInput)
    S.TauCa = inargs{SpInput+1};
else
    S.TauCa = 0.1;
end
SpInput = find(strcmpi(inargs,'doPlot'));
if numel(SpInput)
    S.doPlot = inargs{SpInput+1};
else
    S.doPlot = 0;
end


