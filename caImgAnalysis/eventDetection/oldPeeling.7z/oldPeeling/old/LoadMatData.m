function data = LoadMatData(matfile)

vars = load(matfile);
var_fields = fieldnames(vars);
if numel(var_fields) > 1
    warning(...
        'Specified .mat file contains more than 1 variable. Will load first only.');
end
data = vars.(var_fields{1});