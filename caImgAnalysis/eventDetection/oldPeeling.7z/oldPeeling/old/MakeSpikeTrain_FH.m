function spikes = MakeSpikeTrain_FH
% creates exactly same spike train as implemented by DeclVar macro in Igor


load('spikes.mat');

time_axis = 0.1:0.1:(length(spikes)/10);
figure
set(gcf,'Name','Spikes&Ca','NumberTitle','off','Units','normalized',...
    'Position',[0.01 0.5 0.98 0.43]);
axes('Units','normalized','Position',[0.05 0.05 0.9 0.9]);
plot(time_axis,spikes);
xlim([0.1 time_axis(length(time_axis))]);

hold on