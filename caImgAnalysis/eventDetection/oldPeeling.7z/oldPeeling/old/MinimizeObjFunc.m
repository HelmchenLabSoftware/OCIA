function similarity = MinimizeObjFunc(spikes,opt_args)
if numel(opt_args.ca_tau) > 1 && numel(opt_args.ca_amp) > 1
   opt_args.ca_tau = spikes(1);
   opt_args.ca_amp = spikes(2);
end
dff = opt_args.event_trace;
time_axis = opt_args.event_time_axis;
time_axis = reshape(time_axis,size(dff));
[dur time] = gui_CalculateTimeVector(...
    dff,opt_args.freq_ca,[]);
spike_train = zeros(1,round(dur*opt_args.freq_ap));
% for each value in spikes, find closest value in time_axis and then
% augment spike_train in this position by 1
% time_axis = round(time_axis.*10)/10;
[dur_ap, time_ap] = gui_CalculateTimeVector(spike_train,opt_args.freq_ca,[]);
for n = 1:length(spikes)
    %     current_spike_time = round(spikes(n)*opt_args.freq_ap)/opt_args.freq_ap;
    [min_val,pos] = min(abs(time_ap-spikes(n)));
    %     spike_train(floor(current_spike_time*opt_args.freq_ap)) = ....
    %         spike_train(floor(current_spike_time*opt_args.freq_ap)) + 1;
    %     spikes(n) = current_spike_time;
    if ~spike_train(pos(1))
        spike_train(pos(1)) = 1;
    else
       if ~spike_train(pos(1)+1)
           spike_train(pos(1)+1) = 1;
       else
           spike_train(pos(1)-1) = 1;
       end
    end
    spike_train(pos(1)) = spike_train(pos(1)) + 1;
    %     spike_train_pos = min(abs(spikes(n)-time_axis));
    %     spike_train_pos = find(abs(spikes(n)-time_axis)==spike_train_pos);
    %     spike_train(spike_train_pos(1)) = spike_train(spike_train_pos(1))+1;
end
% spike_train = [spike_train zeros(size(opt_args.event_tail))]';
model = Spike2DFF(spike_train,opt_args.ca_amp,opt_args.ca_tau,...
    opt_args.freq_ap,opt_args.freq_ca,opt_args.saturate,opt_args.delay);
[model_duration model_time_axis] = gui_CalculateTimeVector(model,...
    opt_args.freq_ca,[]);
% model = reshape(model,size(spike_train));
% model = ca_amp*exp(-time_axis/ca_tau);
% model = conv(spike_train,model);
% model(length(dff)+1:end) = [];

% smooth model
if ~strcmp(opt_args.smooth_alg,'none')
    model = SmoothModel(opt_args.smooth_alg,model_time_axis,model,...
        opt_args.windowSize);
end
model = reshape(model,size(dff));
% dff = [dff opt_args.event_tail]';
if strcmp(opt_args.error_func,'-Correlation')
    % fast cc function (mex)
    similarity = -(prcorr2(dff,model));
elseif strcmp(opt_args.error_func,'RMSE')
    similarity = sqrt(mean((dff-model).^2));
end

function model = SmoothModel(method,model_time_axis,model,windowSize)

if strcmp(method,'moving average')
    % 1. Moving average
    method = 'moving';
    span = windowSize * 10;
    model = smooth(model_time_axis,model,span,method);
elseif strcmp(method,'local regression')
    % 2. Local regression using weighted linear least squares
    method = 'lowess';
    span = windowSize / model_time_axis(length(model_time_axis));
    model = smooth(model_time_axis,model,span,method);
elseif strcmp(method,'robust local regression')
    % 3. robust local regression (slow)
    method = 'rlowess';
    span = windowSize / model_time_axis(length(model_time_axis));
    model = smooth(model_time_axis,model,span,method);
end


