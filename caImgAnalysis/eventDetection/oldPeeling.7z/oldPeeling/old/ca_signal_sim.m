%TODO: account for non-linear effects of multiple spikes

% Simulation parameters
% duration of simulation in ms
duration = 20000;
% baseline in ms
baseline = 6000;
% initial sampling interval in ms
sampling = 1;
% Event frequency in Hz
event_freq = 0.5;
% Time constant of exponential decay of probability of occurence of another
% spike
tau_ap = 1;
% Max. number of consecutive APs
max_ap = 3;
% Length of a single AP in ms
dur_ap = 3;
% time constant for Ca-decay in ms
tau_ca = 500;
% variance of Gaussian high f noise (0 for none)
var_gauss = 0.003;
% period of low f sine noise in ms (0 for none)
sin_per = 0;
% amplitude of low f sine noise
sin_amp = 0.05;

% downsampling to imaging frequency (Hz)
ds_freq = 10;
dws_freq = ds_freq/1000;

rep_rate = sampling / ds_freq;

save_basename = 'ca_signal_sim';

spike_no = 1:max_ap;
spike_p = exp(-spike_no/tau_ap);

ap_vect = zeros(1,duration/sampling);
aps = 0;
events = 0;
ap_pos = 1;

while true
    if rand < (event_freq/1000) && ap_pos <= length(ap_vect) ...
            && ap_pos > baseline
        events = events + 1;
        ap_vect(ap_pos) = 1;
        aps = aps + 1;
        prob = rand;
        for m = max_ap:-1:2
            if prob < spike_p(m)
                % we need 'm-1' more APs
                for o = 1:m-1
                    if ap_pos+dur_ap <= length(ap_vect)
                        ap_pos = ap_pos + dur_ap;
                        ap_vect(ap_pos) = 1;
                        aps = aps + 1;
                    end
                end
                break
            end
        end
        ap_pos = ap_pos + dur_ap;
    else
        ap_pos = ap_pos + 1;
    end
    if ap_pos > length(ap_vect)
        break
    end
end

fprintf('Generated %s events with %s APs\n',int2str(events),int2str(aps));

decay_x = 1:length(ap_vect);
decay_y = 0.05*exp(-decay_x/tau_ca);

ap_vect_conv = conv(ap_vect,decay_y);
ap_vect_conv(length(ap_vect)+1:end) = [];
ap_vect(find(ap_vect==0)) = NaN;

clear ap_pos m n o spike_no spike_p prob decay_x decay_y

% add gaussian high f noise
if var_gauss
    noise = sqrt(var_gauss)*randn(size(ap_vect_conv));
    ap_vect_conv = ap_vect_conv + noise;
end

% add low frequency noise
if sin_per
    sin_x = 1:length(ap_vect);
    sin_noise = sin_amp*sin(sin_x./(0.5*sin_per/pi));
    sin_noise = sin_noise + sqrt(var_gauss)*randn(size(sin_noise));
    ap_vect_conv = ap_vect_conv + sin_noise;
end
ap_vect(find(ap_vect==1)) = mean(ap_vect_conv);
% plot
hold on
h = plot(ap_vect_conv,'r','LineWidth',1);
h = plot(ap_vect,'Marker','s','MarkerEdgeColor','k','MarkerFaceColor','k',...
    'MarkerSize',3);

% downsample to imaging frequency
ds_freq = ds_freq/1000;
rep_rate = sampling / ds_freq;
counter = 1;
ap_vect_conv_ds = zeros(1,(length(ap_vect_conv)/rep_rate));
for n = 1:length(ap_vect_conv)
   if rem(n,rep_rate) == 0
      ap_vect_conv_ds(counter) = mean(ap_vect_conv((n-rep_rate+1):n));
      counter = counter + 1;
   end
end
hold off
figure
f = plot(ap_vect_conv_ds,'LineWidth',1);

% save vectors and plots
% save([save_basename '.mat'],'ap_vect', 'ap_vect_conv');
% saveas(h,[save_basename '.fig']);




% e.o.f.



