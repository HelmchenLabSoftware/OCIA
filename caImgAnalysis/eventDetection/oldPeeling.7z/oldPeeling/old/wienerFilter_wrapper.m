%generate random noise array

SIZE = 128;   
N = randn(SIZE,SIZE);  %generates a random Gaussian matrix with SIZExSIZE components
N(50,:)=N(50,:) + 2;   %line is x=50 and raised by 2 above the noise mean.

figure(1)
colormap(jet)
image(N*50)          %multiplies each pixel in the image by 50


h = ones(10,10)/16;  %Filter function

sigma=1;  % should always be 1 for a gaussian noise distribution as stated in the Matlab RANDN function

Xf = fft2(N);            %Fourier Transform of supplied image
Hf = fft2(h,SIZE,SIZE);  %Fourier Transform of blurring filter
y = real(ifft2(Hf.*Xf));  

%y is the real inverse fourier transform of the Fourier transform of 
%the initial image multiplied by the Fourier Transform of the filter 
%function (h). This creates the output image y

% restoration using generalized Wiener filtering
gamma = 1;
alpha = 1;

ewx = wienerFilter(y,h,sigma,gamma,alpha);  

figure(2)

colormap(jet)
image(ewx*50)  %magnifies each pixel in the image by 50

 
return
