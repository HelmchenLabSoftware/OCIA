function varargout = ap_ca_analysisManual(varargin)
% analyse Ca-trace and ephys trace
% in1 ... scenario3-structure with infos about Ca-trace, ephys, sampling
% frequencies etc. (specify as string)
% this file written by Henry Luetcke (hluetck@gmail.com)

% assign variable or open dialog to import from base workspace
if ~nargin
    [config,exp_title] = GetConfigFromBase;
else
    if isstruct(varargin{1})
        config = varargin{1};
        exp_title = 'unknown_exp';
    elseif isstr(varargin{1})
        exp_title = varargin{1};
        config = evalin('base',exp_title);
    else
        [config,exp_title] = GetConfigFromBase;
    end
end
% clear all figures for new overview
if nargin < 2
    close all
end
% restrict part of trace to be analyzed (e.g. only the first 20 s)
% [start_s end_s]
if nargin == 2
    time_restrict = varargin{2};
end
% expID would be everything before the first underscore
exp_title = exp_title(1:strfind(exp_title,'_')-1);

ephys = config.ephys;
ca_trace = config.roi_dff_trace;

% create time vectors for AP and Ca
[dur_ap time_ap] = gui_CalculateTimeVector(ephys,config.freq_ap,[]);
[dur_ca time_ca] = gui_CalculateTimeVector(ca_trace,config.freq_ca,[]);

% APs are ca. 1ms wide --> high-pass filter at 50 Hz (also demeans the
% signal)
ephys = mpi_BandPassFilterTimeSeries(ephys,1/config.freq_ap,50,...
    config.freq_ap*10);
ephys = ephys';

% hp-filter Ca-trace and plot
ca_trace = mpi_BandPassFilterTimeSeries(ca_trace,1/config.freq_ca,0.1,...
    config.freq_ca*10);

% scale ephys such that scale_factor V correspond to 1% DRR
scale_factor = 0.01;
ephys = ephys/scale_factor;

% detect the APs (threshold at 25% the max. ephys_hp amplitude)
ephys_thresh = zeros(size(ephys));
ephys_thresh(ephys>(max(ephys)/2)) = max(ephys)/5;

% select the first timepoint of each spike as the time of occurence
ap_yn = 0;
ap_no = 0;
APonset = zeros(size(ephys));
ManyAPsIsOk = 0;
for n = 1:length(ephys)
    if ap_no > 100 && ~ManyAPsIsOk
        warning('100 APs detected at %s s.',num2str(n/config.freq_ap));
        answer=input('Continue (y or n)? ','s');
        if strcmp(answer,'n')
            clear all
            varargout{1} = {''};
            return
        else
            ManyAPsIsOk = 1;
        end
    end
    if ~ephys_thresh(n) && ~ap_yn
        continue
    end
    if ephys_thresh(n) && ~ap_yn
        ap_yn = 1;
        ap_no = ap_no + 1;
        APonset(n) = max(ephys_thresh);
    elseif ~ephys_thresh(n) && ap_yn
        ap_yn = 0;
    end
end
APonset_plot = APonset;
APonset_plot(~APonset)=NaN;

% plot traces (only if 0 or 1 inputs) and return
if nargin < 2
    h1 = figure('Name',[exp_title ' - data']);
    ystring = ['DRR (%) & Voltage (V/' num2str(1/scale_factor) ')'];
    ylabel(ystring);
    xlabel('Time / s');
    hold all;
    xlim([min([min(time_ca) min(time_ap)]) max([max(time_ca) max(time_ap)])])
    plot(time_ap,ephys);
    plot(time_ca,ca_trace);
    plot(time_ap,ephys_thresh);
    plot(time_ap,APonset_plot,'x')
    legend('ephys\_hp','Ca\_hp','ephys\_thresh','AP onset');
    varargout{1} = {''};
    return
end
ephys_raw = ephys; ephys = APonset;
clear ephys_thresh APonset APonset_plot

% warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
% setWindowState(h1,'minimize');

mean_ca = mean(ca_trace); sd_ca = std(ca_trace);
mean_e = mean(ephys_raw); sd_e = std(ephys_raw);

% select requested part of the trace
if ~isempty(time_restrict)
    [diff start] = min(abs(time_ap-time_restrict(1)));
    [diff stop] = min(abs(time_ap-time_restrict(2)));
    ephys = ephys(start:stop); 
    ephys_raw = ephys_raw(start:stop); 
    time_ap = time_ap(start:stop);
    [diff start] = min(abs(time_ca-time_restrict(1)));
    [diff stop] = min(abs(time_ca-time_restrict(2)));
    ca_trace = ca_trace(start:stop); time_ca = time_ca(start:stop);
    clear start stop
else
    time_restrict = [0 max([dur_ap dur_ca])];
end

% for each AP, calculate the Ca-response from ap_start to ap_stop
ap_start = -1;
ap_stop = 3;
% ap_start = time_restrict(1);
% ap_stop = time_restrict(2);
% pad each of the vectors with gaussian noise to ensure that AP-locked
% averaging still works if APs occur close to start or end
pad_start =zeros(ceil(abs(ap_start)*config.freq_ap),1);
pad_stop = zeros(ceil(abs(ap_stop)*config.freq_ap),1);
ephys = [pad_start; ephys; pad_stop];
pad_start = mean_e+sd_e*randn(1,ceil(abs(ap_start)*config.freq_ap));
pad_stop = mean_e+sd_e*randn(1,ceil(abs(ap_stop)*config.freq_ap));
ephys_raw = [pad_start ephys_raw' pad_stop];
pad_start = mean_ca+sd_ca*randn(1,ceil(abs(ap_start)*config.freq_ca));
pad_stop = mean_ca+sd_ca*randn(1,ceil(abs(ap_stop)*config.freq_ca));
ca_trace = [pad_start ca_trace pad_stop];
[dur_ap time_ap] = gui_CalculateTimeVector(ephys,config.freq_ap,[]);
[dur_ca time_ca] = gui_CalculateTimeVector(ca_trace,config.freq_ca,[]);

% plot the resulting trace
h1 = figure('Name',[exp_title ' - data']);
ystring = ['DRR (%) & Voltage (V/' num2str(1/scale_factor) ')'];
ylabel(ystring);
xlabel('Time / s');
hold all;
xlim([min([min(time_ca) min(time_ap)]) max([max(time_ca) max(time_ap)])])
plot(time_ap,ephys_raw);
plot(time_ca,ca_trace);
plot(time_ap,ephys);
legend('ephys\_hp','Ca\_hp','AP onset');
varargout{1} = {''};

ap_no = 0;
periAP_trace = []; % collect periAP timecourse
for n = 1:length(ephys)
    if ~ephys(n)
        continue
    else
        if ~ap_no
            ap_no = ap_no + 1;
            ap_time = time_ap(n);
            APfirstTime = ap_time;
                        start_time = ap_time+ap_start;
                        end_time = ap_time+ap_stop;
%             start_time = time_ca(1);
%             end_time = time_ca(length(time_ca));
            % corresponding closest values in time_ca (they are different, due
            % to sampling, etc)
            [diff pos] = min(abs(time_ca-start_time));
            start_time = time_ca(pos);
            [diff pos] = min(abs(time_ca-end_time));
            end_time = time_ca(pos);
            [diff pos] = min(abs(time_ca-ap_time));
            ap_time_ca = time_ca(pos);
            tp = 1;
            for m = 1:length(ca_trace)
                if time_ca(m) >= start_time && time_ca(m) <= end_time
                    periAP_trace(1,tp) = ca_trace(m);
                    periAP_trace(2,tp) = time_ca(m)-ap_time;
                    if time_ca(m) == ap_time_ca
                        stop_base = tp;
                    end
                    tp = tp+1;
                end
            end
            % normalize to baseline mean
            base_mean = mean(periAP_trace(1,1:stop_base-1));
            base_sd =  std(periAP_trace(1,1:stop_base-1));
            periAP_trace(1,:) = periAP_trace(1,:) - base_mean;
        else
            ap_no = ap_no + 1;
            ap_time = time_ap(n);
        end
        % AP-amplitude and width
        [APwidth(ap_no), APamp(ap_no)] = ...
            GetAPstats(ephys_raw,time_ap,ap_time);
    end
end
APwidth = mean(APwidth);
APamp = mean(APamp);
ca_trace = periAP_trace(1,:);
time = periAP_trace(2,:);
APevoked = ca_trace(time>0);
APbase = ca_trace(time<=0);
% plot AP-locked timecourse
h2 = figure('Name',[exp_title ' - AP locked Ca']);
hold all
plot(time,ca_trace);
% max. signal would be expected within 700 ms, or so
max_frame = round(0.7*config.freq_ca);
ca_amp = max(APevoked(1:max_frame));
delay = time(find(ca_trace==ca_amp));
fprintf('\nTimecourse statistics for %s (%s APs)\n',exp_title,...
    int2str(ap_no));
fprintf('Ca-amplitude: %s %%DRR\tTtP: %s s\n',num2str(ca_amp),...
    num2str(delay));
fprintf('Baseline mean: %s %%DRR\tSD: %s\n',num2str(mean(APbase)),...
    num2str(std(APbase)));

% fit exponential model from the peak of the curve
time_fit = time(find(time==delay):end);
data_fit = ca_trace(find(time==delay):end);
% data_fit = data_fit(1:length(time_fit));

% fit exponential decay to mean AP-locked timecourses
% set initial and boundary values for the gaussian fit
% amplitude factor (in % DRR)
a1_init = ca_amp;
a1_low = 0.9*ca_amp;
a1_high = 1.1*ca_amp;
% delay constant (in s)
b1_init = delay;
b1_low = 0.9*delay;
b1_high = 1.1*delay;
% decay constant (in s)
c1_init = 0.5;
c1_low = 0.2;
c1_high = 5;
% fit using Matlab advanced fitting procedure
% with constraints on parameter values as well as start points
fo_ = fitoptions('method','NonlinearLeastSquares',...
    'Lower',[a1_low b1_low c1_low], 'Upper',[a1_high b1_high c1_high]);
%start points for parameters
st_ = [a1_init b1_init c1_init];
set(fo_,'Startpoint',st_);
%equation, variables and parameters for fit
ft_ = fittype('a1*exp(-(x-b1)/c1)' ,...
    'dependent',{'y'},'independent',{'x'},...
    'coefficients',{'a1','b1','c1'});
[fresult, gof, fit_info] = fit(time_fit',data_fit',ft_ ,fo_);

coef = coeffvalues(fresult);
fit_amp = coef(1); fit_delay = coef(2); fit_decay = coef(3);
fprintf('Fit results (R^2=%s)\n',num2str(gof.rsquare));
fprintf('Amplitude: %s %%DRR\tDelay: %s s\tDecay: %s s\n',...
    num2str(fit_amp),num2str(fit_delay),num2str(fit_decay));
time_fit = time_fit(1):0.001:time_fit(length(time_fit));
data_fit = fit_amp.*exp(-(time_fit-fit_delay)/fit_decay);
% plot the fit
plot(time_fit,data_fit,'r');
legend('Mean Ca','Fit');
hold off

% save important info in cell array and return
% in columns: exp., CaRate, EvalStart,EvalStop,FirstAPtime, AP number, PeriStart,PeriStop
% CaAmp,TtP, BaseMean, BaseSD,fitCaAmp,fitTtP,fitTau,Gof,APamp,APwidth,PeriAP_trace
varargout{1} = {''};
varargout{1} = {exp_title config.freq_ca time_restrict(1) time_restrict(2) APfirstTime ...
    ap_no ap_start ap_stop ca_amp delay mean(APbase) std(APbase) ...
    fit_amp fit_delay fit_decay gof.rsquare APamp APwidth periAP_trace};

function [config,exp_title] = GetConfigFromBase
vars = evalin('base','who');
if ~isempty(vars)
    [choice,status] = listdlg('PromptString','Select a variable:',...
        'SelectionMode','single',...
        'ListString',vars);
    if ~status return; end
else
    warndlg('No variables in base workspace!');return
end
config = evalin('base',vars{choice});
exp_title = vars{choice};

function [APwidth, APamp] = GetAPstats(etrace,time,ap_onset)
% assume about 1 ms width; get trace from -0.5ms to +2ms from onset;
% discard values smaller 0; find peak; fit Gauss to get FWHM
etrace = reshape(etrace,size(time));
start = ap_onset - (0.5/1000);
stop = ap_onset + (2/1000);
[diff pos1] = min(abs(time-start));
[diff pos2] = min(abs(time-stop));
etrace = etrace(pos1:pos2);
time = time(pos1:pos2);
etrace(etrace<0) = 0;
% figure
% plot(time,etrace)
% hold on
APamp = max(etrace);
PeakTime = time(find(etrace==APamp));
% fit the Gauss
[fresult, gof, fit_info] = fit(time,etrace,'gauss1');

coef = coeffvalues(fresult);
a1 = coef(1); b1 = coef(2); c1 = coef(3);
APwidth = c1;
fprintf('Fit results - Gauss(R^2=%s)\n',num2str(gof.rsquare));
fprintf('a1: %s\tb1: %s\tc1: %s\n',...
    num2str(a1),num2str(b1),num2str(c1));
% time = time(1):0.0001:time(length(time));
% etrace =  a1.*exp(-((time-b1)./c1).^2);
% plot the fit
% plot(time,etrace,'r');
% legend('APtrace','Fit');
hold off



