function Prepare4SpikeRecon(varargin)
% generate data structure that can be loaded into ap_main to compare DFF
% and ephys trace (Scenario 3)
% Inputs:
% in1 ... .fcs-file
% in2 ... ephys-file
% in3 ... sampling frequency for imaging
% in4 ... sampling frequency for ephys
% in5 ... ephys acquisition duration in s
% in6 ... slices to delete
% in7 ... baseline interval in frames ([start stop] or number of initial
% frames); used to calculate stats image
% in8 ... imageJ roi file (or set of several files)

% this file written by Henry Luetcke (hluetck@gmail.com)

% support 'drr' and 'dff' (dff calculated from ch1)
stats_type = 'drr';

% some more settings
% band-pass filter ephys (cutoffs in Hz)
bp_lo = 100;
bp_hi = 1000;
% threshold for bg subtract (percentile cutoff, empty for none)
bg_thresh = [];
% smoothing span
span = 3;



filename = varargin{1};
ephys_file = varargin{2};
freq_ca = varargin{3};
freq_ap = varargin{4};
ephys_time = varargin{5};
ephys_points = ephys_time * freq_ap;
del_slice = varargin{6};
base = varargin{7};
roifile = varargin{8};

% read ephys and delete points corresponding to deleted frames
ephys = ReadEphys(ephys_file,ephys_points)';
del_points = del_slice / freq_ca * freq_ap;
ephys(1:del_points) = [];

% bandpass filter ephys (spikes are only a few ms in width)
ephys = mpi_BandPassFilterTimeSeries(ephys,1/freq_ap,bp_lo,bp_hi);

img = import_raw(filename);
img.ch1 = double(PreprocImageData(img.ch1,del_slice,bg_thresh));
img.ch2 = double(PreprocImageData(img.ch2,del_slice,bg_thresh));

% temporal smoothing of timeseries
% for x = 1:size(img.ch1,1)
%     for y = 1:size(img.ch1,2)
%         img.ch1(x,y,:) = smooth(img.ch1(x,y,:),span);
%         img.ch2(x,y,:) = smooth(img.ch2(x,y,:),span);
%     end
% end

switch stats_type
    case 'drr'
        stats = img.ch1 ./ img.ch2;
    case 'dff'
        stats = img.ch1;
end

if length(base) > 1
    f0 = stats(:,:,base(1):base(2));
else
    f0 = stats(:,:,1:base);
end
f0 = nanmean(f0,3);
f0 = repmat(f0,[1 1 size(stats,3)]);

% calculate stats
img.stats = ((stats-f0) ./ f0).* 100;
img.stats(img.stats==Inf) = 0;
img.stats(img.stats==-Inf) = 0;
img.stats(img.stats==NaN) = 0;

% save image arrays as tif
write_to_tif(img,strrep(filename,'.fcs',''));

% pixel time
pixel_time = (1/freq_ca)/(size(img.ch1,1)*size(img.ch1,2));

roi_set = ij_roiDecoder(roifile,[size(img.ch1,1) size(img.ch1,2)]);

for n = 1:size(roi_set,1)
   roi_stats{n} = mean(GetRoiTimeseries(img.stats,bwunpack(roi_set{n,2})),1);
   roi_id{n} = roi_set{n,1};
   % mean index of non-zero mask pixels (mask must be transposed)
   mask = bwunpack(roi_set{n,2});
   mask = mask';
   ca_shift{n} = mean(find(mask==1)) * pixel_time;
   ca_shift{n} = (1/freq_ca) - ca_shift{n};
end

% create output structure
out.ca_file = filename;
out.e_file = ephys_file;
out.ephys = ephys;
out.freq_ca = freq_ca;
out.freq_ap = freq_ap;
out.baseline = base; % in s
out.roi_stats = roi_stats;
out.roi_id = roi_id;
out.ca_shift = ca_shift;


config = orderfields(out);

SaveAndAssignInBase(config,[strrep(filename,'.fcs','') '_config.mat']);

% save([strrep(filename,'.fcs','') '_config.mat'],'config');


%% Image preprocessing
function img_data = PreprocImageData(img_data,del_slice,bg_thresh)
% in1 ... raw image matrix
% in2 ... number of initial slices to delete
% in3 ... background subtraction threshold (percentile)
img_data(:,:,1:del_slice) = [];
img_data = img_data./255;
img_data = uint8(img_data);
if ~isempty(bg_thresh)
    img_data = bg_subtract_HL(img_data,bg_thresh,1,'percentile');
end
img_data(img_data<0)=0;



