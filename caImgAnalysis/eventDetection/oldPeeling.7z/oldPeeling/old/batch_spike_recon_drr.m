function batch_spike_recon_drr

% requires tif-files for both channels, roi-files, scenario3-structure
base_images = 10;
dir_list = dir('ephys14*');
roi_id = 'cell1.roi';

% threshold for bg. subtraction (in %)
bg_thresh = 5;

for n = 1:length(dir_list)
   fprintf('\nStarted work in directory %s at %s\n',...
        dir_list(n).name,datestr(clock));
    if dir_list(n).isdir
        cd(dir_list(n).name);
        if ~exist(fullfile(pwd,roi_id),'file')
           disp('No ROI-file found here');
           cd ..
           continue
        end
        ch1_image = dir('*_ch1.tif');
        ch1_image = ch1_image(1).name;
        ch1_image = tif2mat(ch1_image,'nosave');
        ch1_image = ch1_image.data;
        ch2_image = dir('*_ch2.tif');
        ch2_image = ch2_image(1).name;
        ch2_image = tif2mat(ch2_image,'nosave');
        ch2_image = ch2_image.data;
        mask = ij_roiDecoder(roi_id,[size(ch1_image,1) size(ch1_image,2)]);
        mat_file = dir('*_config.mat');
        mat_file = mat_file(1).name;
        config = load(mat_file);
        config = config.(cell2mat(fieldnames(config)));
        
        % Image high-pass filter
        ch1_image = hp_filter(ch1_image,2);
        ch2_image = hp_filter(ch2_image,2);
        
        % Background subtraction
        ch1_image = bg_subtract_HL(ch1_image,bg_thresh,0);
        ch2_image = bg_subtract_HL(ch2_image,bg_thresh,0);
        
        % pixel time
        pixel_time = (1/config.freq_ca)/(size(ch1_image,1)*size(ch1_image,2));
        
        % mean index of non-zero mask pixels (mask must be transposed)
        mask = mask';
        % multiply with pixel time to get mean ROI time in s
        config.ca_shift = mean(find(mask==1)) * pixel_time;
        config.ca_shift = (1/config.freq_ca) - config.ca_shift;
        mask = mask';
        fprintf('\nMean ROI time: %s s\n',num2str(config.ca_shift));
        
        % ROI timeseries from ch1 and ch2
        ch1_roi_mat = GetRoiTimeseries(ch1_image,mask);
        ch2_roi_mat = GetRoiTimeseries(ch2_image,mask);
        
        % Background subtraction
%         ch1_roi = mean(bg_subtract(ch1_roi_mat,0));
%         ch2_roi = mean(bg_subtract(ch2_roi_mat,0));
        
        ch1_roi = mean(ch1_roi_mat);
        ch2_roi = mean(ch2_roi_mat);
        
        % calculate DRR
        ratio = ch1_roi ./ ch2_roi;
        r0 = mean(ratio(1:base_images));
        dR = ratio - r0;
        dRR = (dR ./ r0).*100;
        config.roi_dff_trace = dRR;
        
        % save structure
        var_name = strrep(mat_file,'.mat','');
        eval([var_name ' = config']);
        save(mat_file,var_name);
        assignin('base',var_name,config);
        cd ..
    end 
end







