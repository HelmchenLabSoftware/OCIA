function config = CalciumEventDetect(varargin)
% detect events (e.g. APs) in two-photon calcium traces using different
% methods
% input structure with compulsory fields
% ca ... Roi calcium trace as vector
% rate ... frame rate of calcium imaging
% amp ... estimated amplitude of 1AP transient
% tau ... estimated decay time for calcium transients
% return vector with events (zero for no event)
% method ... detection algorithm ('fast_oopsi')
% specific parameters for 'fast_oopsi' algorithm:
% filter ... filter calcium trace for estimation of integral, use
% Savitzky-Golay filter with [span degree] (default [7 2], empty for none)
% base_frames ... number of frames before detected event (for integral
% estimation, default: 5)
% oopsi_thr ... threshold for fast_oopsi output (default: 0.1, 0 for none)
% integral_thr ... minimum number of events derived from integral (default: 1, 0 for none)

% this file written by Henry Luetcke (hluetck@gmail.com)

config = varargin{1};

switch lower(config.method)
    case 'fast_oopsi'
        config = doFast_oopsi(config);
    case 'peeling'
        config = doPeeling(config);
    otherwise
        fprintf('\nEvent detection method %s not implemented yet.\n',...
            config.method);
        return
end

function config = doFast_oopsi(config)
if ~isfield(config,'oopsi_thr')
    config.oopsi_thr = 0.3;
end
config.data.denoised_dff = config.ca;
config.sim_pars.freq_ca = config.rate;
if ~isfield(config,'integral_thr')
    config.integral_thr = 1;
end
if ~isfield(config,'base_frames')
    config.base_frames = 10;
end
if ~isfield(config,'doPlot')
    config.doPlot = 0;
end
if ~isfield(config,'minGof')
    config.minGof = 0.5;
end

config = fast_oopsi_wrapper(config);
% events = config.data.spike_predict;

function config = doPeeling(config)

[ca_p,exp_p,peel_p, data] = InitPeeling(config.ca,config.rate);

% override some parameters
ca_p.amp1=config.amp;
ca_p.tau1=config.tau;
ca_p.onsettau = config.onsettau;

dff = config.ca;

time_ca = 1/config.rate:1/config.rate:length(dff)/config.rate;

% SD of calcium trace
dff_filt = mpi_BandPassFilterTimeSeries( dff ,1/config.rate ,0.5 ,config.rate );
%figure; hold all; plot(time_ca,dff);plot(time_ca,dff_filt);
SDdff = std(dff_filt);

% Schmitt trigger - high threshold, relative to noise
peel_p.smtthigh = config.schmittHi*SDdff;
peel_p.smttlow = config.schmittLo*SDdff; 
peel_p.smttmindur= config.schmittmindur;

peel_p.doPlot = config.doPlot;

P = struct;

[ca_p, peel_p, data] = Peeling(ca_p, exp_p, peel_p, data);
 
spikes_predict = data.spiketrain;
config.data.spike_predict = data.spiketrain;
config.data.oopsi = data.peel;
config.data.model = data.model;
config.data.SD = SDdff;
config.data.P.sig = SDdff;


