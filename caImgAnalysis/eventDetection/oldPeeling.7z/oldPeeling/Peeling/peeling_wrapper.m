function varargout = peeling_wrapper(handles, ca_p, exp_p, peel_p, data)
% run fast_oopsi routine by Joshua Vogelstein

% this file written by Henry Luetcke (hluetck@gmail.com)

SavePlot = 0;
doFilter = 0;

% cost for spike time distance measure (cost per unit time to move a spike)
spikeDistCost = 1;

if isfield(handles,'amp')
    ca_amp = handles.amp;
else
    ca_amp = 2.5;
end

if isfield(handles,'tau')
    ca_tau = handles.tau;
else
    ca_tau = 0.6;
end

if isfield(handles,'id')
    fprintf('%s\n',handles.id);
end

if isfield(handles,'doPlot')
    doPlot = handles.doPlot;
else
    doPlot = 1;
end

% output matrix A with results from spike detection
A = [];

freq_ca = handles.sim_pars.freq_ca;

dff = data.dff;
% time_ca = data.tim;

[dur,time_ca] = gui_CalculateTimeVector(dff,freq_ca,[]);
if isfield(handles,'ca_shift')
   time_ca = time_ca - handles.ca_shift;
end

% SD of calcium trace
dff_filt = mpi_BandPassFilterTimeSeries( dff , 1/freq_ca , 0.5 , 100 );
%figure; hold all; plot(time_ca,dff);plot(time_ca,dff_filt);
SDdff = std(dff_filt);

peel_p.smtthigh = 2*SDdff;        % Schmitt trigger - high threshold, relative to noise
peel_p.smttlow = -1*SDdff; 

P = struct;

[ca_p, peel_p, data] = Peeling(ca_p, exp_p, peel_p, data);
 
spikes_predict = data.spiketrain;
handles.data.spike_predict = data.spiketrain;
handles.data.oopsi = data.peel;

[handles, A] = SpikeTrainCompare(handles,doPlot,time_ca,dff,data.model,...
    spikeDistCost,spikes_predict);

% spike times from ephys
[dur,time_ephys] = gui_CalculateTimeVector(handles.data.spikes,handles.sim_pars.freq_ap,[]);
spkTimesEphys = [];
for n = 1:length(handles.data.spikes_bin)
    if handles.data.spikes_bin(n)
        currentSpkT = repmat(time_ephys(n),handles.data.spikes_bin(n),1);
        spkTimesEphys = [spkTimesEphys; currentSpkT];
    end
end

% spike times from reconstruction
spkTimesPredict = [];
for n = 1:length(spikes_predict)
   if spikes_predict(n)
      currentSpkT = repmat(time_ca(n),spikes_predict(n),1);
      spkTimesPredict = [spkTimesPredict; currentSpkT];
   end
end

maxdt = 0.5; % in s
[dtMean,correct,missed,totalFalse] = ...
    SpikeTimeCompare(spkTimesEphys,spkTimesPredict,maxdt);

A = [numel(spkTimesEphys) numel(spkTimesPredict) correct missed totalFalse ...
            dtMean];


varargout{1} = handles;
varargout{2} = ca_p; 
varargout{3} = exp_p;
varargout{4} = peel_p;
varargout{5} = data;
varargout{6} = A; 

                     
