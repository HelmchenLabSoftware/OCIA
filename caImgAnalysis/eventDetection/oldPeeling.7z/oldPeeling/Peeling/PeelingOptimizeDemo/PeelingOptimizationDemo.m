%% Peeling optimization demo for Hifo progress report 2012-08

% written by Henry Luetcke (hluetck@gmail.com)

clc, clear all

load S.mat

spktSim = S.spkTimes;
spktRecon = S.recon.spkTimesRecon;

dff = S.data.noisyDFFlowResT;
t = (1:numel(dff))./S.frameRate;

% random seed for spike times
idx = randperm(numel(t));
spktInit = t(idx(1:2));

optMethod = 'pattern search';
optMaxIter = 100000;
[spktOpt,output] = PeelingOptimizeSpikeTimes(dff,spktInit,S.frameRate,...
    S.tauOn,S.A1,S.tau1,optMethod,optMaxIter,1);

% all possible spike time combinations
fvalAll = zeros(numel(t),numel(t));
for t1 = 1:numel(t)
    for t2 = 1:numel(t)
        modelTransient = modelCalciumTransient(t,t(1),S.tauOn,S.A1,S.tau1);
        modelTransient = modelTransient';
        spktimes = [t(t1) t(t2)];
        spkVector = zeros(1,numel(t));
        for i = 1:numel(spktimes)
            [~,idx] = min(abs(spktimes(i)-t));
            spkVector(idx) = spkVector(idx)+1;
        end
        model = conv(spkVector,modelTransient);
        model = model(1:length(t));
%         xAll(pos,1:2) = spktimes;
        fvalAll(t1,t2) = sum((dff-model).^2);
    end
end
transpMat = repmat(0.8,numel(t),numel(t));
figure, surf(t,t,fvalAll,'AlphaData',transpMat,'LineStyle','none'), hold on
% plot the trajectory of the search
load iterationData.mat
plot3(x(:,1),x(:,2),fval,'k','LineWidth',4)
xlabel('t1'), ylabel('t2'), zlabel('fval')

