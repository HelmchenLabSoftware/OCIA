function residual = peelObjFunc(schmitt,opt_args)

schmittHi = schmitt(1);
schmittLo = schmitt(2);
schmittMinDur = schmitt(3);

dff = opt_args.dff;
rate = opt_args.rate;
ca_p = opt_args.ca_p;
exp_p = opt_args.exp_p;
peel_p = opt_args.peel_p;

% SD of calcium trace (filter low frequency drifts, e.g. slower than 0.5 Hz)
% dff_filt = mpi_BandPassFilterTimeSeries(dff,1/rate,0.5,rate*2);
% SDdff = std(dff_filt);

SDdff = opt_args.SDdff;

% Schmitt trigger - high threshold, relative to noise
peel_p.smtthigh = schmittHi*SDdff;
peel_p.smttlow = schmittLo*SDdff;
peel_p.smttmindur= schmittMinDur;

P = struct;

[~, ~, data] = Peeling(dff, rate, ca_p, exp_p, peel_p);

residual = sum(data.peel.^2);
