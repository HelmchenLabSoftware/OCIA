function y = FillCalciumModel(xdata, ca_p, spikeTimes)
% FillCalciumModel

% Fill a trace with an artificial summate calcium trace based on the elementary calcium transient
% described by ca_p

y = repmat(0,size(xdata));
for k = 1:length(spikeTimes)
    for n = round(spikeTimes:length(xdata)
        ca_p(1) = spikeTimes(k);
        y(n) = y(n) + OnsetDoubleFit(ca_p,xdata(n));
    end
end

end

