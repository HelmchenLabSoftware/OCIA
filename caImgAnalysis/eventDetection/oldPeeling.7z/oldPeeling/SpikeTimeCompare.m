function [dtMean,dtSD,correct,missed,totalFalse,dtMatAbs] = ...
    SpikeTimeCompare(spkT1,spkT2,maxdt)
% spkT1 ... spike times for the true spike train
% spkT2 ... spike times for the reconstructed spike train
% maxdt ... max. allowed spike separtion (in s)

% this file written by Henry Luetcke (hluetck@gmail.com)

binWidth = 0.05;

dtMatAll = zeros(numel(spkT1),numel(spkT2));

% no spikes found
if isempty(spkT2)
    totalFalse = 0;
    correct = 0;
    missed = numel(spkT1);
    dtMean = NaN;
    dtSD = NaN;
    dtMatAbs = NaN;
    return
end

for n = 1:numel(spkT1)
    dtMatAll(n,:) = (spkT1(n)-spkT2);
end
dtMatAbs = abs(dtMatAll);
dtMat = dtMatAbs;
dtMat(dtMat>maxdt) = inf;
% number of non-inf values
nonInf = numel(~isinf(dtMat));
dtVector = zeros(1,nonInf);
correct = 0;

for n = 1:nonInf
    [minVal,idx] = min(dtMat(:));
    if isinf(minVal)
        break
    end
    trueMin = dtMatAll(idx);
    [currentSpkT1,currentSpkT2] = ind2sub(size(dtMat),idx);
    correct = correct + 1;
    dtVector(correct) = trueMin;
    dtMat(currentSpkT1,:) = inf;
    dtMat(:,currentSpkT2) = inf;
end
dtVector(correct+1:end) = [];

missed = length(spkT1)-correct;
totalFalse = length(spkT2)-correct;

% dtMean = mean(dtVector);
% dtSD = std(dtVector);

% estimate mean / SD of dt by bootstrap
% if numel(dtVector) > 2
%     dtMean = mean(bootstrp(1000,@mean,dtVector));
%     dtSD = mean(bootstrp(1000,@std,dtVector));
% else
%     dtMean = mean(dtVector);
%     dtSD = std(dtVector);
% end

dtMean = dtVector;
dtSD = std(dtVector);

% nBins = maxdt / binWidth;
% [freq,xout] = hist(dtVector,nBins);
% figure
% subplot(1,2,1)
% plot(xout,freq/(correct+totalFalse),'k')
% set(gca,'ylim',[0 1])
% xlabel('Time to spike /s')
% ylabel('Fraction of total target spikes')
% title(sprintf('Sum: %1.2f',sum(freq/(correct+totalFalse))))
% 
% subplot(1,2,2)
% plot(xout,freq/(correct+missed),'k')
% set(gca,'ylim',[0 1])
% xlabel('Time to spike /s')
% ylabel('Fraction of total reference spikes')
% title(sprintf('Sum: %1.2f',sum(freq/(correct+missed))))

% perf = (sum(freq/(correct+totalFalse)) * sum(freq/(correct+missed))) ...
%     - std(dtVector);

% set(gcf,'Name',sprintf('Performance: %1.3f',perf),'NumberTitle','off')




