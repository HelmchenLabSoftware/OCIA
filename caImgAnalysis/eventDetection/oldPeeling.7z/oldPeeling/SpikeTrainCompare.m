function varargout = SpikeTrainCompare(varargin)
% Compare two spike trains and estimate their similarity

% this file written by Henry Luetcke (hluetck@gmail.com)

handles = varargin{1};
doPlot = varargin{2};
time_ca = varargin{3};
dff = varargin{4};
oopsi = varargin{5};
spikeDistCost = varargin{6};
spikes_predict = varargin{7};

PlotOutput = 'AP'; % 'AP' or 'Event'

SavePlot = 0;

%% Spike train comparison
if isfield(handles.data,'spikes')
    ephys = handles.data.spikes;
    freq_ap = handles.sim_pars.freq_ap;
    [dur,time_ephys] = gui_CalculateTimeVector(ephys,freq_ap,[]);
    
    % binarise spike train
    ephys_bin = handles.data.spikes_bin;
    if doPlot
        if isfield(handles,'id')
            figure('Name',handles.id,'NumberTitle','off');
        else
            figure
        end
        hold all
        plot(time_ca,dff);
        if isfield(handles.data,'filtered_dff')
            plot(time_ca,handles.data.filtered_dff');
        end
        ephys_bin_plot = ephys_bin - (max(ephys_bin)-min(dff));
        plot(time_ephys,ephys_bin_plot);
        ephys_plot = ScaleToMinMax(ephys,min(ephys_bin_plot),max(ephys_bin_plot));
        ephys_plot = ephys_plot - (max(ephys_plot)-min(ephys_bin_plot));
        plot(time_ephys,ephys_plot);
    end
    
    spikes_observe = zeros(1,length(dff));
    observed_spikes = 0;
    spikeTimes_obs = [];
    for n = 1:length(ephys)
        if ephys_bin(n)
            observed_spikes = observed_spikes + 1;
            current_time = time_ephys(n);
            spikeTimes_obs(observed_spikes) = current_time;
            current_frame = ceil(current_time*handles.sim_pars.freq_ca);
            spikes_observe(current_frame) = spikes_observe(current_frame)+1;
        end
    end
    
    % make list of predicted spike onsets
    predicted_spikes = 0;
    spikeTimes_est = [];
    for n = 1:length(spikes_predict)
        if spikes_predict(n)
            for m = 1:spikes_predict(n)
                predicted_spikes = predicted_spikes + 1;
                spikeTimes_est(predicted_spikes) = time_ca(n);
            end
        end
    end
    
    if doPlot
        spikes_observe_plot = spikes_observe - ...
            (ceil(max(spikes_observe))-floor(min(ephys_bin_plot)));
        oopsi_plot = oopsi - (ceil(max(oopsi))-floor(min(ephys_plot)));
        plot(time_ca,oopsi_plot)
        spikes_predict_plot = spikes_predict - ...
            (ceil(max(spikes_predict))-floor(min(oopsi_plot)));
        plot(time_ca,spikes_predict_plot)
        legend({'DRR' 'DRR2' 'APs' 'Ephys' 'Oopsi' 'APest'});
        yticks = get(gca,'ylim');
        set(gca,'xlim',[0 max(time_ca)],'ytick',yticks(1):yticks(2))
        if SavePlot
            saveas(gcf,[handles.id '.fig'])
        end
    end
    fprintf('Observed spikes: %s\n',int2str(observed_spikes));
    fprintf('Estimated spikes: %s\n',int2str(predicted_spikes));
    
    % compare observed and estimated spike times (AP detection)
    correct = 0;
    missed = 0;
    max_dt = 1;
    total_false = 0;
    dt_vector = [];
    singleAP_vect = zeros(size(spikeTimes_obs));
    if isempty(spikeTimes_est)
        missed = length(spikeTimes_obs);
    else
        dt_mat = zeros(observed_spikes,predicted_spikes);
        for n = 1:observed_spikes
            % determine if spike is single (more than 1 s away from other
            % spikes)
            spikeTimes_obs_diff = abs(spikeTimes_obs - spikeTimes_obs(n));
            if length(find(spikeTimes_obs_diff<=1)) == 1
                singleAP_vect(n) = 99;
            end
            for m = 1:predicted_spikes
                dt_mat(n,m) = abs(spikeTimes_obs(n)-spikeTimes_est(m));
            end
        end
        % find matrix pairs with smallest distance from each other, remove
        % from matrix, iterate until no more pairs with distance <= max_dt
        while true
            if isempty(find(dt_mat<=max_dt, 1))
                break
            end
            [min_val,idx] = min(dt_mat(:));
            correct = correct + 1;
            dt_vector(correct) = min(dt_mat(:));
            [obsSpike,estSpike] = ind2sub(size(dt_mat),idx);
            % is this a single???
            if singleAP_vect(obsSpike) == 99
                singleAP_vect(obsSpike) = dt_vector(correct);
            end
            dt_mat(obsSpike,:) = NaN;
            dt_mat(:,estSpike) = NaN;
        end
        % count the non-NaN rows (missed spikes)
        for n = 1:size(dt_mat,1)
            if sum(isnan(dt_mat(n,:))) < size(dt_mat,2) % not all row members are NaN
                missed = missed + 1;
            end
        end
        % count the non-NaN columns (false positives)
        for n = 1:size(dt_mat,2)
            if sum(isnan(dt_mat(:,n))) < size(dt_mat,1) % not all column members are NaN
                total_false = total_false + 1;
            end
        end
    end
    singleAP_total = length(find(singleAP_vect>0));
    singleAP_missed = length(find(singleAP_vect==99));
    singleAP_correct = singleAP_vect;
    singleAP_correct(singleAP_correct==99) = [];
    singleAP_correct(singleAP_correct==0) = [];
    singleAP_dt = mean(singleAP_correct);
    singleAP_correct = length(singleAP_correct);
    observed_events = correct + missed;
    predicted_events = correct + total_false;
    if strcmp(PlotOutput,'AP')
        A = [observed_events predicted_events correct missed total_false ...
            nanmean(dt_vector) singleAP_total singleAP_missed singleAP_correct ...
            singleAP_dt];
    end
    
    fprintf('Accuracy - AP detection:\n');
    fprintf('Correct detections: %s\n',int2str(correct));
    fprintf('Missed detections: %s\n',int2str(missed));
    fprintf('False detections: %s\n',int2str(total_false));
    fprintf('Mean dt: %s\n',num2str(nanmean(dt_vector)));
    fprintf('1AP\n');
    fprintf('Correct detections: %s\n',int2str(singleAP_correct));
    fprintf('Missed detections: %s\n',int2str(singleAP_missed));
    fprintf('Mean dt: %s\n',num2str(singleAP_dt));
   
    % compare spikes_observe and spikes_predict (event detection)
    frame_jitter = 5;
    observed_events = 0;
    predicted_events = 0;
    correct = 0;
    missed = 0;
    total_false = 0;
    for n = 1:length(spikes_observe)
        if spikes_observe(n)
            observed_events = observed_events + 1;
            if n - frame_jitter > 0 && n + frame_jitter <= length(spikes_observe)
                startSearch = n - frame_jitter;
                stopSearch = n + frame_jitter;
            elseif n - frame_jitter <= 0
                startSearch = 1;
                stopSearch = n + frame_jitter;
            elseif n + frame_jitter > length(spikes_observe)
                startSearch = n - frame_jitter;
                stopSearch = length(spikes_observe);
            end
            if sum(spikes_predict(startSearch:stopSearch))
                correct = correct + 1;
            else
                missed = missed + 1;
            end
        end
    end
    for n = 1:length(spikes_predict)
        if spikes_predict(n)
            predicted_events = predicted_events + 1;
            if n - frame_jitter > 0 && n + frame_jitter <= length(spikes_predict)
                startSearch = n - frame_jitter;
                stopSearch = n + frame_jitter;
            elseif n - frame_jitter <= 0
                startSearch = 1;
                stopSearch = n + frame_jitter;
            elseif n + frame_jitter > length(spikes_predict)
                startSearch = n - frame_jitter;
                stopSearch = length(spikes_observe);
            end
            if ~sum(spikes_observe(startSearch:stopSearch))
                total_false = total_false + 1;
            end
        end
    end
    
    fprintf('Accuracy - Event detection:\n');
    fprintf('Correct detections: %s\n',int2str(correct));
    fprintf('Missed detections: %s\n',int2str(missed));
    fprintf('False detections: %s\n',int2str(total_false));
    if strcmp(PlotOutput,'Event')
        A = [observed_events predicted_events correct missed total_false ...
            nanmean(dt_vector) singleAP_total singleAP_missed singleAP_correct ...
            singleAP_dt];
    end
    
    % Spike time distance (according to J. Victor)
    spikeDist = spkd(spikeTimes_obs,spikeTimes_est,spikeDistCost);
    fprintf('Spike time distance: %s\n',num2str(spikeDist));
else
    A = [];
end

varargout{1} = handles;

if nargout == 2
    varargout{2} = A;
end

%% The end

%% old Evaluation
% bin spikes_observe and spikes_predict for comparison
%     bin = 2;
%     spikes_observe2 = [];
%     spikes_predict2 = [];
%     pos = 1;
%     for n = bin:bin:length(spikes_observe)
%         spikes_observe2(pos) = sum(spikes_observe((n-bin+1):n));
%         spikes_predict2(pos) = sum(spikes_predict((n-bin+1):n));
%         pos = pos + 1;
%     end
%     if n < length(spikes_observe)
%         spikes_observe2(pos) = sum(spikes_observe(n:length(spikes_observe)));
%         spikes_predict2(pos) = sum(spikes_predict(n:length(spikes_predict)));
%     end
%     spikes_observe = spikes_observe2;
%     spikes_predict = spikes_predict2;

%     jitter = 2; % number of frames tolerable for detections

% compare spikes_observe and spikes_predict
%     total_false_count = 0;
%     total_missed_count = 0;
%     total_correct_count = 0;
%     singles_observed = 0;
%     singles_correct = 0;
%     singles_miss = 0;
%     doublets_observed = 0;
%     doublets_correct = 0;
%     doublets_miss = 0;
%     triplets_observed = 0;
%     triplets_correct = 0;
%     triplets_miss = 0;
%     for n = 1:length(spikes_observe)
%         if spikes_observe(n)
%             if spikes_observe(n) == spikes_predict(n) % bingo
%                 total_correct_count = total_correct_count + spikes_observe(n);
%             elseif spikes_observe(n) > spikes_predict(n) % at least 1 miss
%                 if n > jitter && (n + jitter) <= length(spikes_observe)
%                     adjSpikes = sum(spikes_predict(n-jitter:n+jitter));
%                     %                     total_correct_count = total_correct_count + adjSpikes;
%                     if adjSpikes < spikes_observe(n)
%                         total_missed_count = ...
%                             total_missed_count + (spikes_observe(n) - adjSpikes);
%                     end
%                 elseif n < jitter
%                     adjSpikes = sum(spikes_predict(1:n+jitter));
%                     %                     total_correct_count = total_correct_count + adjSpikes;
%                     if adjSpikes < spikes_observe(n)
%                         total_missed_count = ...
%                             total_missed_count + (spikes_observe(n) - adjSpikes);
%                     end
%                 elseif (n + jitter) > length(spikes_observe)
%                     adjSpikes = sum(spikes_predict(n-jitter:length(spikes_predict)));
%                     %                     total_correct_count = total_correct_count + adjSpikes;
%                     if adjSpikes < spikes_observe(n)
%                         total_missed_count = ...
%                             total_missed_count + (spikes_observe(n) - adjSpikes);
%                     end
%                 end
%             else % at least 1 false detection
%                 total_correct_count = total_correct_count + spikes_observe(n);
%                 total_false_count = ...
%                     total_false_count + (spikes_predict(n) - spikes_observe(n));
%             end
%
%             if n > jitter && n+jitter < length(spikes_observe)
%                 if spikes_observe(n) == 1
%                     singles_observed = singles_observed + 1;
%                     if sum(spikes_predict(n-jitter:n+jitter)) >= 1
%                         singles_correct = singles_correct + 1;
%                     else
%                         singles_miss = singles_miss + 1;
%                     end
%                 elseif spikes_observe(n) == 2
%                     doublets_observed = doublets_observed + 1;
%                     if sum(spikes_predict(n-jitter:n+jitter)) >= 2
%                         doublets_correct = doublets_correct + 1;
%                     else
%                         doublets_miss = doublets_miss + 1;
%                     end
%                 elseif spikes_observe(n) == 3
%                     triplets_observed = triplets_observed + 1;
%                     if sum(spikes_predict(n-jitter:n+jitter)) >= 3
%                         triplets_correct = triplets_correct + 1;
%                     else
%                         triplets_miss = triplets_miss + 1;
%                     end
%                 end
%             end
%         else % all detections false
%             total_false_count = total_false_count + spikes_predict(n);
%         end
%     end
%     fprintf('\nSpikes observed (total):\t%s\n',int2str(sum(spikes_observe)));
%     fprintf('Spikes predicted (total):\t%s\n',int2str(sum(spikes_predict)));
%     fprintf('Correct detections (total):\t%s\n',int2str(total_correct_count));
%     fprintf('Missed detections (total):\t%s\n',int2str(total_missed_count));
%     fprintf('False detections (total):\t%s\n',int2str(total_false_count));
%     fprintf('Spikes observed (1AP):\t%s\n',int2str(singles_observed));
%     fprintf('Correct detections (1AP):\t%s\n',int2str(singles_correct));
%     fprintf('Missed detections (1AP):\t%s\n',int2str(singles_miss));
%     fprintf('Spikes observed (2AP):\t%s\n',int2str(doublets_observed));
%     fprintf('Correct detections (2AP):\t%s\n',int2str(doublets_correct));
%     fprintf('Missed detections (2AP):\t%s\n',int2str(doublets_miss));
%     fprintf('Spikes observed (3AP):\t%s\n',int2str(triplets_observed));
%     fprintf('Correct detections (3AP):\t%s\n',int2str(triplets_correct));
%     fprintf('Missed detections (3AP):\t%s\n',int2str(triplets_miss));
%     A = [...
%         sum(spikes_observe) sum(spikes_predict) total_correct_count ...
%         total_missed_count total_false_count singles_observed ...
%         singles_correct singles_miss doublets_observed doublets_correct ...
%         doublets_miss triplets_observed triplets_correct triplets_miss ...
%         ];

