function out = eventDetectAllDataForMouse(animalID)
% run eventDetectpr for all day for an animal

dbgLevel = 3;

%% Get days with spots
year = '2013'; % leave this as a string, not a number
rootPath = 'W:\Neurophysiology\Projects\Auditory\Analysis\AuditoryLearning\';
% rootPath = 'D:\Balazs\';
% rootPath = 'C:\Users\laurenczy.HIFO\Documents\LocalData\';
analysisRootPath = [rootPath year '\' animalID '\'];

o('#eventDetectAllDataForMouse(): animalID = %s.', animalID, 1, dbgLevel);
o('#event...ForMouse(): analysisRootPath = ''%s''.', analysisRootPath, 3, dbgLevel);

% get all days with at least 1 "spot**" folder inside for this mouse
daysWithSpot = getDaysWithSpot(year, rootPath, animalID, 1);
o('#event...ForMouse(): Found %d day(s) with spot for animal %s.', numel(daysWithSpot), animalID, ...
    2, dbgLevel);

o('#event...ForMouse(): %d day(s) to process...', numel(daysWithSpot), 1, dbgLevel);

sendMail = 0; % requires sendGmail and setup

% configuration parameters (these are handed to roiStatsScript)
%% parameters
eventDetectMethod = 'peeling'; % peeling or fast_oopsi
% eventDetectMethod = 'fast_oopsi'; % peeling or fast_oopsi
startDir = pwd;

if sendMail;
    pw = passwordEntryDialog('CheckPasswordLength',false); %#ok<UNRCH>
end;

%% Process each day with spots
out = cell(1, numel(daysWithSpot));
targetDay = 2;
% targetDay = 0;
for iDay = 1 : numel(daysWithSpot);
    
    % only target day
    if targetDay > 0 && (iDay < targetDay || iDay > targetDay); continue; end;
%     if iDay < 3 || iDay > 5; continue; end;
    
    day = daysWithSpot(iDay);
    % list of spots with short name in notebook file
    spotList = day.spotList(:, 1);
    currentDate = day.date;
    
    o('  #event...ForMouse(): processing day %d/%d: ''%s'', %d spot(s)...', iDay, numel(daysWithSpot), ...
        currentDate, numel(spotList), 2, dbgLevel);
    
    % perform analysis in different directory than the raw data directory
    analysisPath = [analysisRootPath currentDate];
    
    try
        
        % go to the appropriate folder so the figure saving is done in the right place
        cd(analysisPath);
            
        % go through each spot
        for iSpot = 1 : numel(spotList);
            
            if iSpot < 3; continue; end;

            o('  #event...ForMouse(): processing day %d/%d ''%s'' - spot %d/%d ...', ...
                iDay, numel(daysWithSpot), currentDate, iSpot, numel(spotList), 3, dbgLevel);
            % extract stuff for the complicated naming system :p
            ROIStatsName = sprintf('RoiStats_BF_%s_RoiStats', spotList{iSpot});
            ROIStatsFileName = sprintf('%s\\%s\\%s.mat', analysisPath, spotList{iSpot}, ROIStatsName);
            matFileContent = load(ROIStatsFileName);
            ROIStats = matFileContent.(ROIStatsName);
            
            % do the actual event detection
            eventDetector(ROIStats, eventDetectMethod);
            
            o('  #event...ForMouse(): processing day %d/%d ''%s'' - spot %d/%d done.', ...
                iDay, numel(daysWithSpot), currentDate, iSpot, numel(spotList), 2, dbgLevel);
            
        end;
        
%         if ~iscell(out{iDay}) && out{iDay} == -1; 
%             error('eventDetectAllDataForMouse:aborted', 'Aborted');
%         end;

        cd(startDir);
        close all;
        body = sprintf('Completed event detect for %s at %s', currentDate, datestr(clock,31));
        if sendMail;
            subj = sprintf('Completed event detect for %s', currentDate); %#ok<UNRCH>
            sendGmail('hluetck@gmail.com',subj,body,pw);
        end;
        o('  #event...ForMouse(): %s', body, 1, dbgLevel);
        o(1, dbgLevel);
        
    catch e;
        body = sprintf('Error during event detect for %s occured at %s', currentDate, datestr(clock,31));
        if sendMail;
            subj = sprintf('Error during event detect for %s', currentDate); %#ok<UNRCH>
            sendGmail('hluetck@gmail.com',subj,body,pw);
        end;
        o('  #event...ForMouse(): %s', body, 1, dbgLevel);
        o(1, dbgLevel);
        cd(startDir);
        rethrow(e);
    end;
    
end;

end
