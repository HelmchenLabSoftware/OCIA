function mov = MovieMaker(bg_image,roi_set,table,varargin)
% bg_image ... tif-file or 2D matrix (for 3d, take mean along dim3)
% roi_set ... ij-file or cell array
% table ... excel file or 2D matrix
% number of Rois in RoiSet equal to number of columns in table

% this file written by Henry Luetcke (hluetck@gmail.com)

if ischar(bg_image)
    bg_image = tif2mat(bg_image,'nosave');
    bg_image = (bg_image.data);
end
% if length(size(bg_image)) == 3
%    bg_image = mean(bg_image,3); 
% end
dims = size(bg_image);
if ischar(roi_set)
    roi_set = ij_roiDecoder(roi_set,[dims(1) dims(2)]);
end
if ischar(table)
    table = xlsread(table);
end

if nargin > 3
    stim_vector = varargin{1};
else
    stim_vector = [];
end

if nargin > 4
   statLim = varargin{2}; 
else
    statLim = [5 20];
end

if nargin > 5
   movieFilename = varargin{3}; 
else
    movieFilename = 'trial1.avi';
end

if nargin > 6
   cmap = varargin{4}; 
else
   cmap = 'jet';
end

% stats = zeros(dims(1),dims(2),size(table,1));
if ~isempty(roi_set)
    threshMap = zeros(dims(1),dims(2));
else
    threshMap = ones(dims(1),dims(2));
end
for n = 1:size(table,2)
    %    mask{n} = bwunpack(roi_set{n,2});
    if ~isempty(roi_set)
        mask{n} = logical(roi_set{n,2});
        threshMap(mask{n}) = 1;
    end
end

mov = zeros(dims(1),dims(2),3,size(table,1));
% table(table<statLim(1)) = statLim(1);
table(table<statLim(1)) = 0;
table(table>statLim(2)) = statLim(2);
table = ScaleToMinMax(table,0,1);

x = zeros(1,size(table,2));
y = zeros(1,size(table,2));
if isempty(roi_set)
    doPixelWise = 1;
else
    doPixelWise = 0;
end
statsAllFrames = zeros(dims(1),dims(2),dims(3));
for n = 1:size(table,1)
    statsFrame = zeros(dims(1),dims(2));
    if doPixelWise
        for roi = 1:size(table,2)
            if n == 1
                [x(roi),y(roi)] = ind2sub([dims(1) dims(2)],roi);
            end
            if ~isnan(table(n,roi)) && table(n,roi)
                statsFrame(x(roi),y(roi)) = table(n,roi);
            end
        end
    else
        for roi = 1:size(table,2)
            if ~isnan(table(n,roi)) && table(n,roi)
                statsFrame(mask{roi}==1) = table(n,roi);
            end
        end
    end
    statsAllFrames(:,:,n) = statsFrame;
end

% kick out small clusters (in 3D)
minPixelPerCluster = 1000;
CC = bwconncomp(statsAllFrames);
for clust = 1:CC.NumObjects
    if numel(CC.PixelIdxList{clust}) < minPixelPerCluster
        statsAllFrames(CC.PixelIdxList{clust}) = 0;
    end
end

for n = 1:size(table,1)
    transMap = statsAllFrames(:,:,n);
    statsFrame = gray2rgb(statsAllFrames(:,:,n),256,cmap,0);
    if n <= dims(3)
        mov(:,:,1:3,n) = transparentOverlay(bg_image(:,:,n),statsFrame,threshMap,...
            transMap,cmap);
    else
        mov(:,:,1:3,n) = transparentOverlay(bg_image(:,:,1),statsFrame,threshMap,...
            transMap,cmap);
    end
end


% bg_image = repmat(bg_image,[1 1 size(stats,3)]);
% clear stats_frame table mask roi_set
% mov = display_image_MakeColorStats2(stats,bg_image,statLim(1),statLim(2),...
%     256,cmap);

% add square in top left indicating stimuli
stim_rgb_code = [1 0 0; 0 0 1; 0 1 0]; % 3 stims must suffice
square_length = 5; % pixels
if ~isempty(stim_vector)
    for n = 1:size(mov,4)
        if stim_vector(n)
           current_rgb = mov(:,:,:,n);
           for x = 1:dims(1)
               for y = 1:square_length
                   current_rgb(x,y,:) = stim_rgb_code(stim_vector(n),:);
               end
           end
           mov(:,:,:,n) = current_rgb;
        end
    end
end

mov(mov<0) = 0; mov(mov>1) = 1; % only because of rounding errors
for n = 1:size(mov,4)
    M(n) = im2frame(mov(:,:,:,n));
end

if isunix
    movie2avi(M,movieFilename,'fps',25);
else
    movie2avi(M,movieFilename,'fps',25,'compression','none');
end