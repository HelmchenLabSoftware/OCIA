function mov = makeFancyMovie(ch1,ch2,roi,stimVector)
% pixel-wise analysis for empty roi set

% this file written by Henry Luetcke (hluetck@gmail.com)

frameRate = 7.81; % acquisition rate

statLim = [3 15];

scaleFactor = 1; % scale image

movieFile = strrep(ch1,'_ch1.tif','_mov.avi');

cmap = 'spring';

ch1 = tiffread2_wrapper(ch1);
ch1 = ch1.data;
ch2 = tiffread2_wrapper(ch2);
ch2 = ch2.data;

% delete first few frames
ch1(:,:,1:3) = [];
ch2(:,:,1:3) = [];
stimVector(1:3) = [];

meanCh1 = mean(ch1,3);
meanCh2 = mean(ch2,3);
h = fspecial('gaussian',5,5);
meanCh1_smooth = imfilter(meanCh1,h);
% meanCh1(meanCh1_smooth<prctile(meanCh1_smooth(:),10)) = NaN;
meanCh1(meanCh1<prctile(meanCh1(:),10)) = NaN;
meanCh2(isnan(meanCh1)) = NaN;

meanCh1_scaled = imresize(meanCh1,scaleFactor);

time = 1/frameRate:1/frameRate:size(ch1,3)/frameRate;
ch1_noSmooth = ch1;
if isempty(roi)
    for t = 1:size(ch1,3)
        ch1(:,:,t) =  imfilter(ch1(:,:,t),h);
        ch2(:,:,t) =  imfilter(ch2(:,:,t),h);
    end
    %     for n = 1:size(ch1,3)
    %        ch1(:,:,n) = PseudoFlatfieldCorrect(ch1(:,:,n),[size(ch1,1) size(ch1,2)]);
    %        ch2(:,:,n) = PseudoFlatfieldCorrect(ch2(:,:,n),[size(ch1,1) size(ch1,2)]);
    %     end
    drrTable = nan(size(ch1,3),numel(meanCh1));
    roiSet_scaled = [];
    for row = 1:size(ch1,1)
        for col = 1:size(ch1,2)
            if isnan(meanCh1(row,col))
                continue
            end
            r(1:size(ch1,3),1) = ch1(row,col,:) ./ ch2(row,col,:);
%             r0 = CalculateF0(r,frameRate);
            r0 = mean(r(5:45));
            drr = (r - r0) ./ r0 .* 100;
            if nanstd(drr) > 12 % exclude very variable pixels
                drr = nan(size(drr));
            else
                % filter drr
                points = 5;
                drr = filtfilt(ones(1,points)/points,1,drr);
            end
            idx = sub2ind([size(ch1,1) size(ch1,2)],row,col);
            drrTable(:,idx) = drr;
        end
    end
else
    roiSet = ij_roiDecoder(roi,[size(ch1,1) size(ch1,2)]);
    roiSet_scaled = roiSet;
    % process Rois
    offset = 0;
    drrTable = zeros(size(ch1,3),size(roiSet,1));
    figure('Name','Roi DRR','NumberTitle','off'), hold all
    for currentRoi = 1:size(roiSet,1)
        currentMask = roiSet{currentRoi,2};
        [row,col] = find(currentMask);
        row_scaled = row * scaleFactor;
        col_scaled = col * scaleFactor;
        %     roiSet{currentRoi,2} = doActiveModelSegment(meanCh1,[row col]);
        roiSet{currentRoi,2} = drawCircleRoi(meanCh1,[row col],3);
        roiSet_scaled{currentRoi,2} = drawCircleRoi(meanCh1_scaled,...
            [row_scaled col_scaled],5);
        roiCh1 = mean(double(GetRoiTimeseries(ch1,roiSet{currentRoi,2})),1);
        roiCh2 = mean(double(GetRoiTimeseries(ch2,roiSet{currentRoi,2})),1);
        r = (roiCh1 ./ roiCh2)';
        %         r0 = CalculateF0(r,frameRate);
        r0 = mean(r(5:45));
        drr = (r - r0) ./ r0 .* 100;
        % filter drr (2-3 frames)
        points = 5;
        drr = filtfilt(ones(1,points)/points,1,drr);
        roiSet{currentRoi,3} = drr;
        plot(time,drr+offset), hold all
        offset = max(drr+offset);
        drrTable(:,currentRoi) = drr;
    end
    set(gca,'xlim',[min(time) max(time)])
end
% mov = MovieMaker(meanCh1_scaled,roiSet_scaled,...
%     drrTable,stimVector,statLim,movieFile,cmap);
mov = MovieMaker(ch1_noSmooth,roiSet_scaled,...
    drrTable,stimVector,statLim,movieFile,cmap);


disp('Done!');

function f0_mat = CalculateF0(roi_mat,f)
t = (1/f:1/f:length(roi_mat)./f)';
p = polyfit(t,roi_mat,2);
f0_mat = p(1).*t.^2 + p(2).*t + p(3);

function mask = drawCircleRoi(img,cog,radius)
t = linspace(0,2*pi,100);
xval = radius*cos(t) + cog(1);
yval = radius*sin(t) + cog(2);
vert = [yval' xval'];
mask = zeros(size(img));
enlarge = 1;
for n = 1:size(vert,1)
    row = vert(n,2); col = vert(n,1);
    row = cog(1) + (row - cog(1));
    if row < enlarge+1
        row = enlarge+1;
    end
    if row > size(img,1)-enlarge
        row = size(img,1)-enlarge;
    end
    col = cog(2) + (col - cog(2));
    if col < enlarge+1
        col = enlarge+1;
    end
    if col > size(img,2)-enlarge
        col = size(img,2)-enlarge;
    end
    for x = round(row)-enlarge:round(row)+enlarge
        for y = round(col)-enlarge:round(col)+enlarge
            mask(x,y) = 1;
        end
    end
end
mask = imfill(mask,'holes');

%% Active model segmentation
function roi = doActiveModelSegment(img,cog)
options.cog = cog;
options.cellsize = 7;
options.snake_iter1 = 100;
options.snake_iter = 10;
options.alpha = 1;
options.beta = 0;
options.tau = 0.1;
options.filt_range = [3 3];
options.filt_order = 1;
options.canny_lo = [0.1];
options.canny_hi = [0.25];
options.alt_radius = 2;
options.doPlot = 0;
options.enlarge = 1;
options.erode = 0;
try
    roi = ActiveModel_segment(img,options);
    
catch
    roi = zeros(size(img,1),size(img,2));
    rethrow(lasterror);
end