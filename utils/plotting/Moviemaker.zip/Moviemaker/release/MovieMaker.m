function mov = MovieMaker(bg_image,roi_set,table)
% number of Rois in RoiSet equal to number of columns in table

% this file written by Henry Luetcke (hluetck@gmail.com)

bg_image = tif2mat(bg_image,'nosave');
bg_image = (bg_image.data);
dims = size(bg_image);
roi_set = ij_roiDecoder(roi_set,dims);
table = xlsread(table);

stats = zeros(dims(1),dims(2),size(table,1));

for n = 1:size(table,2)
   mask{n} = bwunpack(roi_set{n,2});
end

for n = 1:size(table,1)
    stats_frame = zeros(dims);
    for roi = 1:size(table,2)
        if table(n,roi)
            stats_frame(mask{roi}==1) = table(n,roi);
        end
    end
    stats(:,:,n) = stats_frame;
end
bg_image = repmat(bg_image,[1 1 size(stats,3)]);
clear stats_frame table mask roi_set
mov = display_image_MakeColorStats2(stats,bg_image,0,2,256,'hot');


for n = 1:size(mov,4)
    M(n) = im2frame(mov(:,:,:,n));
end

movie2avi(M,'test.avi','fps',20);