function transRGB = transparentOverlay(img,statsMap,threshMap,trans,cmap)
% img ... 2D grayscale
% statsMap ... 2D grayscale (0 ... 1)
% threshMap ... threshold map (0 pixels are not transparent)
% trans ... transparency factor (1-transparency for alpha data)
% cmap ... colormap (for stats image)

% this file written by Henry Luetcke (hluetck@gmail.com)

% if numel(trans) > 1
%     trans = ScaleToMinMax(trans,0,1);
% end
% trans = 1 - trans;

imgRGB = gray2rgb(img,256,'gray');

if numel(size(statsMap)) < 3
    statsRGB = gray2rgb(statsMap,256,cmap);
else
    statsRGB = statsMap;
end

for rgbDim = 1:3
    transRGB(:,:,rgbDim) = (threshMap==0) .* imgRGB(:,:,rgbDim) + ...
        (threshMap>0).* ( (1-trans) .* imgRGB(:,:,rgbDim) + ...
        (trans) .* statsRGB(:,:,rgbDim) );
end
