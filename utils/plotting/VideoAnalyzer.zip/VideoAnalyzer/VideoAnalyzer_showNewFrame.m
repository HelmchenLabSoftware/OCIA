function handles = VideoAnalyzer_showNewFrame(handles)
% update the axis_movie axis with current frame

set(handles.videoAnalyzer,'CurrentAxes',handles.axis_movie);
imshow(handles.storage.movie(:,:,handles.storage.currentFrame),[]);

set(handles.slider_frames,'Value',handles.storage.currentFrame);
set(handles.currentFrame_edit,'String',num2str(handles.storage.currentFrame));

currentTime = num2str(handles.storage.currentFrame/handles.storage.fps-...
    1/handles.storage.fps,3);

set(handles.currentTime_edit,'String',currentTime);