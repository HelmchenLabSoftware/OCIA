function varargout = VideoAnalyzer(varargin)
% VIDEOANALYZER M-file for VideoAnalyzer.fig
%      VIDEOANALYZER, by itself, creates a new VIDEOANALYZER or raises the existing
%      singleton*.
%
%      H = VIDEOANALYZER returns the handle to a new VIDEOANALYZER or the handle to
%      the existing singleton*.
%
%      VIDEOANALYZER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VIDEOANALYZER.M with the given input arguments.
%
%      VIDEOANALYZER('Property','Value',...) creates a new VIDEOANALYZER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before VideoAnalyzer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to VideoAnalyzer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help VideoAnalyzer

% Last Modified by GUIDE v2.5 16-Nov-2009 22:10:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @VideoAnalyzer_OpeningFcn, ...
                   'gui_OutputFcn',  @VideoAnalyzer_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VideoAnalyzer is made visible.
function VideoAnalyzer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to VideoAnalyzer (see VARARGIN)

% Choose default command line output for VideoAnalyzer
handles.output = hObject;

% handles.storage.fps = 60;
handles.storage.fps = str2double(get(handles.edit_fps,'String'));

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes VideoAnalyzer wait for user response (see UIRESUME)
% uiwait(handles.videoAnalyzer);


% --- Outputs from this function are returned to the command line.
function varargout = VideoAnalyzer_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

setWindowState(gcf,'maximize');




% --- Executes on slider movement.
function slider_frames_Callback(hObject, eventdata, handles)
% hObject    handle to slider_frames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
handles.storage.currentFrame = round(get(hObject,'Value'));
handles = VideoAnalyzer_showNewFrame(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider_frames_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_frames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function currentFrame_edit_Callback(hObject, eventdata, handles)
% hObject    handle to currentFrame_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of currentFrame_edit as text
%        str2double(get(hObject,'String')) returns contents of currentFrame_edit as a double
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
handles.storage.currentFrame = str2double(get(hObject,'String'));
handles = VideoAnalyzer_showNewFrame(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function currentFrame_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function currentTime_edit_Callback(hObject, eventdata, handles)
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
currentTime = str2double(get(hObject,'String'));
handles.storage.currentFrame = round(currentTime*handles.storage.fps);
handles = VideoAnalyzer_showNewFrame(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function currentTime_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_PlayStop.
function button_PlayStop_Callback(hObject, eventdata, handles)
% hObject    handle to button_PlayStop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp(get(hObject,'String'),'Play')
    set(hObject,'String','Stop');
    loop = 1;
    while true
        if loop
            loop = 0;
            for n = handles.storage.currentFrame:size(handles.storage.movie,3)
                handles.storage.currentFrame = n;
                handles = VideoAnalyzer_showNewFrame(handles);
                refresh
                pause(0.05);
                if strcmp(get(hObject,'String'),'Play')
                    break
                end
            end
            if strcmp(get(hObject,'String'),'Play')
                break
            end
        else
            for n = 1:size(handles.storage.movie,3)
                handles.storage.currentFrame = n;
                handles = VideoAnalyzer_showNewFrame(handles);
                refresh
                pause(0.05);
                if strcmp(get(hObject,'String'),'Play')
                    break
                end
            end
            if strcmp(get(hObject,'String'),'Play')
                break
            end
        end
    end
else
    set(hObject,'String','Play');
end
guidata(hObject, handles);


function edit_fps_Callback(hObject, eventdata, handles)
handles.storage.fps = str2double(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit_fps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_fps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton05.
function radiobutton05_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton05 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton05
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
time = (handles.storage.currentFrame/handles.storage.fps)-(1/handles.storage.fps);
handles.storage.table(handles.storage.table(:,1)==time,:) = [];
handles.storage.table(size(handles.storage.table,1)+1,1) = time;
handles.storage.table(size(handles.storage.table,1),2) = 5;
handles.storage.table
guidata(hObject,handles);


% --- Executes on button press in radiobutton04.
function radiobutton04_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton04 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton04
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
time = (handles.storage.currentFrame/handles.storage.fps)-(1/handles.storage.fps);
handles.storage.table(handles.storage.table(:,1)==time,:) = [];
handles.storage.table(size(handles.storage.table,1)+1,1) = time;
handles.storage.table(size(handles.storage.table,1),2) = 4;
handles.storage.table
guidata(hObject,handles);


% --- Executes on button press in radiobutton03.
function radiobutton03_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton03 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton03
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
time = (handles.storage.currentFrame/handles.storage.fps)-(1/handles.storage.fps);
handles.storage.table(handles.storage.table(:,1)==time,:) = [];
handles.storage.table(size(handles.storage.table,1)+1,1) = time;
handles.storage.table(size(handles.storage.table,1),2) = 3;
handles.storage.table
guidata(hObject,handles);


% --- Executes on button press in radiobutton02.
function radiobutton02_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton02 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton02
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
time = (handles.storage.currentFrame/handles.storage.fps)-(1/handles.storage.fps);
handles.storage.table(handles.storage.table(:,1)==time,:) = [];
handles.storage.table(size(handles.storage.table,1)+1,1) = time;
handles.storage.table(size(handles.storage.table,1),2) = 2;
handles.storage.table
guidata(hObject,handles);


% --- Executes on button press in radiobutton01.
function radiobutton01_Callback(hObject, eventdata, handles)
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
time = (handles.storage.currentFrame/handles.storage.fps)-(1/handles.storage.fps);
handles.storage.table(handles.storage.table(:,1)==time,:) = [];
handles.storage.table(size(handles.storage.table,1)+1,1) = time;
handles.storage.table(size(handles.storage.table,1),2) = 1;
handles.storage.table
guidata(hObject,handles);


% --------------------------------------------------------------------
function file_menu_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function tools_menu_Callback(hObject, eventdata, handles)
% hObject    handle to tools_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function tools_PlotTable_menu_Callback(hObject, eventdata, handles)
% hObject    handle to tools_PlotTable_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function file_OpenMovie_menu_Callback(hObject, eventdata, handles)
[FileName,PathName,FilterIdx] = uigetfile({'*.mat';'*.avi'},'Select movie file');

if ~FileName
    return
end
% load the movie file or variable
if FilterIdx == 1
    try
        handles.storage.movie = load(fullfile(PathName,FileName));
        fields = fieldnames(handles.storage.movie);
        handles.storage.movie = handles.storage.movie.(fields{1});
    catch
        rethrow(lasterror);
        fprintf('\nCould not load mat-file. Memory problem?\n');
    end
elseif FilterIdx == 2
    try
        handles.storage.movie = video2mat(fullfile(PathName,FileName));
    catch
        rethrow(lasterror);
        fprintf('\nCould not open avi-file. Memory or codec problem?\n');
    end
end

handles.storage.currentFrame = 1;

% update GUI
max_frame_text = sprintf(' / %2.0f',size(handles.storage.movie,3));
set(handles.maxFrame_text,'String',max_frame_text);
max_time_text = sprintf(' / %2.0f s',...
    size(handles.storage.movie,3)/handles.storage.fps);
set(handles.maxTime_text,'String',max_time_text);
set(handles.slider_frames,'Min',1);
set(handles.slider_frames,'Max',size(handles.storage.movie,3));
set(handles.slider_frames,'SliderStep',...
    [1/(size(handles.storage.movie,3)-1) 10/(size(handles.storage.movie,3)-1)]);
% show first frame
handles = VideoAnalyzer_showNewFrame(handles);
% initialize table (stores time in s in col 1 and category in column 2)
handles.storage.table = [0 1];
guidata(hObject, handles);


% --------------------------------------------------------------------
function file_OpenTable_menu_Callback(hObject, eventdata, handles)
% hObject    handle to file_OpenTable_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function file_SaveTable_menu_Callback(hObject, eventdata, handles)
% hObject    handle to file_SaveTable_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isfield(handles,'storage') || ~isfield(handles.storage,'movie')
    return
end
[sorted,index] = sort(handles.storage.table(:,1));
sorted2 = zeros(size(handles.storage.table));
for n = 1:size(sorted,1)
    sorted2(n,:) = handles.storage.table(index(n),:); 
end
sorted2

[FileName,PathName,FilterIdx] = uiputfile({'*.mat';'*.txt';'*.xls'},'Select file for writing');
if ~FileName
    return
end

switch FilterIdx
    case 1
        SaveAndAssignInBase(sorted2,fullfile(PathName,FileName));
    case 2
        fid = fopen(fullfile(PathName,FileName),'w');
        for n = 1:size(sorted2,1)
            fprintf(fid,'%1.4f\t%1.0f\n',sorted2(n,1),sorted2(n,2));
        end
        fclose(fid);
    case 3
        xlswrite(fullfile(PathName,FileName),sorted2);
end


% --------------------------------------------------------------------
function file_quit_menu_Callback(hObject, eventdata, handles)
% destroys the figure
close(handles.videoAnalyzer);




